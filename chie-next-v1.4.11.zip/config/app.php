<?php

return [
    'name' => env('APP_NAME', 'CHIE NEXT'),
    'env' => env('APP_ENV', 'production'),
    'debug' => (bool) env('APP_DEBUG', false),
    // Để trống: URL được suy ra từ request (chạy được ở tên miền gốc hoặc thư mục /chie).
    'url' => env('APP_URL', 'http://localhost'),
    'timezone' => env('APP_TIMEZONE', 'Asia/Ho_Chi_Minh'),
    'locale' => 'vi',
    'fallback_locale' => 'vi',
    'faker_locale' => 'vi_VN',
    'cipher' => 'AES-256-CBC',
    'key' => env('APP_KEY'),
    'previous_keys' => [],
    'maintenance' => ['driver' => 'file'],
];
