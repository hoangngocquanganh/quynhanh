<?php

use Monolog\Handler\StreamHandler;

return [
    'default' => env('LOG_CHANNEL', 'daily'),
    'deprecations' => ['channel' => 'null', 'trace' => false],
    'channels' => [
        'daily' => [
            'driver' => 'daily',
            'path' => storage_path('logs/chie.log'),
            'level' => env('LOG_LEVEL', 'warning'),
            'days' => 14,
            'replace_placeholders' => true,
        ],
        'single' => ['driver' => 'single', 'path' => storage_path('logs/chie.log'), 'level' => env('LOG_LEVEL', 'debug')],
        'stderr' => ['driver' => 'monolog', 'handler' => StreamHandler::class, 'with' => ['stream' => 'php://stderr']],
        'null' => ['driver' => 'monolog', 'handler' => Monolog\Handler\NullHandler::class],
    ],
];
