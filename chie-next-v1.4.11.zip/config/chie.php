<?php

/**
 * Cấu hình nền của CHIE NEXT. Phần lớn thông số nghiệp vụ (giá, tỉ lệ, cap)
 * nằm trong bảng `settings` và chỉnh trong Admin; đây chỉ là giá trị mặc định ban đầu.
 */
return [
    'version' => '1.4.11',
    'install_lock' => storage_path('installed.lock'),
    'install_token_file' => storage_path('app/install-token.txt'),
    'tts' => ['default_rate' => 0.75, 'slow_rate' => 0.65, 'rates' => [0.65, 0.75, 0.9, 1.0]],
];
