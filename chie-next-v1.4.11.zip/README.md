# Bản 1.3.3 — Học theo sticker, đổi lớp trong Hồ sơ

- **Album sticker**: 17 gói, 223 sticker từ vựng theo chủ đề Việt Nam (Tết, Trung thu, món ngon, chợ, giao thông, lễ hội, thành ngữ…), chia theo lớp 1–12. Có bóc sticker, nghe & chọn hình, ôn sticker sai, hạng đồng/bạc/vàng. Xem [docs/HOC_THEO_STICKER.md](docs/HOC_THEO_STICKER.md).
- **Hồ sơ → Đổi lớp học** cho học sinh, phụ huynh, giáo viên, Admin.
- Thẻ Luyện đề mới; lỗi API hiện mã tra cứu (Admin thấy nguyên nhân).
- Lệnh `php artisan chie:release X.Y.Z` để đóng gói từ máy và cập nhật một chạm lên hosting.

# Bản 1.3.2 — Giao diện "Mạ non", Admin toàn quyền, tạm ẩn trò chơi

- Sửa lỗi trên hosting trả số dạng chữ: bài học 404, Luyện đề lỗi máy chủ, Word Runner báo lỗi liên tục.
- Admin dùng được mọi trang học sinh/giáo viên/phụ huynh; menu có "Khu học tập" và mục "Quản trị" để quay lại.
- Trò chơi mặc định ẩn: Admin → Game Studio → Hiện trò chơi. Link trực tiếp vẫn chơi thử được.
- Giao diện mới kiểu Duolingo thân thiện với người Việt, có chế độ tối và bố cục điện thoại.
Chi tiết: [docs/CHUA_LAM_DUOC_ZOO_GARDEN.md](docs/CHUA_LAM_DUOC_ZOO_GARDEN.md) mục 0.

# Bản 1.3.0 — Nông trại 3D Zoo Garden + Module hóa

Game nông trại 3D **Zoo Garden** chạy tại `/nong-trai` (dùng chung tài khoản, lưu MySQL, đổi Xu → Năng lượng ϟ, đố Tiếng Anh ưu tiên Sổ lỗi, giới hạn phút chơi, thống kê cho phụ huynh, Admin → Quản lý Zoo Garden 3D). Game và học liệu từng lớp tách thành module trong `modules/`.
- Cài lên hosting: [docs/HUONG_DAN_CAI_LEN_HOSTING.md](docs/HUONG_DAN_CAI_LEN_HOSTING.md)
- Tính năng & kỹ thuật: [docs/ZOO_GARDEN_V1_3.md](docs/ZOO_GARDEN_V1_3.md)
- Tình trạng / giới hạn: [docs/CHUA_LAM_DUOC_ZOO_GARDEN.md](docs/CHUA_LAM_DUOC_ZOO_GARDEN.md)
- Việc cần Node.js để làm sau (Online, build lại game): [docs/NODE_ONLINE_ZOO_GARDEN.md](docs/NODE_ONLINE_ZOO_GARDEN.md)

# Bản 1.2.0 — Thị trấn Mầm Xanh 3D

Hướng dẫn thay đổi, triển khai và giới hạn kiểm thử: [docs/MAM_XANH_3D_V1_2.md](docs/MAM_XANH_3D_V1_2.md). Các báo cáo kiểm thử cũ bên dưới chỉ áp dụng cho bản trước.

# CHIE NEXT 1.1.0

Nền tảng học tiếng Anh cho học sinh Việt Nam (lớp 1–12): học theo lộ trình, ôn tập theo lịch, luyện đề, game học tập, nông trại học từ — với tài khoản Học sinh, Phụ huynh, Giáo viên và Admin.

- Giao diện tiếng Việt, nội dung luyện tập tiếng Anh.
- Laravel 11 · PHP 8.2+ · MySQL/MariaDB · chạy trên cPanel ở tên miền gốc hoặc thư mục con.
- Không cần Node/npm/Composer trên hosting.

### Mới trong 1.1

- **4 game học 3D** (Word Runner, Grammar Tower, Voice Island, Reading Escape), bản đồ thế giới 3D và nông trại 3D — tự chọn mức đồ họa theo máy, có chế độ 2D tiết kiệm pin; máy không hỗ trợ WebGL tự dùng 2D.
- **Đấu 1–1** (ghép nhanh, thách bạn cùng lớp/người nhà, hoặc đấu với máy), **Đội trong lớp** với điểm tuần, **Thử thách gia đình** (bố mẹ và con làm cùng bộ câu rồi so kết quả).
- Nông trại: **vật nuôi** (gà, cừu, bò — trả lời câu tiếng Anh để cho ăn), món mới dùng trứng/sữa.
- **Cài lên màn hình chính (PWA)** và gói ôn thẻ từ ngoại tuyến.
- **Cập nhật một chạm** trong Admin (kiểm tra SHA-256 từng tệp, sao lưu, tự khôi phục, hoàn tác) và nút cập nhật CSDL không cần Terminal.

## Bắt đầu

Đọc `docs/HUONG_DAN_CAI_DAT.md`. Tóm tắt: giải nén vào `public_html` (hoặc `public_html/chie`), tạo CSDL trống, mở website, nhập mã trong `storage/app/install-token.txt`, điền thông tin CSDL và Admin đầu tiên.

## Tài liệu

| Tệp | Nội dung |
|---|---|
| `docs/HUONG_DAN_CAI_DAT.md` | Cài đặt, cập nhật, SMTP, khắc phục sự cố |
| `docs/BANG_CHUC_NANG.md` | Trạng thái từng chức năng, giới hạn, cách giải quyết mâu thuẫn tài liệu |
| `docs/MA_TRAN_QUYEN.md` | Ai được làm gì, cách xác minh quan hệ, chống lạm dụng |
| `docs/BAO_CAO_NHAP_DU_LIEU.md` | Học liệu nhập từ bản cũ, phần bị loại, gói chuyên đề mới |
| `docs/KET_QUA_KIEM_THU.md` | Đã kiểm thử gì, kết quả, chưa kiểm thử gì |

## Lệnh hữu ích (nếu hosting có Terminal)

```
php artisan chie:import --dry                # chạy thử nhập tất cả gói học liệu trong database/content
php artisan chie:import ten_goi.json         # nhập một gói
php artisan chie:create-admin email@ví-dụ.vn # tạo thêm Admin (nhập mật khẩu ẩn)
php artisan migrate --force                  # cập nhật cấu trúc CSDL khi nâng cấp
```

## Bản quyền thành phần

Phông Be Vietnam Pro và Noto Sans (SIL Open Font License, xem `assets/fonts/`), biểu tượng Lucide (ISC, `assets/img/LICENSE-lucide.txt`), three.js r160 (MIT, `assets/vendor/three/LICENSE`), Laravel và các thư viện trong `vendor/` theo giấy phép riêng của từng gói. Học liệu chưa được Bộ GD&ĐT thẩm định hay chứng nhận.
