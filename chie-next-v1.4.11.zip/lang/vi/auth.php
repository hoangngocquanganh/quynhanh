<?php

return [
    'failed' => 'Email/tên đăng nhập hoặc mật khẩu chưa đúng.',
    'password' => 'Mật khẩu chưa đúng.',
    'throttle' => 'Bạn thử quá nhiều lần. Vui lòng thử lại sau :seconds giây.',
];
