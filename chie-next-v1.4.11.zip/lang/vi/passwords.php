<?php

return [
    'reset' => 'Mật khẩu đã được đặt lại.',
    'sent' => 'Nếu email có trong hệ thống, hướng dẫn đặt lại mật khẩu đã được gửi.',
    'throttled' => 'Vui lòng chờ một lúc trước khi thử lại.',
    'token' => 'Liên kết đặt lại mật khẩu không hợp lệ hoặc đã hết hạn.',
    'user' => 'Nếu email có trong hệ thống, hướng dẫn đặt lại mật khẩu đã được gửi.',
];
