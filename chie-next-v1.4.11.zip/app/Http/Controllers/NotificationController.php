<?php

namespace App\Http\Controllers;

use App\Models\InboxNotification;
use Illuminate\Http\Request;

class NotificationController extends Controller
{
    public function index(Request $r)
    {
        $items = InboxNotification::where('user_id', $r->user()->id)->orderByDesc('id')->paginate(20);
        return view('profile.notifications', ['items' => $items]);
    }

    public function readAll(Request $r)
    {
        InboxNotification::where('user_id', $r->user()->id)->whereNull('read_at')->update(['read_at' => now()]);
        return back()->with('success', 'Đã đánh dấu tất cả là đã đọc.');
    }
}
