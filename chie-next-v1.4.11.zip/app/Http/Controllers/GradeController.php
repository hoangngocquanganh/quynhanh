<?php

namespace App\Http\Controllers;

use App\Models\ClassroomMember;
use App\Models\Grade;
use App\Support\Audit;
use App\Support\Settings;
use Illuminate\Http\Request;

/**
 * Chọn lớp (khách) / Lớp học của tôi (học sinh).
 * - Khối học liệu (grade_level) ≠ lớp học do giáo viên quản lý (classroom).
 * - Đổi khối học liệu KHÔNG chuyển học sinh sang lớp của giáo viên khác; tiến độ mỗi lớp lưu riêng.
 */
class GradeController extends Controller
{
    public function pick(Request $r)
    {
        $u = $r->user();
        // v1.3.1: Admin / giáo viên cũng chọn lớp để dùng thử khu học tập (lưu cookie, không đổi tài khoản)
        $grades = Grade::orderBy('id')->get();
        $ready = \App\Services\Curriculum::readinessAll();
        return view('guest.grade-pick', ['grades' => $grades, 'ready' => $ready, 'next' => $r->query('next'), 'current' => current_grade()]);
    }

    public function choose(Request $r)
    {
        $data = $r->validate(['grade' => 'required|integer|min:1|max:12', 'next' => 'nullable|string|max:300']);
        $g = (int) $data['grade'];
        $next = $this->safeNext($data['next'] ?? null) ?: route('learn.home');
        $u = $r->user();
        if ($u && $u->isStudent()) {
            // Học sinh chưa có lớp (onboarding) → lưu vào DB. Đã có lớp → dùng trang "Lớp học của tôi".
            if ($u->grade_level) return redirect()->route('grade.mine');
            $u->grade_level = $g; $u->grade_changed_at = now(); $u->save();
            Audit::log('student.grade_set', $u, null, ['grade_level' => $g]);
            return redirect($next)->with('success', 'Đã chọn ' . grade_name($g) . '. Bắt đầu học thôi!');
        }
        if ($u && $u->isParent()) {
            $s = $u->settings ?? []; $s['self_grade'] = $g; $u->settings = $s; $u->save();
            return redirect($next);
        }
        session(['guest_grade' => $g]);
        return redirect($next)->withCookie(cookie('chie_grade', (string) $g, 60 * 24 * 365));
    }

    public function mine(Request $r)
    {
        $u = $r->user();
        $memberships = ClassroomMember::with(['classroom.teachers'])->where('student_id', $u->id)->whereIn('status', ['active', 'pending'])->get();
        $cooldown = (int) Settings::get('auth.grade_change_cooldown_days', 0);
        $nextChange = ($cooldown && $u->grade_changed_at) ? $u->grade_changed_at->copy()->addDays($cooldown) : null;
        return view('student.my-class', [
            'grades' => Grade::orderBy('id')->get(), 'memberships' => $memberships,
            'nextChange' => $nextChange && $nextChange->isFuture() ? $nextChange : null,
            'ready' => \App\Services\Curriculum::readinessAll(),
        ]);
    }

    public function change(Request $r)
    {
        $u = $r->user();
        $data = $r->validate(['grade' => 'required|integer|min:1|max:12']);
        $g = (int) $data['grade'];
        if ($g === (int) $u->grade_level) return back()->with('info', 'Bạn đang học ' . grade_name($g) . '.');
        $cooldown = (int) Settings::get('auth.grade_change_cooldown_days', 0);
        if ($cooldown && $u->grade_changed_at && $u->grade_changed_at->copy()->addDays($cooldown)->isFuture()) {
            return back()->with('error', 'Bạn vừa đổi lớp gần đây. Có thể đổi lại sau ' . $u->grade_changed_at->copy()->addDays($cooldown)->format('d/m/Y') . '.');
        }
        $old = $u->grade_level;
        $u->grade_level = $g; $u->grade_changed_at = now(); $u->save();
        Audit::log('student.grade_changed', $u, ['grade_level' => $old], ['grade_level' => $g]);
        return redirect()->route('learn.home')->with('success', 'Đã chuyển sang học liệu ' . grade_name($g) . '. Tiến độ ' . grade_name($old) . ' vẫn được giữ nguyên.');
    }

    protected function safeNext(?string $next): ?string
    {
        return safe_next($next);
    }
}
