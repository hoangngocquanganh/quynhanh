<?php

namespace App\Http\Controllers;

use App\Models\InventoryItem;
use App\Models\TradeOffer;
use App\Services\FarmService;
use App\Services\TradeService;
use App\Support\Audit;
use Illuminate\Http\Request;

class TradeController extends Controller
{
    public function index(Request $r)
    {
        $u = $r->user();
        $partners = TradeService::partners($u);
        $pid = (int) $r->query('ban');
        $partner = $partners->firstWhere('user.id', $pid);
        $theirItems = $partner ? TradeService::tradeable($partner['user']) : collect();
        $theirProduce = $partner && $partner['family'] ? FarmService::storage($partner['user']->id) : null;
        $offers = TradeOffer::with(['sender', 'receiver', 'senderItem.item', 'receiverItem.item'])->where(fn ($q) => $q->where('sender_id', $u->id)->orWhere('receiver_id', $u->id))
            ->latest('id')->limit(20)->get();
        return view('shop.trade', ['partners' => $partners, 'partner' => $partner, 'mine' => TradeService::tradeable($u), 'theirItems' => $theirItems,
            'myProduce' => FarmService::storage($u->id), 'theirProduce' => $theirProduce, 'offers' => $offers]);
    }

    public function create(Request $r)
    {
        $d = $r->validate(['partner_id' => 'required|integer', 'kind' => 'required|in:decor,produce', 'my_item' => 'nullable|integer', 'their_item' => 'nullable|integer',
            'my_produce' => 'nullable|string|max:40', 'their_produce' => 'nullable|string|max:40']);
        $o = TradeService::create($r->user(), (int) $d['partner_id'], $d['kind'], $d['my_item'] ?? null, $d['their_item'] ?? null, $d['my_produce'] ?? null, $d['their_produce'] ?? null);
        Audit::log('trade.offered', $o);
        \App\Services\Notifier::send($o->receiver_id, 'trade', $r->user()->name . ' muốn đổi đồ với bạn', null, route('trade.index'));
        return back()->with('success', 'Đã gửi lời mời đổi đồ.');
    }

    public function respond(Request $r, TradeOffer $offer, string $action)
    {
        $msg = TradeService::respond($r->user(), $offer, $action);
        Audit::log('trade.' . $action, $offer);
        return back()->with('success', $msg);
    }
}
