<?php

namespace App\Http\Controllers;

use App\Services\SelfStudy;
use Illuminate\Http\Request;

/** Menu Tự học: nhiệm vụ hôm nay + toàn bộ lộ trình của lớp theo đúng thứ tự. */
class SelfStudyController extends Controller
{
    public function index(Request $r)
    {
        $g = current_grade();
        if (!$g) return redirect()->route('grade.pick', ['next' => $r->getRequestUri()]);
        return view('learn.self-study', ['grade' => $g] + SelfStudy::build($r->user(), $g));
    }

    /** Đánh dấu đã học xong một bước chỉ có lý thuyết (ngữ pháp chưa có câu luyện đã duyệt). */
    public function mark(Request $r)
    {
        $data = $r->validate(['key' => 'required|string|max:60|starts_with:g:']);
        $u = $r->user();
        $done = array_values(array_unique(array_merge((array) $u->setting('selfstudy_done', []), [$data['key']])));
        $u->settings = array_merge($u->settings ?? [], ['selfstudy_done' => array_slice($done, -300)]);
        $u->save();
        return back()->with('success', 'Đã đánh dấu học xong. Tiếp tục bước sau nhé!');
    }
}
