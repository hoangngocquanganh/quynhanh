<?php

namespace App\Http\Controllers;

use App\Models\Assignment;
use App\Models\AssignmentSubmission;
use App\Models\Attempt;
use App\Models\Question;
use App\Services\AttemptService;
use App\Services\DomainError;
use App\Services\Grader;
use App\Services\Notifier;
use App\Services\QuestionPicker;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class StudentAssignmentController extends Controller
{
    /** Bài giao mà học sinh này được phép thấy (lớp đang tham gia + đúng đối tượng). */
    public static function visibleQuery(int $studentId)
    {
        $classIds = DB::table('classroom_members')->where('student_id', $studentId)->where('status', 'active')->pluck('classroom_id');
        return Assignment::whereIn('classroom_id', $classIds)
            ->where(fn ($q) => $q->whereNull('available_from')->orWhere('available_from', '<=', now()))
            ->where(fn ($q) => $q->where('target', 'class')->orWhereExists(fn ($e) => $e->from('assignment_targets')
                ->whereColumn('assignment_targets.assignment_id', 'assignments.id')->where('student_id', $studentId)));
    }

    protected function findVisible(Request $r, int $id): Assignment
    {
        $a = static::visibleQuery($r->user()->id)->with(['classroom', 'teacher', 'lesson', 'blueprint'])->find($id);
        abort_unless($a, 404);
        return $a;
    }

    public function index(Request $r)
    {
        $u = $r->user();
        $items = static::visibleQuery($u->id)->with('classroom')->orderByRaw('due_at IS NULL')->orderBy('due_at')->orderByDesc('id')->get();
        $subs = AssignmentSubmission::where('student_id', $u->id)->whereIn('assignment_id', $items->pluck('id'))->get()->keyBy('assignment_id');
        return view('student.assignments', ['items' => $items, 'subs' => $subs]);
    }

    public function show(Request $r, int $assignment)
    {
        $a = $this->findVisible($r, $assignment);
        $sub = AssignmentSubmission::where('assignment_id', $a->id)->where('student_id', $r->user()->id)->first();
        $open = Attempt::where('user_id', $r->user()->id)->where('assignment_id', $a->id)->where('status', 'in_progress')->latest('id')->first();
        return view('student.assignment', ['a' => $a, 'sub' => $sub, 'open' => $open]);
    }

    public function start(Request $r, int $assignment)
    {
        $a = $this->findVisible($r, $assignment);
        $u = $r->user();
        if ($a->status !== 'published') throw new DomainError('Bài này đã đóng, không làm thêm được.');
        $open = Attempt::where('user_id', $u->id)->where('assignment_id', $a->id)->where('status', 'in_progress')->latest('id')->first();
        if ($open && AttemptService::expireIfNeeded($open)->status === 'in_progress') return redirect()->route('attempt.show', $open);
        $g = (int) $a->classroom->grade_level;
        $opts = ['title' => $a->title, 'assignment_id' => $a->id, 'feedback' => 'immediate', 'meta' => ['mode' => 'assignment']];
        if ($a->type === 'lesson' && $a->lesson) {
            $qs = collect(Grader::shuffle($a->lesson->questions()->where('status', 'published')->get()->all()));
            $opts['guided_count'] = min(4, (int) ceil($qs->count() * 0.4));
        } elseif ($a->type === 'practice') {
            $qs = collect(Grader::shuffle(Question::whereIn('id', $a->question_ids ?? [])->where('status', 'published')->get()->all()));
        } elseif ($a->type === 'exam' && $a->blueprint) {
            $qs = QuestionPicker::pick($g, $a->blueprint->question_count, $u->id, $a->blueprint->skill_mix ?? []);
            $opts['feedback'] = 'after_submit';
            $opts['duration_min'] = $a->blueprint->duration_min;
            $opts['meta']['shareable'] = true;
        } else {
            throw new DomainError('Bài này nộp bằng cách viết/ghi nhận trực tiếp trên trang bài giao.');
        }
        if ($qs->isEmpty()) throw new DomainError('Bài giao chưa có câu hỏi đã duyệt. Hãy báo giáo viên.');
        $attempt = AttemptService::create($u, 'assignment', 'assignment', $a->id, $g, $qs, $opts);
        AssignmentSubmission::firstOrCreate(['assignment_id' => $a->id, 'student_id' => $u->id], ['status' => 'in_progress', 'attempt_id' => $attempt->id]);
        return redirect()->route('attempt.show', $attempt);
    }

    /** Bài viết / bài nói (tự đánh giá) — giáo viên chấm và nhận xét. */
    public function submitText(Request $r, int $assignment)
    {
        $a = $this->findVisible($r, $assignment);
        abort_unless(in_array($a->type, ['writing', 'speaking']), 404);
        if ($a->status !== 'published') throw new DomainError('Bài này đã đóng.');
        $data = $r->validate([
            'text_answer' => ($a->type === 'writing' ? 'required' : 'nullable') . '|string|max:5000',
            'self_assessment' => ($a->type === 'speaking' ? 'required' : 'nullable') . '|in:tot,kha,can_luyen',
        ], [], ['text_answer' => 'bài viết', 'self_assessment' => 'tự đánh giá']);
        $sub = AssignmentSubmission::firstOrNew(['assignment_id' => $a->id, 'student_id' => $r->user()->id]);
        if (in_array($sub->status, ['graded', 'returned'])) return back()->with('error', 'Bài đã được chấm, không sửa được nữa.');
        $sub->fill(['text_answer' => $data['text_answer'] ?? null, 'self_assessment' => $data['self_assessment'] ?? null, 'status' => 'submitted',
            'submitted_at' => now(), 'is_late' => $a->due_at && now()->gt($a->due_at)]);
        $sub->save();
        Notifier::send($a->teacher_id, 'submission', $r->user()->name . ' đã nộp "' . $a->title . '"', null, route('teacher.submission', $sub));
        return back()->with('success', 'Đã nộp bài. Giáo viên sẽ chấm và nhận xét.');
    }
}
