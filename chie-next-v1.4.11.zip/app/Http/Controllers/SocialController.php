<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Teacher\TeacherController;
use App\Models\ClassroomMember;
use App\Models\FamilyChallenge;
use App\Models\Team;
use App\Models\TeamMember;
use App\Services\DomainError;
use App\Services\SocialService;
use App\Support\Audit;
use App\Support\Settings;
use Illuminate\Http\Request;

class SocialController extends Controller
{
    // ------------------------------------------------------------------ đội (học sinh)

    public function teams(Request $r)
    {
        $u = $r->user();
        $classes = ClassroomMember::with('classroom')->where('student_id', $u->id)->where('status', 'active')->get()->pluck('classroom');
        $data = $classes->map(fn ($c) => ['class' => $c, 'teams' => SocialService::classTeams($c->id),
            'mine' => TeamMember::where('classroom_id', $c->id)->where('student_id', $u->id)->value('team_id')]);
        return view('social.teams', ['data' => $data, 'canJoin' => (bool) Settings::get('teams.students_can_join', true)]);
    }

    public function join(Request $r, Team $team)
    {
        abort_unless(Settings::get('teams.students_can_join', true), 403);
        SocialService::setMember($team, $r->user()->id);
        Audit::log('team.joined', $team);
        return back()->with('success', 'Bạn đã vào đội ' . $team->name . '!');
    }

    public function leave(Request $r, Team $team)
    {
        SocialService::leave($team->classroom_id, $r->user()->id);
        return back()->with('success', 'Bạn đã rời đội.');
    }

    // ------------------------------------------------------------------ đội (giáo viên)

    public function teacherTeams(Request $r, int $classroom)
    {
        $c = TeacherController::classOf($r, $classroom);
        $students = ClassroomMember::with('student')->where('classroom_id', $c->id)->where('status', 'active')->get()->pluck('student')->sortBy('name');
        $assigned = TeamMember::where('classroom_id', $c->id)->pluck('team_id', 'student_id');
        return view('social.teacher-teams', ['c' => $c, 'teams' => SocialService::classTeams($c->id), 'students' => $students, 'assigned' => $assigned]);
    }

    public function teacherCreate(Request $r, int $classroom)
    {
        $c = TeacherController::classOf($r, $classroom);
        $d = $r->validate(['name' => 'required|string|max:40', 'emoji' => 'nullable|string|max:8', 'weekly_goal' => 'nullable|integer|min:50|max:100000'], [], ['name' => 'tên đội']);
        $t = SocialService::createTeam($c->id, $d['name'], $d['emoji'] ?? '⭐', (int) ($d['weekly_goal'] ?? 500), $r->user()->id);
        Audit::log('team.created', $t);
        return back()->with('success', 'Đã tạo đội ' . $t->name . '.');
    }

    public function teacherAssign(Request $r, int $classroom)
    {
        $c = TeacherController::classOf($r, $classroom);
        $d = $r->validate(['assign' => 'present|array', 'assign.*' => 'nullable|integer']);
        $teamIds = Team::where('classroom_id', $c->id)->pluck('id')->all();
        foreach ($d['assign'] as $sid => $tid) {
            $sid = (int) $sid;
            if (!$tid) { SocialService::leave($c->id, $sid); continue; }
            if (!in_array((int) $tid, $teamIds, true)) continue;
            SocialService::setMember(Team::find($tid), $sid, $r->user()->id);
        }
        Audit::log('team.assigned', $c);
        return back()->with('success', 'Đã lưu phân đội.');
    }

    public function teacherDelete(Request $r, int $classroom, Team $team)
    {
        $c = TeacherController::classOf($r, $classroom);
        abort_unless($team->classroom_id === $c->id, 404);
        $team->delete();
        Audit::log('team.deleted', $c, null, ['team' => $team->name]);
        return back()->with('success', 'Đã xóa đội.');
    }

    // ------------------------------------------------------------------ thử thách gia đình

    public function familyIndex(Request $r)
    {
        $u = $r->user();
        $q = FamilyChallenge::with(['parent', 'student', 'parentAttempt', 'childAttempt'])->latest('id')->limit(20);
        $list = $u->isParent() ? $q->where('parent_id', $u->id)->get() : $q->where('student_id', $u->id)->get();
        $list = $list->map(fn ($c) => SocialService::refresh($c)->load(['parent', 'student', 'parentAttempt', 'childAttempt']));
        return view('social.family', ['list' => $list, 'kids' => $u->isParent() ? $u->children()->get() : collect()]);
    }

    public function familyCreate(Request $r)
    {
        $d = $r->validate(['student_id' => 'required|integer', 'skill' => 'nullable|string|in:' . implode(',', array_keys(\App\Models\Question::SKILLS)),
            'count' => 'required|integer|min:5|max:15', 'message' => 'nullable|string|max:200'], [], ['student_id' => 'con', 'count' => 'số câu', 'message' => 'lời nhắn']);
        $c = SocialService::createChallenge($r->user(), (int) $d['student_id'], $d['skill'] ?? null, (int) $d['count'], $d['message'] ?? null);
        Audit::log('family.challenge_created', $c);
        return redirect()->route('family.show', $c)->with('success', 'Đã gửi thử thách cho con. Bố mẹ cũng làm cùng bộ câu này nhé!');
    }

    public function familyShow(Request $r, FamilyChallenge $challenge)
    {
        abort_unless(SocialService::canSee($r->user(), $challenge), 404);
        $c = SocialService::refresh($challenge)->load(['parent', 'student', 'parentAttempt', 'childAttempt']);
        return view('social.family-show', ['c' => $c, 'isParent' => $r->user()->id === $c->parent_id]);
    }

    public function familyStart(Request $r, FamilyChallenge $challenge)
    {
        $a = SocialService::start($r->user(), $challenge);
        return redirect()->route('attempt.show', $a);
    }
}
