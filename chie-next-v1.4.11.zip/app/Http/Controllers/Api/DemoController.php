<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Lesson;
use App\Services\Curriculum;
use App\Services\DomainError;
use App\Services\Grader;
use App\Services\MistakeTips;
use Illuminate\Http\Request;

/**
 * Học thử công khai cho khách: đề mã hóa giữ trong trang, không ghi DB hoặc phiên; máy chủ chấm.
 */
class DemoController extends Controller
{
    public function start(Request $r, Lesson $lesson)
    {
        if ($r->user()) return response()->json(['redirect' => route('learn.lesson', $lesson)]);
        abort_unless(Curriculum::canViewLesson($lesson, null, current_grade()), 404);
        $qs = collect(Grader::shuffle($lesson->questions()->where('status', 'published')->get()->all()));
        if ($qs->isEmpty()) throw new DomainError('Bài này chưa có câu luyện đã duyệt.');
        session()->forget('demo_attempt');
        return \App\Services\GuestAttempt::create($qs, $lesson->title_vi, 'learn_view');
    }

    public function page(Request $r)
    {
        if ($r->user()) return redirect()->route('learn.home');
        return view('attempt.player', ['attempt' => null, 'mode' => 'demo', 'demoTitle' => 'Học không lưu điểm', 'demoLesson' => null]);
    }

    public function show(Request $r)
    {
        $d = session('demo_attempt');
        if (!$d) abort(404, 'Chưa có bài học thử. Hãy chọn một bài công khai.');
        $items = [];
        foreach ($d['items'] as $i => $it) {
            $answered = $it['response'] !== null;
            $v = Grader::publicView($it['snapshot'], $answered);
            $v += ['position' => $i, 'phase' => $it['phase'], 'answered' => $answered, 'response' => $it['response']];
            if ($answered) { $v['is_correct'] = $it['is_correct']; $v['tips'] = $it['is_correct'] === false ? MistakeTips::forTags($it['snapshot']['tags'] ?? []) : []; }
            elseif ($it['phase'] === 'guided') $v['hint_vi'] = $it['snapshot']['prompt']['hint_vi'] ?? null;
            $items[] = $v;
        }
        $answered = collect($d['items'])->whereNotNull('response')->count();
        $correct = collect($d['items'])->where('is_correct', true)->count();
        return ['id' => 'demo', 'kind' => 'demo', 'title' => $d['title'], 'status' => 'in_progress', 'total' => count($items), 'answered' => $answered,
            'correct' => $correct, 'feedback' => 'immediate', 'items' => $items, 'seconds_left' => null, 'result' => null];
    }

    public function answer(Request $r)
    {
        $d = session('demo_attempt');
        if (!$d) abort(404);
        $data = $r->validate(['position' => 'required|integer|min:0', 'response' => 'present|array']);
        $i = (int) $data['position'];
        abort_unless(isset($d['items'][$i]), 404);
        $it = &$d['items'][$i];
        if ($it['response'] === null) {
            [$ok, $clean] = Grader::grade($it['snapshot'], $data['response']);
            $it['response'] = $clean; $it['is_correct'] = $ok;
            $d['streak'] = $ok ? $d['streak'] + 1 : 0;
            session(['demo_attempt' => $d]);
        }
        $snap = $it['snapshot'];
        $answered = collect($d['items'])->whereNotNull('response')->count();
        return ['position' => $i, 'answered' => true, 'answered_count' => $answered, 'total' => count($d['items']),
            'is_correct' => $it['is_correct'], 'correct_text' => $snap['key']['correct_text'] ?? null, 'correct_index' => $snap['key']['correct_index'] ?? null,
            'explanation_vi' => $snap['explanation_vi'] ?? null, 'example_after' => $snap['prompt']['example_after'] ?? null,
            'tips' => $it['is_correct'] === false ? MistakeTips::forTags($snap['tags'] ?? []) : [], 'streak' => $d['streak'],
            'demo_done' => $answered === count($d['items']), 'demo_correct' => collect($d['items'])->where('is_correct', true)->count()];
    }
}
