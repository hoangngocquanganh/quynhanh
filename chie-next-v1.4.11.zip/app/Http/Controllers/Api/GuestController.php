<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\LexiconItem;
use App\Models\Question;
use App\Services\DomainError;
use App\Services\Grader;
use App\Services\GuestAttempt;
use App\Services\QuestionPicker;
use Illuminate\Http\Request;

class GuestController extends Controller
{
    public function practice(Request $r)
    {
        $d = $r->validate(['skill' => 'nullable|in:' . implode(',', array_keys(Question::SKILLS))]);
        $g = current_grade();
        if (!$g) throw new DomainError('Hãy chọn lớp trước khi học.');
        $qs = QuestionPicker::pick($g, 10, null, [], empty($d['skill']) ? [] : ['skills' => [$d['skill']]]);
        return GuestAttempt::create($qs, 'Luyện tập không lưu điểm', 'guest_practice');
    }

    public function words(Request $r)
    {
        $d = $r->validate(['topic' => 'nullable|string|max:60']);
        $g = current_grade();
        if (!$g) throw new DomainError('Hãy chọn lớp trước khi học.');
        $pool = LexiconItem::where('status', 'published')->where('grade_id', '<=', max(3, $g))
            ->when(!empty($d['topic']), fn ($q) => $q->where('topic', $d['topic']))->inRandomOrder()->limit(60)->get();
        if ($pool->count() < 4) throw new DomainError('Chủ đề này chưa đủ từ đã duyệt để luyện.');
        $items = $pool->take(10)->map(fn ($w) => Grader::buildWord($w, $pool, (bool) random_int(0, 1)));
        return GuestAttempt::create($items, 'Luyện từ vựng không lưu điểm', 'vocab');
    }

    public function show(Request $r) { return GuestAttempt::show($r); }
    public function answer(Request $r) { return GuestAttempt::answer($r); }
}
