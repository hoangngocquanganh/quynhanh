<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\GachaPool;
use App\Models\InventoryItem;
use App\Services\DomainError;
use App\Services\Economy;
use App\Services\ShopService;
use Illuminate\Http\Request;

class ShopApiController extends Controller
{
    public function buy(Request $r)
    {
        $d = $r->validate(['item_id' => 'required|integer', 'idempotency_key' => 'required|string|max:80']);
        $inv = ShopService::buy($r->user(), (int) $d['item_id'], $d['idempotency_key']);
        return ['message' => 'Đã mua ' . $inv->item->name_vi . '!', 'xu' => Economy::walletFor($r->user()->id)->xu];
    }

    public function sell(Request $r)
    {
        $d = $r->validate(['inventory_id' => 'required|integer', 'idempotency_key' => 'required|string|max:80']);
        $price = ShopService::sell($r->user(), (int) $d['inventory_id'], $d['idempotency_key']);
        return ['message' => "Đã bán lại cho CHIE, nhận {$price} Xu.", 'xu' => Economy::walletFor($r->user()->id)->xu];
    }

    public function spin(Request $r)
    {
        $d = $r->validate(['pool_id' => 'required|integer', 'idempotency_key' => 'required|string|max:80']);
        $pool = GachaPool::findOrFail($d['pool_id']);
        $res = ShopService::spin($r->user(), $pool, $d['idempotency_key']);
        return ['item' => ['name' => $res['item']->name_vi, 'icon' => $res['item']->icon, 'rarity' => $res['rarity'], 'rarity_label' => rarity_label($res['rarity'])],
            'was_pity' => $res['was_pity'], 'replayed' => $res['replayed'], 'pity' => $res['pity'], 'xu' => Economy::walletFor($r->user()->id)->xu,
            'spins_today' => Economy::counter($r->user()->id, 'gacha_spins')];
    }

    /** Đặt / gỡ đồ trang trí trong phòng (lưới 8×6). */
    public function place(Request $r)
    {
        $d = $r->validate(['inventory_id' => 'required|integer', 'x' => 'nullable|integer|min:0|max:7', 'y' => 'nullable|integer|min:0|max:5']);
        $inv = InventoryItem::with('item')->where('user_id', $r->user()->id)->findOrFail($d['inventory_id']);
        if (!in_array($inv->item->category, ['decor', 'gacha_only'])) throw new DomainError('Chỉ đặt được đồ trang trí.');
        if (!isset($d['x'], $d['y'])) {
            $inv->update(['placed' => false, 'pos_x' => null, 'pos_y' => null]);
            return ['message' => 'Đã cất vào túi đồ.', 'beauty' => ShopService::beauty($r->user()->id)];
        }
        $taken = InventoryItem::where('user_id', $r->user()->id)->where('placed', true)->where('pos_x', $d['x'])->where('pos_y', $d['y'])->where('id', '<>', $inv->id)->exists();
        if ($taken) throw new DomainError('Ô này đã có đồ.');
        $inv->update(['placed' => true, 'pos_x' => $d['x'], 'pos_y' => $d['y']]);
        return ['message' => 'Đã đặt ' . $inv->item->name_vi . '.', 'beauty' => ShopService::beauty($r->user()->id)];
    }
}
