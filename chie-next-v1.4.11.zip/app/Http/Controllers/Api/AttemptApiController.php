<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Attempt;
use App\Models\ExamBlueprint;
use App\Models\Lesson;
use App\Models\LexiconItem;
use App\Models\Question;
use App\Models\SrsCard;
use App\Services\AttemptService;
use App\Services\Curriculum;
use App\Services\DomainError;
use App\Services\Grader;
use App\Services\QuestionPicker;
use App\Support\Settings;
use Illuminate\Http\Request;

class AttemptApiController extends Controller
{
    protected function grade(Request $r): int
    {
        $g = current_grade();
        if (!$g) throw new DomainError('Hãy chọn lớp trước khi học.');
        return $g;
    }

    protected function own(Request $r, Attempt $a): Attempt
    {
        // Chỉ chủ lượt làm được xem/làm. Người khác: 404 (không lộ sự tồn tại).
        abort_unless($a->user_id === $r->user()->id, 404);
        return $a;
    }

    public function startLesson(Request $r, Lesson $lesson)
    {
        $u = $r->user();
        $g = $this->grade($r);
        abort_unless(Curriculum::canViewLesson($lesson, $u, $g), 404);
        $open = Attempt::where('user_id', $u->id)->where('kind', 'lesson')->where('ref_type', 'lesson')->where('ref_id', $lesson->id)
            ->where('grade_level', $g)->where('status', 'in_progress')->latest('id')->first();
        if ($open) return ['redirect' => route('attempt.show', $open), 'resumed' => true];
        $qs = $lesson->questions()->where('status', 'published')->get();
        $qs = collect(Grader::shuffle($qs->all()));
        $guided = min(4, (int) ceil($qs->count() * (float) Settings::get('learn.lesson_guided_ratio', 0.4)));
        $a = AttemptService::create($u, 'lesson', 'lesson', $lesson->id, $g, $qs, [
            'title' => $lesson->title_vi, 'feedback' => 'immediate', 'guided_count' => $guided, 'meta' => ['lesson_id' => $lesson->id, 'mode' => 'lesson'],
        ]);
        return ['redirect' => route('attempt.show', $a)];
    }

    public function startReview(Request $r)
    {
        $u = $r->user();
        $g = $this->grade($r);
        $size = (int) Settings::get('learn.review_session_size', 10);
        $only = $r->input('only');   // null | words | questions
        $cards = SrsCard::where('user_id', $u->id)->where('grade_level', $g)->where('due_at', '<=', now())->where('stage', '<', 3)
            ->when($only === 'words', fn ($q) => $q->where('item_type', 'word'))
            ->when($only === 'questions', fn ($q) => $q->where('item_type', 'question'))
            ->orderBy('due_at')->limit($size)->get();
        if ($cards->isEmpty()) throw new DomainError('Hôm nay chưa có mục nào đến hạn ôn. Giỏi lắm! Hãy học bài mới nhé.');
        $items = collect();
        $qIds = $cards->where('item_type', 'question')->pluck('item_id');
        $questions = Question::whereIn('id', $qIds)->where('status', 'published')->get()->keyBy('id');
        $wIds = $cards->where('item_type', 'word')->pluck('item_id');
        $words = LexiconItem::whereIn('id', $wIds)->where('status', 'published')->get()->keyBy('id');
        $pool = $words->count() ? LexiconItem::where('status', 'published')->where('grade_id', '<=', max($g, 3))->inRandomOrder()->limit(60)->get() : collect();
        foreach ($cards as $c) {
            if ($c->item_type === 'question' && isset($questions[$c->item_id])) $items->push($questions[$c->item_id]);
            if ($c->item_type === 'word' && isset($words[$c->item_id]) && $pool->count() >= 4) $items->push(Grader::buildWord($words[$c->item_id], $pool, (bool) random_int(0, 1)));
        }
        if ($items->isEmpty()) throw new DomainError('Các mục đến hạn ôn đã bị thu hồi hoặc đang chỉnh sửa. Hãy học bài mới nhé.');
        $a = AttemptService::create($u, 'review', 'srs', null, $g, collect(Grader::shuffle($items->all())), ['title' => 'Ôn tập theo lịch', 'feedback' => 'immediate', 'meta' => ['mode' => 'review']]);
        return ['redirect' => route('attempt.show', $a)];
    }

    public function startPractice(Request $r)
    {
        $data = $r->validate([
            'skill' => 'nullable|string|in:' . implode(',', array_keys(Question::SKILLS)),
            'tags' => 'nullable|array|max:5', 'tags.*' => 'string|max:40',
            'count' => 'nullable|integer|min:5|max:20',
        ]);
        $u = $r->user();
        $g = $this->grade($r);
        $count = (int) ($data['count'] ?? 10);
        $qs = QuestionPicker::pick($g, $count, $u->id, [], array_filter(['skills' => !empty($data['skill']) ? [$data['skill']] : null, 'tags' => $data['tags'] ?? null]));
        if ($qs->count() < 3) throw new DomainError('Chưa đủ câu đã duyệt cho phần luyện này ở ' . grade_name($g) . '. Nội dung đang được bổ sung.');
        $title = !empty($data['skill']) ? 'Luyện ' . mb_strtolower(Question::SKILLS[$data['skill']]) : (!empty($data['tags']) ? 'Luyện chủ điểm yếu' : 'Luyện tập nhanh');
        $a = AttemptService::create($u, 'lesson', 'practice', null, $g, $qs, ['title' => $title, 'feedback' => 'immediate', 'meta' => ['mode' => 'practice']]);
        return ['redirect' => route('attempt.show', $a)];
    }

    /** Luyện từ vựng theo chủ đề: câu thẻ hình "Đâu là …?" xen kẽ câu chọn nghĩa, sinh từ Kho từ đã duyệt. */
    public function startWords(Request $r)
    {
        $data = $r->validate(['topic' => 'nullable|string|max:60', 'from' => 'nullable|in:tu-hoc']);
        $u = $r->user();
        $g = $this->grade($r);
        $topic = $data['topic'] ?? null;
        $base = LexiconItem::where('status', 'published')->where('grade_id', '<=', max($g, 3))
            ->when($topic, fn ($q) => $q->where('topic', $topic), fn ($q) => $q->whereNull('topic'));
        // ưu tiên từ chưa học / đang học, rồi tới từ có hình
        $known = SrsCard::where('user_id', $u->id)->where('item_type', 'word')->where('stage', '>=', 3)->pluck('item_id');
        $words = (clone $base)->whereNotIn('id', $known)->orderByRaw("emoji IS NULL OR emoji = ''")->inRandomOrder()->limit(10)->get();
        if ($words->count() < 4) $words = (clone $base)->inRandomOrder()->limit(10)->get();
        $pool = (clone $base)->limit(80)->get();
        if ($words->count() < 4 || $pool->count() < 4) throw new DomainError('Chủ đề này chưa đủ từ để luyện. Hãy chọn chủ đề khác nhé.');
        $items = $words->values()->map(fn ($w, $i) => Grader::buildWord($w, $pool, $i % 2 === 0 && $w->emoji));
        $a = AttemptService::create($u, 'review', 'words', null, $g, collect(Grader::shuffle($items->all())),
            ['title' => 'Từ vựng: ' . ($topic ?: 'Từ khác'), 'feedback' => 'immediate', 'meta' => array_filter(['mode' => 'words', 'topic' => $topic, 'from' => $data['from'] ?? null])]);
        return ['redirect' => route('attempt.show', $a)];
    }

    public function startExam(Request $r, ExamBlueprint $blueprint)
    {
        $u = $r->user();
        $g = $this->grade($r);
        abort_unless($blueprint->is_active && $blueprint->grade_from <= $g && $blueprint->grade_to >= $g, 404);
        $open = Attempt::where('user_id', $u->id)->where('kind', 'exam')->where('ref_type', 'blueprint')->where('ref_id', $blueprint->id)
            ->where('status', 'in_progress')->latest('id')->first();
        if ($open) {
            $open = AttemptService::expireIfNeeded($open);
            if ($open->status === 'in_progress') return ['redirect' => route('attempt.show', $open), 'resumed' => true];
        }
        $qs = QuestionPicker::pick($g, $blueprint->question_count, $u->id, $blueprint->skill_mix ?? []);
        $min = (int) ceil($blueprint->question_count * 0.6);
        if ($qs->count() < $min) {
            throw new DomainError('Ngân hàng câu đã duyệt của ' . grade_name($g) . ' hiện có ' . $qs->count() . ' câu, chưa đủ để tạo "' . $blueprint->title . '" (' . $blueprint->question_count . ' câu). Hãy thử đề ngắn hơn.');
        }
        $duration = (int) round($blueprint->duration_min * $qs->count() / max(1, $blueprint->question_count));
        $a = AttemptService::create($u, 'exam', 'blueprint', $blueprint->id, $g, $qs, [
            'title' => $blueprint->title, 'feedback' => 'after_submit', 'duration_min' => max(3, $duration),
            'meta' => ['mode' => 'exam', 'shareable' => true, 'blueprint_type' => $blueprint->type, 'short' => $qs->count() < $blueprint->question_count],
        ]);
        return ['redirect' => route('attempt.show', $a)];
    }

    public function show(Request $r, Attempt $attempt)
    {
        return AttemptService::view($this->own($r, $attempt));
    }

    public function answer(Request $r, Attempt $attempt)
    {
        $this->own($r, $attempt);
        $data = $r->validate([
            'position' => 'required|integer|min:0|max:500',
            'response' => 'present|array',
            'time_ms' => 'nullable|integer|min:0',
            'hint_used' => 'nullable|boolean',
        ]);
        return AttemptService::answer($attempt, (int) $data['position'], $data['response'] ?? [], $data['time_ms'] ?? null, (bool) ($data['hint_used'] ?? false));
    }

    public function submit(Request $r, Attempt $attempt)
    {
        $this->own($r, $attempt);
        if ($attempt->kind === 'raid') throw new DomainError('Lượt cướp trại được kết thúc trong màn hình nông trại.');
        $a = AttemptService::submit($attempt);
        return ['status' => $a->status, 'result' => AttemptService::resultSummary($a), 'redirect' => route('attempt.result', $a)];
    }
}
