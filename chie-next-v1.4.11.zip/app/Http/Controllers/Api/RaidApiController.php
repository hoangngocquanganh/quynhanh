<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\FarmRaid;
use App\Services\RaidService;
use Illuminate\Http\Request;

class RaidApiController extends Controller
{
    public function start(Request $r)
    {
        $d = $r->validate(['defender_id' => 'required|integer']);
        $raid = RaidService::start($r->user(), (int) $d['defender_id']);
        return ['redirect' => route('attempt.show', $raid->attempt_id)];
    }

    public function finish(Request $r, FarmRaid $raid)
    {
        $raid = RaidService::finish($r->user(), $raid);
        return ['status' => $raid->status, 'redirect' => route('farm.raid')];
    }
}
