<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\WorldLevel;
use App\Services\AttemptService;
use App\Services\DomainError;
use App\Services\Games;
use App\Services\QuestionPicker;
use Illuminate\Http\Request;

class GameApiController extends Controller
{
    public function start(Request $r, string $code)
    {
        abort_unless(isset(Games::LIST[$code]), 404);
        $cfg = Games::config($code);
        if (!$cfg || !$cfg->enabled) throw new DomainError('Game đang tạm đóng.');
        $u = $r->user();
        if (!$u) {
            $g = current_grade();
            if (!$g) throw new DomainError('Hãy chọn lớp trước khi chơi.');
            $meta = Games::LIST[$code];
            $qs = QuestionPicker::pick($g, max(5, min(30, (int) ($cfg->config['question_count'] ?? 12))), null, [], ['skills' => $meta['pick']['skills'], 'types' => $meta['pick']['types']]);
            if ($qs->count() < 5) throw new DomainError('Lớp này chưa đủ câu đã duyệt cho game. Hãy chọn game khác nhé!');
            $round = \App\Services\GuestAttempt::create($qs, $cfg->title, 'games', $meta['max_options']);
            $extra = [];
            if ($code === 'voice_island') $extra['sentences'] = \App\Models\Question::published()->where('grade_id', $g)->where('type', 'word_order')->limit(5)->get()->map(fn ($q) => $q->answer['correct'] ?? '')->filter()->values();
            return ['guest_token' => $round['guest_token'], 'attempt' => $round['attempt'], 'extra' => $extra,
                'urls' => ['answer' => route('api.guest.answer'), 'submit' => null], 'config' => $cfg->config];
        }
        $g = (int) $u->grade_level;
        $meta = Games::LIST[$code];
        $count = max(5, min(30, (int) ($cfg->config['question_count'] ?? 12)));
        $qs = QuestionPicker::pick($g, $count, $u->id, [], ['skills' => $meta['pick']['skills'], 'types' => $meta['pick']['types']]);
        if ($qs->count() < 5) throw new DomainError('Lớp của bạn chưa có đủ câu hỏi đã duyệt cho game này (cần ít nhất 5). Hãy thử game khác nhé!');
        $a = AttemptService::create($u, 'game', $code, null, $g, $qs, ['title' => $cfg->title, 'feedback' => 'immediate', 'max_options' => $meta['max_options'],
            'guided_count' => $code === 'reading_escape' ? $qs->count() : 0, 'meta' => ['mode' => 'game', 'game' => $code, 'config_version' => $cfg->version]]);
        $extra = [];
        if ($code === 'voice_island') {
            $extra['sentences'] = \App\Models\Question::published()->where('grade_id', $g)->where('type', 'word_order')->inRandomOrder()
                ->limit((int) ($cfg->config['shadowing_sentences'] ?? 5))->get()->map(fn ($q) => rtrim($q->answer['correct'] ?? '', '.!?') . '.')->filter(fn ($s) => strlen($s) > 2)->values();
        }
        return ['extra' => $extra, 'attempt' => AttemptService::view($a), 'urls' => ['answer' => route('api.attempt.answer', $a), 'submit' => route('api.attempt.submit', $a)], 'config' => $cfg->config];
    }

    public function startWorld(Request $r, WorldLevel $level)
    {
        abort_unless($level->is_active && $level->world->is_active, 404);
        $u = $r->user();
        [, $states] = \App\Http\Controllers\GameController::worldStates($u);
        if (empty($states[$level->id]['open'])) throw new DomainError('Màn này chưa mở — hãy vượt màn trước.');
        $g = (int) $u->grade_level;
        $opts = $level->mode === 'boss' ? ['types' => ['mcq', 'listen_mcq', 'word_order', 'matching']] : [];
        $qs = QuestionPicker::pick($g, $level->question_count, $u->id, [], $opts);
        if ($qs->count() < min(5, $level->question_count)) throw new DomainError('Lớp của bạn chưa có đủ câu hỏi đã duyệt cho màn này.');
        $a = AttemptService::create($u, 'game', 'world_level', $level->id, $g, $qs, ['title' => $level->title, 'feedback' => 'immediate', 'meta' => ['mode' => 'world', 'level_mode' => $level->mode]]);
        return ['redirect' => route('attempt.show', $a)];
    }
}
