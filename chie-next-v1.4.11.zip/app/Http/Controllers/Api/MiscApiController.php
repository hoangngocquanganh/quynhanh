<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\AttemptItem;
use App\Models\ErrorReport;
use App\Services\LiveStatus;
use Illuminate\Http\Request;

class MiscApiController extends Controller
{
    public function heartbeat(Request $r)
    {
        $data = $r->validate(['module' => 'nullable|string|max:20', 'label' => 'nullable|string|max:190']);
        $module = array_key_exists($data['module'] ?? '', LiveStatus::MODULES) ? $data['module'] : 'browse';
        // Khi đang làm bài, nhãn chi tiết do máy chủ ghi (Câu x/y) — không ghi đè bằng nhãn trình duyệt
        $row = \Illuminate\Support\Facades\DB::table('user_live_status')->where('user_id', $r->user()->id)->first();
        $keep = $row && in_array($row->module, ['exam', 'learn', 'review', 'game'], true) && $row->module === $module && $row->last_seen_at && now()->diffInSeconds($row->last_seen_at, true) < 600;
        LiveStatus::touch($r->user()->id, $module, $keep ? $row->label : ($data['label'] ?? null));
        try { \App\Services\ActivityAnalytics::record($r, $module); } catch (\Throwable $e) { report($e); }
        return ['ok' => true, 'next_in' => 60];
    }

    public function tts(Request $r)
    {
        $data = $r->validate(['rate' => 'required|numeric|min:0.5|max:1.2']);
        $u = $r->user();
        $s = $u->settings ?? [];
        $s['tts_rate'] = round((float) $data['rate'], 2);
        $u->settings = $s;
        $u->save();
        return ['ok' => true];
    }

    public function reportQuestion(Request $r, int $question)
    {
        $data = $r->validate(['message' => 'required|string|min:3|max:500', 'attempt_id' => 'nullable|integer', 'position' => 'nullable|integer']);
        $qid = $question ?: null;
        if (!empty($data['attempt_id'])) {
            $item = AttemptItem::where('attempt_id', $data['attempt_id'])->where('position', (int) ($data['position'] ?? -1))
                ->whereHas('attempt', fn ($q) => $q->where('user_id', $r->user()->id))->first();
            if (!$item) abort(404);
            $qid = $item->question_id;
        }
        ErrorReport::create(['user_id' => $r->user()->id, 'kind' => 'question_report', 'ref_id' => $qid, 'message' => $data['message'], 'url' => $r->header('referer')]);
        return ['ok' => true];
    }

    public function clientError(Request $r)
    {
        $data = $r->validate(['message' => 'required|string|max:300', 'url' => 'nullable|string|max:255']);
        ErrorReport::create(['user_id' => $r->user()?->id, 'kind' => 'client_error', 'message' => $data['message'], 'url' => $data['url'] ?? null]);
        return ['ok' => true];
    }

    /** Gói thẻ từ để ôn khi mất mạng (chỉ từ vựng đã duyệt — không có câu hỏi/đáp án của đề). */
    public function offlinePack(Request $r)
    {
        $g = current_grade() ?: 3;
        $words = \App\Models\LexiconItem::where('status', 'published')->where('grade_id', '<=', $g)->orderByDesc('grade_id')->orderBy('id')->limit(400)
            ->get(['word', 'ipa_uk', 'meaning_vi', 'example_en'])->map(fn ($w) => ['word' => $w->word, 'ipa' => $w->ipa_uk, 'meaning' => $w->meaning_vi, 'example' => $w->example_en])->values();
        return ['grade' => $g, 'grade_name' => grade_name($g), 'words' => $words, 'generated_at' => now()->toIso8601String()];
    }
}
