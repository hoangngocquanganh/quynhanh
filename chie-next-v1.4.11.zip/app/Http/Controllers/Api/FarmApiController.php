<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Services\FarmService;
use App\Services\LiveStatus;
use Illuminate\Http\Request;

class FarmApiController extends Controller
{
    public function state(Request $r)
    {
        FarmService::expireCold($r->user()->id);
        LiveStatus::touch($r->user()->id, 'farm', 'Nông trại');
        return FarmService::state($r->user());
    }

    public function quiz(Request $r)
    {
        $d = $r->validate(['purpose' => 'required|in:plant,water,pest,feed', 'crop' => 'nullable|string|max:40', 'slot' => 'nullable|integer|min:0|max:47', 'animal' => 'nullable|integer']);
        return FarmService::quiz($r->user(), $d['purpose'], array_filter(['crop' => $d['crop'] ?? null, 'slot' => $d['slot'] ?? null, 'animal' => $d['animal'] ?? null], fn ($v) => $v !== null));
    }

    public function plant(Request $r)
    {
        $d = $r->validate(['slot' => 'required|integer|min:0|max:47', 'crop' => 'required|string|max:40', 'token' => 'nullable|string', 'choice' => 'required_with:token|nullable|integer']);
        return FarmService::plant($r->user(), (int) $d['slot'], $d['crop'], $d['token'] ?? null, $d['choice'] ?? null) + ['state' => FarmService::state($r->user())];
    }

    public function water(Request $r)
    {
        $d = $r->validate(['slot' => 'required|integer|min:0|max:47', 'purpose' => 'required|in:water,pest', 'token' => 'nullable|string', 'choice' => 'required_with:token|nullable|integer']);
        return FarmService::care($r->user(), (int) $d['slot'], $d['purpose'], $d['token'] ?? null, $d['choice'] ?? null) + ['state' => FarmService::state($r->user())];
    }

    public function harvest(Request $r)
    {
        $d = $r->validate(['slot' => 'required|integer|min:0|max:47']);
        return FarmService::harvest($r->user(), (int) $d['slot']) + ['state' => FarmService::state($r->user())];
    }

    public function move(Request $r)
    {
        $d = $r->validate(['code' => 'required|string|max:40', 'from' => 'required|string', 'to' => 'required|string', 'qty' => 'required|integer|min:1|max:9999']);
        return FarmService::move($r->user(), $d['code'], $d['from'], $d['to'], (int) $d['qty']) + ['state' => FarmService::state($r->user())];
    }

    public function sell(Request $r)
    {
        $d = $r->validate(['code' => 'required|string|max:40', 'from' => 'required|string', 'qty' => 'required|integer|min:1|max:9999']);
        return FarmService::sell($r->user(), $d['code'], $d['from'], (int) $d['qty']) + ['state' => FarmService::state($r->user())];
    }

    public function cook(Request $r)
    {
        $d = $r->validate(['recipe' => 'required|string|max:40', 'ingredients' => 'present|array|max:6', 'ingredients.*' => 'string|max:40']);
        return FarmService::cook($r->user(), $d['recipe'], $d['ingredients']) + ['state' => FarmService::state($r->user())];
    }

    public function buy(Request $r)
    {
        $d = $r->validate(['what' => 'required|in:plot,wall,shield,cold,inner', 'hours' => 'nullable|integer|min:1|max:72']);
        return FarmService::buy($r->user(), $d['what'], $d['hours'] ?? null) + ['state' => FarmService::state($r->user())];
    }

    public function buyAnimal(Request $r)
    {
        $d = $r->validate(['kind' => 'required|string|max:30']);
        return FarmService::buyAnimal($r->user(), $d['kind']) + ['state' => FarmService::state($r->user())];
    }

    public function feed(Request $r)
    {
        $d = $r->validate(['animal' => 'required|integer', 'token' => 'nullable|string', 'choice' => 'required_with:token|nullable|integer']);
        return FarmService::feed($r->user(), (int) $d['animal'], $d['token'] ?? null, $d['choice'] ?? null) + ['state' => FarmService::state($r->user())];
    }

    public function collect(Request $r)
    {
        $d = $r->validate(['animal' => 'required|integer']);
        return FarmService::collect($r->user(), (int) $d['animal']) + ['state' => FarmService::state($r->user())];
    }

    // ------------------------------------------------------------------ Zoo Garden 3D (v1.3)

    public function zooBoot(Request $r)
    {
        return \App\Services\ZooGardenService::bootPayload($r->user());
    }

    public function zooSave(Request $r)
    {
        // save_json là chuỗi JSON nguyên vẹn (tránh middleware TrimStrings/ConvertEmptyStringsToNull làm hỏng bản lưu)
        $d = $r->validate([
            'save_json' => 'nullable|string|max:3000000',
            'revision' => 'required|integer|min:0',
            'active_seconds_delta' => 'nullable|integer|min:0|max:120',
            'claimed_energy' => 'nullable|integer|min:0|max:100000000',
        ]);
        return \App\Services\ZooGardenService::saveState($r->user(), $d['save_json'] ?? null, (int) $d['revision'],
            (int) ($d['active_seconds_delta'] ?? 0), (int) ($d['claimed_energy'] ?? 0));
    }

    public function zooExchange(Request $r)
    {
        $d = $r->validate(['xu' => 'required|integer|min:1|max:5000']);
        return \App\Services\ZooGardenService::exchangeXuToEnergy($r->user(), (int) $d['xu']);
    }

    public function zooQuizStart(Request $r)
    {
        $d = $r->validate(['context' => 'required|in:care,cook,space,dungeon,playtime_unlock', 'target_code' => 'nullable|string|max:60']);
        return \App\Services\ZooGardenService::startQuiz($r->user(), $d['context'], $d['target_code'] ?? null);
    }

    public function zooQuizSubmit(Request $r)
    {
        $d = $r->validate(['token' => 'required|string|max:20000', 'answers' => 'required|array|min:1|max:15', 'answers.*' => 'integer']);
        return \App\Services\ZooGardenService::submitQuiz($r->user(), $d['token'], array_values($d['answers']));
    }

    /** Vé đăng nhập 1 lần (60 giây) cho máy chủ Online Node.js — xem docs/NODE_ONLINE_ZOO_GARDEN.md. */
    public function zooTicket(Request $r)
    {
        return \App\Services\ZooGardenService::onlineTicket($r->user());
    }
}
