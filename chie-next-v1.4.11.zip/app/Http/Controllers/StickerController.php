<?php

namespace App\Http\Controllers;

use App\Models\StickerPack;
use App\Services\StickerService;
use Illuminate\Http\Request;

/** v1.3.3 — Album sticker: xem, bóc sticker mới, ôn sticker cần ôn, nghe & chọn hình. */
class StickerController extends Controller
{
    public function index(Request $r)
    {
        if (!StickerService::available()) return response()->view('stickers.unavailable', [], 503);
        $g = current_grade();
        if (!$g) return redirect()->route('grade.pick', ['next' => $r->getRequestUri()]);
        $u = $r->user();
        $packs = StickerService::packs($u, $g);
        return view('stickers.index', [
            'grade' => $g, 'fit' => $packs->where('fits', true)->values(), 'more' => $packs->where('fits', false)->values(),
            'today' => StickerService::ofTheDay($g), 'totals' => $u ? StickerService::totals($u) : null,
        ]);
    }

    public function pack(Request $r, string $pack)
    {
        if (!StickerService::available()) return response()->view('stickers.unavailable', [], 503);
        $p = StickerPack::where('code', $pack)->where('status', 'published')->firstOrFail();
        $u = $r->user();
        [$stickers, $mine] = StickerService::album($p, $u);
        $g = current_grade();
        return view('stickers.pack', [
            'pack' => $p, 'stickers' => $stickers, 'mine' => $mine, 'grade' => $g,
            'got' => $mine->where('level', '>=', 1)->count(), 'gold' => $mine->where('level', '>=', 3)->count(),
            'due' => $mine->filter(fn ($m) => $m->due_at && $m->due_at->lte(now()))->count(),
        ]);
    }

    public function session(Request $r)
    {
        abort_unless(StickerService::available(), 503, 'Sticker đang cập nhật dữ liệu. Vui lòng thử lại sau.');
        $data = $r->validate(['pack' => 'nullable|string|max:60', 'mode' => 'required|in:learn,review,listen']);
        $pack = !empty($data['pack']) ? StickerPack::where('code', $data['pack'])->where('status', 'published')->firstOrFail() : null;
        return StickerService::session($r->user(), $pack, $data['mode'], current_grade());
    }

    public function answer(Request $r)
    {
        abort_unless(StickerService::available(), 503, 'Sticker đang cập nhật dữ liệu. Vui lòng thử lại sau.');
        $data = $r->validate(['sticker_id' => 'required|integer|min:1', 'choice_id' => 'required|integer|min:0']);
        return StickerService::answer($r->user(), (int) $data['sticker_id'], (int) $data['choice_id']);
    }
}
