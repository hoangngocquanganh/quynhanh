<?php

namespace App\Http\Controllers;

use App\Models\GachaLog;
use App\Models\GachaPool;
use App\Models\InventoryItem;
use App\Models\ShopItem;
use App\Services\Economy;
use App\Services\ShopService;
use Illuminate\Http\Request;

class ShopController extends Controller
{
    public function index(Request $r)
    {
        $u = $r->user();
        $items = ShopItem::where('is_active', true)->whereNotNull('price_xu')->where('category', '<>', 'gacha_only')
            ->where(fn ($q) => $q->whereNull('season_ends_at')->orWhere('season_ends_at', '>', now()))->orderBy('price_xu')->get()->groupBy('category');
        $pool = GachaPool::where('is_active', true)->with('items')->first();
        $inv = InventoryItem::with('item')->where('user_id', $u->id)->latest('id')->get();
        return view('shop.index', ['items' => $items, 'pool' => $pool, 'gacha' => $pool ? ShopService::gachaStatus($u, $pool) : null, 'inventory' => $inv,
            'wallet' => Economy::walletFor($u->id), 'history' => GachaLog::with('item')->where('user_id', $u->id)->latest('id')->limit(10)->get(),
            'tab' => $r->query('tab', 'shop')]);
    }
}
