<?php

namespace App\Http\Controllers;

use App\Models\TermsVersion;
use App\Services\Accounts;
use App\Services\ContentImporter;
use App\Services\NameFilter;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\DB;

/**
 * Trình cài đặt web (kiểu WordPress), được bảo vệ bằng MÃ CÀI ĐẶT nằm trong tệp
 * storage/app/install-token.txt (chỉ người có quyền truy cập hosting đọc được).
 * Cài xong tự khóa: tạo storage/installed.lock, mọi request /install trả 404.
 */
class InstallController extends Controller
{
    protected function tokenFile(): string
    {
        return config('chie.install_token_file');
    }

    protected function token(): string
    {
        $f = $this->tokenFile();
        if (!is_file($f)) {
            @mkdir(dirname($f), 0775, true);
            file_put_contents($f, bin2hex(random_bytes(12)) . "\n");
            @chmod($f, 0640);
        }
        return trim((string) file_get_contents($f));
    }

    public function requirements(): array
    {
        $checks = [
            ['PHP ≥ 8.2', version_compare(PHP_VERSION, '8.2.0', '>='), PHP_VERSION],
            ['PDO MySQL', extension_loaded('pdo_mysql'), ''],
            ['mbstring', extension_loaded('mbstring'), ''],
            ['openssl', extension_loaded('openssl'), ''],
            ['tokenizer', extension_loaded('tokenizer'), ''],
            ['ctype', extension_loaded('ctype'), ''],
            ['fileinfo', extension_loaded('fileinfo'), ''],
            ['JSON', function_exists('json_encode'), ''],
            ['Ghi được thư mục storage/', is_writable(storage_path()) && is_writable(storage_path('framework')), ''],
            ['Ghi được bootstrap/cache/', is_writable(base_path('bootstrap/cache')), ''],
            ['Ghi được tệp .env', is_writable(base_path('.env')) || (!file_exists(base_path('.env')) && is_writable(base_path())), ''],
        ];
        return $checks;
    }

    public function show()
    {
        $this->token();
        return view('install.show', ['checks' => $this->requirements(), 'packages' => ContentImporter::packages()]);
    }

    public function run(Request $r)
    {
        $data = $r->validate([
            'install_token' => 'required|string|max:64',
            'db_host' => 'required|string|max:190', 'db_port' => 'required|integer|min:1|max:65535',
            'db_name' => 'required|string|max:64', 'db_user' => 'required|string|max:64', 'db_pass' => 'nullable|string|max:190',
            'site_name' => 'required|string|max:60',
            'admin_name' => 'required|string|min:2|max:30', 'admin_email' => 'required|email|max:190',
            'admin_password' => 'required|string|min:10|max:100|confirmed',
            'import' => 'nullable|array', 'import.*' => 'string',
            'mail_host' => 'nullable|string|max:190', 'mail_port' => 'nullable|integer', 'mail_user' => 'nullable|string|max:190',
            'mail_pass' => 'nullable|string|max:190', 'mail_from' => 'nullable|email|max:190', 'mail_scheme' => 'nullable|in:smtp,smtps',
        ], ['admin_password.confirmed' => 'Hai lần nhập mật khẩu Admin chưa khớp.'], ['admin_password' => 'mật khẩu Admin']);

        if (!hash_equals($this->token(), trim($data['install_token']))) {
            return back()->withInput($r->except('admin_password', 'admin_password_confirmation', 'db_pass', 'mail_pass'))->withErrors(['install_token' => 'Mã cài đặt không đúng. Mở tệp storage/app/install-token.txt trên hosting để lấy mã.']);
        }
        foreach ($this->requirements() as [$name, $ok]) {
            if (!$ok) return back()->withInput()->withErrors(['install_token' => 'Chưa đạt yêu cầu: ' . $name]);
        }
        // Kiểm tra kết nối CSDL
        try {
            $pdo = new \PDO("mysql:host={$data['db_host']};port={$data['db_port']};dbname={$data['db_name']};charset=utf8mb4", $data['db_user'], $data['db_pass'] ?? '', [\PDO::ATTR_TIMEOUT => 8, \PDO::ATTR_ERRMODE => \PDO::ERRMODE_EXCEPTION]);
            $ver = $pdo->query('SELECT VERSION()')->fetchColumn();
            $hasTables = (int) $pdo->query("SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = " . $pdo->quote($data['db_name']) . " AND table_name = 'users'")->fetchColumn();
        } catch (\Throwable $e) {
            return back()->withInput($r->except('admin_password', 'admin_password_confirmation', 'db_pass', 'mail_pass'))->withErrors(['db_host' => 'Không kết nối được CSDL: kiểm tra tên CSDL, người dùng, mật khẩu và quyền (cPanel → MySQL Databases).']);
        }
        if ($hasTables) {
            return back()->withInput($r->except('admin_password', 'admin_password_confirmation', 'db_pass', 'mail_pass'))->withErrors(['db_name' => 'CSDL này đã có dữ liệu (bảng users). Hãy dùng một CSDL trống cho bản cài mới.']);
        }

        // Ghi .env
        $env = [
            'APP_NAME' => $data['site_name'], 'APP_ENV' => 'production', 'APP_DEBUG' => 'false', 'APP_URL' => '',
            'DB_CONNECTION' => 'mysql', 'DB_HOST' => $data['db_host'], 'DB_PORT' => (string) $data['db_port'], 'DB_DATABASE' => $data['db_name'],
            'DB_USERNAME' => $data['db_user'], 'DB_PASSWORD' => $data['db_pass'] ?? '',
        ];
        if (!empty($data['mail_host'])) {
            $env += ['MAIL_MAILER' => 'smtp', 'MAIL_HOST' => $data['mail_host'], 'MAIL_PORT' => (string) ($data['mail_port'] ?: 587), 'MAIL_USERNAME' => $data['mail_user'] ?? '',
                'MAIL_PASSWORD' => $data['mail_pass'] ?? '', 'MAIL_FROM_ADDRESS' => $data['mail_from'] ?? $data['admin_email'], 'MAIL_SCHEME' => $data['mail_scheme'] ?? ''];
        }
        static::writeEnv($env);
        config(['database.connections.mysql.host' => $data['db_host'], 'database.connections.mysql.port' => $data['db_port'],
            'database.connections.mysql.database' => $data['db_name'], 'database.connections.mysql.username' => $data['db_user'],
            'database.connections.mysql.password' => $data['db_pass'] ?? '', 'database.default' => 'mysql']);
        DB::purge('mysql');

        @set_time_limit(300);
        $log = [];
        try {
            Artisan::call('migrate', ['--force' => true]);
            $log[] = 'Tạo bảng CSDL: xong';
            Artisan::call('db:seed', ['--force' => true]);
            $log[] = 'Dữ liệu nền: xong';
            foreach ($data['import'] ?? [] as $pkg) {
                $all = ContentImporter::packages();
                if (isset($all[$pkg])) {
                    $run = (new ContentImporter())->run($all[$pkg]['file']);
                    $log[] = 'Nhập ' . $pkg . ': ' . ($run->stats['cau_nhap_moi'] ?? 0) . ' câu, ' . ($run->stats['bai_nhap_moi'] ?? 0) . ' bài, ' . ($run->stats['tu_nhap_moi'] ?? 0) . ' từ';
                }
            }
            \App\Support\Settings::set('site.name', $data['site_name']);
            \App\Support\Settings::set('auth.require_email_verification', !empty($data['mail_host']));
            $admin = Accounts::create(['name' => trim($data['admin_name']), 'email' => mb_strtolower($data['admin_email']),
                'canonical_email' => NameFilter::canonicalEmail($data['admin_email']), 'password' => $data['admin_password'], 'role' => 'admin', 'email_verified_at' => now()]);
            if ($t = TermsVersion::where('is_active', true)->first()) Accounts::recordConsent($admin, $t, $r);
            $log[] = 'Tạo tài khoản Admin: xong';
        } catch (\Throwable $e) {
            report($e);
            return back()->withInput($r->except('admin_password', 'admin_password_confirmation', 'db_pass', 'mail_pass'))->withErrors(['install_token' => 'Cài đặt dừng do lỗi: ' . $e->getMessage()]);
        }
        file_put_contents(config('chie.install_lock'), 'installed_at=' . now()->toIso8601String() . "\n");
        @unlink($this->tokenFile());
        Artisan::call('config:clear');
        return view('install.done', ['log' => $log, 'dbVersion' => $ver]);
    }

    public static function writeEnv(array $values): void
    {
        $path = base_path('.env');
        $env = is_file($path) ? file_get_contents($path) : (is_file(base_path('.env.example')) ? file_get_contents(base_path('.env.example')) : '');
        if (!preg_match('/^APP_KEY=base64:.+$/m', $env)) {
            $key = 'base64:' . base64_encode(random_bytes(32));
            $env = preg_match('/^APP_KEY=.*$/m', $env) ? preg_replace('/^APP_KEY=.*$/m', 'APP_KEY=' . $key, $env) : "APP_KEY={$key}\n" . $env;
        }
        foreach ($values as $k => $v) {
            $v = (string) $v;
            $quoted = $v === '' ? '' : '"' . str_replace(['\\', '"', "\n"], ['\\\\', '\\"', ''], $v) . '"';
            $line = $k . '=' . $quoted;
            $env = preg_match('/^' . preg_quote($k, '/') . '=.*$/m', $env) ? preg_replace('/^' . preg_quote($k, '/') . '=.*$/m', str_replace('$', '\\$', $line), $env) : rtrim($env) . "\n" . $line . "\n";
        }
        file_put_contents($path, $env, LOCK_EX);
        @chmod($path, 0640);
    }
}
