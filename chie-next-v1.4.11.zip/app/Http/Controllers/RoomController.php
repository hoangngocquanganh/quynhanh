<?php

namespace App\Http\Controllers;

use App\Models\InventoryItem;
use App\Services\ShopService;
use Illuminate\Http\Request;

class RoomController extends Controller
{
    public function show(Request $r)
    {
        $items = InventoryItem::with('item')->where('user_id', $r->user()->id)->get()->filter(fn ($i) => in_array($i->item->category, ['decor', 'gacha_only']))->values();
        return view('shop.room', ['items' => $items, 'beauty' => ShopService::beauty($r->user()->id)]);
    }
}
