<?php

namespace App\Http\Controllers;

use App\Models\Assignment;
use App\Models\AssignmentSubmission;
use App\Models\Lesson;
use App\Models\LexiconItem;
use App\Models\Question;
use App\Models\SkillStat;
use App\Models\SrsCard;
use App\Services\Curriculum;
use App\Services\MistakeTips;
use App\Services\Pronunciation;
use App\Services\QuestionPicker;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class LearnController extends Controller
{
    protected function gradeOrPick()
    {
        $g = current_grade();
        return $g ?: null;
    }

    public function home(Request $r)
    {
        $g = $this->gradeOrPick();
        if (!$g) return redirect()->route('grade.pick', ['next' => $r->getRequestUri()]);
        $u = $r->user();
        $path = Curriculum::path($g, $u);
        $ready = Curriculum::readiness($g);
        $data = ['grade' => $g, 'path' => $path, 'ready' => $ready];
        try { $data['stickerToday'] = \App\Services\StickerService::ofTheDay($g); } catch (\Throwable $e) { $data['stickerToday'] = null; }
        if ($u) {
            $data['open'] = Curriculum::openLessonAttempt($u, $g);
            $data['due'] = Curriculum::dueCount($u->id, $g);
            $data['pendingAssignments'] = $u->isStudent() ? $this->pendingAssignments($u->id)->count() : 0;
            $data['currentUnit'] = $path['current']?->unit;
        }
        return view('learn.home', $data);
    }

    public function path(Request $r)
    {
        $g = $this->gradeOrPick();
        if (!$g) return redirect()->route('grade.pick', ['next' => $r->getRequestUri()]);
        $u = $r->user();
        $data = ['grade' => $g, 'path' => Curriculum::path($g, $u), 'ready' => Curriculum::readiness($g)];
        if ($u && $u->isStudent()) {
            $data['wallet'] = \App\Services\Economy::walletFor($u->id);
            $data['due'] = Curriculum::dueCount($u->id, $g);
            $data['quests'] = \App\Services\DailyQuests::forUser($u->id);
            $data['questBonus'] = \App\Services\DailyQuests::bonus() + ['claimed' => \App\Services\DailyQuests::claimed($u->id)];
        }
        return view('learn.path', $data);
    }


    public function lesson(Request $r, Lesson $lesson)
    {
        $u = $r->user();
        $g = $this->gradeOrPick();
        $lesson->load('unit');
        if (!Curriculum::canViewLesson($lesson, $u, $g)) {
            // Bài chưa xuất bản / khác lớp: không lộ nội dung khi đoán URL.
            $publishedInGrade = $lesson->isAvailable() && $g && Curriculum::canViewLesson($lesson->replicate()->forceFill(['is_public' => true])->setRelation('unit', $lesson->unit), null, $g);
            if (!$u && $publishedInGrade) {
                return redirect()->route('login', ['next' => $r->getRequestUri()])->with('info', 'Bài này dành cho tài khoản học sinh. Đăng nhập để học và lưu tiến độ nhé!');
            }
            abort(404);
        }
        $vocab = LexiconItem::whereIn('id', $lesson->content['vocab_ids'] ?? [])->where('status', 'published')->get();
        $progress = $u ? \App\Models\LessonProgress::where('user_id', $u->id)->where('lesson_id', $lesson->id)->where('grade_level', $g)->first() : null;
        $open = $u ? \App\Models\Attempt::where('user_id', $u->id)->where('kind', 'lesson')->where('ref_id', $lesson->id)->where('status', 'in_progress')->latest('id')->first() : null;
        return view('learn.lesson', ['lesson' => $lesson, 'vocab' => $vocab, 'grade' => $g, 'progress' => $progress, 'open' => $open,
            'questionCount' => $lesson->questions()->where('status', 'published')->count()]);
    }

    public function skills(Request $r)
    {
        $g = $this->gradeOrPick();
        if (!$g) return redirect()->route('grade.pick', ['next' => $r->getRequestUri()]);
        $counts = Question::published()->where('grade_id', $g)->groupBy('skill')->selectRaw('skill, COUNT(*) c')->pluck('c', 'skill');
        $stats = $r->user() ? SkillStat::where('user_id', $r->user()->id)->where('grade_level', $g)->where('tag', '')->get()->keyBy('skill') : collect();
        return view('learn.skills', ['grade' => $g, 'counts' => $counts, 'stats' => $stats]);
    }

    /** Trang Luyện tập: chọn một cách luyện, xem hoạt động gần đây và gợi ý. */
    public function practice(Request $r)
    {
        $g = $this->gradeOrPick();
        if (!$g) return redirect()->route('grade.pick', ['next' => $r->getRequestUri()]);
        $u = $r->user();
        $counts = Question::published()->where('grade_id', $g)->whereIn('type', QuestionPicker::autoTypes())
            ->groupBy('skill')->selectRaw('skill, COUNT(*) c')->pluck('c', 'skill');
        $data = ['grade' => $g, 'counts' => $counts, 'total' => $counts->sum(), 'path' => Curriculum::path($g, $u)];
        if ($u) {
            $data['due'] = Curriculum::dueCount($u->id, $g);
            $data['mistakes'] = SrsCard::where('user_id', $u->id)->where('grade_level', $g)->where('item_type', 'question')->where('lapses', '>', 0)->where('stage', '<', 3)->count();
            $data['recent'] = \App\Models\Attempt::where('user_id', $u->id)->where('status', 'submitted')->whereIn('kind', ['lesson', 'review', 'exam', 'assignment'])
                ->latest('submitted_at')->limit(5)->get(['id', 'kind', 'title', 'score_100', 'correct', 'total', 'submitted_at']);
            $data['weak'] = SkillStat::where('user_id', $u->id)->where('grade_level', $g)->where('tag', '')->where('total', '>=', 5)
                ->orderByRaw('correct / total')->first();
        }
        return view('learn.practice', $data);
    }

    public function skill(Request $r, string $skill)
    {
        abort_unless(array_key_exists($skill, Question::SKILLS), 404);
        $g = $this->gradeOrPick();
        if (!$g) return redirect()->route('grade.pick', ['next' => $r->getRequestUri()]);
        if ($skill === 'pronunciation') return redirect()->route('learn.pronunciation');
        $count = QuestionPicker::availableCount($g, [$skill]);
        $examples = [];
        if ($skill === 'speaking') {
            // câu mẫu để luyện nói (shadowing) lấy từ câu sắp xếp/hội thoại đã duyệt đúng lớp
            $examples = Question::published()->where('grade_id', $g)->whereIn('type', ['word_order'])->inRandomOrder()->limit(8)->get()
                ->map(fn ($q) => $q->answer['correct'] ?? null)->filter()->values();
        }
        $weak = $r->user() ? SkillStat::where('user_id', $r->user()->id)->where('grade_level', $g)->where('skill', $skill)->where('tag', '<>', '')
            ->whereColumn('correct', '<', DB::raw('total * 0.7'))->orderByDesc('total')->limit(4)->get() : collect();
        return view('learn.skill', ['grade' => $g, 'skill' => $skill, 'count' => $count, 'examples' => $examples, 'weak' => $weak]);
    }

    public function words(Request $r)
    {
        $g = $this->gradeOrPick();
        if (!$g) return redirect()->route('grade.pick', ['next' => $r->getRequestUri()]);
        $u = $r->user();
        $topic = $r->query('chu-de');
        $q = LexiconItem::where('status', 'published')->where('grade_id', '<=', $g);
        $topics = (clone $q)->whereNotNull('topic')->distinct()->orderBy('topic')->pluck('topic');
        if ($topic === 'khac') $q->whereNull('topic');
        elseif ($topic) $q->where('topic', $topic);
        $search = trim((string) $r->query('tim'));
        if ($search !== '') $q->where(fn ($w) => $w->where('word', 'like', '%' . $search . '%')->orWhere('meaning_vi', 'like', '%' . $search . '%'));
        $words = $q->orderByDesc('grade_id')->orderBy('word')->paginate(30)->withQueryString();
        $due = $u ? Curriculum::dueCount($u->id, $g)['words'] : 0;

        // thẻ chủ đề: số từ, hình đại diện, số từ bạn đã học
        $learnedByTopic = $u ? DB::table('srs_cards')->join('lexicon_items', 'lexicon_items.id', '=', 'srs_cards.item_id')
            ->where('srs_cards.user_id', $u->id)->where('srs_cards.item_type', 'word')
            ->groupBy('lexicon_items.topic')->selectRaw("COALESCE(lexicon_items.topic, '') t, COUNT(*) c")->pluck('c', 't') : collect();
        $topicCards = LexiconItem::where('status', 'published')->where('grade_id', '<=', $g)->groupBy('topic')
            ->selectRaw("topic, COUNT(*) c, MAX(emoji) e")->orderByRaw('topic IS NULL')->orderByDesc('c')->get()
            ->map(fn ($t) => ['key' => $t->topic ?? 'khac', 'name' => $t->topic ?? 'Từ khác', 'count' => (int) $t->c,
                'emoji' => LexiconItem::where('status', 'published')->where('topic', $t->topic)->whereNotNull('emoji')->where('emoji', '<>', '')->value('emoji') ?: '📘',
                'learned' => min((int) $t->c, (int) ($learnedByTopic[$t->topic ?? ''] ?? 0))]);

        // mức nhớ: 0 mới học → 1 nhớ tạm → 2 nhớ lâu → 3 thuộc lòng
        $levels = $u ? SrsCard::where('user_id', $u->id)->where('item_type', 'word')->groupBy('stage')->selectRaw('LEAST(stage, 3) s, COUNT(*) c')->pluck('c', 's') : collect();

        return view('learn.words', ['grade' => $g, 'words' => $words, 'topics' => $topics, 'topic' => $topic, 'search' => $search, 'due' => $due,
            'topicCards' => $topicCards, 'levels' => $levels, 'browsing' => $topic || $search !== '' || $r->query('page')]);
    }

    public function pronunciation(Request $r)
    {
        $g = $this->gradeOrPick();
        if (!$g) return redirect()->route('grade.pick', ['next' => $r->getRequestUri()]);
        $count = QuestionPicker::availableCount($g, ['pronunciation']);
        return view('learn.pronunciation', ['grade' => $g, 'chart' => Pronunciation::chart(), 'pairs' => Pronunciation::minimalPairs(),
            'focus' => Pronunciation::vietnameseFocus(), 'count' => $count]);
    }

    public function review(Request $r)
    {
        $u = $r->user();
        $g = current_grade();
        if (!$g) return redirect()->route('grade.pick', ['next' => $r->getRequestUri()]);
        $due = Curriculum::dueCount($u->id, $g);
        $next = SrsCard::where('user_id', $u->id)->where('grade_level', $g)->where('due_at', '>', now())->where('stage', '<', 3)->min('due_at');
        $weak = SkillStat::where('user_id', $u->id)->where('grade_level', $g)->where('tag', '<>', '')->where('total', '>=', 2)
            ->whereColumn('correct', '<', DB::raw('total * 0.7'))->orderByRaw('correct / total')->limit(6)->get();
        $counts = [
            'learning' => SrsCard::where('user_id', $u->id)->where('grade_level', $g)->where('stage', '<', 3)->count(),
            'mastered' => SrsCard::where('user_id', $u->id)->where('grade_level', $g)->where('stage', '>=', 3)->count(),
        ];
        return view('learn.review', ['grade' => $g, 'due' => $due, 'next' => $next, 'weak' => $weak, 'counts' => $counts]);
    }

    public function mistakes(Request $r)
    {
        $u = $r->user();
        $g = current_grade();
        if (!$g) return redirect()->route('grade.pick');
        $cards = SrsCard::where('user_id', $u->id)->where('grade_level', $g)->where('item_type', 'question')
            ->orderByRaw('stage >= 3')->orderBy('due_at')->paginate(20);
        $questions = Question::whereIn('id', $cards->pluck('item_id'))->get()->keyBy('id');
        return view('learn.mistakes', ['grade' => $g, 'cards' => $cards, 'questions' => $questions]);
    }

    protected function pendingAssignments(int $studentId)
    {
        $classIds = DB::table('classroom_members')->where('student_id', $studentId)->where('status', 'active')->pluck('classroom_id');
        return Assignment::whereIn('classroom_id', $classIds)->where('status', 'published')
            ->where(fn ($q) => $q->where('target', 'class')->orWhereExists(fn ($e) => $e->from('assignment_targets')->whereColumn('assignment_targets.assignment_id', 'assignments.id')->where('student_id', $studentId)))
            ->whereNotExists(fn ($e) => $e->from('assignment_submissions')->whereColumn('assignment_submissions.assignment_id', 'assignments.id')->where('student_id', $studentId)->whereIn('status', ['submitted', 'graded', 'returned']))
            ->get();
    }
}
