<?php

namespace App\Http\Controllers;

use App\Models\TermsVersion;
use App\Services\Accounts;
use App\Support\Nav;
use Illuminate\Http\Request;

class TermsController extends Controller
{
    public function show(Request $r)
    {
        $t = TermsVersion::where('is_active', true)->firstOrFail();
        return view('auth.terms', ['terms' => $t, 'next' => $r->query('next')]);
    }

    public function accept(Request $r)
    {
        $r->validate(['agree' => 'accepted', 'version' => 'required|string'], ['agree.accepted' => 'Bạn cần tích đồng ý để tiếp tục.']);
        $t = TermsVersion::where('is_active', true)->firstOrFail();
        if ($r->input('version') !== $t->version) return back()->with('error', 'Điều khoản vừa được cập nhật, vui lòng đọc lại bản mới.');
        Accounts::recordConsent($r->user(), $t, $r);
        return redirect()->to(safe_next($r->input('next')) ?: Nav::home($r->user()));
    }
}
