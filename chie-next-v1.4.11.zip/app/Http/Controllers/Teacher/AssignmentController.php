<?php

namespace App\Http\Controllers\Teacher;

use App\Http\Controllers\Controller;
use App\Models\Assignment;
use App\Models\AssignmentSubmission;
use App\Models\AssignmentTarget;
use App\Models\Classroom;
use App\Models\ClassroomMember;
use App\Models\ExamBlueprint;
use App\Models\Lesson;
use App\Models\Question;
use App\Services\AttemptService;
use App\Services\DomainError;
use App\Services\Notifier;
use App\Services\QuestionPicker;
use App\Support\Audit;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class AssignmentController extends Controller
{
    public function create(Request $r)
    {
        $ids = $r->user()->teachingClassroomIds();
        $classes = Classroom::whereIn('id', $ids)->orderBy('grade_level')->get();
        $cid = (int) $r->query('lop', $classes->first()->id ?? 0);
        $class = $classes->firstWhere('id', $cid);
        $lessons = $class ? Lesson::with('unit')->where('status', 'published')->whereHas('unit', fn ($q) => $q->where('status', 'published')->forGrade($class->grade_level))->orderBy('unit_id')->orderBy('sort')->get() : collect();
        $blueprints = $class ? ExamBlueprint::forGrade($class->grade_level)->where('is_active', true)->orderBy('sort')->get() : collect();
        $students = $class ? $class->students()->orderBy('name')->get() : collect();
        $counts = $class ? Question::published()->where('grade_id', $class->grade_level)->whereIn('type', Question::AUTO_GRADED)->groupBy('skill')->selectRaw('skill, COUNT(*) c')->pluck('c', 'skill') : collect();
        return view('teacher.assign', compact('classes', 'class', 'lessons', 'blueprints', 'students', 'counts'));
    }

    public function store(Request $r)
    {
        $data = $r->validate([
            'classroom_id' => 'required|integer', 'title' => 'required|string|max:190', 'instructions' => 'nullable|string|max:3000',
            'type' => 'required|in:lesson,practice,exam,writing,speaking',
            'lesson_id' => 'required_if:type,lesson|nullable|integer', 'blueprint_id' => 'required_if:type,exam|nullable|integer',
            'practice_skill' => 'nullable|string', 'practice_count' => 'required_if:type,practice|nullable|integer|min:5|max:40',
            'prompt_text' => 'required_if:type,writing|required_if:type,speaking|nullable|string|max:2000',
            'min_score' => 'nullable|integer|min:0|max:100', 'due_at' => 'nullable|date|after:now', 'available_from' => 'nullable|date',
            'target' => 'required|in:class,students', 'students' => 'required_if:target,students|array', 'students.*' => 'integer',
        ], ['due_at.after' => 'Hạn nộp phải ở tương lai.'], ['title' => 'tiêu đề', 'lesson_id' => 'bài học', 'blueprint_id' => 'đề', 'prompt_text' => 'đề bài', 'students' => 'học sinh']);
        $c = TeacherController::classOf($r, (int) $data['classroom_id']);
        $attrs = ['classroom_id' => $c->id, 'teacher_id' => $r->user()->id, 'title' => $data['title'], 'instructions' => $data['instructions'] ?? null,
            'type' => $data['type'], 'min_score' => (int) ($data['min_score'] ?? 0), 'target' => $data['target'],
            'due_at' => $data['due_at'] ?? null, 'available_from' => $data['available_from'] ?? null, 'status' => 'published'];
        if ($data['type'] === 'lesson') {
            $lesson = Lesson::with('unit')->findOrFail($data['lesson_id']);
            abort_unless($lesson->isAvailable() && \App\Models\Unit::forGrade($c->grade_level)->whereKey($lesson->unit_id)->exists(), 422, 'Bài học không thuộc khối lớp này.');
            $attrs['lesson_id'] = $lesson->id;
        } elseif ($data['type'] === 'exam') {
            $bp = ExamBlueprint::forGrade($c->grade_level)->findOrFail($data['blueprint_id']);
            $attrs['blueprint_id'] = $bp->id;
        } elseif ($data['type'] === 'practice') {
            $skills = array_key_exists($data['practice_skill'] ?? '', Question::SKILLS) ? [$data['practice_skill']] : [];
            $qs = QuestionPicker::pick($c->grade_level, (int) $data['practice_count'], null, [], array_filter(['skills' => $skills ?: null]));
            if ($qs->count() < 5) throw new DomainError('Ngân hàng câu đã duyệt của ' . grade_name($c->grade_level) . ' chưa đủ cho yêu cầu này.');
            $attrs['question_ids'] = $qs->pluck('id')->all();
        } else {
            $attrs['prompt_text'] = $data['prompt_text'];
        }
        $memberIds = ClassroomMember::where('classroom_id', $c->id)->where('status', 'active')->pluck('student_id')->all();
        $targets = $data['target'] === 'students' ? array_values(array_intersect(array_map('intval', $data['students'] ?? []), $memberIds)) : $memberIds;
        if ($data['target'] === 'students' && !$targets) throw new DomainError('Hãy chọn ít nhất một học sinh trong lớp.');
        $a = DB::transaction(function () use ($attrs, $data, $targets) {
            $a = Assignment::create($attrs);
            if ($data['target'] === 'students') foreach ($targets as $sid) AssignmentTarget::create(['assignment_id' => $a->id, 'student_id' => $sid]);
            return $a;
        });
        Notifier::many($targets, 'assignment', 'Bài mới: ' . $a->title, $a->due_at ? 'Hạn nộp ' . $a->due_at->format('H:i d/m') : null, route('learn.assignment', $a->id));
        Audit::log('assignment.created', $a, null, ['classroom_id' => $c->id, 'type' => $a->type, 'targets' => count($targets)]);
        return redirect()->route('teacher.assignment', $a)->with('success', 'Đã giao bài cho ' . count($targets) . ' học sinh.');
    }

    protected function own(Request $r, int $id): Assignment
    {
        $a = Assignment::with('classroom')->findOrFail($id);
        abort_unless(in_array($a->classroom_id, $r->user()->teachingClassroomIds(), true), 404);
        return $a;
    }

    public function show(Request $r, int $assignment)
    {
        $a = $this->own($r, $assignment);
        $memberIds = ClassroomMember::where('classroom_id', $a->classroom_id)->where('status', 'active')->pluck('student_id');
        $targetIds = $a->target === 'class' ? $memberIds : AssignmentTarget::where('assignment_id', $a->id)->pluck('student_id');
        $students = \App\Models\User::whereIn('id', $targetIds)->orderBy('name')->get();
        $subs = AssignmentSubmission::where('assignment_id', $a->id)->get()->keyBy('student_id');
        return view('teacher.assignment', compact('a', 'students', 'subs'));
    }

    public function close(Request $r, int $assignment)
    {
        $a = $this->own($r, $assignment);
        $a->update(['status' => $a->status === 'published' ? 'closed' : 'published']);
        Audit::log('assignment.' . $a->status, $a);
        return back()->with('success', $a->status === 'closed' ? 'Đã đóng bài — học sinh không nộp thêm được.' : 'Đã mở lại bài.');
    }

    public function grading(Request $r)
    {
        $ids = $r->user()->teachingClassroomIds();
        $pending = AssignmentSubmission::with(['assignment.classroom', 'student'])->whereHas('assignment', fn ($q) => $q->whereIn('classroom_id', $ids))
            ->where('status', 'submitted')->orderBy('submitted_at')->paginate(25);
        return view('teacher.grading', ['pending' => $pending]);
    }

    protected function ownSubmission(Request $r, int $id): AssignmentSubmission
    {
        $s = AssignmentSubmission::with(['assignment.classroom', 'student', 'attempt'])->findOrFail($id);
        abort_unless(in_array($s->assignment->classroom_id, $r->user()->teachingClassroomIds(), true), 404);
        return $s;
    }

    public function submission(Request $r, int $submission)
    {
        $s = $this->ownSubmission($r, $submission);
        $view = $s->attempt && $s->attempt->status === 'submitted' ? AttemptService::view($s->attempt) : null;
        return view('teacher.submission', ['s' => $s, 'view' => $view]);
    }

    public function grade(Request $r, int $submission)
    {
        $s = $this->ownSubmission($r, $submission);
        $data = $r->validate(['teacher_score' => 'nullable|integer|min:0|max:100', 'feedback' => 'nullable|string|max:3000', 'share_feedback_with_parent' => 'nullable|boolean']);
        $old = $s->only(['teacher_score', 'feedback', 'status']);
        $s->update(['teacher_score' => $data['teacher_score'] ?? null, 'feedback' => $data['feedback'] ?? null,
            'share_feedback_with_parent' => (bool) ($data['share_feedback_with_parent'] ?? false), 'status' => 'graded', 'graded_by' => $r->user()->id, 'graded_at' => now()]);
        Audit::log('submission.graded', $s, $old, $s->only(['teacher_score', 'feedback', 'status']));
        Notifier::send($s->student_id, 'graded', 'Giáo viên đã chấm "' . $s->assignment->title . '"', $data['feedback'] ?? null, route('learn.assignment', $s->assignment_id));
        return redirect()->route('teacher.grading')->with('success', 'Đã lưu điểm và nhận xét cho ' . $s->student->name . '.');
    }
}
