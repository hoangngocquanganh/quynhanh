<?php

namespace App\Http\Controllers\Teacher;

use App\Http\Controllers\Controller;
use App\Models\Question;
use App\Services\DomainError;
use App\Services\QuestionForm;
use App\Support\Audit;
use App\Support\Settings;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

/** Giáo viên soạn câu hỏi → "chờ duyệt"; chỉ Admin/biên tập được cấp quyền mới xuất bản. */
class ContentController extends Controller
{
    protected function allowed(): void
    {
        if (!Settings::get('content.teachers_can_author', true)) throw new DomainError('Admin chưa cấp quyền soạn học liệu cho giáo viên.');
    }

    public function index(Request $r)
    {
        $items = Question::where('created_by', $r->user()->id)->latest('id')->paginate(20);
        return view('teacher.content', ['items' => $items, 'allowed' => (bool) Settings::get('content.teachers_can_author', true)]);
    }

    public function create(Request $r)
    {
        $this->allowed();
        return view('teacher.content-form', ['f' => QuestionForm::toForm(null), 'action' => route('teacher.content.store'), 'admin' => false, 'q' => null]);
    }

    public function store(Request $r)
    {
        $this->allowed();
        $attrs = QuestionForm::parse($r);
        $hash = Question::hashContent($attrs['prompt']['text'], $attrs['options'] ?? [], $attrs['answer']);
        if (Question::where('content_hash', $hash)->exists()) throw new DomainError('Câu hỏi này đã có trong ngân hàng.');
        $q = DB::transaction(function () use ($attrs, $hash, $r) {
            $q = Question::create($attrs + ['subject_id' => DB::table('subjects')->where('code', 'en')->value('id'), 'status' => 'review', 'version' => 1,
                'content_hash' => $hash, 'source' => 'teacher', 'created_by' => $r->user()->id]);
            $q->versions()->create(['version' => 1, 'snapshot' => $q->snapshot(), 'created_by' => $r->user()->id, 'created_at' => now()]);
            return $q;
        });
        Audit::log('question.created_by_teacher', $q);
        return redirect()->route('teacher.content')->with('success', 'Đã gửi câu hỏi #' . $q->id . ' chờ Admin duyệt.');
    }
}
