<?php

namespace App\Http\Controllers\Teacher;

use App\Http\Controllers\Controller;
use App\Models\Assignment;
use App\Models\AssignmentSubmission;
use App\Models\ClassInvite;
use App\Models\Classroom;
use App\Models\ClassroomMember;
use App\Models\ClassroomTeacher;
use App\Models\User;
use App\Services\DomainError;
use App\Services\LiveStatus;
use App\Services\Notifier;
use App\Services\StudentReport;
use App\Support\Audit;
use App\Support\Settings;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

/**
 * Giáo viên chỉ thao tác trên lớp ĐANG được phân công (kiểm tra ở máy chủ mỗi request).
 * Không thấy Xu/túi đồ, không sửa số dư/lịch sử điểm, không truy cập cấu hình hệ thống.
 */
class TeacherController extends Controller
{
    public static function classOf(Request $r, int $id): Classroom
    {
        abort_unless(in_array($id, $r->user()->teachingClassroomIds(), true), 404);
        return Classroom::findOrFail($id);
    }

    public function pending(Request $r)
    {
        $u = $r->user();
        if ($u->isApprovedTeacher()) return redirect()->route('teacher.home');
        abort_unless($u->isTeacher(), 404);
        return view('teacher.pending', ['u' => $u]);
    }

    public function home(Request $r)
    {
        $ids = $r->user()->teachingClassroomIds();
        $classes = Classroom::whereIn('id', $ids)->withCount(['activeMembers', 'members as pending_count' => fn ($q) => $q->where('status', 'pending')])->orderBy('grade_level')->get();
        $toGrade = AssignmentSubmission::whereHas('assignment', fn ($q) => $q->whereIn('classroom_id', $ids)->whereIn('type', ['writing', 'speaking']))->where('status', 'submitted')->count();
        return view('teacher.home', ['classes' => $classes, 'toGrade' => $toGrade, 'canCreate' => (bool) Settings::get('classes.teachers_can_create', true)]);
    }

    public function createClass(Request $r)
    {
        if (!Settings::get('classes.teachers_can_create', true)) throw new DomainError('Admin chưa cho phép giáo viên tự tạo lớp. Hãy liên hệ Admin để được phân công lớp.');
        $data = $r->validate(['name' => 'required|string|max:120', 'grade_level' => 'required|integer|min:1|max:12', 'school_name' => 'nullable|string|max:190',
            'school_year' => 'nullable|string|max:20', 'join_policy' => 'required|in:auto,approval'], [], ['name' => 'tên lớp', 'grade_level' => 'khối lớp']);
        $c = DB::transaction(function () use ($data, $r) {
            $c = Classroom::create($data + ['status' => 'active', 'created_by' => $r->user()->id]);
            ClassroomTeacher::create(['classroom_id' => $c->id, 'teacher_id' => $r->user()->id, 'role' => 'main', 'assigned_at' => now(), 'assigned_by' => $r->user()->id]);
            static::newInvite($c, $r->user()->id);
            return $c;
        });
        Audit::log('class.created', $c, null, $data);
        return redirect()->route('teacher.class', $c)->with('success', 'Đã tạo lớp ' . $c->name . '. Gửi mã mời cho học sinh để vào lớp.');
    }

    public static function newInvite(Classroom $c, int $by, ?int $days = null, ?int $max = null): ClassInvite
    {
        $alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
        do {
            $code = '';
            for ($i = 0; $i < 8; $i++) $code .= $alphabet[random_int(0, strlen($alphabet) - 1)];
        } while (ClassInvite::where('code', $code)->exists());
        return ClassInvite::create(['classroom_id' => $c->id, 'code' => $code, 'expires_at' => now()->addDays($days ?? (int) Settings::get('classes.invite_days', 14)),
            'max_uses' => $max ?? (int) Settings::get('classes.invite_max_uses', 60), 'created_by' => $by]);
    }

    public function classroom(Request $r, int $classroom)
    {
        $c = static::classOf($r, $classroom);
        $members = ClassroomMember::with('student')->where('classroom_id', $c->id)->whereIn('status', ['active', 'pending'])->get();
        $sids = $members->where('status', 'active')->pluck('student_id');
        $live = DB::table('user_live_status')->whereIn('user_id', $sids)->get()->keyBy('user_id');
        $avg = DB::table('attempts')->whereIn('user_id', $sids)->where('status', 'submitted')->whereNotNull('score_100')->where('submitted_at', '>=', now()->subDays(30))
            ->groupBy('user_id')->selectRaw('user_id, ROUND(AVG(score_100)) a, COUNT(*) n')->get()->keyBy('user_id');
        $done = DB::table('lesson_progress')->whereIn('user_id', $sids)->where('grade_level', $c->grade_level)->whereIn('status', ['completed', 'mastered'])
            ->groupBy('user_id')->selectRaw('user_id, COUNT(*) n')->pluck('n', 'user_id');
        // câu cả lớp hay sai nhất (30 ngày)
        $missed = DB::table('attempt_items')->join('attempts', 'attempts.id', '=', 'attempt_items.attempt_id')
            ->whereIn('attempts.user_id', $sids)->where('attempts.started_at', '>=', now()->subDays(30))->whereNotNull('attempt_items.question_id')->whereNotNull('attempt_items.answered_at')
            ->groupBy('attempt_items.question_id')->selectRaw('attempt_items.question_id, SUM(attempt_items.is_correct = 0) wrong, COUNT(*) total')
            ->havingRaw('SUM(attempt_items.is_correct = 0) > 0')->orderByDesc('wrong')->limit(5)->get();
        $missedQ = \App\Models\Question::whereIn('id', $missed->pluck('question_id'))->get()->keyBy('id');
        $assignments = Assignment::where('classroom_id', $c->id)->withCount(['submissions as done_count' => fn ($q) => $q->whereIn('status', ['submitted', 'graded', 'returned'])])->latest('id')->limit(20)->get();
        $invites = ClassInvite::where('classroom_id', $c->id)->latest('id')->get();
        $teachers = $c->teachers()->get();
        return view('teacher.class', compact('c', 'members', 'live', 'avg', 'done', 'missed', 'missedQ', 'assignments', 'invites', 'teachers'));
    }

    public function createInvite(Request $r, int $classroom)
    {
        $c = static::classOf($r, $classroom);
        $data = $r->validate(['days' => 'nullable|integer|min:1|max:90', 'max_uses' => 'nullable|integer|min:1|max:500']);
        $inv = static::newInvite($c, $r->user()->id, $data['days'] ?? null, $data['max_uses'] ?? null);
        Audit::log('class.invite_created', $c, null, ['code' => $inv->code]);
        return back()->with('success', 'Đã tạo mã mời ' . $inv->code . '.');
    }

    public function revokeInvite(Request $r, int $classroom, int $invite)
    {
        $c = static::classOf($r, $classroom);
        $inv = ClassInvite::where('classroom_id', $c->id)->findOrFail($invite);
        $inv->update(['revoked_at' => now()]);
        Audit::log('class.invite_revoked', $c, null, ['code' => $inv->code]);
        return back()->with('success', 'Đã thu hồi mã ' . $inv->code . '.');
    }

    public function member(Request $r, int $classroom, int $member, string $action)
    {
        $c = static::classOf($r, $classroom);
        $m = ClassroomMember::where('classroom_id', $c->id)->findOrFail($member);
        if ($action === 'approve' && $m->status === 'pending') {
            $m->update(['status' => 'active', 'joined_at' => now(), 'changed_by' => $r->user()->id]);
            Notifier::send($m->student_id, 'class', 'Bạn đã được duyệt vào lớp ' . $c->name);
        } elseif ($action === 'remove' && in_array($m->status, ['active', 'pending'])) {
            $m->update(['status' => 'removed', 'left_at' => now(), 'changed_by' => $r->user()->id]);
        } else {
            return back();
        }
        Audit::log('class.member_' . $action, $c, null, ['student_id' => $m->student_id]);
        return back()->with('success', $action === 'approve' ? 'Đã duyệt học sinh vào lớp.' : 'Đã xóa học sinh khỏi lớp.');
    }

    public function student(Request $r, int $classroom, int $student)
    {
        $c = static::classOf($r, $classroom);
        abort_unless(ClassroomMember::where('classroom_id', $c->id)->where('student_id', $student)->where('status', 'active')->exists(), 404);
        $s = User::findOrFail($student);
        return view('teacher.student', ['c' => $c, 's' => $s, 'rep' => StudentReport::build($s, false)]);
    }

    public function reports(Request $r)
    {
        $ids = $r->user()->teachingClassroomIds();
        $rows = [];
        foreach (Classroom::whereIn('id', $ids)->get() as $c) {
            $sids = ClassroomMember::where('classroom_id', $c->id)->where('status', 'active')->pluck('student_id');
            $as = Assignment::where('classroom_id', $c->id)->where('status', 'published')->get();
            $expected = 0; $done = 0; $late = 0;
            foreach ($as as $a) {
                $targets = $a->target === 'class' ? $sids : DB::table('assignment_targets')->where('assignment_id', $a->id)->whereIn('student_id', $sids)->pluck('student_id');
                $expected += count($targets);
                $subs = AssignmentSubmission::where('assignment_id', $a->id)->whereIn('student_id', $targets)->whereIn('status', ['submitted', 'graded', 'returned']);
                $done += (clone $subs)->count();
                $late += (clone $subs)->where('is_late', true)->count();
            }
            $avg = DB::table('attempts')->whereIn('user_id', $sids)->where('status', 'submitted')->whereNotNull('score_100')->where('submitted_at', '>=', now()->subDays(30))->avg('score_100');
            $weak = DB::table('skill_stats')->whereIn('user_id', $sids)->where('tag', '<>', '')->groupBy('tag')
                ->selectRaw('tag, SUM(correct) c, SUM(total) t')->havingRaw('SUM(total) >= 5 AND SUM(correct) < SUM(total) * 0.7')->orderByRaw('SUM(correct)/SUM(total)')->limit(3)->get();
            $rows[] = ['c' => $c, 'students' => count($sids), 'expected' => $expected, 'done' => $done, 'late' => $late, 'avg' => $avg !== null ? (int) round($avg) : null, 'weak' => $weak];
        }
        return view('teacher.reports', ['rows' => $rows]);
    }
}
