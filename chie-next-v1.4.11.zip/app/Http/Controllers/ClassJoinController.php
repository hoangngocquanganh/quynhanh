<?php

namespace App\Http\Controllers;

use App\Models\ClassInvite;
use App\Models\ClassroomMember;
use App\Services\Notifier;
use App\Support\Audit;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

/** Học sinh tham gia/rời lớp của giáo viên bằng mã mời có thời hạn, giới hạn lượt, thu hồi được. */
class ClassJoinController extends Controller
{
    public function join(Request $r)
    {
        $data = $r->validate(['code' => 'required|string|max:20'], [], ['code' => 'mã lớp']);
        $code = strtoupper(preg_replace('/[^A-Za-z0-9]/', '', $data['code']));
        $u = $r->user();
        return DB::transaction(function () use ($code, $u) {
            $inv = ClassInvite::with('classroom')->where('code', $code)->lockForUpdate()->first();
            if (!$inv || !$inv->isUsable() || $inv->classroom->status !== 'active') {
                return back()->withErrors(['code' => 'Mã lớp không đúng, đã hết hạn hoặc đã bị thu hồi. Hãy hỏi lại giáo viên.']);
            }
            $m = ClassroomMember::where('classroom_id', $inv->classroom_id)->where('student_id', $u->id)->first();
            if ($m && in_array($m->status, ['active', 'pending'])) return back()->with('info', 'Bạn đã ở trong lớp ' . $inv->classroom->name . '.');
            $status = $inv->classroom->join_policy === 'approval' ? 'pending' : 'active';
            ClassroomMember::updateOrCreate(['classroom_id' => $inv->classroom_id, 'student_id' => $u->id],
                ['status' => $status, 'joined_at' => now(), 'left_at' => null, 'changed_by' => $u->id]);
            $inv->increment('uses');
            Audit::log('class.joined', $inv->classroom, null, ['student_id' => $u->id, 'status' => $status]);
            $teacherIds = DB::table('classroom_teachers')->where('classroom_id', $inv->classroom_id)->whereNull('revoked_at')->pluck('teacher_id');
            Notifier::many($teacherIds, 'class', $u->name . ($status === 'pending' ? ' xin vào lớp ' : ' đã vào lớp ') . $inv->classroom->name,
                null, route('teacher.class', $inv->classroom_id));
            $msg = $status === 'pending' ? 'Đã gửi yêu cầu vào lớp ' . $inv->classroom->name . '. Chờ giáo viên duyệt nhé.' : 'Bạn đã vào lớp ' . $inv->classroom->name . '!';
            if ($inv->classroom->grade_level !== $u->grade_level) $msg .= ' Lưu ý: lớp này dùng học liệu ' . grade_name($inv->classroom->grade_level) . ', bạn đang học ' . grade_name($u->grade_level) . ' — có thể đổi ở mục "Lớp học liệu".';
            return back()->with('success', $msg);
        });
    }

    public function leave(Request $r, ClassroomMember $member)
    {
        abort_unless($member->student_id === $r->user()->id && in_array($member->status, ['active', 'pending']), 404);
        $member->update(['status' => 'left', 'left_at' => now(), 'changed_by' => $r->user()->id]);
        Audit::log('class.left', $member->classroom);
        return back()->with('success', 'Bạn đã rời lớp ' . $member->classroom->name . '.');
    }
}
