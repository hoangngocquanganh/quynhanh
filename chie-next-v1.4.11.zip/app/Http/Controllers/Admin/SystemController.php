<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\AuditLog;
use App\Models\CheatFlag;
use App\Models\ErrorReport;
use App\Models\TermsVersion;
use App\Models\WordFilter;
use App\Support\Audit;
use App\Support\Settings;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;

class SystemController extends Controller
{
    /** Các khóa cấu hình chỉnh được ở trang Hệ thống (kinh tế/game chỉnh ở trang riêng). */
    public const KEYS = [
        'site.name' => ['Tên website', 'text'], 'site.contact_email' => ['Email liên hệ / báo bản quyền', 'text'],
        'auth.require_email_verification' => ['Bắt buộc xác minh email (cần SMTP)', 'bool'], 'auth.allow_teacher_signup' => ['Cho đăng ký tài khoản giáo viên', 'bool'],
        'auth.min_self_signup_age' => ['Tuổi tối thiểu học sinh tự đăng ký', 'int'], 'auth.grade_change_cooldown_days' => ['Số ngày chờ giữa 2 lần đổi lớp (0 = không giới hạn)', 'int'],
        'classes.teachers_can_create' => ['Giáo viên được tự tạo lớp', 'bool'], 'classes.invite_days' => ['Hạn mã mời mặc định (ngày)', 'int'], 'classes.invite_max_uses' => ['Số lượt tối đa của mã mời', 'int'],
        'content.teachers_can_author' => ['Giáo viên được soạn câu hỏi (chờ duyệt)', 'bool'], 'leaderboard.enabled' => ['Bật bảng xếp hạng', 'bool'],
        'learn.pass_score' => ['Điểm hoàn thành bài (thang 100)', 'int'], 'learn.mastery_score' => ['Điểm thành thạo', 'int'], 'learn.review_session_size' => ['Số mục mỗi lượt ôn', 'int'],
        'sticker.session_size' => ['Sticker: số câu mỗi lượt (4–12)', 'int'], 'sticker.xp_new' => ['Sticker: XP khi bóc sticker mới', 'int'], 'sticker.xp_gold' => ['Sticker: XP khi lên hạng vàng', 'int'], 'sticker.xp_pack' => ['Sticker: XP khi đủ gói', 'int'], 'sticker.xu_pack' => ['Sticker: Xu khi đủ gói', 'int'],
        'tts.default_rate' => ['Tốc độ đọc mặc định', 'float'], 'tts.slow_rate' => ['Tốc độ đọc chậm', 'float'],
        'wellbeing.break_reminder_minutes_primary' => ['Nhắc nghỉ sau (phút) — tiểu học', 'int'], 'wellbeing.break_reminder_minutes_secondary' => ['Nhắc nghỉ sau (phút) — THCS/THPT', 'int'],
    ];

    public function index()
    {
        $env = ['php' => PHP_VERSION, 'db' => DB::selectOne('SELECT VERSION() v')->v, 'mail' => config('mail.default'), 'debug' => config('app.debug'),
            'storage_writable' => is_writable(storage_path()), 'version' => config('chie.version')];
        return view('admin.system', ['keys' => self::KEYS, 'env' => $env]);
    }

    public function saveSettings(Request $r)
    {
        foreach (self::KEYS as $key => [$label, $type]) {
            $field = str_replace('.', '__', $key);
            if (!$r->has($field) && $type !== 'bool') continue;
            $v = $r->input($field);
            $v = match ($type) { 'bool' => (bool) $v, 'int' => max(0, (int) $v), 'float' => max(0.5, min(1.2, (float) $v)), default => mb_substr((string) $v, 0, 190) };
            $old = Settings::get($key);
            if ($old !== $v) {
                Settings::set($key, $v, $r->user()->id);
                Audit::log('settings.changed', ['Setting', null], [$key => $old], [$key => $v]);
            }
        }
        return back()->with('success', 'Đã lưu cấu hình (áp dụng cho các lượt tiếp theo).');
    }

    public function audit(Request $r)
    {
        $q = AuditLog::with('actor');
        if ($a = $r->query('hanh-dong')) $q->where('action', 'like', $a . '%');
        if ($u = (int) $r->query('nguoi')) $q->where('actor_user_id', $u);
        return view('admin.audit', ['items' => $q->orderByDesc('id')->paginate(50)->withQueryString()]);
    }

    public function errors()
    {
        $items = ErrorReport::with('user')->where('kind', 'client_error')->orderByRaw("status = 'resolved'")->latest('id')->paginate(30);
        $log = [];
        foreach (array_slice(glob(storage_path('logs/*.log')) ?: [], -2) as $f) {
            $lines = @file($f, FILE_IGNORE_NEW_LINES) ?: [];
            foreach (array_slice(preg_grep('/^\[\d{4}-/', $lines), -40) as $l) {
                $log[] = preg_replace(['/[\w.+-]+@[\w-]+\.[\w.]+/', '/\b\d{1,3}(\.\d{1,3}){3}\b/', '/(password|token|secret|key)[^,\s]*/i'], ['[email]', '[ip]', '[ẩn]'], mb_substr($l, 0, 400));
            }
        }
        return view('admin.errors', ['items' => $items, 'log' => array_reverse($log)]);
    }

    public function resolveError(ErrorReport $report)
    {
        $report->update(['status' => 'resolved']);
        return back();
    }

    public function terms()
    {
        return view('admin.terms', ['items' => TermsVersion::orderByDesc('id')->get()]);
    }

    /** Phát hành phiên bản điều khoản mới → mọi tài khoản phải đồng ý lại. */
    public function saveTerms(Request $r)
    {
        $data = $r->validate(['version' => 'required|string|max:20|unique:terms_versions,version|regex:/^terms-\d+$/', 'title' => 'required|string|max:190', 'content' => 'required|string|min:50']);
        DB::transaction(function () use ($data) {
            TermsVersion::query()->update(['is_active' => false]);
            TermsVersion::create($data + ['content_sha256' => hash('sha256', $data['content']), 'is_active' => true, 'published_at' => now()]);
        });
        Cache::forget('chie.terms.active');
        Audit::log('terms.published', null, null, ['version' => $data['version']]);
        return back()->with('success', 'Đã phát hành ' . $data['version'] . '. Người dùng sẽ được yêu cầu đồng ý lại khi truy cập.');
    }

    public function filters(Request $r)
    {
        $test = $r->query('thu');
        return view('admin.filters', ['items' => WordFilter::orderBy('list')->orderBy('term')->paginate(100), 'test' => $test,
            'result' => $test !== null ? (\App\Services\NameFilter::check($test) ?? 'Hợp lệ') : null]);
    }

    public function saveFilter(Request $r)
    {
        $data = $r->validate(['term' => 'required|string|max:80', 'list' => 'required|in:block,allow', 'category' => 'required|string|max:30', 'match' => 'required|in:word,substring']);
        WordFilter::updateOrCreate(['term' => mb_strtolower(trim($data['term'])), 'list' => $data['list']], $data);
        Cache::forget('chie.wordfilters');
        Audit::log('wordfilter.saved', null, null, $data);
        return back()->with('success', 'Đã lưu.');
    }

    public function deleteFilter(WordFilter $filter)
    {
        $filter->delete();
        Cache::forget('chie.wordfilters');
        Audit::log('wordfilter.deleted', null, ['term' => $filter->term]);
        return back()->with('success', 'Đã xóa.');
    }

    public function flags()
    {
        return view('admin.flags', ['items' => CheatFlag::with('user')->orderByRaw("status <> 'open'")->latest('id')->paginate(30)]);
    }

    public function resolveFlag(Request $r, CheatFlag $flag)
    {
        $data = $r->validate(['status' => 'required|in:dismissed,confirmed']);
        $flag->update(['status' => $data['status']]);
        Audit::log('cheatflag.' . $data['status'], $flag);
        return back()->with('success', 'Đã cập nhật. Hệ thống không tự trừ điểm; nếu cần thu hồi thưởng, hãy điều chỉnh Xu có ghi lý do.');
    }

    public function clearCache()
    {
        Artisan::call('cache:clear');
        Artisan::call('view:clear');
        Settings::flush();
        Audit::log('system.cache_cleared');
        return back()->with('success', 'Đã xóa bộ nhớ đệm.');
    }
}
