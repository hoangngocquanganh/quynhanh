<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\FarmCrop;
use App\Models\FarmRecipe;
use App\Models\GachaPool;
use App\Models\ShopItem;
use App\Models\XuLedger;
use App\Services\DomainError;
use App\Support\Audit;
use App\Support\Settings;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class EconomyController extends Controller
{
    public const KEYS = [
        'reward.xp_per_correct' => ['XP mỗi câu đúng', 'int'], 'reward.xu_per_xp' => ['Xu / XP', 'float'], 'reward.daily_xp_cap' => ['Trần XP/ngày (học + game)', 'int'],
        'reward.daily_xu_cap' => ['Trần Xu/ngày (học + game)', 'int'], 'reward.repeat_2_percent' => ['Làm lại lần 2 trong ngày (% thưởng)', 'int'], 'reward.repeat_3_percent' => ['Từ lần 3 (% thưởng)', 'int'],
        'reward.fast_answer_ms' => ['Ngưỡng trả lời quá nhanh (ms) để gắn cờ', 'int'],
        'shop.sell_back_percent' => ['Bán lại đồ mua (% giá gốc)', 'int'], 'shop.gacha_sell_price' => ['Giá thu mua đồ Gacha (Xu)', 'int'],
        'trade.weekly_per_pair' => ['Số lần đổi/tuần/cặp', 'int'], 'trade.new_account_days' => ['Tài khoản mới (ngày) chỉ đổi đồ Thường', 'int'], 'trade.curated_lock_days' => ['Khóa đổi đồ Tuyển chọn (ngày)', 'int'],
        'farm.start_plots' => ['Ô đất ban đầu', 'int'], 'farm.max_plots' => ['Ô đất tối đa', 'int'], 'farm.plot_price_base' => ['Giá mở ô đầu tiên', 'int'], 'farm.plot_price_step' => ['Tăng giá mỗi ô', 'int'],
        'farm.water_speedup_percent' => ['Tưới đúng: tăng tốc (%)', 'int'], 'farm.pest_chance_percent' => ['Tỉ lệ sâu (%)', 'int'], 'farm.inner_expand_price' => ['Giá mở rộng Kho Trong', 'int'],
        'farm.cold_price_per_hour' => ['Giá Kho Lạnh / giờ', 'int'], 'farm.cold_capacity' => ['Sức chứa Kho Lạnh', 'int'],
        'farm.shield_prices' => ['Giá khiên {giờ: Xu}', 'json'], 'farm.wall_prices' => ['Giá nâng tường {cấp: Xu}', 'json'],
        'raid.enabled' => ['Bật cướp trại', 'bool'], 'raid.fee_xu' => ['Phí đi cướp (đốt)', 'int'], 'raid.take_percent' => ['Lấy tối đa mỗi trận (%)', 'int'],
        'raid.daily_loss_cap_percent' => ['Trần mất mỗi ngày (%)', 'int'], 'raid.destroy_percent' => ['Hao hụt (%)', 'int'], 'raid.pair_per_day' => ['Cướp cùng 1 người / ngày', 'int'],
        'raid.pair_per_week' => ['Cướp cùng 1 người / tuần', 'int'], 'raid.min_level' => ['Cấp tối thiểu', 'int'], 'raid.stages_by_wall' => ['Số màn theo cấp tường {cấp: màn}', 'json'], 'raid.seconds_per_stage' => ['Giây mỗi màn', 'int'],
    ];

    public function index(Request $r)
    {
        $today = today();
        $flow = DB::table('xu_ledger')->where('created_at', '>=', now()->subDays(7))->groupBy('type')
            ->selectRaw('type, SUM(GREATEST(delta_xu,0)) earned, SUM(LEAST(delta_xu,0)) burned, COUNT(*) n')->get();
        return view('admin.economy', ['keys' => self::KEYS, 'items' => ShopItem::orderBy('category')->orderBy('rarity')->get(), 'pools' => GachaPool::with('items')->get(),
            'crops' => FarmCrop::orderBy('sort')->get(), 'recipes' => FarmRecipe::get(), 'flow' => $flow, 'edit' => $r->query('sua') ? ShopItem::find($r->query('sua')) : null,
            'totalXu' => (int) DB::table('wallets')->sum('xu')]);
    }

    public function settings(Request $r)
    {
        foreach (self::KEYS as $key => [$label, $type]) {
            $field = str_replace('.', '__', $key);
            if (!$r->has($field) && $type !== 'bool') continue;
            $v = $r->input($field);
            $v = match ($type) {
                'bool' => (bool) $v, 'int' => max(0, (int) $v), 'float' => max(0, (float) $v),
                'json' => is_array($d = json_decode((string) $v, true)) ? $d : throw new DomainError($label . ': JSON không hợp lệ.'),
            };
            $old = Settings::get($key);
            if ($old !== $v) { Settings::set($key, $v, $r->user()->id); Audit::log('economy.setting', ['Setting', null], [$key => $old], [$key => $v]); }
        }
        return back()->with('success', 'Đã lưu. Thông số mới áp dụng cho các lượt tiếp theo, không áp dụng ngược.');
    }

    public function saveItem(Request $r)
    {
        $d = $r->validate(['id' => 'nullable|integer', 'code' => 'required|alpha_dash|max:60', 'name_vi' => 'required|string|max:120', 'name_en' => 'nullable|string|max:120',
            'category' => 'required|in:decor,avatar_frame,title,farm_tool,gacha_only', 'rarity' => 'required|in:common,rare,epic,curated', 'price_xu' => 'nullable|integer|min:1|max:1000000',
            'min_level' => 'required|integer|min:1|max:200', 'icon' => 'required|string|max:40', 'beauty' => 'required|integer|min:0|max:1000', 'description' => 'nullable|string|max:255',
            'is_active' => 'nullable|boolean', 'season_ends_at' => 'nullable|date']);
        $item = !empty($d['id']) ? ShopItem::findOrFail($d['id']) : new ShopItem();
        $old = $item->exists ? $item->toArray() : null;
        unset($d['id']);
        $d['is_active'] = (bool) ($d['is_active'] ?? false);
        if ($d['category'] === 'gacha_only') $d['price_xu'] = null;
        $item->fill($d)->save();
        Audit::log($old ? 'shop.item_updated' : 'shop.item_created', $item, $old, $item->toArray());
        return redirect()->route('admin.economy')->with('success', 'Đã lưu vật phẩm.');
    }

    public function savePool(Request $r, GachaPool $pool)
    {
        $d = $r->validate(['price_xu' => 'required|integer|min:1', 'daily_limit' => 'required|integer|min:1|max:100', 'pity_threshold' => 'required|integer|min:2|max:10000',
            'rates' => 'required|array', 'rates.common' => 'required|numeric|min:0', 'rates.rare' => 'required|numeric|min:0', 'rates.epic' => 'required|numeric|min:0', 'rates.curated' => 'required|numeric|min:0',
            'items' => 'nullable|array', 'items.*' => 'integer', 'is_active' => 'nullable|boolean']);
        $rates = array_map('floatval', array_intersect_key($d['rates'], array_flip(['common', 'rare', 'epic', 'curated'])));
        if (abs(array_sum($rates) - 100) > 0.0001) throw new DomainError('Tổng tỉ lệ phải đúng 100% (hiện là ' . array_sum($rates) . '%). Chưa lưu.');
        $old = $pool->toArray();
        DB::transaction(function () use ($pool, $d, $rates) {
            $pool->update(['price_xu' => $d['price_xu'], 'daily_limit' => $d['daily_limit'], 'pity_threshold' => $d['pity_threshold'], 'rates' => $rates, 'is_active' => (bool) ($d['is_active'] ?? false)]);
            $pool->items()->sync($d['items'] ?? []);
        });
        Audit::log('gacha.pool_updated', $pool, $old, $pool->fresh()->toArray());
        return back()->with('success', 'Đã lưu Hòm quà.');
    }

    public function saveFarm(Request $r)
    {
        $d = $r->validate(['kind' => 'required|in:crop,recipe', 'id' => 'nullable|integer', 'code' => 'required|alpha_dash|max:40', 'name_vi' => 'required|string|max:80',
            'name_en' => 'required|string|max:80', 'icon' => 'required|string|max:16', 'is_active' => 'nullable|boolean',
            'grow_minutes' => 'required_if:kind,crop|nullable|integer|min:1|max:10080', 'seed_price' => 'required_if:kind,crop|nullable|integer|min:0', 'sell_price' => 'required|integer|min:0',
            'yield' => 'nullable|integer|min:1|max:50', 'min_level' => 'nullable|integer|min:1', 'words' => 'nullable|string|max:1000',
            'inputs' => 'required_if:kind,recipe|nullable|string|max:300', 'fee_xu' => 'nullable|integer|min:0', 'recipe_en' => 'required_if:kind,recipe|nullable|string|max:255']);
        if ($d['kind'] === 'crop') {
            $words = [];
            foreach (preg_split('/\r?\n/', (string) ($d['words'] ?? '')) as $l) { $p = array_map('trim', explode('=', $l, 2)); if (count($p) === 2 && $p[0] && $p[1]) $words[] = $p; }
            if (count($words) < 2) throw new DomainError('Cây cần ít nhất 2 từ vựng (mỗi dòng "word = nghĩa").');
            $m = !empty($d['id']) ? FarmCrop::findOrFail($d['id']) : new FarmCrop();
            $m->fill(['code' => $d['code'], 'name_vi' => $d['name_vi'], 'name_en' => $d['name_en'], 'icon' => $d['icon'], 'grow_minutes' => $d['grow_minutes'], 'seed_price' => $d['seed_price'],
                'sell_price' => $d['sell_price'], 'yield' => $d['yield'] ?? 2, 'min_level' => $d['min_level'] ?? 1, 'words' => $words, 'is_active' => (bool) ($d['is_active'] ?? false)])->save();
        } else {
            $inputs = [];
            foreach (array_filter(array_map('trim', explode(',', (string) $d['inputs']))) as $part) { [$c, $n] = array_pad(explode(':', $part), 2, 1); $inputs[trim($c)] = max(1, (int) $n); }
            if (!$inputs || FarmCrop::whereIn('code', array_keys($inputs))->count() !== count($inputs)) throw new DomainError('Nguyên liệu dạng "strawberry:2, wheat:1" với mã cây có thật.');
            $m = !empty($d['id']) ? FarmRecipe::findOrFail($d['id']) : new FarmRecipe();
            $m->fill(['code' => $d['code'], 'name_vi' => $d['name_vi'], 'name_en' => $d['name_en'], 'icon' => $d['icon'], 'inputs' => $inputs, 'fee_xu' => $d['fee_xu'] ?? 0,
                'sell_price' => $d['sell_price'], 'recipe_en' => $d['recipe_en'], 'is_active' => (bool) ($d['is_active'] ?? false)])->save();
        }
        Audit::log('farm.' . $d['kind'] . '_saved', $m, null, $m->toArray());
        return back()->with('success', 'Đã lưu.');
    }

    public function ledger(Request $r)
    {
        $q = XuLedger::query()->join('users', 'users.id', '=', 'xu_ledger.user_id')->select('xu_ledger.*', 'users.name');
        if ($t = $r->query('loai')) $q->where('type', $t);
        if ($u = (int) $r->query('nguoi')) $q->where('user_id', $u);
        return view('admin.ledger', ['items' => $q->orderByDesc('xu_ledger.id')->paginate(50)->withQueryString()]);
    }
}
