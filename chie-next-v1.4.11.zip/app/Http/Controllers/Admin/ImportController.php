<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\ImportRun;
use App\Services\ContentImporter;
use App\Support\Audit;
use Illuminate\Http\Request;

class ImportController extends Controller
{
    public function index()
    {
        return view('admin.import', ['packages' => ContentImporter::packages(), 'runs' => ImportRun::orderByDesc('id')->limit(20)->get()]);
    }

    public function run(Request $r)
    {
        $data = $r->validate(['package' => 'required|string', 'dry' => 'nullable|boolean']);
        $all = ContentImporter::packages();
        abort_unless(isset($all[$data['package']]), 404);
        @set_time_limit(300);
        $run = (new ContentImporter())->run($all[$data['package']]['file'], (bool) ($data['dry'] ?? false), $r->user()->id);
        Audit::log('content.import' . ($run->dry_run ? '_dry' : ''), $run, null, $run->stats);
        return redirect()->route('admin.import.show', $run)->with('success', $run->dry_run ? 'Đã chạy thử (không ghi CSDL).' : 'Đã nhập xong.');
    }

    public function show(ImportRun $run)
    {
        return view('admin.import-show', ['run' => $run]);
    }
}
