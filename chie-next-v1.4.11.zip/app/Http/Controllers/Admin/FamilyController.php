<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\GuardianLink;
use App\Models\User;
use App\Services\DomainError;
use App\Support\Audit;
use Illuminate\Http\Request;

class FamilyController extends Controller
{
    public function index(Request $r)
    {
        $q = GuardianLink::with(['parent', 'student']);
        if ($s = trim((string) $r->query('tim'))) $q->where(fn ($outer) => $outer->whereHas('parent', fn ($w) => $w->where('name', 'like', "%{$s}%")->orWhere('email', 'like', "%{$s}%"))
            ->orWhereHas('student', fn ($w) => $w->where('name', 'like', "%{$s}%")->orWhere('username', 'like', "%{$s}%")));
        return view('admin.families', ['links' => $q->orderByDesc('id')->paginate(30)->withQueryString()]);
    }

    /** Admin liên kết thủ công sau khi đã xác minh ngoài hệ thống (ghi nhật ký, bắt buộc ghi chú). */
    public function store(Request $r)
    {
        $data = $r->validate(['parent' => 'required|string', 'student' => 'required|string', 'note' => 'required|string|min:5|max:200'], [], ['note' => 'ghi chú xác minh']);
        $find = fn ($v, $role) => User::where('role', $role)->where(fn ($q) => $q->where('id', (int) $v)->orWhere('email', $v)->orWhere('username', $v))->first();
        $p = $find($data['parent'], 'parent');
        $s = $find($data['student'], 'student');
        if (!$p || !$s) throw new DomainError('Không tìm thấy phụ huynh hoặc học sinh (nhập ID, email hoặc tên đăng nhập).');
        $l = GuardianLink::updateOrCreate(['parent_id' => $p->id, 'student_id' => $s->id], ['status' => 'active', 'verified_via' => 'admin', 'verified_at' => now(), 'revoked_at' => null]);
        Audit::log('admin.guardian_linked', $l, null, ['parent_id' => $p->id, 'student_id' => $s->id], $data['note']);
        return back()->with('success', 'Đã liên kết.');
    }

    public function revoke(Request $r, GuardianLink $link)
    {
        $link->update(['status' => 'revoked', 'revoked_at' => now(), 'revoked_by' => $r->user()->id]);
        Audit::log('admin.guardian_revoked', $link);
        return back()->with('success', 'Đã hủy liên kết.');
    }
}
