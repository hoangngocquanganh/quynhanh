<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Controllers\Teacher\TeacherController;
use App\Models\ClassInvite;
use App\Models\Classroom;
use App\Models\ClassroomMember;
use App\Models\ClassroomTeacher;
use App\Models\User;
use App\Services\DomainError;
use App\Services\Notifier;
use App\Support\Audit;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ClassController extends Controller
{
    public function index(Request $r)
    {
        $q = Classroom::withCount('activeMembers')->with('teachers');
        if ($s = trim((string) $r->query('tim'))) $q->where('name', 'like', "%{$s}%");
        if ($g = (int) $r->query('lop')) $q->where('grade_level', $g);
        return view('admin.classes', ['classes' => $q->orderByDesc('id')->paginate(30)->withQueryString(),
            'teachers' => User::where('role', 'teacher')->where('teacher_status', 'approved')->orderBy('name')->get()]);
    }

    public function store(Request $r)
    {
        $data = $r->validate(['name' => 'required|string|max:120', 'grade_level' => 'required|integer|min:1|max:12', 'school_name' => 'nullable|string|max:190',
            'teacher_id' => 'nullable|integer', 'join_policy' => 'required|in:auto,approval']);
        $c = DB::transaction(function () use ($data, $r) {
            $c = Classroom::create(['name' => $data['name'], 'grade_level' => $data['grade_level'], 'school_name' => $data['school_name'] ?? null, 'join_policy' => $data['join_policy'], 'created_by' => $r->user()->id]);
            if (!empty($data['teacher_id'])) $this->assign($c, (int) $data['teacher_id'], 'main', $r->user()->id);
            TeacherController::newInvite($c, $r->user()->id);
            return $c;
        });
        Audit::log('admin.class_created', $c, null, $data);
        return redirect()->route('admin.classes.show', $c)->with('success', 'Đã tạo lớp.');
    }

    protected function assign(Classroom $c, int $teacherId, string $role, int $by): void
    {
        $t = User::where('id', $teacherId)->where('role', 'teacher')->where('teacher_status', 'approved')->first();
        if (!$t) throw new DomainError('Chỉ phân công được giáo viên đã duyệt.');
        if (ClassroomTeacher::where('classroom_id', $c->id)->where('teacher_id', $t->id)->whereNull('revoked_at')->exists()) throw new DomainError('Giáo viên đã phụ trách lớp này.');
        ClassroomTeacher::create(['classroom_id' => $c->id, 'teacher_id' => $t->id, 'role' => $role, 'assigned_at' => now(), 'assigned_by' => $by]);
        Notifier::send($t->id, 'class', 'Bạn được phân công phụ trách lớp ' . $c->name, null, route('teacher.class', $c));
    }

    public function show(Classroom $classroom)
    {
        $c = $classroom;
        $links = ClassroomTeacher::with('teacher')->where('classroom_id', $c->id)->orderByDesc('id')->get();
        $members = ClassroomMember::with('student')->where('classroom_id', $c->id)->orderBy('status')->get();
        return view('admin.class', ['c' => $c, 'links' => $links, 'members' => $members, 'invites' => ClassInvite::where('classroom_id', $c->id)->latest('id')->get(),
            'teachers' => User::where('role', 'teacher')->where('teacher_status', 'approved')->orderBy('name')->get(),
            'others' => Classroom::where('id', '<>', $c->id)->where('status', 'active')->orderBy('name')->get()]);
    }

    public function update(Request $r, Classroom $classroom)
    {
        $data = $r->validate(['name' => 'required|string|max:120', 'grade_level' => 'required|integer|min:1|max:12', 'school_name' => 'nullable|string|max:190',
            'status' => 'required|in:active,archived', 'join_policy' => 'required|in:auto,approval']);
        $old = $classroom->only(array_keys($data));
        $classroom->update($data);
        Audit::log('admin.class_updated', $classroom, $old, $data);
        return back()->with('success', 'Đã lưu lớp.');
    }

    public function assignTeacher(Request $r, Classroom $classroom)
    {
        $data = $r->validate(['teacher_id' => 'required|integer', 'role' => 'required|in:main,assistant']);
        $this->assign($classroom, (int) $data['teacher_id'], $data['role'], $r->user()->id);
        Audit::log('admin.class_teacher_assigned', $classroom, null, $data);
        return back()->with('success', 'Đã phân công giáo viên.');
    }

    public function revokeTeacher(Request $r, Classroom $classroom, int $link)
    {
        $l = ClassroomTeacher::where('classroom_id', $classroom->id)->whereNull('revoked_at')->findOrFail($link);
        $l->update(['revoked_at' => now()]);
        Audit::log('admin.class_teacher_revoked', $classroom, null, ['teacher_id' => $l->teacher_id]);
        return back()->with('success', 'Đã thu hồi phân công. Giáo viên mất quyền truy cập lớp ngay lập tức.');
    }

    public function addStudent(Request $r, Classroom $classroom)
    {
        $data = $r->validate(['student' => 'required|string|max:190']);
        $s = User::where('role', 'student')->where(fn ($q) => $q->where('id', (int) $data['student'])->orWhere('username', $data['student'])->orWhere('email', $data['student']))->first();
        if (!$s) throw new DomainError('Không tìm thấy học sinh (nhập ID, tên đăng nhập hoặc email).');
        ClassroomMember::updateOrCreate(['classroom_id' => $classroom->id, 'student_id' => $s->id], ['status' => 'active', 'joined_at' => now(), 'left_at' => null, 'changed_by' => $r->user()->id]);
        Audit::log('admin.class_student_added', $classroom, null, ['student_id' => $s->id]);
        return back()->with('success', 'Đã thêm ' . $s->name . ' vào lớp.');
    }

    /** Chuyển học sinh sang lớp khác (rời lớp cũ, vào lớp mới; lịch sử bài nộp giữ nguyên). */
    public function transfer(Request $r, Classroom $classroom)
    {
        $data = $r->validate(['student_id' => 'required|integer', 'to_classroom_id' => 'required|integer']);
        $to = Classroom::where('status', 'active')->where('id', '<>', $classroom->id)->findOrFail($data['to_classroom_id']);
        $m = ClassroomMember::where('classroom_id', $classroom->id)->where('student_id', $data['student_id'])->where('status', 'active')->firstOrFail();
        DB::transaction(function () use ($m, $to, $r) {
            $m->update(['status' => 'left', 'left_at' => now(), 'changed_by' => $r->user()->id]);
            ClassroomMember::updateOrCreate(['classroom_id' => $to->id, 'student_id' => $m->student_id], ['status' => 'active', 'joined_at' => now(), 'left_at' => null, 'changed_by' => $r->user()->id]);
        });
        Audit::log('admin.class_transfer', $classroom, null, ['student_id' => $m->student_id, 'to' => $to->id]);
        Notifier::send($m->student_id, 'class', 'Bạn đã được chuyển sang lớp ' . $to->name);
        return back()->with('success', 'Đã chuyển học sinh sang lớp ' . $to->name . '.');
    }
}
