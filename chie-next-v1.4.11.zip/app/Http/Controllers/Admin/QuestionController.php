<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Question;
use App\Services\Curriculum;
use App\Services\DomainError;
use App\Services\QuestionForm;
use App\Support\Audit;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class QuestionController extends Controller
{
    protected function filtered(Request $r)
    {
        $q = Question::query();
        if ($g = (int) $r->query('lop')) $q->where('grade_id', $g);
        if ($s = $r->query('ky-nang')) $q->where('skill', $s);
        if ($t = $r->query('dang')) $q->where('type', $t);
        if ($st = $r->query('trang-thai')) $q->where('status', $st);
        if ($r->query('co-co')) $q->whereNotNull('flags');
        if ($src = $r->query('nguon')) $q->where('source', 'like', $src . '%');
        if ($tag = $r->query('nhan')) $q->whereJsonContains('tags', (string) $tag);   // v1.4: lọc theo chủ điểm ngữ pháp (gp:<mã>)
        if ($k = trim((string) $r->query('tim'))) $q->where(fn ($w) => $w->where('prompt', 'like', '%' . $k . '%')->orWhere('id', (int) $k));
        return $q;
    }

    public function index(Request $r)
    {
        $items = $this->filtered($r)->orderByDesc('id')->paginate(40)->withQueryString();
        return view('admin.questions', ['items' => $items]);
    }

    public function create()
    {
        return view('admin.question-form', ['f' => QuestionForm::toForm(null), 'q' => null, 'action' => route('admin.questions.store')]);
    }

    public function store(Request $r)
    {
        $attrs = QuestionForm::parse($r);
        $status = in_array($r->input('status'), ['draft', 'review', 'published', 'archived'], true) ? $r->input('status') : 'review';
        $hash = Question::hashContent($attrs['prompt']['text'], $attrs['options'] ?? [], $attrs['answer']);
        if (Question::where('content_hash', $hash)->exists()) throw new DomainError('Câu hỏi này đã tồn tại.');
        $q = DB::transaction(function () use ($attrs, $status, $hash, $r) {
            $q = Question::create($attrs + ['subject_id' => DB::table('subjects')->where('code', 'en')->value('id'), 'status' => $status, 'version' => 1, 'content_hash' => $hash,
                'source' => 'admin', 'created_by' => $r->user()->id, 'reviewed_by' => $status === 'published' ? $r->user()->id : null, 'reviewed_at' => $status === 'published' ? now() : null]);
            $q->versions()->create(['version' => 1, 'snapshot' => $q->snapshot(), 'created_by' => $r->user()->id, 'created_at' => now()]);
            return $q;
        });
        Audit::log('question.created', $q, null, ['status' => $status]);
        Curriculum::flush();
        return redirect()->route('admin.questions.edit', $q)->with('success', 'Đã tạo câu hỏi #' . $q->id . '.');
    }

    public function edit(Question $question)
    {
        $usage = DB::table('attempt_items')->where('question_id', $question->id)->selectRaw('COUNT(*) n, SUM(is_correct = 1) ok')->first();
        return view('admin.question-form', ['f' => QuestionForm::toForm($question), 'q' => $question, 'action' => route('admin.questions.update', $question),
            'usage' => $usage, 'versions' => $question->versions()->orderByDesc('version')->get(), 'lessons' => $question->lessons()->get()]);
    }

    public function update(Request $r, Question $question)
    {
        $attrs = QuestionForm::parse($r);
        $status = in_array($r->input('status'), ['draft', 'review', 'published', 'archived'], true) ? $r->input('status') : $question->status;
        $hash = Question::hashContent($attrs['prompt']['text'], $attrs['options'] ?? [], $attrs['answer']);
        if (Question::where('content_hash', $hash)->where('id', '<>', $question->id)->exists()) throw new DomainError('Nội dung trùng với một câu hỏi khác.');
        $old = $question->snapshot() + ['status' => $question->status];
        $contentChanged = $hash !== $question->content_hash || $attrs['explanation_vi'] !== $question->explanation_vi;
        DB::transaction(function () use ($question, $attrs, $status, $hash, $contentChanged, $r) {
            $question->fill($attrs + ['status' => $status, 'content_hash' => $hash]);
            if ($contentChanged) $question->version = $question->version + 1;   // phiên bản mới; bài đã nộp giữ snapshot cũ
            if ($status === 'published' && $question->isDirty('status')) { $question->reviewed_by = $r->user()->id; $question->reviewed_at = now(); }
            if ($status === 'published') $question->flags = null;
            $question->save();
            if ($contentChanged) $question->versions()->create(['version' => $question->version, 'snapshot' => $question->snapshot(), 'created_by' => $r->user()->id, 'created_at' => now()]);
        });
        Audit::log('question.updated', $question, $old, $question->snapshot() + ['status' => $question->status]);
        Curriculum::flush();
        return back()->with('success', 'Đã lưu' . ($contentChanged ? ' (phiên bản ' . $question->version . ')' : '') . '.');
    }

    public function bulk(Request $r)
    {
        $data = $r->validate(['ids' => 'required_without:all_filtered|array|min:1|max:500', 'ids.*' => 'integer', 'action' => 'required|in:published,review,draft,archived',
            'all_filtered' => 'nullable|boolean', 'filter' => 'nullable|array']);
        if (!empty($data['all_filtered'])) {
            // áp dụng cho toàn bộ kết quả lọc (giới hạn 2.000 câu mỗi lần để tránh thao tác nhầm quá lớn)
            $ids = $this->filtered(new Request($data['filter'] ?? []))->orderBy('id')->limit(2000)->pluck('id')->all();
            if (!$ids) return back()->with('error', 'Không có câu nào khớp bộ lọc.');
            $data['ids'] = $ids;
        }
        $q = Question::whereIn('id', $data['ids']);
        $upd = ['status' => $data['action']];
        if ($data['action'] === 'published') $upd += ['reviewed_by' => $r->user()->id, 'reviewed_at' => now(), 'flags' => null];
        $n = $q->update($upd);
        Audit::log('question.bulk_' . $data['action'], null, null, ['ids' => $data['ids'], 'affected' => $n]);
        Curriculum::flush();
        return back()->with('success', "Đã chuyển {$n} câu sang trạng thái \"" . status_label($data['action']) . '".');
    }

    public function export(Request $r)
    {
        $rows = $this->filtered($r)->orderBy('id')->limit(10000)->get();
        $out = fopen('php://temp', 'w+');
        fwrite($out, "\xEF\xBB\xBF");
        fputcsv($out, ['id', 'grade', 'skill', 'type', 'difficulty', 'status', 'text', 'speak', 'options', 'correct', 'explanation_vi', 'tags']);
        foreach ($rows as $q) {
            $opts = $q->type === 'matching' ? implode(' || ', array_map(fn ($p) => $p[0] . ' = ' . $p[1], $q->answer['pairs'] ?? [])) : implode(' || ', $q->options ?? []);
            fputcsv($out, [$q->id, $q->grade_id, $q->skill, $q->type, $q->difficulty, $q->status, $q->prompt['text'] ?? '', $q->prompt['speak'] ?? '', $opts,
                $q->answer['correct'] ?? '', $q->explanation_vi, implode(',', $q->tags ?? [])]);
        }
        rewind($out);
        $csv = stream_get_contents($out);
        Audit::log('question.exported', null, null, ['count' => $rows->count()]);
        return response($csv, 200, ['Content-Type' => 'text/csv; charset=UTF-8', 'Content-Disposition' => 'attachment; filename="cau-hoi-' . date('Ymd-His') . '.csv"']);
    }

    /** Nhập CSV cùng định dạng xuất. Dòng lỗi được báo cáo, không nhập; câu mới luôn ở trạng thái "chờ duyệt". */
    public function importCsv(Request $r)
    {
        $r->validate(['file' => 'required|file|mimes:csv,txt|max:5120']);
        $fh = fopen($r->file('file')->getRealPath(), 'r');
        $head = fgetcsv($fh);
        if ($head && isset($head[0])) $head[0] = preg_replace('/^\xEF\xBB\xBF/', '', $head[0]);
        $need = ['grade', 'skill', 'type', 'text', 'options', 'correct', 'explanation_vi'];
        if (!$head || array_diff($need, $head)) throw new DomainError('Tệp CSV cần các cột: ' . implode(', ', $need) . '. Hãy xuất mẫu từ nút "Xuất CSV".');
        $ok = 0; $dup = 0; $errors = [];
        $subject = DB::table('subjects')->where('code', 'en')->value('id');
        $line = 1;
        while (($row = fgetcsv($fh)) !== false) {
            $line++;
            if (count(array_filter($row)) === 0) continue;
            $d = array_combine($head, array_pad(array_slice($row, 0, count($head)), count($head), ''));
            $fake = new Request(['grade_id' => $d['grade'], 'skill' => $d['skill'], 'type' => $d['type'], 'difficulty' => $d['difficulty'] ?? 1, 'text' => $d['text'],
                'speak' => $d['speak'] ?? null, 'options_text' => str_replace(' || ', "\n", $d['options']), 'correct' => $d['correct'], 'explanation_vi' => $d['explanation_vi'],
                'tags' => array_filter(explode(',', $d['tags'] ?? ''))]);
            try {
                $attrs = QuestionForm::parse($fake);
            } catch (\Illuminate\Validation\ValidationException $e) {
                $errors[] = "Dòng {$line}: " . collect($e->errors())->flatten()->first(); continue;
            } catch (DomainError $e) {
                $errors[] = "Dòng {$line}: " . $e->getMessage(); continue;
            }
            $hash = Question::hashContent($attrs['prompt']['text'], $attrs['options'] ?? [], $attrs['answer']);
            if (Question::where('content_hash', $hash)->exists()) { $dup++; continue; }
            $q = Question::create($attrs + ['subject_id' => $subject, 'status' => 'review', 'version' => 1, 'content_hash' => $hash, 'source' => 'csv', 'created_by' => $r->user()->id]);
            $q->versions()->create(['version' => 1, 'snapshot' => $q->snapshot(), 'created_by' => $r->user()->id, 'created_at' => now()]);
            $ok++;
        }
        Audit::log('question.csv_imported', null, null, ['ok' => $ok, 'dup' => $dup, 'errors' => count($errors)]);
        return back()->with('success', "Nhập CSV: {$ok} câu mới (chờ duyệt), {$dup} câu trùng bỏ qua, " . count($errors) . ' dòng lỗi.')->with('csv_errors', array_slice($errors, 0, 30));
    }
}
