<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\GameConfig;
use App\Services\DomainError;
use App\Support\Audit;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

/**
 * Game Mechanics Studio: chỉnh thông số từng game bằng biểu mẫu (không sửa code), lưu phiên bản + hoàn tác 1 chạm,
 * tự xuất JSON tĩnh assets/config/mechanics.v{n}.json để trình duyệt đọc nhanh.
 */
class GameAdminController extends Controller
{
    public const SCHEMA = [
        'word_runner' => ['lanes' => ['Số làn', 'int', 3, 3], 'hearts' => ['Số tim', 'int', 1, 10], 'speed_base' => ['Tốc độ ban đầu', 'float', 1, 10], 'speed_step' => ['Tăng tốc mỗi câu đúng', 'float', 0, 2],
            'question_count' => ['Số câu mỗi lượt', 'int', 5, 30], 'boss_every' => ['Boss sau mỗi N câu', 'int', 2, 20], 'hide_vietnamese_challenge' => ['Thử thách ẩn nghĩa tiếng Việt', 'bool']],
        'grammar_tower' => ['waves' => ['Số đợt quái', 'int', 1, 10], 'enemies_per_wave' => ['Quái mỗi đợt', 'int', 1, 10], 'castle_hp' => ['Máu thành', 'int', 1, 20],
            'enemy_speed' => ['Tốc độ quái', 'float', 0.1, 2], 'question_count' => ['Số câu mỗi lượt', 'int', 5, 30]],
        'voice_island' => ['question_count' => ['Số câu nghe', 'int', 5, 30], 'shadowing_sentences' => ['Số câu shadowing', 'int', 0, 10], 'fall_speed' => ['Tốc độ rơi', 'float', 0.3, 3]],
        'reading_escape' => ['rooms' => ['Số phòng', 'int', 1, 6], 'questions_per_room' => ['Câu mỗi phòng', 'int', 2, 8], 'hints' => ['Số gợi ý', 'int', 0, 10], 'room_seconds' => ['Giây mỗi phòng (0 = không giới hạn)', 'int', 0, 1800]],
    ];

    public function index()
    {
        $configs = GameConfig::orderBy('id')->get();
        $versions = DB::table('game_config_versions')->orderByDesc('id')->limit(40)->get()->groupBy('game_code');
        $schema = [];
        foreach ($configs as $c) $schema[$c->game_code] = \App\Services\Games::schema($c->game_code);
        return view('admin.games', ['configs' => $configs, 'schema' => $schema, 'versions' => $versions, 'modules' => \App\Services\ModuleRegistry::allGames()]);
    }

    public function save(Request $r, string $code)
    {
        $cfg = GameConfig::where('game_code', $code)->firstOrFail();
        $schema = \App\Services\Games::schema($code);
        $new = $cfg->config;
        foreach ($schema as $k => $def) {
            [$label, $type] = $def;
            $v = $r->input('cfg.' . $k);
            if ($type === 'bool') { $new[$k] = (bool) $v; continue; }
            if ($v === null || $v === '') throw new DomainError('Thiếu giá trị: ' . $label);
            $v = $type === 'int' ? (int) $v : (float) $v;
            if ($v < $def[2] || $v > $def[3]) throw new DomainError("{$label} phải trong khoảng {$def[2]}–{$def[3]}.");
            $new[$k] = $v;
        }
        $old = ['enabled' => $cfg->enabled, 'config' => $cfg->config, 'version' => $cfg->version];
        DB::transaction(function () use ($cfg, $new, $r) {
            $cfg->enabled = $r->boolean('enabled');
            $cfg->config = $new;
            $cfg->version = $cfg->version + 1;
            $cfg->updated_by = $r->user()->id;
            $cfg->save();
            DB::table('game_config_versions')->insert(['game_code' => $cfg->game_code, 'version' => $cfg->version, 'enabled' => $cfg->enabled, 'config' => json_encode($cfg->config), 'created_by' => $r->user()->id, 'created_at' => now()]);
        });
        static::exportStatic();
        Audit::log('game.config_saved', $cfg, $old, ['enabled' => $cfg->enabled, 'config' => $cfg->config, 'version' => $cfg->version]);
        return back()->with('success', 'Đã áp dụng cơ chế mới (phiên bản ' . $cfg->version . ') cho lượt chơi tiếp theo.');
    }

    /** v1.3: đặt cấu hình về "defaults" trong modules/games/<game>/module.json (tạo phiên bản mới, hoàn tác được). */
    public function moduleDefaults(Request $r, string $code)
    {
        $cfg = GameConfig::where('game_code', $code)->firstOrFail();
        $defaults = \App\Services\Games::moduleDefaults($code);
        if (!$defaults) throw new DomainError('Module của game này chưa khai báo "defaults".');
        $schema = \App\Services\Games::schema($code);
        $new = $cfg->config;
        foreach ($schema as $k => $def) {
            if (!array_key_exists($k, $defaults)) continue;
            $v = $defaults[$k];
            $new[$k] = $def[1] === 'bool' ? (bool) $v : ($def[1] === 'int' ? (int) $v : (float) $v);
        }
        $old = $cfg->config;
        DB::transaction(function () use ($cfg, $new, $r) {
            $cfg->config = $new;
            $cfg->version = $cfg->version + 1;
            $cfg->updated_by = $r->user()->id;
            $cfg->save();
            DB::table('game_config_versions')->insert(['game_code' => $cfg->game_code, 'version' => $cfg->version, 'enabled' => $cfg->enabled, 'config' => json_encode($cfg->config), 'created_by' => $r->user()->id, 'created_at' => now()]);
        });
        static::exportStatic();
        Audit::log('game.config_module_defaults', $cfg, ['config' => $old], ['config' => $cfg->config, 'version' => $cfg->version]);
        return back()->with('success', 'Đã đặt về mặc định của module (phiên bản ' . $cfg->version . ').');
    }

    /** v1.3.1: bật/tắt hiển thị toàn bộ tính năng trò chơi với học sinh. */
    public function visibility(Request $r)
    {
        $on = $r->boolean('visible');
        \App\Support\Settings::set('features.games_visible', $on, $r->user()->id);
        Audit::log('game.visibility', ['Setting', null], null, ['features.games_visible' => $on]);
        return back()->with('success', $on ? 'Đã HIỆN tính năng trò chơi cho học sinh.' : 'Đã ẨN tính năng trò chơi (link trực tiếp vẫn dùng được).');
    }

    public function rollback(Request $r, string $code, int $version)
    {
        $cfg = GameConfig::where('game_code', $code)->firstOrFail();
        $v = DB::table('game_config_versions')->where('game_code', $code)->where('version', $version)->first();
        abort_unless($v, 404);
        $old = $cfg->config;
        $cfg->config = json_decode($v->config, true);
        $cfg->enabled = (bool) $v->enabled;
        $cfg->version = $cfg->version + 1;
        $cfg->save();
        DB::table('game_config_versions')->insert(['game_code' => $code, 'version' => $cfg->version, 'enabled' => $cfg->enabled, 'config' => $v->config, 'created_by' => $r->user()->id, 'created_at' => now()]);
        static::exportStatic();
        Audit::log('game.config_rollback', $cfg, ['config' => $old], ['from_version' => $version, 'config' => $cfg->config]);
        return back()->with('success', "Đã hoàn tác về cấu hình phiên bản {$version}.");
    }

    public static function exportStatic(): void
    {
        $all = GameConfig::get()->mapWithKeys(fn ($c) => [$c->game_code => ['enabled' => $c->enabled, 'version' => $c->version, 'config' => $c->config]])->all();
        $dir = base_path('assets/config');
        if (!is_dir($dir)) @mkdir($dir, 0755, true);
        $ver = (int) GameConfig::sum('version');
        @file_put_contents($dir . '/mechanics.v' . $ver . '.json', json_encode(['version' => $ver, 'games' => $all], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
        @file_put_contents($dir . '/mechanics.latest.json', json_encode(['version' => $ver, 'games' => $all], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    }
}
