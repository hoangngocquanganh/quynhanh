<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\LexiconItem;
use App\Services\Curriculum;
use App\Support\Audit;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class LexiconController extends Controller
{
    public function index(Request $r)
    {
        $q = LexiconItem::query();
        if ($s = trim((string) $r->query('tim'))) $q->where(fn ($w) => $w->where('word', 'like', "%{$s}%")->orWhere('meaning_vi', 'like', "%{$s}%"));
        if ($g = (int) $r->query('lop')) $q->where('grade_id', $g);
        if ($st = $r->query('trang-thai')) $q->where('status', $st);
        if ($t = $r->query('chu-de')) $q->where('topic', $t);
        $edit = $r->query('sua') ? LexiconItem::find($r->query('sua')) : null;
        return view('admin.lexicon', ['items' => $q->orderBy('word')->paginate(40)->withQueryString(), 'edit' => $edit,
            'topics' => LexiconItem::whereNotNull('topic')->distinct()->orderBy('topic')->pluck('topic')]);
    }

    public function save(Request $r)
    {
        $data = $r->validate(['id' => 'nullable|integer', 'word' => 'required|string|max:120', 'pos' => 'nullable|string|max:20',
            'ipa_uk' => ['nullable', 'string', 'max:120', 'regex:#^/[^/]+/$#u'], 'ipa_us' => ['nullable', 'string', 'max:120', 'regex:#^/[^/]+/$#u'],
            'meaning_vi' => 'required|string|max:190', 'example_en' => 'nullable|string|max:255', 'example_vi' => 'nullable|string|max:255',
            'emoji' => 'nullable|string|max:16', 'topic' => 'nullable|string|max:60', 'grade_id' => 'required|integer|min:1|max:12',
            'status' => 'required|in:draft,review,published,archived'], ['ipa_uk.regex' => 'Phiên âm phải đặt trong dấu /.../', 'ipa_us.regex' => 'Phiên âm phải đặt trong dấu /.../']);
        $key = mb_strtolower(preg_replace('/\s+/', ' ', trim($data['word'])));
        $exists = LexiconItem::where('word_key', $key)->when(!empty($data['id']), fn ($q) => $q->where('id', '<>', $data['id']))->exists();
        if ($exists) return back()->withErrors(['word' => 'Từ này đã có trong kho.'])->withInput();
        $item = !empty($data['id']) ? LexiconItem::findOrFail($data['id']) : new LexiconItem(['subject_id' => DB::table('subjects')->where('code', 'en')->value('id'), 'source' => 'admin']);
        $old = $item->exists ? $item->toArray() : null;
        unset($data['id']);
        $item->fill($data + ['word_key' => $key]);
        if ($item->status === 'published') $item->flags = null;
        $item->save();
        Audit::log($old ? 'lexicon.updated' : 'lexicon.created', $item, $old, $item->toArray());
        Curriculum::flush();
        return redirect()->route('admin.lexicon', ['tim' => $item->word])->with('success', 'Đã lưu từ "' . $item->word . '".');
    }

    public function bulk(Request $r)
    {
        $data = $r->validate(['ids' => 'required|array|min:1', 'ids.*' => 'integer', 'action' => 'required|in:published,review,draft,archived']);
        $n = LexiconItem::whereIn('id', $data['ids'])->update(['status' => $data['action']] + ($data['action'] === 'published' ? ['flags' => null] : []));
        Audit::log('lexicon.bulk_' . $data['action'], null, null, ['ids' => $data['ids']]);
        Curriculum::flush();
        return back()->with('success', "Đã cập nhật {$n} từ.");
    }
}
