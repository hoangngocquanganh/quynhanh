<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Attempt;
use App\Models\ExamBlueprint;
use App\Models\Question;
use App\Support\Audit;
use Illuminate\Http\Request;

class BlueprintController extends Controller
{
    public function index()
    {
        return view('admin.blueprints', ['items' => ExamBlueprint::orderBy('sort')->get()]);
    }

    public function save(Request $r)
    {
        $data = $r->validate(['id' => 'nullable|integer', 'code' => 'required|string|max:40|alpha_dash', 'title' => 'required|string|max:190',
            'type' => 'required|in:daily5,daily10,unit20,quiz15,midterm,final,mock10,mockgrad,custom', 'grade_from' => 'required|integer|min:1|max:12', 'grade_to' => 'required|integer|min:1|max:12|gte:grade_from',
            'question_count' => 'required|integer|min:3|max:100', 'duration_min' => 'required|integer|min:1|max:240', 'note' => 'nullable|string|max:500',
            'is_active' => 'nullable|boolean', 'sort' => 'nullable|integer', 'mix' => 'nullable|array', 'mix.*' => 'nullable|integer|min:0|max:100']);
        $mix = array_filter(array_intersect_key($data['mix'] ?? [], Question::SKILLS));
        $bp = !empty($data['id']) ? ExamBlueprint::findOrFail($data['id']) : new ExamBlueprint();
        $old = $bp->exists ? $bp->toArray() : null;
        $bp->fill(['code' => $data['code'], 'title' => $data['title'], 'type' => $data['type'], 'grade_from' => $data['grade_from'], 'grade_to' => $data['grade_to'],
            'question_count' => $data['question_count'], 'duration_min' => $data['duration_min'], 'note' => $data['note'] ?? null, 'is_active' => (bool) ($data['is_active'] ?? false),
            'sort' => (int) ($data['sort'] ?? 0), 'skill_mix' => $mix ?: null]);
        $bp->save();
        Audit::log($old ? 'blueprint.updated' : 'blueprint.created', $bp, $old, $bp->toArray());
        return back()->with('success', 'Đã lưu khung đề.');
    }

    public function shares(Request $r)
    {
        $items = Attempt::with('user')->whereNotNull('share_token')->latest('submitted_at')->paginate(30);
        return view('admin.shares', ['items' => $items]);
    }

    public function revokeShare(Request $r, Attempt $attempt)
    {
        $attempt->update(['share_revoked_at' => $attempt->share_revoked_at ? null : now()]);
        Audit::log('share.' . ($attempt->share_revoked_at ? 'revoked' : 'restored'), $attempt);
        return back()->with('success', $attempt->share_revoked_at ? 'Đã thu hồi link.' : 'Đã mở lại link.');
    }
}
