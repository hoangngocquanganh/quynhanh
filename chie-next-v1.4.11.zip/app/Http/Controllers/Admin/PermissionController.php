<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Support\Audit;
use App\Support\Permissions;
use App\Support\Settings;
use Illuminate\Http\Request;

/** Quản trị → Người dùng → Phân quyền: bật/tắt từng tính năng cho từng vai trò. */
class PermissionController extends Controller
{
    public function index()
    {
        return view('admin.permissions', ['matrix' => Permissions::matrix(), 'defaults' => Permissions::defaults()]);
    }

    public function save(Request $r)
    {
        $in = (array) $r->input('perm', []);
        $old = Settings::get('permissions.matrix', []);
        $new = [];
        foreach (Permissions::ROLES as $role => $_) {
            if ($role === 'admin') continue;   // Admin luôn toàn quyền
            foreach (Permissions::FEATURES as $f => $def) {
                if (Permissions::locked($role, $f)) continue;
                $new[$role][$f] = !empty($in[$role][$f]);
            }
        }
        Settings::set('permissions.matrix', $new, $r->user()->id);
        Audit::log('permissions.saved', ['Setting', null], ['permissions.matrix' => $old], ['permissions.matrix' => $new]);
        return back()->with('success', 'Đã lưu phân quyền. Thay đổi có hiệu lực ngay.');
    }

    public function reset(Request $r)
    {
        Settings::set('permissions.matrix', [], $r->user()->id);
        Audit::log('permissions.reset', ['Setting', null], null, ['permissions.matrix' => 'default']);
        return back()->with('success', 'Đã khôi phục phân quyền mặc định.');
    }
}
