<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\ZooCatalogOverride;
use App\Services\FarmService;
use App\Services\ModuleRegistry;
use App\Services\ZooGardenService;
use App\Support\Audit;
use App\Support\Settings;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

/** v1.3 — Admin: Quản lý Zoo Garden 3D (cài đặt, Playtime Gate, danh mục cây/thú/cá/vật phẩm/hành tinh) + Module. */
class ZooAdminController extends Controller
{
    public const TABS = [
        'general' => 'Cài đặt chung',
        'playtime' => 'Giờ chơi & thưởng Tiếng Anh',
        'crops' => 'Cây trồng',
        'animals_fish' => 'Vật nuôi & Cá',
        'items' => 'Vật phẩm',
        'planets' => 'Hành tinh',
        'modules' => 'Module game & khối lớp',
    ];

    public function index(Request $r)
    {
        $tab = array_key_exists($r->query('tab'), self::TABS) ? $r->query('tab') : 'general';
        $today = today()->toDateString();
        $counter = fn (string $k) => (int) DB::table('daily_counters')->where('day', $today)->where('key', $k)->sum('value');
        $stats = [
            'players_saved' => DB::table('farms')->whereNotNull('zoo_save')->count(),
            'today_players' => (int) DB::table('daily_counters')->where('day', $today)->where('key', 'zoo_play_seconds')->count(),
            'today_play_hours' => round($counter('zoo_play_seconds') / 3600, 1),
            'today_quiz_correct' => $counter('zoo_quiz_correct'),
            'today_quiz_total' => $counter('zoo_quiz_total'),
            'today_srs_cleared' => $counter('zoo_srs_cleared'),
            'today_exchanged_xu' => $counter('zoo_exchanged_xu'),
        ];
        $overrides = ZooCatalogOverride::all()->groupBy('category')->map(fn ($g) => $g->keyBy('item_code'));
        $q = trim((string) $r->query('q', ''));
        $type = (string) $r->query('type', '');
        $catalog = ZooGardenService::defaultCatalog();
        $items = collect($catalog['item'] ?? []);
        if ($type !== '') $items = $items->where('type', $type);
        if ($q !== '') {
            $needle = mb_strtolower($q);
            $items = $items->filter(fn ($i) => str_contains(mb_strtolower($i['code'] . ' ' . $i['name_en'] . ' ' . ($i['name_vi'] ?? '') . ' ' . ($overrides['item'][$i['code']]->name_vi ?? '')), $needle));
        }
        $bundle = ZooGardenService::bundle();
        return view('admin.zoo', [
            'tab' => $tab, 'tabs' => self::TABS, 'schema' => ZooGardenService::SETTINGS_SCHEMA, 'settings' => ZooGardenService::allSettings(true),
            'overrides' => $overrides, 'stats' => $stats, 'catalog' => $catalog, 'items' => $items->values(), 'q' => $q, 'type' => $type,
            'itemTypes' => collect($catalog['item'] ?? [])->pluck('type')->unique()->sort()->values(),
            'bundle' => $bundle, 'build' => @json_decode((string) @file_get_contents(base_path('assets/zoo-garden/build-info.json')), true),
            'games' => $tab === 'modules' ? ModuleRegistry::allGames() : [], 'grades' => $tab === 'modules' ? ModuleRegistry::allGrades() : [],
            'iconBase' => asset('assets/zoo-garden/assets/icons') . '/',
        ]);
    }

    public function saveSettings(Request $r)
    {
        $tab = $r->input('tab', 'general');
        $changed = [];
        foreach (ZooGardenService::SETTINGS_SCHEMA as $key => [$label, $type, $def, $group]) {
            if ($group !== $tab) continue;
            $field = str_replace('.', '__', $key);
            $raw = $r->input($field);
            $val = match ($type) {
                'bool' => (bool) $raw,
                'int' => max(0, min(1000000, (int) $raw)),
                default => mb_substr(trim((string) $raw), 0, 255),
            };
            if ($key === 'zoo.online_shared_secret' && $val !== '' && strlen($val) < 32) return back()->with('error', 'Khóa bí mật Online phải có ít nhất 32 ký tự.');
            if ($key === 'zoo.default_language' && !in_array($val, ['vi', 'en'], true)) $val = 'vi';
            if ($key === 'zoo.online_server_url' && $val !== '' && !preg_match('#^wss?://#i', $val) && !preg_match('#^https?://#i', $val)) {
                return back()->with('error', 'URL máy chủ Online phải bắt đầu bằng wss:// hoặc https://');
            }
            $old = ZooGardenService::cfg($key);
            if ($old !== $val) {
                Settings::set($key, $val, $r->user()->id);
                $changed[$key] = str_ends_with($key, '_secret') ? ['(ẩn)', '(đã đổi)'] : [$old, $val];
            }
        }
        if ($changed) Audit::log('zoo.settings_updated', ['Setting', null], array_map(fn ($c) => $c[0], $changed), array_map(fn ($c) => $c[1], $changed));
        ZooGardenService::flushCatalog();
        return back()->with('success', $changed ? 'Đã lưu ' . count($changed) . ' thay đổi. Học sinh nhận cài đặt mới khi mở lại Nông trại.' : 'Không có gì thay đổi.');
    }

    public function saveCatalogItem(Request $r)
    {
        $d = $r->validate([
            'category' => 'required|in:' . implode(',', ZooGardenService::CATEGORIES),
            'item_code' => 'required|string|max:60|regex:/^[a-z0-9_]+$/',
            'name_vi' => 'nullable|string|max:120',
            'name_en' => 'nullable|string|max:120',
            'desc_vi' => 'nullable|string|max:255',
            'price_energy' => 'nullable|integer|min:0|max:100000000',
            'sell_energy' => 'nullable|integer|min:0|max:100000000',
            'min_level' => 'nullable|integer|min:1|max:999',
            'grow_seconds' => 'nullable|integer|min:1|max:2592000',
            'words_text' => 'nullable|string|max:2000',
            'is_enabled' => 'nullable|boolean',
        ]);
        $known = collect(ZooGardenService::defaultCatalog()[$d['category']] ?? [])->pluck('code')->all();
        if ($known && !in_array($d['item_code'], $known, true)) return back()->with('error', "Mã [{$d['item_code']}] không có trong danh mục game.");
        $words = [];
        foreach (preg_split('/\r?\n/', (string) ($d['words_text'] ?? '')) as $line) {
            $parts = array_map('trim', explode('=', $line, 2));
            if (count($parts) === 2 && $parts[0] !== '' && $parts[1] !== '') $words[] = [mb_substr($parts[0], 0, 60), mb_substr($parts[1], 0, 80)];
        }
        $row = ZooCatalogOverride::updateOrCreate(['category' => $d['category'], 'item_code' => $d['item_code']], [
            'name_vi' => ($d['name_vi'] ?? '') !== '' ? $d['name_vi'] : null,
            'name_en' => ($d['name_en'] ?? '') !== '' ? $d['name_en'] : null,
            'desc_vi' => ($d['desc_vi'] ?? '') !== '' ? $d['desc_vi'] : null,
            'price_energy' => $d['price_energy'] ?? null,
            'sell_energy' => $d['sell_energy'] ?? null,
            'min_level' => $d['min_level'] ?? null,
            'grow_seconds' => $d['grow_seconds'] ?? null,
            'extra_json' => $words ? ['words' => array_slice($words, 0, 20)] : null,
            'is_enabled' => $r->boolean('is_enabled'),
            'updated_by' => $r->user()->id,
        ]);
        ZooGardenService::flushCatalog();
        Audit::log('zoo.catalog_saved', $row, null, $row->only(['category', 'item_code', 'name_vi', 'name_en', 'price_energy', 'sell_energy', 'min_level', 'grow_seconds', 'is_enabled']));
        return back()->with('success', "Đã lưu [{$d['item_code']}]. Áp dụng khi học sinh mở lại Nông trại.");
    }

    public function resetCatalogItem(Request $r)
    {
        $d = $r->validate(['category' => 'required|in:' . implode(',', ZooGardenService::CATEGORIES), 'item_code' => 'required|string|max:60']);
        ZooCatalogOverride::where('category', $d['category'])->where('item_code', $d['item_code'])->delete();
        ZooGardenService::flushCatalog();
        Audit::log('zoo.catalog_reset', ['ZooCatalogOverride', null], $d);
        return back()->with('success', "Đã khôi phục thông số gốc cho [{$d['item_code']}].");
    }

    /** Xóa bản lưu Zoo Garden của 1 học sinh (hỗ trợ khi hỏng dữ liệu). */
    public function resetStudentSave(Request $r)
    {
        $d = $r->validate(['login' => 'required|string|max:190', 'confirm' => 'accepted']);
        $u = User::where('email', $d['login'])->orWhere('username', $d['login'])->first();
        if (!$u) return back()->with('error', 'Không tìm thấy tài khoản.');
        $f = FarmService::farm($u->id);
        $f->zoo_save = null;
        $f->zoo_revision = (int) $f->zoo_revision + 1;
        $f->zoo_updated_at = now();
        $f->save();
        Audit::log('zoo.save_reset', $u);
        return back()->with('success', "Đã xóa bản lưu Zoo Garden của {$u->name}. Lưu ý: trình duyệt của học sinh có thể còn bản cũ — hãy nhắc em đăng xuất/đăng nhập trên máy khác hoặc xóa dữ liệu trang.");
    }

    public function exportModule(Request $r, string $type, string $folder)
    {
        $path = ModuleRegistry::exportModuleZip($type, $folder);
        Audit::log('module.exported', ['Module', null], null, ['type' => $type, 'folder' => $folder]);
        return response()->download($path, $folder . '-' . date('Ymd') . '.zip')->deleteFileAfterSend(true);
    }

    public function installModule(Request $r)
    {
        $r->validate(['module_zip' => 'required|file|mimes:zip|max:204800']);
        $res = ModuleRegistry::installModuleZip($r->file('module_zip'), $r->user()->id);
        $msg = "Đã cài module {$res['name']} (v{$res['version']}).";
        if ($res['deployed']) $msg .= ' Đã triển khai: ' . implode(', ', $res['deployed']) . '.';
        if ($res['import']) $msg .= ' Đã nhập học liệu vào CSDL (lượt nhập #' . $res['import']['run_id'] . ').';
        return redirect()->route('admin.zoo', ['tab' => 'modules'])->with('success', $msg);
    }

    public function syncGrade(Request $r, int $gradeId)
    {
        abort_unless($gradeId >= 1 && $gradeId <= 12, 404);
        $res = ModuleRegistry::syncGradeModule($gradeId, $r->user()->id);
        $s = $res['stats'] ?? [];
        return redirect()->route('admin.zoo', ['tab' => 'modules'])->with('success', "Đã đồng bộ Lớp {$gradeId}: câu mới " . ($s['cau_nhap_moi'] ?? 0) . ', từ mới ' . ($s['tu_nhap_moi'] ?? 0) . ', bài mới ' . ($s['bai_nhap_moi'] ?? 0) . ' (lượt nhập #' . $res['run_id'] . ').');
    }
}
