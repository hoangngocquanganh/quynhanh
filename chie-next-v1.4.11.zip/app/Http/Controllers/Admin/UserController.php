<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\GuardianLink;
use App\Models\TermsVersion;
use App\Models\User;
use App\Models\XuLedger;
use App\Services\Accounts;
use App\Services\DomainError;
use App\Services\Economy;
use App\Services\NameFilter;
use App\Services\Notifier;
use App\Support\Audit;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class UserController extends Controller
{
    public function index(Request $r)
    {
        $q = User::query();
        if ($s = trim((string) $r->query('tim'))) {
            $q->where(fn ($w) => $w->where('name', 'like', "%{$s}%")->orWhere('email', 'like', "%{$s}%")->orWhere('username', 'like', "%{$s}%")->orWhere('full_name', 'like', "%{$s}%")
                ->orWhere('id', (int) $s));
        }
        if ($role = $r->query('vai-tro')) $q->where('role', $role);
        if ($st = $r->query('trang-thai')) {
            if ($st === 'pending') $q->where('teacher_status', 'pending'); else $q->where('status', $st);
        }
        if ($g = (int) $r->query('lop')) $q->where('grade_level', $g);
        $users = $q->orderByDesc('id')->paginate(30)->withQueryString();
        return view('admin.users', ['users' => $users]);
    }

    public function create()
    {
        return view('admin.user-create');
    }

    public function store(Request $r)
    {
        $data = $r->validate([
            'role' => 'required|in:student,parent,teacher,admin', 'name' => 'required|string|min:2|max:30', 'full_name' => 'nullable|string|max:120',
            'email' => 'nullable|required_unless:role,student|email|max:190', 'username' => ['nullable', 'required_without:email', 'string', 'min:4', 'max:30', 'regex:/^[a-z0-9_.]+$/'],
            'password' => 'required|string|min:8|max:100', 'grade_level' => 'required_if:role,student|nullable|integer|min:1|max:12',
        ], [], ['name' => 'tên hiển thị', 'username' => 'tên đăng nhập', 'grade_level' => 'lớp']);
        if ($msg = NameFilter::check($data['name'])) return back()->withErrors(['name' => $msg])->withInput();
        if (!empty($data['email']) && User::where('email', mb_strtolower($data['email']))->exists()) return back()->withErrors(['email' => 'Email đã tồn tại.'])->withInput();
        if (!empty($data['username']) && User::where('username', mb_strtolower($data['username']))->exists()) return back()->withErrors(['username' => 'Tên đăng nhập đã tồn tại.'])->withInput();
        $u = Accounts::create(['name' => $data['name'], 'full_name' => $data['full_name'] ?? null, 'email' => !empty($data['email']) ? mb_strtolower($data['email']) : null,
            'canonical_email' => !empty($data['email']) ? NameFilter::canonicalEmail($data['email']) : null, 'username' => !empty($data['username']) ? mb_strtolower($data['username']) : null,
            'password' => $data['password'], 'role' => $data['role'], 'teacher_status' => $data['role'] === 'teacher' ? 'approved' : null,
            'grade_level' => $data['role'] === 'student' ? (int) $data['grade_level'] : null, 'email_verified_at' => now()]);
        Audit::log('admin.user_created', $u, null, ['role' => $u->role]);
        return redirect()->route('admin.users.show', $u)->with('success', 'Đã tạo tài khoản. Người dùng sẽ đồng ý điều khoản khi đăng nhập lần đầu.');
    }

    public function show(User $user)
    {
        $wallet = Economy::walletFor($user->id);
        $ledger = XuLedger::where('user_id', $user->id)->orderByDesc('id')->limit(15)->get();
        $links = GuardianLink::with(['parent', 'student'])->where(fn ($q) => $q->where('parent_id', $user->id)->orWhere('student_id', $user->id))->get();
        $classes = DB::table('classroom_members')->join('classrooms', 'classrooms.id', '=', 'classroom_members.classroom_id')->where('student_id', $user->id)->get(['classrooms.id', 'classrooms.name', 'classroom_members.status']);
        $teaching = DB::table('classroom_teachers')->join('classrooms', 'classrooms.id', '=', 'classroom_teachers.classroom_id')->where('teacher_id', $user->id)->whereNull('revoked_at')->get(['classrooms.id', 'classrooms.name']);
        $consents = DB::table('user_terms_consents')->where('user_id', $user->id)->get();
        return view('admin.user', compact('user', 'wallet', 'ledger', 'links', 'classes', 'teaching', 'consents'));
    }

    public function update(Request $r, User $user)
    {
        $data = $r->validate([
            'name' => 'required|string|min:2|max:30', 'full_name' => 'nullable|string|max:120', 'role' => 'required|in:student,parent,teacher,admin',
            'status' => 'required|in:active,suspended', 'teacher_status' => 'nullable|in:pending,approved,rejected', 'grade_level' => 'nullable|integer|min:1|max:12',
            'new_password' => 'nullable|string|min:8|max:100',
        ]);
        $me = $r->user();
        if ($user->id === $me->id && ($data['role'] !== 'admin' || $data['status'] !== 'active')) throw new DomainError('Không thể tự hạ quyền hoặc tự khóa tài khoản Admin đang dùng.');
        if ($user->isAdmin() && ($data['role'] !== 'admin' || $data['status'] !== 'active') && User::where('role', 'admin')->where('status', 'active')->count() <= 1) {
            throw new DomainError('Phải luôn còn ít nhất một Admin đang hoạt động.');
        }
        $old = $user->only(['name', 'full_name', 'role', 'status', 'teacher_status', 'grade_level']);
        $user->fill(['name' => $data['name'], 'full_name' => $data['full_name'] ?? null, 'role' => $data['role'], 'status' => $data['status'],
            'teacher_status' => $data['role'] === 'teacher' ? ($data['teacher_status'] ?? 'pending') : null,
            'grade_level' => $data['role'] === 'student' ? ($data['grade_level'] ?? $user->grade_level) : $user->grade_level]);
        if (!empty($data['new_password'])) { $user->password = $data['new_password']; $user->setRememberToken(Str::random(60)); }
        $user->save();
        if ($old['teacher_status'] !== $user->teacher_status && $user->teacher_status === 'approved') {
            Notifier::send($user->id, 'teacher', 'Tài khoản giáo viên của bạn đã được duyệt', 'Bạn có thể tạo lớp và giao bài.', route('teacher.home'));
        }
        Audit::log('admin.user_updated', $user, $old, $user->only(array_keys($old)) + (!empty($data['new_password']) ? ['password' => 'đổi'] : []));
        return back()->with('success', 'Đã lưu thay đổi.');
    }

    public function adjustXu(Request $r, User $user)
    {
        $data = $r->validate(['delta' => 'required|integer|between:-100000,100000|not_in:0', 'reason' => 'required|string|min:5|max:200'], [], ['delta' => 'số Xu', 'reason' => 'lý do']);
        $l = Economy::adminAdjust($user->id, (int) $data['delta'], $data['reason'], $r->user()->id);
        Audit::log('admin.xu_adjusted', $user, null, ['delta' => (int) $data['delta'], 'reason' => $data['reason'], 'ledger_id' => $l->id]);
        return back()->with('success', 'Đã điều chỉnh ' . $data['delta'] . ' Xu (ghi sổ cái kèm lý do).');
    }

    public function bulk(Request $r)
    {
        $data = $r->validate(['ids' => 'required|array|min:1|max:200', 'ids.*' => 'integer', 'action' => 'required|in:activate,suspend,approve_teacher,reject_teacher']);
        $ids = array_diff(array_map('intval', $data['ids']), [$r->user()->id]);
        $q = User::whereIn('id', $ids)->where('role', '<>', 'admin');
        $n = match ($data['action']) {
            'activate' => (clone $q)->update(['status' => 'active']),
            'suspend' => (clone $q)->update(['status' => 'suspended']),
            'approve_teacher' => (clone $q)->where('role', 'teacher')->update(['teacher_status' => 'approved']),
            'reject_teacher' => (clone $q)->where('role', 'teacher')->update(['teacher_status' => 'rejected']),
        };
        Audit::log('admin.users_bulk_' . $data['action'], null, null, ['ids' => array_values($ids), 'affected' => $n]);
        return back()->with('success', "Đã cập nhật {$n} tài khoản (không áp dụng cho Admin và chính bạn).");
    }
}
