<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\AppUpdate;
use App\Services\DomainError;
use App\Services\UpdateService;
use App\Support\Audit;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class UpdateController extends Controller
{
    public function index(Request $r)
    {
        $pending = session('update_pending');
        if ($pending && (!is_file(storage_path('app/updates/' . ($pending['file'] ?? '')))
            || version_compare((string) ($pending['info']['version'] ?? '0'), UpdateService::currentVersion(), '<='))) {
            session()->forget('update_pending');
            $pending = null;
        }
        // migration chưa chạy (vd. vừa chép tệp bản mới bằng tay mà không có Terminal)
        $migrator = app('migrator');
        $files = $migrator->getMigrationFiles([database_path('migrations')]);
        $ran = $migrator->getRepository()->repositoryExists() ? $migrator->getRepository()->getRan() : [];
        $todo = array_values(array_diff(array_keys($files), $ran));
        $hasTable = \Illuminate\Support\Facades\Schema::hasTable('app_updates');
        return view('admin.update', ['current' => UpdateService::currentVersion(), 'history' => $hasTable ? AppUpdate::latest('id')->limit(20)->get() : collect(), 'todo' => $todo,
            'pending' => $pending && is_file(storage_path('app/updates/' . $pending['file'])) ? $pending : null,
            'maxUpload' => ini_get('upload_max_filesize'), 'zipOk' => class_exists(\ZipArchive::class), 'local' => UpdateService::localPackages()]);
    }

    protected function confirmPassword(Request $r): void
    {
        $r->validate(['password' => 'required|string'], [], ['password' => 'mật khẩu của bạn']);
        if (!Hash::check($r->input('password'), $r->user()->password)) throw new DomainError('Mật khẩu xác nhận chưa đúng.');
    }

    public function upload(Request $r)
    {
        $this->confirmPassword($r);
        @set_time_limit(300);
        \Illuminate\Support\Facades\File::ensureDirectoryExists(storage_path('app/updates'));
        if ($r->filled('local')) {
            // gói đã đặt sẵn qua File Manager
            $name = basename((string) $r->input('local'));
            if (!in_array($name, UpdateService::localPackages(), true)) throw new DomainError('Không thấy gói ' . $name . ' trong storage/app/updates/.');
        } else {
            if (!$r->hasFile('package')) throw new DomainError('Chưa nhận được tệp. Có thể tệp lớn hơn giới hạn tải lên của máy chủ (' . ini_get('upload_max_filesize') . '): hãy dùng gói cập nhật rút gọn, hoặc tải gói vào thư mục storage/app/updates/ bằng File Manager rồi chọn ở ô bên dưới.');
            $r->validate(['package' => 'required|file|mimes:zip|max:102400'], [], ['package' => 'gói cập nhật']);
            $name = 'update-' . now()->format('YmdHis') . '-' . bin2hex(random_bytes(4)) . '.zip';
            $r->file('package')->move(storage_path('app/updates'), $name);
        }
        // v1.3: gói module lẻ (có module.json, không có chie-release.json) → cài module ngay, không đụng lõi.
        if (\App\Services\ModuleRegistry::isModuleZip(storage_path('app/updates/' . $name))) {
            try {
                $res = \App\Services\ModuleRegistry::installModuleZipPath(storage_path('app/updates/' . $name), $r->user()->id);
            } finally {
                if (!$r->filled('local')) @unlink(storage_path('app/updates/' . $name));
            }
            $msg = "Đã cài gói module {$res['name']} (v{$res['version']}).";
            if ($res['deployed']) $msg .= ' Đã triển khai: ' . implode(', ', $res['deployed']) . '.';
            if ($res['import']) $msg .= ' Đã nhập học liệu (lượt nhập #' . $res['import']['run_id'] . ').';
            return back()->with('success', $msg);
        }
        try {
            $info = UpdateService::inspect(storage_path('app/updates/' . $name));
        } catch (DomainError $e) {
            if (!$r->filled('local')) @unlink(storage_path('app/updates/' . $name));
            throw $e;
        }
        session(['update_pending' => ['file' => $name, 'info' => $info]]);
        Audit::log('system.update_checked', null, null, $info);
        return back()->with('success', 'Gói hợp lệ: phiên bản ' . $info['version'] . '. Xem lại rồi bấm "Áp dụng cập nhật".');
    }

    public function apply(Request $r)
    {
        $this->confirmPassword($r);
        $p = session('update_pending');
        if (!$p || !is_file(storage_path('app/updates/' . $p['file']))) throw new DomainError('Chưa có gói đã kiểm tra. Hãy tải gói lên lại.');
        @set_time_limit(300);
        $u = UpdateService::apply(storage_path('app/updates/' . $p['file']), $r->user());
        @unlink(storage_path('app/updates/' . $p['file']));
        session()->forget('update_pending');
        Audit::log('system.update_applied', $u, ['version' => $u->version_from], ['version' => $u->version_to]);
        return redirect()->route('admin.update')->with('success', 'Đã cập nhật lên ' . $u->version_to . '. Bản sao lưu: ' . $u->backup_path . '.');
    }

    /** Chạy migration còn thiếu (dùng khi cập nhật thủ công trên hosting không có Terminal). */
    public function migrate(Request $r)
    {
        $this->confirmPassword($r);
        @set_time_limit(300);
        UpdateService::migrateDatabase();
        UpdateService::clearRuntimeCaches();
        Audit::log('system.migrated');
        return back()->with('success', 'Đã cập nhật cấu trúc CSDL.');
    }

    public function discard(Request $r)
    {
        $p = session('update_pending');
        if ($p) @unlink(storage_path('app/updates/' . $p['file']));
        session()->forget('update_pending');
        return back()->with('info', 'Đã bỏ gói cập nhật.');
    }

    public function rollback(Request $r, AppUpdate $update)
    {
        $this->confirmPassword($r);
        UpdateService::rollback($update);
        Audit::log('system.update_rolled_back', $update);
        return back()->with('success', 'Đã hoàn tác tệp về phiên bản ' . $update->version_from . '. (Thay đổi CSDL, nếu có, không bị hoàn tác.)');
    }
}
