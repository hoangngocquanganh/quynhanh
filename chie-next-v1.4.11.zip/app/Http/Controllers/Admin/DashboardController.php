<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Services\Curriculum;
use Illuminate\Support\Facades\DB;

class DashboardController extends Controller
{
    public function index(\Illuminate\Http\Request $request)
    {
        $analytics = \App\Services\ActivityAnalytics::report(\App\Services\ActivityAnalytics::filters($request));
        if ($request->expectsJson()) return response()->json(['html'=>view('admin._analytics',['a'=>$analytics])->render(),'updated_at'=>now()->format('H:i:s')]);
        $today = today();
        $online = DB::table('user_live_status')->where('last_seen_at', '>=', now()->subSeconds(150))->groupBy('module')->selectRaw('module, COUNT(*) c')->pluck('c', 'module');
        $kpi = [
            'online' => $online->sum(),
            'new_users' => DB::table('users')->where('created_at', '>=', $today)->count(),
            'submitted' => DB::table('attempts')->where('status', 'submitted')->where('submitted_at', '>=', $today)->count(),
            'xu_in' => (int) DB::table('xu_ledger')->where('created_at', '>=', $today)->where('delta_xu', '>', 0)->sum('delta_xu'),
            'xu_out' => (int) -DB::table('xu_ledger')->where('created_at', '>=', $today)->where('delta_xu', '<', 0)->sum('delta_xu'),
            'errors' => DB::table('error_reports')->where('status', 'open')->count(),
        ];
        $todo = [
            'teachers' => DB::table('users')->where('role', 'teacher')->where('teacher_status', 'pending')->count(),
            'questions_review' => DB::table('questions')->where('status', 'review')->count(),
            'lessons_review' => DB::table('lessons')->where('status', 'review')->count(),
            'units_draft' => DB::table('units')->whereIn('status', ['draft', 'review'])->count(),
            'reports' => DB::table('error_reports')->where('kind', 'question_report')->where('status', 'open')->count(),
            'flags' => DB::table('cheat_flags')->where('status', 'open')->count(),
        ];
        $users = DB::table('users')->groupBy('role')->selectRaw('role, COUNT(*) c')->pluck('c', 'role');
        $feed = DB::table('user_live_status')->join('users', 'users.id', '=', 'user_live_status.user_id')->where('last_seen_at', '>=', now()->subSeconds(150))
            ->orderByDesc('last_seen_at')->limit(15)->get(['users.name', 'users.role', 'module', 'label', 'last_seen_at']);
        return view('admin.dashboard', ['analytics'=>$analytics, 'kpi' => $kpi, 'todo' => $todo, 'online' => $online, 'users' => $users, 'feed' => $feed, 'ready' => Curriculum::readinessAll()]);
    }
}
