<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\ErrorReport;
use App\Models\MediaFile;
use App\Models\Question;
use App\Services\Curriculum;
use App\Support\Audit;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class ContentController extends Controller
{
    public function index()
    {
        $byStatus = Question::groupBy('status')->selectRaw('status, COUNT(*) c')->pluck('c', 'status');
        $bySkill = Question::published()->groupBy('skill')->selectRaw('skill, COUNT(*) c')->pluck('c', 'skill');
        $flagged = Question::whereNotNull('flags')->where('status', '<>', 'published')->count();
        $media = MediaFile::latest('id')->limit(20)->get();
        return view('admin.content', ['ready' => Curriculum::readinessAll(), 'byStatus' => $byStatus, 'bySkill' => $bySkill, 'flagged' => $flagged, 'media' => $media,
            'lexicon' => DB::table('lexicon_items')->groupBy('status')->selectRaw('status, COUNT(*) c')->pluck('c', 'status')]);
    }

    public function reports()
    {
        $items = ErrorReport::with('user')->where('kind', 'question_report')->orderByRaw("status = 'resolved'")->latest('id')->paginate(30);
        return view('admin.reports', ['items' => $items]);
    }

    public function resolveReport(Request $r, ErrorReport $report)
    {
        $data = $r->validate(['quarantine' => 'nullable|boolean']);
        if (!empty($data['quarantine']) && $report->ref_id) {
            Question::whereKey($report->ref_id)->update(['status' => 'review']);
            Audit::log('question.quarantined', ['Question', $report->ref_id], null, null, $report->message);
            Curriculum::flush();
        }
        $report->update(['status' => 'resolved']);
        return back()->with('success', !empty($data['quarantine']) ? 'Đã tạm gỡ câu hỏi (chuyển "chờ duyệt") và đóng báo lỗi.' : 'Đã đóng báo lỗi.');
    }

    /** Tải lên âm thanh/hình học liệu (có giấy phép) — lưu storage/app/public, phục vụ qua /media/... */
    public function upload(Request $r)
    {
        $data = $r->validate(['file' => 'required|file|max:8192|mimetypes:audio/mpeg,audio/ogg,audio/wav,audio/x-wav,audio/webm,audio/mp4,image/png,image/jpeg,image/webp',
            'license' => 'required|string|max:60', 'license_source' => 'nullable|string|max:255'], [], ['license' => 'giấy phép']);
        $f = $r->file('file');
        $ext = strtolower($f->guessExtension() ?: 'bin');
        $path = $f->storeAs('hoc-lieu/' . date('Y/m'), Str::random(20) . '.' . $ext, 'public');
        $m = MediaFile::create(['path' => $path, 'original_name' => mb_substr($f->getClientOriginalName(), 0, 190), 'mime' => $f->getMimeType(), 'size' => $f->getSize(),
            'sha256' => hash_file('sha256', $f->getRealPath()), 'license' => $data['license'], 'license_source' => $data['license_source'] ?? null, 'uploaded_by' => $r->user()->id]);
        Audit::log('media.uploaded', $m, null, ['path' => $path, 'license' => $m->license]);
        return back()->with('success', 'Đã tải lên. Đường dẫn dùng trong câu hỏi: ' . route('media.show', $path));
    }
}
