<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Sticker;
use App\Models\StickerPack;
use App\Services\StickerService;
use App\Support\Audit;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

/** v1.3.3 — Admin → Sticker học tập: bật/tắt gói, chỉnh khoảng lớp, sửa từng sticker, nhập gói JSON. */
class StickerAdminController extends Controller
{
    public function index(Request $r)
    {
        if (!StickerService::available()) return response()->view('stickers.unavailable', [], 503);
        $packs = StickerPack::withCount('stickers')->orderBy('sort')->orderBy('id')->get();
        $open = $r->query('goi') ? $packs->firstWhere('code', $r->query('goi')) : null;
        $collectors = DB::table('user_stickers')->where('level', '>=', 1)->distinct()->count('user_id');
        $collected = DB::table('user_stickers')->where('level', '>=', 1)->count();
        return view('admin.stickers', ['packs' => $packs, 'open' => $open, 'stickers' => $open ? $open->stickers()->get() : collect(),
            'collectors' => $collectors, 'collected' => $collected]);
    }

    public function savePack(Request $r, StickerPack $pack)
    {
        $data = $r->validate([
            'title_vi' => 'required|string|max:120', 'title_en' => 'nullable|string|max:120', 'emoji' => 'nullable|string|max:16',
            'description' => 'nullable|string|max:255', 'grade_from' => 'required|integer|min:1|max:12', 'grade_to' => 'required|integer|min:1|max:12|gte:grade_from',
            'color' => 'required|in:green,sky,violet,coral,mai,dao', 'status' => 'required|in:draft,published,archived', 'sort' => 'nullable|integer|min:0|max:9999',
        ]);
        $old = $pack->toArray();
        $pack->update($data + ['sort' => (int) ($data['sort'] ?? $pack->sort)]);
        Audit::log('sticker.pack_updated', $pack, $old, $pack->toArray());
        return back()->with('success', 'Đã lưu gói "' . $pack->title_vi . '".');
    }

    public function saveSticker(Request $r, Sticker $sticker)
    {
        $data = $r->validate([
            'emoji' => 'required|string|max:16', 'word' => 'required|string|max:120', 'ipa' => 'nullable|string|max:120', 'meaning_vi' => 'required|string|max:190',
            'example_en' => 'nullable|string|max:255', 'example_vi' => 'nullable|string|max:255', 'note_vi' => 'nullable|string|max:255', 'is_active' => 'nullable|boolean',
        ]);
        $old = $sticker->toArray();
        $sticker->update($data + ['is_active' => $r->boolean('is_active')]);
        Audit::log('sticker.updated', $sticker, $old, $sticker->toArray());
        return back()->with('success', 'Đã lưu sticker "' . $sticker->word . '".');
    }

    public function import(Request $r)
    {
        $r->validate(['file' => 'required|file|max:4096']);
        $tmp = $r->file('file')->getRealPath();
        [$p, $s] = StickerService::importFile($tmp);
        Audit::log('sticker.imported', null, null, ['packs' => $p, 'stickers' => $s]);
        return back()->with('success', "Đã nhập {$p} gói mới, {$s} sticker mới (mục đã có giữ nguyên).");
    }
}
