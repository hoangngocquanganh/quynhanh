<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Lesson;
use App\Models\LexiconItem;
use App\Models\Question;
use App\Models\Unit;
use App\Services\Curriculum;
use App\Services\DomainError;
use App\Support\Audit;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

/** Cây chương trình: Lớp → Học kỳ → Chủ điểm (Unit) → Bài. Xuất bản/thu hồi có nhật ký. */
class CurriculumController extends Controller
{
    public function index(Request $r)
    {
        $g = max(1, min(12, (int) $r->query('lop', 3)));
        $units = Unit::where(fn ($q) => $q->where('grade_id', $g)->orWhere(fn ($w) => $w->where('grade_id', '<=', $g)->where('grade_to', '>=', $g)))
            ->with(['lessons' => fn ($q) => $q->withCount('questions')])->orderByRaw("kind = 'focus'")->orderBy('semester')->orderBy('sort')->get();
        return view('admin.curriculum', ['g' => $g, 'units' => $units, 'ready' => Curriculum::readiness($g)]);
    }

    public function saveUnit(Request $r)
    {
        $data = $r->validate(['id' => 'nullable|integer', 'grade_id' => 'required|integer|min:1|max:12', 'grade_to' => 'nullable|integer|min:1|max:12',
            'semester' => 'required|integer|min:1|max:2', 'sort' => 'required|integer|min:0|max:999', 'title_vi' => 'required|string|max:190',
            'title_en' => 'nullable|string|max:190', 'kind' => 'required|in:core,focus', 'description' => 'nullable|string|max:2000', 'status' => 'required|in:draft,review,published,archived']);
        $unit = !empty($data['id']) ? Unit::findOrFail($data['id']) : new Unit(['source' => 'admin']);
        $old = $unit->exists ? $unit->toArray() : null;
        unset($data['id']);
        $unit->fill($data);
        if ($unit->status === 'published') $unit->flags = null;
        $unit->save();
        Audit::log($old ? 'unit.updated' : 'unit.created', $unit, $old, $unit->toArray());
        Curriculum::flush();
        return back()->with('success', 'Đã lưu chủ điểm.');
    }

    public function editLesson(Lesson $lesson)
    {
        $lesson->load(['unit', 'questions']);
        $words = LexiconItem::whereIn('id', $lesson->content['vocab_ids'] ?? [])->get();
        return view('admin.lesson-edit', ['lesson' => $lesson, 'words' => $words, 'units' => Unit::orderBy('grade_id')->orderBy('sort')->get()]);
    }

    public function saveLesson(Request $r)
    {
        $data = $r->validate([
            'id' => 'nullable|integer', 'unit_id' => 'required|integer|exists:units,id', 'sort' => 'required|integer|min:0|max:999', 'title_vi' => 'required|string|max:190',
            'title_en' => 'nullable|string|max:190', 'lesson_type' => 'required|in:core,review,focus', 'difficulty' => 'required|integer|min:1|max:5',
            'is_public' => 'nullable|boolean', 'status' => 'required|in:draft,review,published,archived',
            'objectives' => 'nullable|string|max:2000', 'intro_vi' => 'nullable|string|max:3000', 'examples' => 'nullable|string|max:5000',
            'grammar_note_vi' => 'nullable|string|max:5000', 'mistakes' => 'nullable|string|max:5000', 'vocab_words' => 'nullable|string|max:3000',
            'question_ids' => 'nullable|string|max:5000',
        ]);
        $lesson = !empty($data['id']) ? Lesson::findOrFail($data['id']) : new Lesson(['source' => 'admin', 'created_by' => $r->user()->id]);
        $old = $lesson->exists ? $lesson->only(['title_vi', 'status', 'content', 'objectives']) : null;
        $lines = fn ($s) => array_values(array_filter(array_map('trim', preg_split('/\r?\n/', (string) $s)), fn ($x) => $x !== ''));
        $examples = array_map(function ($l) { [$en, $vi] = array_pad(array_map('trim', explode('=', $l, 2)), 2, null); return array_filter(['en' => $en, 'vi' => $vi]); }, $lines($data['examples'] ?? ''));
        $mistakes = [];
        foreach ($lines($data['mistakes'] ?? '') as $l) {
            $p = array_map('trim', explode('|', $l));
            if (count($p) >= 3) $mistakes[] = ['wrong' => $p[0], 'right' => $p[1], 'why_vi' => $p[2]];
        }
        $vocabIds = [];
        foreach (array_filter(array_map('trim', explode(',', (string) ($data['vocab_words'] ?? '')))) as $w) {
            $id = LexiconItem::where('word_key', mb_strtolower($w))->value('id');
            if (!$id) throw new DomainError('Từ "' . $w . '" chưa có trong Kho từ vựng. Hãy thêm ở mục Từ vựng trước.');
            $vocabIds[] = $id;
        }
        $content = array_merge($lesson->content ?? [], ['intro_vi' => $data['intro_vi'] ?? null, 'examples' => $examples, 'grammar_note_vi' => $data['grammar_note_vi'] ?? null,
            'mistakes' => $mistakes, 'vocab_ids' => $vocabIds]);
        unset($content['derived_from_questions']);
        $qIds = array_values(array_unique(array_filter(array_map('intval', preg_split('/[\s,]+/', (string) ($data['question_ids'] ?? ''))))));
        $unit = Unit::find($data['unit_id']);
        if ($qIds) {
            $bad = Question::whereIn('id', $qIds)->where(fn ($q) => $q->where('grade_id', '<', $unit->grade_id)->orWhere('grade_id', '>', $unit->grade_to ?? $unit->grade_id))->pluck('id');
            if ($bad->count()) throw new DomainError('Câu ' . $bad->implode(', ') . ' không thuộc lớp của chủ điểm này.');
            $missing = array_diff($qIds, Question::whereIn('id', $qIds)->pluck('id')->all());
            if ($missing) throw new DomainError('Không tìm thấy câu: ' . implode(', ', $missing));
        }
        DB::transaction(function () use ($lesson, $data, $content, $lines, $qIds, $r) {
            $lesson->fill(['unit_id' => $data['unit_id'], 'sort' => $data['sort'], 'title_vi' => $data['title_vi'], 'title_en' => $data['title_en'] ?? null,
                'lesson_type' => $data['lesson_type'], 'difficulty' => $data['difficulty'], 'is_public' => (bool) ($data['is_public'] ?? false), 'status' => $data['status'],
                'objectives' => $lines($data['objectives'] ?? ''), 'content' => $content]);
            if ($lesson->exists && $lesson->isDirty(['content', 'objectives'])) $lesson->version = $lesson->version + 1;
            if ($data['status'] === 'published' && $lesson->isDirty('status')) { $lesson->reviewed_by = $r->user()->id; $lesson->reviewed_at = now(); }
            $lesson->save();
            DB::table('lesson_question')->where('lesson_id', $lesson->id)->delete();
            foreach ($qIds as $i => $qid) DB::table('lesson_question')->insert(['lesson_id' => $lesson->id, 'question_id' => $qid, 'sort' => $i]);
        });
        Audit::log($old ? 'lesson.updated' : 'lesson.created', $lesson, $old, $lesson->only(['title_vi', 'status', 'content', 'objectives']));
        Curriculum::flush();
        return redirect()->route('admin.curriculum.lesson.edit', $lesson)->with('success', 'Đã lưu bài học.');
    }

    public function status(Request $r)
    {
        $data = $r->validate(['kind' => 'required|in:unit,lesson', 'ids' => 'required|array|min:1', 'ids.*' => 'integer', 'status' => 'required|in:draft,review,published,archived']);
        $model = $data['kind'] === 'unit' ? Unit::class : Lesson::class;
        $upd = ['status' => $data['status']];
        if ($data['status'] === 'published' && $data['kind'] === 'unit') $upd['flags'] = null;
        $n = $model::whereIn('id', $data['ids'])->update($upd);
        Audit::log($data['kind'] . '.bulk_' . $data['status'], null, null, ['ids' => $data['ids']]);
        Curriculum::flush();
        return back()->with('success', "Đã cập nhật {$n} mục.");
    }
}
