<?php

namespace App\Http\Controllers;

use App\Models\Attempt;
use App\Models\ExamBlueprint;
use App\Services\QuestionPicker;
use Illuminate\Http\Request;

class ExamController extends Controller
{
    public function home(Request $r)
    {
        $g = current_grade();
        if (!$g) return redirect()->route('grade.pick', ['next' => $r->getRequestUri()]);
        $available = QuestionPicker::availableCount($g);
        $blueprints = ExamBlueprint::forGrade($g)->where('is_active', true)->orderBy('sort')->get();
        $recent = $r->user() ? Attempt::where('user_id', $r->user()->id)->where('kind', 'exam')->where('status', 'submitted')
            ->where('grade_level', $g)->latest('submitted_at')->limit(8)->get() : collect();
        $open = $r->user() ? Attempt::where('user_id', $r->user()->id)->where('kind', 'exam')->where('status', 'in_progress')->latest('id')->first() : null;
        return view('exam.home', compact('blueprints', 'available', 'recent', 'open') + ['grade' => $g]);
    }
}
