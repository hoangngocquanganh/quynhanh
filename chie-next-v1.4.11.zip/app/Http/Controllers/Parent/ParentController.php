<?php

namespace App\Http\Controllers\Parent;

use App\Http\Controllers\Controller;
use App\Models\Assignment;
use App\Models\AssignmentSubmission;
use App\Models\GuardianLink;
use App\Models\GuardianLinkCode;
use App\Models\TermsVersion;
use App\Models\User;
use App\Services\Accounts;
use App\Services\DomainError;
use App\Services\NameFilter;
use App\Services\Notifier;
use App\Services\StudentReport;
use App\Support\Audit;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

/**
 * Phụ huynh: chỉ xem con ĐÃ LIÊN KẾT qua xác minh (mã do con tạo, hoặc tài khoản con do chính phụ huynh tạo).
 * Không sửa đáp án, không chấm điểm, không làm bài thay, không xem học sinh khác.
 */
class ParentController extends Controller
{
    protected function findChild(Request $r, int $id): User
    {
        abort_unless($r->user()->isParentOf($id), 404);
        return User::findOrFail($id);
    }

    public function home(Request $r)
    {
        $kids = $r->user()->children()->get();
        $cards = $kids->map(fn ($k) => ['child' => $k, 'report' => StudentReport::build($k, true)]);
        return view('parent.home', ['cards' => $cards]);
    }

    public function progress(Request $r)
    {
        $kids = $r->user()->children()->get();
        if ($kids->count() === 1) return redirect()->route('parent.child', $kids->first()->id);
        return view('parent.progress', ['kids' => $kids]);
    }

    public function child(Request $r, int $student)
    {
        $s = $this->findChild($r, $student);
        return view('parent.child', ['s' => $s, 'rep' => StudentReport::build($s, true)]);
    }

    public function work(Request $r)
    {
        $kids = $r->user()->children()->get()->keyBy('id');
        $classIds = DB::table('classroom_members')->whereIn('student_id', $kids->keys())->where('status', 'active')->get()->groupBy('student_id');
        $rows = collect();
        foreach ($kids as $kid) {
            $ids = ($classIds[$kid->id] ?? collect())->pluck('classroom_id');
            $as = Assignment::with(['classroom', 'teacher'])->whereIn('classroom_id', $ids)
                ->where(fn ($q) => $q->where('target', 'class')->orWhereExists(fn ($e) => $e->from('assignment_targets')->whereColumn('assignment_targets.assignment_id', 'assignments.id')->where('student_id', $kid->id)))
                ->latest('id')->limit(30)->get();
            $subs = AssignmentSubmission::where('student_id', $kid->id)->whereIn('assignment_id', $as->pluck('id'))->get()->keyBy('assignment_id');
            foreach ($as as $a) $rows->push(['kid' => $kid, 'a' => $a, 'sub' => $subs[$a->id] ?? null]);
        }
        return view('parent.work', ['rows' => $rows->sortByDesc(fn ($x) => $x['a']->id)->values()]);
    }

    public function links(Request $r)
    {
        $links = GuardianLink::with('student')->where('parent_id', $r->user()->id)->where('status', 'active')->get();
        return view('parent.links', ['links' => $links, 'suggest' => NameFilter::suggestions()]);
    }

    public function linkByCode(Request $r)
    {
        $data = $r->validate(['code' => 'required|string|max:20', 'relation' => 'nullable|string|max:30'], [], ['code' => 'mã liên kết']);
        $code = strtoupper(preg_replace('/[^A-Za-z0-9]/', '', $data['code']));
        $p = $r->user();
        return DB::transaction(function () use ($code, $p, $data) {
            $row = GuardianLinkCode::where('code_hash', hash('sha256', $code))->lockForUpdate()->first();
            if (!$row || $row->used_at || $row->revoked_at || $row->expires_at->isPast()) {
                Audit::log('guardian.code_failed', null, null, null, 'parent ' . $p->id);
                return redirect()->route('parent.links')->withErrors(['code' => 'Mã không đúng hoặc đã hết hạn. Hãy nhờ con tạo mã mới trong mục Hồ sơ → Liên kết phụ huynh.']);
            }
            $student = User::where('id', $row->student_id)->where('role', 'student')->first();
            if (!$student) return redirect()->route('parent.links')->withErrors(['code' => 'Mã không hợp lệ.']);
            $row->update(['used_at' => now(), 'used_by' => $p->id]);
            GuardianLink::updateOrCreate(['parent_id' => $p->id, 'student_id' => $student->id], [
                'status' => 'active', 'verified_via' => 'student_code', 'relation' => $data['relation'] ?? null, 'verified_at' => now(), 'revoked_at' => null, 'revoked_by' => null,
            ]);
            Audit::log('guardian.linked', $student, null, ['parent_id' => $p->id, 'via' => 'student_code']);
            Notifier::send($student->id, 'guardian', $p->name . ' đã liên kết tài khoản phụ huynh với bạn', 'Nếu bạn không đưa mã cho người này, hãy hủy liên kết trong Hồ sơ.', route('profile.show') . '#phu-huynh');
            return redirect()->route('parent.links')->with('success', 'Đã liên kết với ' . $student->name . '.');
        });
    }

    /** Phụ huynh tạo tài khoản cho con (dưới 16 tuổi), đăng nhập bằng tên đăng nhập + mật khẩu. */
    public function createChild(Request $r)
    {
        $data = $r->validate([
            'name' => 'required|string|min:2|max:30',
            'username' => ['required', 'string', 'min:4', 'max:30', 'regex:/^[a-z0-9_.]+$/'],
            'password' => 'required|string|min:6|max:100|confirmed',
            'grade' => 'required|integer|min:1|max:12',
            'birth_year' => 'required|integer|min:' . (date('Y') - 20) . '|max:' . (date('Y') - 4),
            'consent' => 'accepted',
        ], ['username.regex' => 'Tên đăng nhập chỉ gồm chữ thường không dấu, số, dấu chấm hoặc gạch dưới.', 'consent.accepted' => 'Bạn cần đồng ý điều khoản thay mặt con.',
            'password.confirmed' => 'Hai lần nhập mật khẩu chưa khớp.'],
            ['name' => 'tên hiển thị của con', 'username' => 'tên đăng nhập', 'password' => 'mật khẩu', 'grade' => 'lớp', 'birth_year' => 'năm sinh']);
        if ($msg = NameFilter::check($data['name'])) return back()->withErrors(['name' => $msg])->withInput();
        $username = mb_strtolower($data['username']);
        if (User::where('username', $username)->exists() || NameFilter::check($username, 4, 30)) {
            return back()->withErrors(['username' => 'Tên đăng nhập đã có người dùng hoặc chưa phù hợp, hãy chọn tên khác.'])->withInput();
        }
        $p = $r->user();
        $child = DB::transaction(function () use ($data, $username, $p, $r) {
            $child = Accounts::create(['name' => trim($data['name']), 'username' => $username, 'password' => $data['password'], 'role' => 'student',
                'grade_level' => (int) $data['grade'], 'birth_year' => (int) $data['birth_year'], 'created_by_parent_id' => $p->id]);
            GuardianLink::create(['parent_id' => $p->id, 'student_id' => $child->id, 'status' => 'active', 'verified_via' => 'created_by_parent', 'verified_at' => now()]);
            if ($t = TermsVersion::where('is_active', true)->first()) Accounts::recordConsent($child, $t, $r, $p->id);
            Audit::log('guardian.child_created', $child, null, ['parent_id' => $p->id]);
            return $child;
        });
        return back()->with('success', 'Đã tạo tài khoản cho ' . $child->name . '. Con đăng nhập bằng tên "' . $username . '" và mật khẩu bạn vừa đặt.');
    }

    public function unlink(Request $r, GuardianLink $link)
    {
        abort_unless($link->parent_id === $r->user()->id && $link->status === 'active', 404);
        $link->update(['status' => 'revoked', 'revoked_at' => now(), 'revoked_by' => $r->user()->id]);
        Audit::log('guardian.revoked_by_parent', $link);
        return back()->with('success', 'Đã hủy liên kết. Bạn sẽ không xem được dữ liệu của con này nữa.');
    }

    public function resetChildPassword(Request $r, int $student)
    {
        $s = $this->findChild($r, $student);
        if ($s->created_by_parent_id !== $r->user()->id) throw new DomainError('Chỉ đặt lại được mật khẩu cho tài khoản con do bạn tạo. Tài khoản có email hãy dùng "Quên mật khẩu".');
        $data = $r->validate(['password' => 'required|string|min:6|max:100|confirmed'], ['password.confirmed' => 'Hai lần nhập mật khẩu chưa khớp.']);
        $s->password = $data['password'];
        $s->setRememberToken(Str::random(60));
        $s->save();
        Audit::log('guardian.child_password_reset', $s);
        return back()->with('success', 'Đã đặt lại mật khẩu cho ' . $s->name . '.');
    }

    public function selfGrade(Request $r)
    {
        $data = $r->validate(['grade' => 'required|integer|min:1|max:12']);
        $u = $r->user();
        $s = $u->settings ?? []; $s['self_grade'] = (int) $data['grade']; $u->settings = $s; $u->save();
        return redirect()->route('learn.home');
    }
}
