<?php

namespace App\Http\Controllers;

abstract class Controller
{
    protected function user(): ?\App\Models\User
    {
        return auth()->user();
    }
}
