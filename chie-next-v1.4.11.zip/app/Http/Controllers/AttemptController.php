<?php

namespace App\Http\Controllers;

use App\Models\Attempt;
use App\Services\AttemptService;
use App\Support\Audit;
use Illuminate\Http\Request;

class AttemptController extends Controller
{
    public function show(Request $r, Attempt $attempt)
    {
        abort_unless($attempt->user_id === $r->user()->id, 404);
        $attempt = AttemptService::expireIfNeeded($attempt);
        if ($attempt->status !== 'in_progress') return redirect()->route('attempt.result', $attempt);
        return view('attempt.player', ['attempt' => $attempt, 'mode' => 'live']);
    }

    public function result(Request $r, Attempt $attempt)
    {
        // xem bài của người kia trong Thử thách gia đình khi cả hai đã làm xong
        $familyPeer = $attempt->kind === 'family' && $attempt->user_id !== $r->user()->id
            && \App\Models\FamilyChallenge::whereKey($attempt->ref_id)->where('status', 'done')
                ->where(fn ($q) => $q->where('parent_id', $r->user()->id)->orWhere('student_id', $r->user()->id))->exists();
        abort_unless($attempt->user_id === $r->user()->id || $familyPeer, 404);
        $attempt = AttemptService::expireIfNeeded($attempt);
        if ($attempt->status === 'in_progress') return redirect()->route('attempt.show', $attempt);
        if ($attempt->kind === 'raid') return redirect()->route('farm.raid');
        $view = AttemptService::view($attempt);
        $next = null;
        if ($attempt->kind === 'lesson' && $attempt->ref_type === 'lesson') {
            $path = \App\Services\Curriculum::path($attempt->grade_level, $r->user());
            $next = $path['current'];
        }
        return view('attempt.result', ['attempt' => $attempt, 'view' => $view, 'result' => $view['result'], 'next' => $next]);
    }

    public function revokeShare(Request $r, Attempt $attempt)
    {
        abort_unless($attempt->user_id === $r->user()->id, 404);
        $attempt->share_revoked_at = now();
        $attempt->save();
        Audit::log('share.revoked_by_owner', $attempt);
        return back()->with('success', 'Đã thu hồi link chia sẻ. Người có link cũ sẽ không xem được nữa.');
    }
}
