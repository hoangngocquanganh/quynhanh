<?php

namespace App\Http\Controllers;

use App\Models\TermsVersion;
use App\Models\User;
use App\Services\Accounts;
use App\Services\NameFilter;
use App\Support\Audit;
use App\Support\Nav;
use App\Support\Settings;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rule;

class AuthController extends Controller
{
    public function showLogin(Request $r)
    {
        return view('auth.login', ['next' => $r->query('next')]);
    }

    public function login(Request $r)
    {
        $data = $r->validate(['login' => 'required|string|max:190', 'password' => 'required|string|max:200', 'next' => 'nullable|string|max:300'],
            [], ['login' => 'email hoặc tên đăng nhập', 'password' => 'mật khẩu']);
        $login = trim($data['login']);
        $user = str_contains($login, '@')
            ? User::where('email', mb_strtolower($login))->orWhere('canonical_email', NameFilter::canonicalEmail($login))->first()
            : User::where('username', mb_strtolower($login))->first();
        if (!$user || !Hash::check($data['password'], $user->password)) {
            if ($user) Audit::log('auth.login_failed', $user);   // chỉ ghi khi tài khoản tồn tại; không lưu mật khẩu đã nhập
            return back()->withInput($r->only('login'))->withErrors(['login' => 'Email/tên đăng nhập hoặc mật khẩu chưa đúng.']);
        }
        if ($user->status !== 'active') {
            return back()->withInput($r->only('login'))->withErrors(['login' => 'Tài khoản đang tạm khóa. Vui lòng liên hệ quản trị viên hoặc phụ huynh.']);
        }
        Auth::login($user, $r->boolean('remember'));
        $r->session()->regenerate();
        $user->forceFill(['last_login_at' => now()])->save();
        if (in_array($user->role, ['admin', 'teacher'], true)) Audit::log('auth.login', $user);
        $next = safe_next($data['next'] ?? null);
        return redirect()->to($next ?: Nav::home($user));
    }

    public function logout(Request $r)
    {
        Auth::logout();
        $r->session()->invalidate();
        $r->session()->regenerateToken();
        return redirect()->route('home');
    }

    public function showRegister(Request $r)
    {
        $role = in_array($r->query('vai-tro'), ['student', 'parent', 'teacher'], true) ? $r->query('vai-tro') : 'student';
        if ($role === 'teacher' && !Settings::get('auth.allow_teacher_signup')) $role = 'student';
        return view('auth.register', ['role' => $role, 'terms' => TermsVersion::where('is_active', true)->first(),
            'grade' => current_grade(), 'suggest' => NameFilter::suggestions(), 'minAge' => (int) Settings::get('auth.min_self_signup_age', 16)]);
    }

    public function register(Request $r)
    {
        $roles = Settings::get('auth.allow_teacher_signup') ? 'student,parent,teacher' : 'student,parent';
        $year = (int) date('Y');
        $data = $r->validate([
            'role' => 'required|in:' . $roles,                         // không có lựa chọn tự đăng ký Admin
            'name' => 'required|string|min:2|max:30',
            'email' => 'required|email:rfc|max:190',
            'password' => 'required|string|min:8|max:100|confirmed',
            'grade' => 'required_if:role,student|nullable|integer|min:1|max:12',
            'birth_year' => 'required_if:role,student|nullable|integer|min:' . ($year - 100) . '|max:' . ($year - 4),
            'full_name' => 'required_if:role,teacher|nullable|string|max:120',
            'school' => 'nullable|string|max:190',
            'agree' => 'accepted',
        ], [
            'agree.accepted' => 'Bạn cần đọc hết và đồng ý Điều khoản sử dụng.',
            'grade.required_if' => 'Học sinh cần chọn lớp đang học.',
            'birth_year.required_if' => 'Học sinh cần nhập năm sinh.',
            'password.confirmed' => 'Hai lần nhập mật khẩu chưa khớp.',
        ], ['name' => 'tên hiển thị', 'email' => 'email', 'password' => 'mật khẩu', 'full_name' => 'họ tên', 'grade' => 'lớp', 'birth_year' => 'năm sinh']);

        if ($msg = NameFilter::check($data['name'])) return back()->withInput($r->except('password', 'password_confirmation'))->withErrors(['name' => $msg]);
        if (NameFilter::disposableDomain($data['email'])) return back()->withInput($r->except('password', 'password_confirmation'))->withErrors(['email' => 'Vui lòng dùng email thật (không dùng email tạm thời).']);
        $canon = NameFilter::canonicalEmail($data['email']);
        if (User::where('canonical_email', $canon)->orWhere('email', mb_strtolower($data['email']))->exists()) {
            return back()->withInput($r->except('password', 'password_confirmation'))->withErrors(['email' => 'Email này đã có tài khoản. Hãy đăng nhập hoặc dùng "Quên mật khẩu".']);
        }
        if ($data['role'] === 'student') {
            $age = $year - (int) $data['birth_year'];
            $min = (int) Settings::get('auth.min_self_signup_age', 16);
            if ($age < $min) {
                return back()->withInput($r->except('password', 'password_confirmation'))->with('under_age', true)->withErrors(['birth_year' =>
                    "Học sinh dưới {$min} tuổi cần phụ huynh tạo tài khoản. Bố mẹ hãy đăng ký tài khoản Phụ huynh, sau đó vào mục \"Liên kết & cài đặt\" → \"Tạo tài khoản cho con\"."]);
            }
        }
        $terms = TermsVersion::where('is_active', true)->first();
        $user = Accounts::create([
            'name' => trim($data['name']), 'email' => mb_strtolower($data['email']), 'canonical_email' => $canon,
            'password' => $data['password'], 'role' => $data['role'],
            'teacher_status' => $data['role'] === 'teacher' ? 'pending' : null,
            'grade_level' => $data['role'] === 'student' ? (int) $data['grade'] : null,
            'birth_year' => $data['birth_year'] ?? null, 'full_name' => $data['full_name'] ?? null,
            'settings' => array_filter(['school' => $data['school'] ?? null]),
        ]);
        if ($terms) Accounts::recordConsent($user, $terms, $r);
        Audit::log('auth.register', $user, null, ['role' => $user->role]);
        Auth::login($user);
        $r->session()->regenerate();
        if (Settings::get('auth.require_email_verification')) {
            \App\Services\EmailCodes::send($user);
            return redirect()->route('verify.show');
        }
        if ($user->role === 'teacher') return redirect()->route('teacher.pending');
        return redirect()->to(Nav::home($user))->with('success', 'Chào mừng ' . $user->name . ' đến với CHIE NEXT!');
    }
}
