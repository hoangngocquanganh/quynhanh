<?php

namespace App\Http\Controllers;

use App\Models\Attempt;
use App\Models\FarmRaid;
use App\Services\FarmService;
use App\Services\NameFilter;
use App\Services\RaidService;
use App\Services\ZooGardenService;
use App\Support\Settings;
use Illuminate\Http\Request;

class FarmController extends Controller
{
    /** /nong-trai: Zoo Garden 3D (v1.3) nếu Admin bật, ngược lại nông trại cổ điển. */
    public function show(Request $r)
    {
        if (ZooGardenService::cfg('zoo.enabled') && ZooGardenService::bundle()['js']) {
            return view('farm.zoo', ['playtime' => ZooGardenService::playtimeState($r->user())]);
        }
        return $this->classic($r);
    }

    /** Khung chơi Zoo Garden (trang độc lập, nhúng bằng iframe trong /nong-trai — tách CSS/JS khỏi giao diện CHIE). */
    public function zooFrame(Request $r)
    {
        if (!ZooGardenService::cfg('zoo.enabled')) return redirect()->route('farm.classic');
        $bundle = ZooGardenService::bundle();
        abort_unless($bundle['js'], 503, 'Chưa có bản build Zoo Garden trong assets/zoo-garden.');
        $res = response()->view('farm.zoo-frame', ['boot' => ZooGardenService::bootPayload($r->user()), 'bundle' => $bundle]);
        // WebGL + bộ giải nén Meshopt (WebAssembly) cần 'wasm-unsafe-eval'; dữ liệu khởi tạo nằm trong <script type="application/json">.
        $res->headers->set('Content-Security-Policy', "default-src 'self'; script-src 'self' 'wasm-unsafe-eval'; worker-src 'self' blob:; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; media-src 'self' data: blob:; font-src 'self' data:; connect-src 'self' data: blob:; frame-ancestors 'self'; base-uri 'self'; form-action 'self'");
        return $res;
    }

    /** Nông trại cổ điển (bản 1.2) — vẫn giữ để dùng khi tắt Zoo Garden hoặc máy yếu. */
    public function classic(Request $r)
    {
        $u = $r->user();
        FarmService::expireCold($u->id);
        $cat = FarmService::catalog();
        return view('farm.show', ['crops' => $cat['crops'], 'recipes' => $cat['recipes'], 'animalKinds' => $cat['animals'], 'state' => FarmService::state($u),
            'shieldPrices' => Settings::get('farm.shield_prices', []), 'wallPrices' => Settings::get('farm.wall_prices', []),
            'coldPrice' => (int) Settings::get('farm.cold_price_per_hour', 6), 'innerPrice' => (int) Settings::get('farm.inner_expand_price', 150)]);
    }

    public function raid(Request $r)
    {
        $u = $r->user();
        $open = FarmRaid::where('attacker_id', $u->id)->where('status', 'in_progress')->latest('id')->first();
        if ($open && $open->expires_at->isPast()) $open = RaidService::finish($u, $open);
        $history = FarmRaid::with(['attacker', 'defender'])->where(fn ($q) => $q->where('attacker_id', $u->id)->orWhere('defender_id', $u->id))->latest('id')->limit(15)->get();
        $last = FarmRaid::where('attacker_id', $u->id)->whereIn('status', ['won', 'lost'])->latest('finished_at')->first();
        return view('farm.raid', ['candidates' => RaidService::candidates($u), 'open' => $open && $open->status === 'in_progress' ? $open : null, 'history' => $history,
            'last' => $last && $last->finished_at && $last->finished_at->gt(now()->subMinutes(5)) ? $last : null,
            'fee' => (int) Settings::get('raid.fee_xu', 30), 'enabled' => (bool) Settings::get('raid.enabled', true), 'minLevel' => (int) Settings::get('raid.min_level', 3)]);
    }
}
