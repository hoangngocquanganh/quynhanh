<?php

namespace App\Http\Controllers;

use App\Services\EmailCodes;
use App\Support\Nav;
use Illuminate\Http\Request;

class VerifyController extends Controller
{
    public function show(Request $r)
    {
        if ($r->user()->email_verified_at) return redirect(Nav::home($r->user()));
        return view('auth.verify');
    }

    public function verify(Request $r)
    {
        $data = $r->validate(['code' => 'required|digits:6'], [], ['code' => 'mã xác minh']);
        if (!EmailCodes::verify($r->user(), $data['code'])) return back()->withErrors(['code' => 'Mã chưa đúng, hãy kiểm tra lại email.']);
        return redirect(Nav::home($r->user()))->with('success', 'Đã xác minh email. Cảm ơn bạn!');
    }

    public function resend(Request $r)
    {
        EmailCodes::send($r->user());
        return back()->with('success', 'Đã gửi mã mới tới ' . $r->user()->email . '.');
    }
}
