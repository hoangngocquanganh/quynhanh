<?php

namespace App\Http\Controllers;

use App\Models\TermsVersion;

class LegalController extends Controller
{
    public function show()
    {
        return view('legal.show', ['terms' => TermsVersion::where('is_active', true)->first()]);
    }
}
