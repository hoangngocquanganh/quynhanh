<?php
namespace App\Http\Controllers;

use App\Models\World;
use App\Models\WorldLevel;
use App\Services\GuestAttempt;
use App\Services\QuestionPicker;
use App\Services\ZooGardenService;
use App\Services\DomainError;
use Illuminate\Http\Request;

class GuestPlayController extends Controller
{
    public function world(Request $r)
    {
        if ($r->user()) return redirect()->route('world.show');
        if (!current_grade()) return redirect()->route('grade.pick',['next'=>$r->getRequestUri()]);
        $world=World::where('is_active',true)->with(['levels'=>fn($q)=>$q->where('is_active',true)])->orderBy('sort')->first();
        $states=[];
        foreach($world?->levels ?? [] as $lv) $states[$lv->id]=['open'=>true,'passed'=>false,'stars'=>0,'best'=>null];
        return view('game.world',['world'=>$world,'states'=>$states,'grade'=>current_grade(),'guest'=>true]);
    }

    public function startWorld(Request $r, WorldLevel $level)
    {
        abort_if($r->user(),403,'Lượt khách chỉ dành cho người chưa đăng nhập.');
        abort_unless($level->is_active && $level->world?->is_active,404);
        $g=current_grade(); if(!$g)throw new DomainError('Hãy chọn lớp trước khi chơi.');
        $qs=QuestionPicker::pick($g,max(5,min(30,(int)$level->question_count)),null,[]);
        if($qs->count()<5)throw new DomainError('Lớp này chưa đủ câu hỏi đã duyệt cho màn chơi.');
        return GuestAttempt::create($qs,$level->title,'guest_play');
    }

    public function farm(Request $r)
    {
        if($r->user())return redirect()->route('farm.show');
        if(ZooGardenService::cfg('zoo.enabled') && ZooGardenService::bundle()['js'])
            return view('farm.zoo',['playtime'=>['gate_enabled'=>false],'guest'=>true]);
        return $this->classic($r);
    }

    public function frame(Request $r)
    {
        if($r->user())return redirect()->route('farm.zoo.frame');
        if(!ZooGardenService::cfg('zoo.enabled'))return redirect()->route('guest.play.farm.classic');
        $bundle=ZooGardenService::bundle();abort_unless($bundle['js'],503,'Nông trại 3D đang cập nhật. Hãy thử bản cổ điển.');
        $boot=ZooGardenService::guestPayload();
        $res=response()->view('farm.zoo-frame',compact('boot','bundle'));
        $res->headers->set('Content-Security-Policy',"default-src 'self'; script-src 'self' 'wasm-unsafe-eval'; worker-src 'self' blob:; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; media-src 'self' data: blob:; font-src 'self' data:; connect-src 'self' data: blob:; frame-ancestors 'self'; base-uri 'self'; form-action 'self'");
        return $res;
    }

    public function classic(Request $r)
    {
        if($r->user())return redirect()->route('farm.classic');
        return view('farm.guest');
    }
}
