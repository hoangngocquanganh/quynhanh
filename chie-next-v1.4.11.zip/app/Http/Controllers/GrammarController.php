<?php

namespace App\Http\Controllers;

use App\Models\GrammarTopic;
use App\Models\Question;
use App\Models\SkillStat;
use App\Services\AttemptService;
use App\Services\DomainError;
use Illuminate\Http\Request;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;

/**
 * Menu Ngữ pháp theo CT GDPT 2018: chủ điểm từng lớp (HK1/HK2), luyện cơ bản / nâng cao,
 * ôn giữa kì – cuối kì theo học kì, ôn thi vào 10 (lớp 9) và ôn thi tốt nghiệp THPT (lớp 12).
 * Học sinh chỉ luyện câu đã duyệt; Admin/giáo viên xem thử được cả câu chờ duyệt.
 */
class GrammarController extends Controller
{
    public const STAGES = ['tieu_hoc' => ['Tiểu học', [1, 2, 3, 4, 5]], 'thcs' => ['THCS', [6, 7, 8, 9]], 'thpt' => ['THPT', [10, 11, 12]]];

    /** Bài ôn theo học kì: [tên, học kì lấy chủ điểm, nửa đầu học kì?, số câu, phút] */
    public const TESTS = [
        'mid1' => ['Ôn thi giữa học kì 1', [1], true, 20, 30],
        'end1' => ['Ôn thi cuối học kì 1', [1], false, 30, 45],
        'mid2' => ['Ôn thi giữa học kì 2', [2], true, 20, 30],
        'end2' => ['Ôn thi cuối học kì 2 (cả năm)', [1, 2], false, 30, 45],
    ];

    public static function canPreview($u): bool
    {
        return $u && in_array($u->role, ['admin', 'teacher'], true);
    }

    public function index(Request $r)
    {
        if (!\Illuminate\Support\Facades\Schema::hasTable('grammar_topics')) return response()->view('grammar.unavailable', [], 503);
        $u = $r->user();
        $g = (int) ($r->query('lop') ?: current_grade() ?: 6);
        $g = max(1, min(12, $g));
        $topics = GrammarTopic::where('grade_id', $g)->where('status', 'published')->orderBy('track')->orderBy('semester')->orderBy('sort')->get();
        $counts = $this->counts($topics);
        $progress = $this->progress($u, $topics);
        return view('grammar.index', [
            'grade' => $g, 'stage' => GrammarTopic::stageOf($g), 'core' => $topics->where('track', 'core')->groupBy('semester'),
            'exam' => $topics->where('track', '<>', 'core'), 'counts' => $counts, 'progress' => $progress,
            'preview' => self::canPreview($u), 'tests' => self::TESTS,
            'gradeTopics' => GrammarTopic::where('status', 'published')->groupBy('grade_id')->selectRaw('grade_id, COUNT(*) c')->pluck('c', 'grade_id'),
        ]);
    }

    public function show(Request $r, string $code)
    {
        if (!\Illuminate\Support\Facades\Schema::hasTable('grammar_topics')) return response()->view('grammar.unavailable', [], 503);
        $topic = GrammarTopic::where('code', $code)->where('status', 'published')->firstOrFail();
        $u = $r->user();
        $siblings = GrammarTopic::where('grade_id', $topic->grade_id)->where('track', $topic->track)->where('status', 'published')
            ->orderBy('semester')->orderBy('sort')->get(['id', 'code', 'title_vi', 'semester', 'sort']);
        $i = $siblings->search(fn ($t) => $t->id === $topic->id);
        return view('grammar.show', [
            'topic' => $topic, 'counts' => $this->counts(collect([$topic]))[$topic->code], 'progress' => $this->progress($u, collect([$topic]))[$topic->code] ?? null,
            'preview' => self::canPreview($u), 'prev' => $i > 0 ? $siblings[$i - 1] : null, 'next' => $siblings[$i + 1] ?? null,
        ]);
    }

    /** POST api/grammar/start — {topic, level} | {grade, test} | {grade, track} */
    public function start(Request $r)
    {
        if (!\Illuminate\Support\Facades\Schema::hasTable('grammar_topics')) throw new DomainError('Ngữ pháp đang chờ cập nhật CSDL. Vui lòng liên hệ quản trị viên.');
        $data = $r->validate([
            'topic' => 'nullable|string|max:40', 'level' => 'nullable|in:co-ban,nang-cao,tat-ca',
            'grade' => 'nullable|integer|min:1|max:12', 'test' => 'nullable|in:' . implode(',', array_keys(self::TESTS)), 'track' => 'nullable|in:exam10,examgrad',
            'preview' => 'nullable|boolean', 'from' => 'nullable|in:tu-hoc',
        ]);
        $u = $r->user();
        $statuses = (!empty($data['preview']) && self::canPreview($u)) ? ['published', 'review'] : ['published'];
        $previewNote = count($statuses) > 1 ? ' (xem thử, gồm câu chờ duyệt)' : '';

        if (!empty($data['topic'])) {
            $topic = GrammarTopic::where('code', $data['topic'])->where('status', 'published')->firstOrFail();
            $level = $data['level'] ?? 'tat-ca';
            $qs = $this->pick(collect([$topic]), $statuses, 10, $level === 'tat-ca' ? null : $level);
            $grade = $topic->grade_id;
            $title = 'Ngữ pháp: ' . $topic->title_vi . ($level === 'co-ban' ? ' · Cơ bản' : ($level === 'nang-cao' ? ' · Nâng cao' : ''));
            $opts = ['feedback' => 'immediate'];
            $meta = ['mode' => 'grammar', 'topic' => $topic->code, 'level' => $level];
        } else {
            $grade = (int) ($data['grade'] ?? current_grade() ?? 0);
            if ($grade < 1) throw new DomainError('Hãy chọn lớp trước.');
            if (!empty($data['track'])) {
                $topics = GrammarTopic::where('grade_id', $grade)->where('track', $data['track'])->where('status', 'published')->get();
                [$title, $n, $min] = [GrammarTopic::TRACKS[$data['track']], 40, 60];
                $meta = ['mode' => 'grammar_exam', 'track' => $data['track']];
            } else {
                [$title, $sems, $half, $n, $min] = self::TESTS[$data['test'] ?? 'end1'];
                $topics = $this->testTopics($grade, $sems, $half);
                $meta = ['mode' => 'grammar_exam', 'test' => $data['test'] ?? 'end1'];
            }
            $qs = $this->pick($topics, $statuses, $n);
            $title .= ' · ' . grade_name($grade);
            $opts = ['feedback' => 'after_submit', 'duration_min' => max(5, (int) round($min * max(1, $qs->count()) / $n))];
        }
        if ($qs->count() < 3) {
            $waiting = $this->pick($topics ?? collect([$topic]), ['review'], 50)->count();
            throw new DomainError('Phần này chưa có đủ câu hỏi đã duyệt' . ($waiting ? " ({$waiting} câu đang chờ giáo viên duyệt)" : '') . '. Hãy thử chủ điểm khác nhé!');
        }
        if (!$u) return \App\Services\GuestAttempt::create($qs, $title, 'grammar');
        $a = AttemptService::create($u, empty($data['topic']) ? 'exam' : 'lesson', 'grammar', null, $grade, $qs,
            ['title' => $title . $previewNote, 'meta' => $meta + array_filter(['from' => $data['from'] ?? null])] + $opts);
        return ['redirect' => route('attempt.show', $a)];
    }

    /** Chủ điểm cho bài ôn học kì: giữa kì = nửa đầu danh sách của học kì đó. */
    protected function testTopics(int $grade, array $sems, bool $half): Collection
    {
        $all = GrammarTopic::where('grade_id', $grade)->where('track', 'core')->where('status', 'published')->whereIn('semester', $sems)->orderBy('semester')->orderBy('sort')->get();
        return $half ? $all->take(max(1, (int) ceil($all->count() / 2))) : $all;
    }

    /** Lấy câu trải đều các chủ điểm (mỗi chủ điểm một phần), xáo trộn. */
    protected function pick(Collection $topics, array $statuses, int $n, ?string $level = null): Collection
    {
        if ($topics->isEmpty()) return collect();
        $per = max(2, (int) ceil($n / $topics->count()));
        $out = collect();
        foreach ($topics as $t) {
            $q = Question::whereIn('status', $statuses)->whereJsonContains('tags', $t->tag());
            if ($level) $q->whereJsonContains('tags', 'gp-level:' . $level);
            $out = $out->merge($q->inRandomOrder()->limit($per)->get());
        }
        return $out->unique('id')->shuffle()->take($n)->values();
    }

    /** Số câu theo chủ điểm: đã duyệt (cơ bản/nâng cao) và chờ duyệt. */
    protected function counts(Collection $topics): array
    {
        $out = [];
        foreach ($topics as $t) $out[$t->code] = ['co-ban' => 0, 'nang-cao' => 0, 'review' => 0];
        if ($topics->isEmpty()) return $out;
        $rows = Question::whereIn('status', ['published', 'review'])->where(function ($q) use ($topics) {
            foreach ($topics as $t) $q->orWhereJsonContains('tags', $t->tag());
        })->get(['tags', 'status']);
        foreach ($rows as $row) {
            $tags = $row->tags ?? [];
            foreach ($tags as $tag) {
                if (!str_starts_with($tag, 'gp:') || !isset($out[substr($tag, 3)])) continue;
                $c = &$out[substr($tag, 3)];
                if ($row->status === 'review') $c['review']++;
                else $c[in_array('gp-level:nang-cao', $tags, true) ? 'nang-cao' : 'co-ban']++;
                unset($c);
            }
        }
        return $out;
    }

    /** Tỉ lệ đúng của học sinh theo chủ điểm (skill_stats ghi theo nhãn gp:<mã>). */
    protected function progress($u, Collection $topics): array
    {
        if (!$u || $topics->isEmpty()) return [];
        return SkillStat::where('user_id', $u->id)->whereIn('tag', $topics->map(fn ($t) => $t->tag()))->get()
            ->groupBy('tag')->map(fn ($rows) => ['correct' => (int) $rows->sum('correct'), 'total' => (int) $rows->sum('total')])
            ->mapWithKeys(fn ($v, $k) => [substr($k, 3) => $v])->all();
    }
}
