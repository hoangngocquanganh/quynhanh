<?php

namespace App\Http\Controllers;

use App\Models\Attempt;
use App\Models\World;
use App\Models\WorldProgress;
use App\Services\Economy;
use App\Services\Games;
use App\Support\Settings;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class GameController extends Controller
{
    public function home(Request $r)
    {
        $g = current_grade();
        if (!$g) return redirect()->route('grade.pick', ['next' => $r->getRequestUri()]);
        $configs = \App\Models\GameConfig::pluck('enabled', 'game_code');
        $avail = [];
        foreach (array_keys(Games::LIST) as $code) $avail[$code] = Games::available($code, $g);
        $u = $r->user();
        $recent = $u ? Attempt::where('user_id', $u->id)->where('kind', 'game')->where('status', 'submitted')->latest('submitted_at')->limit(5)->get() : collect();
        return view('game.home', ['grade' => $g, 'configs' => $configs, 'avail' => $avail, 'recent' => $recent, 'isStudent' => $u && ($u->isStudent() || $u->isAdmin())]);   // Admin dùng khu game như học sinh để kiểm tra
    }

    public function play(Request $r, string $code)
    {
        if (!current_grade()) return redirect()->route('grade.pick', ['next' => $r->getRequestUri()]);
        abort_unless(isset(Games::LIST[$code]), 404);
        $cfg = Games::config($code);
        if (!$cfg || !$cfg->enabled) return redirect()->route('game.home')->with('info', 'Game này đang tạm đóng để bảo trì.');
        return view('game.play', ['code' => $code, 'meta' => Games::LIST[$code], 'cfg' => $cfg, 'grade' => current_grade(),
            'available' => Games::available($code, current_grade())]);
    }

    /** Trạng thái mở khóa các màn của Thế giới phiêu lưu (theo lớp hiện tại). */
    public static function worldStates(\App\Models\User $u): array
    {
        $g = $u->grade_level;
        $world = World::where('is_active', true)->with(['levels' => fn ($q) => $q->where('is_active', true)])->orderBy('sort')->first();
        $states = [];
        if (!$world) return [null, $states];
        $progress = WorldProgress::where('user_id', $u->id)->where('grade_level', $g)->whereIn('world_level_id', $world->levels->pluck('id'))->get()->keyBy('world_level_id');
        $chapterDone = [];
        foreach ($world->levels as $lv) {
            if (in_array($lv->mode, ['daily', 'boss', 'survival'])) continue;
            $chapterDone[$lv->chapter] = ($chapterDone[$lv->chapter] ?? true) && (bool) ($progress[$lv->id]->passed ?? false);
        }
        $prevPassed = true;
        foreach ($world->levels as $lv) {
            $passed = (bool) ($progress[$lv->id]->passed ?? false);
            $open = match ($lv->unlock_rule) {
                'first', 'always' => true,
                'chapter_complete' => $chapterDone && collect($chapterDone)->every(fn ($v) => $v),
                default => $prevPassed,
            };
            $states[$lv->id] = ['open' => $open, 'passed' => $passed, 'stars' => (int) ($progress[$lv->id]->stars ?? 0), 'best' => $progress[$lv->id]->best_score ?? null];
            if ($lv->mode !== 'daily') $prevPassed = $passed;
        }
        return [$world, $states];
    }

    public function world(Request $r)
    {
        [$world, $states] = static::worldStates($r->user());
        return view('game.world', ['world' => $world, 'states' => $states, 'grade' => $r->user()->grade_level]);
    }

    public function leaderboard(Request $r)
    {
        $u = $r->user();
        $g = $u->grade_level;
        $enabled = (bool) Settings::get('leaderboard.enabled', true);
        $rows = collect();
        if ($enabled) {
            $rows = DB::table('attempts')->join('users', 'users.id', '=', 'attempts.user_id')
                ->where('users.role', 'student')->where('users.status', 'active')->where('attempts.grade_level', $g)->where('attempts.status', 'submitted')
                ->whereNotNull('attempts.score_100')->where('attempts.submitted_at', '>=', now()->startOfWeek())
                ->groupBy('users.id', 'users.name')->havingRaw('COUNT(*) >= 3')
                ->selectRaw('users.id, users.name, ROUND(AVG(attempts.score_100)) avg_score, COUNT(*) n')
                ->orderByDesc('avg_score')->orderByDesc('n')->limit(30)->get();
            $done = DB::table('lesson_progress')->whereIn('user_id', $rows->pluck('id'))->where('grade_level', $g)->whereIn('status', ['completed', 'mastered'])
                ->groupBy('user_id')->selectRaw('user_id, COUNT(*) c')->pluck('c', 'user_id');
            $total = max(1, \App\Services\Curriculum::readiness($g)['lessons']);
            $beauty = DB::table('inventory_items')->join('shop_items', 'shop_items.id', '=', 'inventory_items.shop_item_id')->whereIn('inventory_items.user_id', $rows->pluck('id'))
                ->where('placed', true)->groupBy('inventory_items.user_id')->selectRaw('inventory_items.user_id, SUM(beauty) b')->pluck('b', 'user_id');
            $rows = $rows->map(fn ($x) => (array) $x + ['pct' => (int) round(($done[$x->id] ?? 0) / $total * 100), 'beauty' => (int) ($beauty[$x->id] ?? 0)]);
        }
        return view('game.leaderboard', ['rows' => $rows, 'grade' => $g, 'enabled' => $enabled, 'me' => $u->id]);
    }
}
