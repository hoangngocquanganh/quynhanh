<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Storage;

/** Phục vụ tệp tải lên (âm thanh/hình học liệu) từ storage/app/public mà không cần symlink trên hosting. */
class MediaController extends Controller
{
    public function show(string $path)
    {
        if (str_contains($path, '..')) abort(404);
        $disk = Storage::disk('public');
        if (!$disk->exists($path)) abort(404);
        $mime = $disk->mimeType($path) ?: 'application/octet-stream';
        if (!preg_match('#^(image/(png|jpeg|webp|gif|svg\+xml)|audio/(mpeg|ogg|wav|webm|mp4|x-wav)|video/mp4)$#', $mime)) abort(404);
        return response()->file($disk->path($path), ['Content-Type' => $mime, 'Cache-Control' => 'public, max-age=604800', 'X-Content-Type-Options' => 'nosniff']);
    }
}
