<?php

namespace App\Http\Controllers;

use App\Models\DuelMatch;
use App\Services\DuelService;
use App\Services\TradeService;
use Illuminate\Http\Request;

class DuelController extends Controller
{
    public function index(Request $r)
    {
        $u = $r->user();
        DuelService::expireOld();
        $incoming = DuelMatch::with('a')->where('player_b', $u->id)->where('mode', 'challenge')->where('status', 'waiting')->latest('id')->get();
        $active = DuelMatch::where(fn ($q) => $q->where('player_a', $u->id)->orWhere('player_b', $u->id))->whereIn('status', ['waiting', 'active'])->latest('id')->first();
        $history = DuelMatch::with(['a', 'b'])->where(fn ($q) => $q->where('player_a', $u->id)->orWhere('player_b', $u->id))->where('status', 'finished')->latest('id')->limit(10)->get();
        $wins = DuelMatch::where('winner_id', $u->id)->count();
        return view('duel.index', ['incoming' => $incoming, 'active' => $active, 'history' => $history, 'wins' => $wins, 'partners' => TradeService::partners($u),
            'count' => DuelService::questionCount(), 'seconds' => DuelService::seconds()]);
    }

    public function show(Request $r, DuelMatch $match)
    {
        $state = DuelService::state($r->user(), $match);
        return view('duel.show', ['match' => $match, 'state' => $state]);
    }

    // ---------- API ----------
    public function quick(Request $r) { $m = DuelService::quick($r->user()); return ['redirect' => route('duel.show', $m)]; }

    public function challenge(Request $r)
    {
        $d = $r->validate(['friend_id' => 'required|integer']);
        $m = DuelService::challenge($r->user(), (int) $d['friend_id']);
        return ['redirect' => route('duel.show', $m)];
    }

    public function accept(Request $r, DuelMatch $match) { DuelService::accept($r->user(), $match); return ['redirect' => route('duel.show', $match)]; }
    public function bot(Request $r, DuelMatch $match) { DuelService::vsBot($r->user(), $match); return DuelService::state($r->user(), $match->fresh()); }
    public function cancel(Request $r, DuelMatch $match) { DuelService::cancel($r->user(), $match); return ['redirect' => route('duel.index')]; }

    public function state(Request $r, DuelMatch $match)
    {
        $s = DuelService::state($r->user(), $match->fresh());
        // khi trận đang diễn ra, gửi kèm câu hỏi (không có đáp án) cho người chơi
        if ($s['my_attempt'] && $s['status'] === 'active' && $r->boolean('with_items')) {
            $s['items'] = \App\Services\AttemptService::view(\App\Models\Attempt::findOrFail($s['my_attempt']))['items'];
        }
        return $s;
    }
}
