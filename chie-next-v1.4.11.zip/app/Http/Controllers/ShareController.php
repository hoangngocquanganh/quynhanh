<?php

namespace App\Http\Controllers;

use App\Models\Attempt;
use App\Services\AttemptService;

/** Link chia sẻ kết quả: chỉ hiển thị tên hiển thị, lớp, điểm, thời gian, chi tiết từng câu. Thu hồi được. */
class ShareController extends Controller
{
    public function show(string $token)
    {
        $a = Attempt::where('share_token', $token)->whereNull('share_revoked_at')->where('status', 'submitted')->first();
        if (!$a) abort(404, 'Link không tồn tại hoặc đã bị thu hồi.');
        $view = AttemptService::view($a);
        return response()->view('share.show', ['attempt' => $a, 'view' => $view, 'result' => $view['result'], 'name' => $a->user->name])
            ->header('X-Robots-Tag', 'noindex, nofollow');
    }
}
