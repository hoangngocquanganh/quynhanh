<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Support\Audit;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Str;

class PasswordController extends Controller
{
    public function showForgot()
    {
        return view('auth.forgot');
    }

    public function sendLink(Request $r)
    {
        $data = $r->validate(['email' => 'required|email|max:190']);
        $u = User::where('email', mb_strtolower($data['email']))->first();
        if ($u) {
            $token = Str::random(48);
            DB::table('password_reset_tokens')->updateOrInsert(['email' => $u->email], ['token' => Hash::make($token), 'created_at' => now()]);
            $link = route('password.reset', ['token' => $token, 'email' => $u->email]);
            try {
                Mail::raw("Xin chào {$u->name},\n\nBấm vào liên kết sau để đặt lại mật khẩu CHIE NEXT (hiệu lực 60 phút):\n{$link}\n\nNếu bạn không yêu cầu, hãy bỏ qua email này.",
                    fn ($m) => $m->to($u->email)->subject('Đặt lại mật khẩu CHIE NEXT'));
            } catch (\Throwable $e) {
                report($e);
                return back()->with('error', 'Chưa gửi được email (máy chủ thư chưa cấu hình). Vui lòng liên hệ quản trị viên.');
            }
        }
        // Không tiết lộ email có tồn tại hay không
        return back()->with('success', 'Nếu email có trong hệ thống, bạn sẽ nhận được liên kết đặt lại mật khẩu trong vài phút.');
    }

    public function showReset(Request $r, string $token)
    {
        return view('auth.reset', ['token' => $token, 'email' => $r->query('email')]);
    }

    public function reset(Request $r)
    {
        $data = $r->validate(['token' => 'required|string', 'email' => 'required|email', 'password' => 'required|string|min:8|max:100|confirmed'],
            ['password.confirmed' => 'Hai lần nhập mật khẩu chưa khớp.'], ['password' => 'mật khẩu']);
        $row = DB::table('password_reset_tokens')->where('email', mb_strtolower($data['email']))->first();
        if (!$row || !Hash::check($data['token'], $row->token) || now()->subMinutes(60)->gt($row->created_at)) {
            return back()->withErrors(['email' => 'Liên kết đặt lại đã hết hạn hoặc không hợp lệ. Hãy yêu cầu lại.']);
        }
        $u = User::where('email', mb_strtolower($data['email']))->firstOrFail();
        $u->password = $data['password'];
        $u->setRememberToken(Str::random(60));
        $u->save();
        DB::table('password_reset_tokens')->where('email', $u->email)->delete();
        Audit::log('auth.password_reset', $u);
        return redirect()->route('login')->with('success', 'Đã đặt lại mật khẩu. Hãy đăng nhập bằng mật khẩu mới.');
    }
}
