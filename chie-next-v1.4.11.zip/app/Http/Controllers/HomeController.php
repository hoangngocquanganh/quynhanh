<?php

namespace App\Http\Controllers;

use App\Support\Nav;
use Illuminate\Http\Request;

class HomeController extends Controller
{
    public function index(Request $r)
    {
        $u = $r->user();
        if ($u) return redirect(Nav::home($u));
        // Khách: lần đầu hỏi lớp, không tự mặc định lớp
        if (!current_grade()) return redirect()->route('grade.pick');
        return redirect()->route('learn.home');
    }

    /** Đổi giao diện sáng/tối (khách lưu cookie, tài khoản lưu DB). */
    public function theme(Request $r)
    {
        $theme = $r->input('theme') === 'dark' ? 'dark' : 'light';
        if ($u = $r->user()) {
            $s = $u->settings ?? []; $s['theme'] = $theme; $u->settings = $s; $u->save();
            return back();
        }
        return back()->withCookie(cookie('chie_theme', $theme, 60 * 24 * 365));
    }
}
