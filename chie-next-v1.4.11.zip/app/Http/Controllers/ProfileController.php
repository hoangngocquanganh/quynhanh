<?php

namespace App\Http\Controllers;

use App\Models\Attempt;
use App\Models\GuardianLink;
use App\Models\GuardianLinkCode;
use App\Models\InventoryItem;
use App\Models\LessonProgress;
use App\Models\XuLedger;
use App\Services\Economy;
use App\Services\NameFilter;
use App\Support\Audit;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;

class ProfileController extends Controller
{
    public function appearance(Request $r)
    {
        $u = $r->user();
        $stats = \App\Services\ProfileStats::build($u);
        $options = \App\Services\ProfileCosmetics::options($u);
        return view('profile.appearance', ['person' => $u, 'options' => $options,
            'appearance' => \App\Services\ProfileCosmetics::appearance($u, $options), 'badges' => $stats['badges']]);
    }

    public function saveAppearance(Request $r)
    {
        $d = $r->validate(['avatar' => 'required|string|max:30', 'color' => 'required|string|max:20',
            'frame' => 'required|string|max:40', 'badge' => 'nullable|string|max:40']);
        \Illuminate\Support\Facades\DB::transaction(function () use ($r, $d) {
            $u = \App\Models\User::whereKey($r->user()->id)->lockForUpdate()->firstOrFail();
            $o = \App\Services\ProfileCosmetics::options($u);
            $errors = [];
            if (!isset($o['avatars'][$d['avatar']])) $errors['avatar'] = 'Avatar không hợp lệ.';
            elseif (empty($o['avatar_rules'][$d['avatar']]['unlocked'])) $errors['avatar'] = 'Bạn chưa đạt cấp để mở khóa avatar này.';
            if (!isset($o['colors'][$d['color']])) $errors['color'] = 'Màu nền không hợp lệ.';
            if (empty($o['frames'][$d['frame']]['unlocked'])) $errors['frame'] = 'Bạn chưa mở khóa hoặc không còn sở hữu khung này.';
            if (!empty($d['badge']) && (!isset($o['earned'][$d['badge']]) || !isset(\App\Services\Badges::CATALOG[$d['badge']]))) $errors['badge'] = 'Chỉ gắn được huy hiệu bạn đã đạt.';
            if ($errors) throw \Illuminate\Validation\ValidationException::withMessages($errors);
            $u->settings = array_merge($u->settings ?? [], ['appearance' => $d]);
            $u->save();
        });
        return redirect()->route('profile.show')->with('success', 'Đã thay avatar, khung và huy hiệu đại diện.');
    }

    public function show(Request $r)
    {
        $u = $r->user();
        $g = $u->grade_level;
        $wallet = Economy::walletFor($u->id);
        $weekAvg = (int) round((float) Attempt::where('user_id', $u->id)->where('status', 'submitted')->whereNotNull('score_100')
            ->where('submitted_at', '>=', now()->startOfWeek())->avg('score_100'));
        $completed = LessonProgress::where('user_id', $u->id)->where('grade_level', $g)->whereIn('status', ['completed', 'mastered'])->count();
        $guardians = GuardianLink::with('parent')->where('student_id', $u->id)->where('status', 'active')->get();
        $classes = $u->activeClassrooms()->get();
        $recent = Attempt::where('user_id', $u->id)->where('status', 'submitted')->latest('submitted_at')->limit(6)->get();
        $frames = InventoryItem::with('item')->where('user_id', $u->id)->get()->filter(fn ($i) => in_array($i->item->category, ['avatar_frame', 'title']));
        return view('profile.show', compact('wallet', 'weekAvg', 'completed', 'guardians', 'classes', 'recent', 'frames') + [
            'nextLevelXp' => Economy::xpForLevel($wallet->level + 1), 'curLevelXp' => Economy::xpForLevel($wallet->level),
            'newCode' => session('guardian_code'), 'stats' => \App\Services\ProfileStats::build($u),
        ]);
    }

    public function wallet(Request $r)
    {
        $u = $r->user();
        $ledger = XuLedger::where('user_id', $u->id)->orderByDesc('id')->paginate(25);
        return view('profile.wallet', ['wallet' => Economy::walletFor($u->id), 'ledger' => $ledger]);
    }

    public function settings(Request $r)
    {
        return view('profile.settings', ['u' => $r->user()]);
    }

    public function saveSettings(Request $r)
    {
        $u = $r->user();
        $data = $r->validate([
            'name' => 'required|string|min:2|max:30',
            'theme' => 'required|in:light,dark',
            'font_scale' => 'required|in:thuong,lon,rat-lon',
            'reduced_motion' => 'nullable|boolean',
            'tts_rate' => 'required|numeric|min:0.5|max:1.2',
        ], [], ['name' => 'tên hiển thị']);
        if ($data['name'] !== $u->name) {
            if ($msg = NameFilter::check($data['name'])) return back()->withErrors(['name' => $msg])->withInput();
            Audit::log('profile.name_changed', $u, ['name' => $u->name], ['name' => $data['name']]);
            $u->name = trim($data['name']);
        }
        $s = $u->settings ?? [];
        $s['theme'] = $data['theme'];
        $s['font_scale'] = $data['font_scale'];
        $s['reduced_motion'] = (bool) ($data['reduced_motion'] ?? false);
        $s['tts_rate'] = round((float) $data['tts_rate'], 2);
        $u->settings = $s;
        $u->save();
        return back()->with('success', 'Đã lưu cài đặt.');
    }

    public function changePassword(Request $r)
    {
        $u = $r->user();
        $data = $r->validate(['current_password' => 'required|string', 'password' => 'required|string|min:8|max:100|confirmed'],
            ['password.confirmed' => 'Hai lần nhập mật khẩu mới chưa khớp.'], ['password' => 'mật khẩu mới']);
        if (!Hash::check($data['current_password'], $u->password)) return back()->withErrors(['current_password' => 'Mật khẩu hiện tại chưa đúng.']);
        $u->password = $data['password'];
        $u->setRememberToken(Str::random(60));
        $u->save();
        Audit::log('profile.password_changed', $u);
        return back()->with('success', 'Đã đổi mật khẩu.');
    }

    /** Học sinh tạo mã để phụ huynh liên kết (8 ký tự, hết hạn 48 giờ, dùng 1 lần, thu hồi được). */
    public function createGuardianCode(Request $r)
    {
        $u = $r->user();
        GuardianLinkCode::where('student_id', $u->id)->whereNull('used_at')->whereNull('revoked_at')->update(['revoked_at' => now()]);
        $alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
        $code = '';
        for ($i = 0; $i < 8; $i++) $code .= $alphabet[random_int(0, strlen($alphabet) - 1)];
        GuardianLinkCode::create(['student_id' => $u->id, 'code_hash' => hash('sha256', $code), 'expires_at' => now()->addHours(48)]);
        Audit::log('guardian.code_created', $u);
        return redirect()->to(route('profile.show') . '#phu-huynh')->with('guardian_code', substr($code, 0, 4) . '-' . substr($code, 4))->with('success', 'Đã tạo mã liên kết mới. Mã chỉ hiện một lần.');
    }

    public function revokeGuardian(Request $r, GuardianLink $link)
    {
        $u = $r->user();
        abort_unless($link->student_id === $u->id && $link->status === 'active', 404);
        if ($link->verified_via === 'created_by_parent') {
            return back()->with('error', 'Tài khoản này do phụ huynh tạo nên không thể tự hủy liên kết. Hãy liên hệ quản trị viên nếu cần hỗ trợ.');
        }
        $link->update(['status' => 'revoked', 'revoked_at' => now(), 'revoked_by' => $u->id]);
        Audit::log('guardian.revoked_by_student', $link);
        \App\Services\Notifier::send($link->parent_id, 'guardian', 'Liên kết với ' . $u->name . ' đã được hủy');
        return back()->with('success', 'Đã hủy liên kết phụ huynh.');
    }
}
