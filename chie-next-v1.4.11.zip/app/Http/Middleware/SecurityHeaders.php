<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;

class SecurityHeaders
{
    public function handle(Request $request, Closure $next)
    {
        if (defined('CHIE_RELEASE_ID') && CHIE_RELEASE_ID !== 'root') {
            app('url')->useAssetOrigin($request->getSchemeAndHttpHost().$request->getBaseUrl().'/assets/chie-releases/'.CHIE_RELEASE_ID);
        }
        $response = $next($request);
        $h = $response->headers;
        $h->set('X-Content-Type-Options', 'nosniff');
        $h->set('X-Frame-Options', 'SAMEORIGIN');
        $h->set('Referrer-Policy', 'strict-origin-when-cross-origin');
        $h->set('Permissions-Policy', 'camera=(), geolocation=(), microphone=(self)');
        if (!$h->has('Content-Security-Policy')) {
            $h->set('Content-Security-Policy', "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; media-src 'self' blob:; font-src 'self'; connect-src 'self'; frame-ancestors 'self'; base-uri 'self'; form-action 'self'");
        }
        if ($request->user() || $request->is('api/*')) {
            $h->set('Cache-Control', 'no-store, private');
        }
        return $response;
    }
}
