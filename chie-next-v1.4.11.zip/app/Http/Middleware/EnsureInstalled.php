<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;

/** Chưa cài đặt → chuyển tới trình cài đặt. Đã cài → trình cài đặt bị khóa (404). */
class EnsureInstalled
{
    public function handle(Request $request, Closure $next)
    {
        $installed = is_file(config('chie.install_lock'));
        $isInstaller = $request->is('install') || $request->is('install/*');
        if (!$installed && !$isInstaller) {
            return redirect()->to(url('/install'));
        }
        if ($installed && $isInstaller) {
            abort(404);
        }
        return $next($request);
    }
}
