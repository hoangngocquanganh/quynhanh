<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;

/** Học sinh thiếu lớp phải chọn lớp trước khi học. */
class RequireStudentGrade
{
    public function handle(Request $request, Closure $next)
    {
        $u = $request->user();
        // v1.3.1: Admin / giáo viên / phụ huynh dùng trang học sinh → lấy lớp đang chọn (cookie/cài đặt), chỉ trong bộ nhớ, không lưu vào tài khoản.
        if ($u && !$u->isStudent() && !$u->grade_level) {
            $g = current_grade();
            if ($g) {
                $u->setAttribute('grade_level', $g);
                $u->syncOriginalAttribute('grade_level');   // không bị lưu nếu có lệnh save() sau đó
            } elseif ($request->isMethod('GET') && !$request->expectsJson() && empty($request->route()?->parameters())) {
                // Chỉ trang tổng (Học tập, Lộ trình, Luyện đề…) mới cần lớp; API, thao tác POST và trang của một đối tượng cụ thể
                // (lượt làm, bài học, thử thách gia đình…) tự kiểm tra quyền sở hữu.
                return redirect()->route('grade.pick', ['next' => $request->getRequestUri()]);
            }
            return $next($request);
        }
        if ($u && $u->isStudent() && !$u->grade_level) {
            if ($request->expectsJson()) abort(409, 'Bạn cần chọn lớp trước khi học.');
            return redirect()->route('grade.pick', ['next' => $request->getRequestUri()]);
        }
        return $next($request);
    }
}
