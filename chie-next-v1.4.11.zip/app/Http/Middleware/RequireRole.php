<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;

class RequireRole
{
    public function handle(Request $request, Closure $next, string ...$roles)
    {
        $u = $request->user();
        // v1.3.1: Admin là quyền cao nhất — dùng được mọi trang (kể cả trang của học sinh, phụ huynh, giáo viên).
        if ($u && $u->role === 'admin') return $next($request);
        // v1.4: Admin đã BẬT tính năng của route này cho vai trò của người dùng (Quản trị → Phân quyền) → cho qua
        $feature = \App\Support\Permissions::featureForRoute($request->route()?->getName());
        if ($u && $feature && !\App\Support\Permissions::locked($u->role, $feature) && \App\Support\Permissions::allows($u, $feature)
            && !in_array($u->role, \App\Support\Permissions::FEATURES[$feature][4], true)) {
            return $next($request);
        }
        if (!$u || !in_array($u->role, $roles, true)) {
            abort(403, 'Bạn không có quyền truy cập khu vực này.');
        }
        return $next($request);
    }
}
