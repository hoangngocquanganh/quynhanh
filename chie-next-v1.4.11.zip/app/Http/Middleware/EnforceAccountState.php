<?php

namespace App\Http\Middleware;

use App\Models\TermsVersion;
use App\Support\Settings;
use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;

/**
 * Kiểm tra trạng thái tài khoản ở MỌI request (thu hồi có hiệu lực ngay ở máy chủ):
 * khóa tài khoản → đăng xuất; chưa đồng ý điều khoản hiện hành → trang điều khoản; chưa xác minh email (nếu bật).
 */
class EnforceAccountState
{
    protected array $always = ['logout', 'terms.show', 'terms.accept', 'legal', 'verify.*', 'install.*', 'share.show', 'media.show', 'api.heartbeat', 'api.client-error'];

    public function handle(Request $request, Closure $next)
    {
        $u = $request->user();
        if (!$u) return $next($request);

        if ($u->status !== 'active') {
            Auth::logout();
            $request->session()->invalidate();
            $request->session()->regenerateToken();
            if ($request->expectsJson()) abort(401, 'Tài khoản đã bị tạm khóa.');
            return redirect()->route('login')->with('error', 'Tài khoản của bạn đang tạm khóa. Vui lòng liên hệ quản trị viên.');
        }
        if ($request->routeIs(...$this->always)) return $next($request);

        if (Settings::get('auth.require_email_verification') && $u->email && !$u->email_verified_at && !$u->created_by_parent_id && !$u->isAdmin()) {
            if ($request->expectsJson()) abort(403, 'Bạn cần xác minh email trước.');
            return redirect()->route('verify.show');
        }

        $active = Cache::remember('chie.terms.active', 300, fn () => TermsVersion::where('is_active', true)->value('version'));
        if ($active) {
            $ok = DB::table('user_terms_consents')->where('user_id', $u->id)->where('terms_version', $active)->exists();
            if (!$ok) {
                if ($request->expectsJson()) abort(403, 'Bạn cần đọc và đồng ý điều khoản sử dụng mới.');
                return redirect()->route('terms.show', ['next' => $request->getRequestUri()]);
            }
        }
        return $next($request);
    }
}
