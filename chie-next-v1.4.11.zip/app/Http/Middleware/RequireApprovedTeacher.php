<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;

class RequireApprovedTeacher
{
    public function handle(Request $request, Closure $next)
    {
        $u = $request->user();
        if ($u && $u->isAdmin()) return $next($request);   // v1.3.1: Admin vào được khu giáo viên
        if (!$u || !$u->isApprovedTeacher()) {
            if ($request->expectsJson()) abort(403, 'Tài khoản giáo viên chưa được Admin duyệt.');
            return redirect()->route('teacher.pending');
        }
        return $next($request);
    }
}
