<?php

namespace App\Http\Middleware;

use App\Support\Permissions;
use Closure;
use Illuminate\Http\Request;

/** Chặn route khi tính năng của nó đang TẮT cho vai trò hiện tại (ma trận Quản trị → Phân quyền). */
class CheckFeature
{
    public function handle(Request $request, Closure $next)
    {
        $route = $request->route();
        $feature = Permissions::featureForRoute($route?->getName());
        if (!$feature) return $next($request);
        $u = $request->user();
        // khách vào trang cần đăng nhập → để middleware auth chuyển tới trang đăng nhập như cũ
        if (!$u && in_array('auth', $route->gatherMiddleware(), true)) return $next($request);
        if (Permissions::allows($u, $feature)) return $next($request);

        $name = Permissions::FEATURES[$feature][1];
        $msg = 'Tính năng "' . $name . '" đang tắt cho tài khoản ' . mb_strtolower(Permissions::ROLES[Permissions::roleOf($u)]) . '.';
        if ($request->expectsJson() || !$request->isMethod('GET')) abort(403, $msg);
        return redirect()->route($u ? 'home' : 'learn.home')->with('error', $msg);
    }
}
