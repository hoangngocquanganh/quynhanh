<?php
namespace App\Http\Middleware;
use Closure;
use Illuminate\Http\Request;
use App\Services\ActivityAnalytics;
class RecordActivity
{
    public function handle(Request $r, Closure $next)
    {
        $response=$next($r);
        if ($r->isMethod('GET') && !$r->expectsJson() && $r->user() && $response->getStatusCode()===200
            && str_contains((string)$response->headers->get('Content-Type'),'text/html') && !$r->routeIs('api.*','media.*','install.*')) {
            $name=(string)$r->route()?->getName();
            $module=match(true){str_starts_with($name,'exam.')=>'exam', str_starts_with($name,'farm.')=>'farm',
                str_starts_with($name,'game.'),str_starts_with($name,'duel.'),str_starts_with($name,'world.')=>'game',
                in_array($name,['learn.review','learn.mistakes'])=>'review',
                str_starts_with($name,'learn.'),str_starts_with($name,'grammar.'),str_starts_with($name,'attempt.')=>'learn',default=>'browse'};
            try {ActivityAnalytics::record($r,$module,true);}catch(\Throwable $e){report($e);}
        }
        return $response;
    }
}
