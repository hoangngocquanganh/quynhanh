<?php

namespace App\Console\Commands;

use App\Services\ContentImporter;
use Illuminate\Console\Command;

class ImportContent extends Command
{
    protected $signature = 'chie:import {file? : Tên tệp trong database/content (mặc định: tất cả gói)} {--dry : Chạy thử, không ghi CSDL}';
    protected $description = 'Nhập gói học liệu đã chuẩn hóa (idempotent, có kiểm tra, có báo cáo)';

    public function handle(): int
    {
        $packages = ContentImporter::packages();
        $file = $this->argument('file');
        $targets = $file ? array_filter($packages, fn ($k) => $k === $file, ARRAY_FILTER_USE_KEY) : $packages;
        if (!$targets) { $this->error('Không tìm thấy gói: ' . $file); return self::FAILURE; }
        foreach ($targets as $name => $p) {
            $this->info("Đang nhập {$name}" . ($this->option('dry') ? ' (chạy thử)' : ''));
            $run = (new ContentImporter())->run($p['file'], (bool) $this->option('dry'));
            foreach ($run->stats as $k => $v) $this->line("  {$k}: {$v}");
        }
        return self::SUCCESS;
    }
}
