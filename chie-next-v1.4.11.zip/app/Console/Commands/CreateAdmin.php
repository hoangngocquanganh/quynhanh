<?php

namespace App\Console\Commands;

use App\Models\TermsVersion;
use App\Models\User;
use App\Services\Accounts;
use Illuminate\Console\Command;

class CreateAdmin extends Command
{
    protected $signature = 'chie:create-admin {email} {--name=Quản trị viên}';
    protected $description = 'Tạo tài khoản Admin (mật khẩu nhập ẩn, không có mật khẩu mặc định)';

    public function handle(): int
    {
        $email = mb_strtolower($this->argument('email'));
        if (User::where('email', $email)->exists()) { $this->error('Email đã tồn tại.'); return self::FAILURE; }
        $pass = $this->secret('Mật khẩu (ít nhất 10 ký tự)');
        if (mb_strlen((string) $pass) < 10 || $pass !== $this->secret('Nhập lại mật khẩu')) { $this->error('Mật khẩu không hợp lệ hoặc không khớp.'); return self::FAILURE; }
        $u = Accounts::create(['name' => $this->option('name'), 'email' => $email, 'canonical_email' => \App\Services\NameFilter::canonicalEmail($email), 'password' => $pass, 'role' => 'admin', 'email_verified_at' => now()]);
        if ($t = TermsVersion::where('is_active', true)->first()) Accounts::recordConsent($u, $t);
        $this->info('Đã tạo Admin #' . $u->id);
        return self::SUCCESS;
    }
}
