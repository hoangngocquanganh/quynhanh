<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;

/**
 * v1.3.3 — Đóng gói bản phát hành từ máy (Laragon/XAMPP) để tải lên Admin → Cập nhật phiên bản trên hosting.
 *   php artisan chie:release 1.3.4 --notes="Sửa giao diện Luyện đề"
 * Tạo storage/app/releases/chie-next-v1.3.4.zip kèm chie-release.json (mã băm SHA-256 từng tệp).
 * Không bao giờ đóng gói .env, storage/ (chỉ giữ thư mục rỗng), bootstrap/cache, .git, node_modules.
 */
class BuildRelease extends Command
{
    protected $signature = 'chie:release {version : Phiên bản mới, phải lớn hơn bản đang chạy trên hosting (vd 1.3.4)} {--notes= : Ghi chú hiện trong trang Cập nhật} {--no-tests : Bỏ thư mục tests/ cho gói nhẹ hơn} {--live : Đã kiểm tra tương thích API và không có migration mới}';
    protected $description = 'Đóng gói CHIE NEXT thành .zip để cập nhật một chạm trên hosting';

    protected array $skipPrefix = ['.git/', 'node_modules/', 'storage/', 'assets/chie-releases/', 'bootstrap/cache/', '.idea/', '.vscode/'];
    protected array $skipFile = ['.env', 'chie-release.json', '.DS_Store', 'Thumbs.db'];

    public function handle(): int
    {
        $v = (string) $this->argument('version');
        if (!preg_match('/^\d+\.\d+\.\d+$/', $v)) { $this->error('Phiên bản phải dạng 1.3.4'); return self::FAILURE; }
        $cur = (string) config('chie.version');
        if (version_compare($v, $cur, '<=')) { $this->error("Phiên bản {$v} phải lớn hơn bản hiện tại {$cur}."); return self::FAILURE; }
        if (!class_exists(\ZipArchive::class)) { $this->error('PHP chưa bật tiện ích zip.'); return self::FAILURE; }
        $root = base_path();
        $skipPrefix = $this->skipPrefix;
        if ($this->option('no-tests')) $skipPrefix[] = 'tests/';

        // 1) ghi số phiên bản mới
        $cfg = config_path('chie.php');
        $txt = file_get_contents($cfg);
        $txt2 = preg_replace("/'version'\\s*=>\\s*'[0-9.]+'/", "'version' => '{$v}'", $txt, 1);
        if ($txt2 === null || $txt2 === $txt) { $this->error('Không tìm thấy dòng version trong config/chie.php'); return self::FAILURE; }
        file_put_contents($cfg, $txt2);

        // 2) liệt kê tệp + mã băm
        $files = [];
        $it = new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator($root, \FilesystemIterator::SKIP_DOTS));
        foreach ($it as $f) {
            if (!$f->isFile()) continue;
            $rel = str_replace('\\', '/', substr($f->getPathname(), strlen($root) + 1));
            if (in_array($rel, $this->skipFile, true) || in_array(basename($rel), ['.DS_Store', 'Thumbs.db'], true)) continue;
            foreach ($skipPrefix as $p) if (str_starts_with($rel, $p)) continue 2;
            $files[$rel] = hash_file('sha256', $f->getPathname());
        }
        ksort($files);
        $manifestPath = $root . '/chie-release.json';
        $old = is_file($manifestPath) ? (json_decode(file_get_contents($manifestPath), true) ?: []) : [];
        $manifest = ['app' => 'chie-next', 'version' => $v, 'min_from' => $old['min_from'] ?? '1.1.0',
            'notes' => (string) ($this->option('notes') ?: 'Bản ' . $v), 'files' => $files];
        file_put_contents($manifestPath, json_encode($manifest, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
        if ($this->option('live')) {
            $manifest['live_update'] = ['protocol'=>1,'schema'=>'unchanged'];
            file_put_contents($manifestPath,json_encode($manifest,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES));
        }

        // 3) nén
        $dir = storage_path('app/releases');
        if (!is_dir($dir)) mkdir($dir, 0775, true);
        $zipPath = $dir . '/chie-next-v' . $v . '.zip';
        @unlink($zipPath);
        $zip = new \ZipArchive();
        if ($zip->open($zipPath, \ZipArchive::CREATE) !== true) { $this->error('Không tạo được ' . $zipPath); return self::FAILURE; }
        $zip->addFile($manifestPath, 'chie-release.json');
        foreach (array_keys($files) as $rel) $zip->addFile($root . '/' . $rel, $rel);
        foreach (['storage/app/public', 'storage/framework/cache/data', 'storage/framework/sessions', 'storage/framework/views', 'storage/logs', 'bootstrap/cache'] as $d) $zip->addEmptyDir($d);
        $zip->close();

        $this->info("Đã tạo {$zipPath}");
        $this->line(count($files) . ' tệp · ' . number_format(filesize($zipPath) / 1048576, 1) . ' MB');
        $this->line('Tiếp theo: trên hosting vào Admin → Hệ thống → Cập nhật phiên bản → tải tệp zip này lên.');
        return self::SUCCESS;
    }
}
