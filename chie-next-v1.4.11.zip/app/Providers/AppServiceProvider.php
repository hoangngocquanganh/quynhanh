<?php

namespace App\Providers;

use Carbon\Carbon;
use Illuminate\Cache\RateLimiting\Limit;
use Illuminate\Http\Request;
use Illuminate\Pagination\Paginator;
use Illuminate\Support\Facades\RateLimiter;
use Illuminate\Support\Facades\View;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    public function register(): void
    {
    }

    public function boot(): void
    {
        Carbon::setLocale('vi');
        Paginator::defaultView('partials.pagination');

        RateLimiter::for('login', fn (Request $r) => [
            Limit::perMinute(8)->by('login:' . mb_strtolower((string) $r->input('login')) . '|' . $r->ip()),
            Limit::perMinute(30)->by('login-ip:' . $r->ip()),
        ]);
        RateLimiter::for('codes', fn (Request $r) => Limit::perMinute(10)->by('codes:' . ($r->user()?->id ?: $r->ip())));
        RateLimiter::for('api', fn (Request $r) => Limit::perMinute(240)->by('api:' . ($r->user()?->id ?: $r->ip())));
        RateLimiter::for('register', fn (Request $r) => Limit::perHour(20)->by('reg:' . $r->ip()));

        View::composer('*', function ($view) {
            static $shared = null;
            if ($shared === null) {
                $shared = ['appName' => \App\Support\Settings::get('site.name', 'CHIE NEXT')];
            }
            $view->with($shared);
        });
    }
}
