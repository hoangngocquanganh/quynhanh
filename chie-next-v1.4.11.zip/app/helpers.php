<?php

use Illuminate\Support\HtmlString;

if (!function_exists('ic')) {
    /** Icon từ sprite Lucide (ISC). */
    function ic(string $name, string $class = ''): HtmlString
    {
        $href = asset('assets/img/icons.svg') . '?v=' . chie_asset_version() . '#i-' . $name;
        return new HtmlString('<svg class="ic ' . e($class) . '" aria-hidden="true" focusable="false"><use href="' . e($href) . '"></use></svg>');
    }
}

if (!function_exists('chie_asset_version')) {
    function chie_asset_version(): string
    {
        static $v = null;
        return $v ??= substr(md5(config('chie.version') . '|' . @filemtime(base_path('assets/js/app.js')) . '|' . @filemtime(base_path('assets/css/app.css'))), 0, 10);
    }
}

if (!function_exists('asset_v')) {
    /** URL tài nguyên tĩnh có tham số phiên bản (cập nhật cache khi đổi code). */
    function asset_v(string $path): string
    {
        $full = base_path($path);
        $v = is_file($full) ? substr(md5((string) filemtime($full) . filesize($full)), 0, 10) : chie_asset_version();
        return asset($path) . '?v=' . $v;
    }
}

if (!function_exists('grade_name')) {
    function grade_name(?int $g): string
    {
        return $g ? 'Lớp ' . $g : 'Chưa chọn lớp';
    }
}

if (!function_exists('grade_stage')) {
    function grade_stage(?int $g): string
    {
        if (!$g) return 'thcs';
        return $g <= 5 ? 'tieu_hoc' : ($g <= 9 ? 'thcs' : 'thpt');
    }
}

if (!function_exists('stage_label')) {
    function stage_label(string $s): string
    {
        return ['tieu_hoc' => 'Tiểu học', 'thcs' => 'THCS', 'thpt' => 'THPT'][$s] ?? $s;
    }
}

if (!function_exists('rarity_label')) {
    function rarity_label(?string $r): string
    {
        return ['common' => 'Thường', 'rare' => 'Hiếm', 'epic' => 'Sử thi', 'curated' => 'Tuyển chọn'][$r] ?? (string) $r;
    }
}

if (!function_exists('status_label')) {
    function status_label(?string $s): string
    {
        return ['draft' => 'Nháp', 'review' => 'Chờ duyệt', 'published' => 'Đã xuất bản', 'archived' => 'Đã thu hồi',
            'active' => 'Đang hoạt động', 'suspended' => 'Tạm khóa', 'pending' => 'Chờ duyệt', 'approved' => 'Đã duyệt', 'rejected' => 'Từ chối',
            'in_progress' => 'Đang làm', 'submitted' => 'Đã nộp', 'graded' => 'Đã chấm', 'returned' => 'Đã trả bài', 'expired' => 'Hết hạn',
            'left' => 'Đã rời lớp', 'removed' => 'Đã bị xóa khỏi lớp', 'revoked' => 'Đã hủy', 'closed' => 'Đã đóng', 'archived_class' => 'Lưu trữ'][$s] ?? (string) $s;
    }
}

if (!function_exists('num')) {
    function num($n): string
    {
        return number_format((float) $n, 0, ',', '.');
    }
}

if (!function_exists('current_grade')) {
    /** Lớp học liệu hiện hành: tài khoản học sinh ưu tiên hơn lựa chọn trên trình duyệt. */
    function current_grade(): ?int
    {
        $u = auth()->user();
        if ($u && $u->isStudent()) return $u->grade_level ?: null;
        if ($u && $u->isParent()) {
            $g = (int) ($u->setting('self_grade') ?? 0);
            if ($g >= 1 && $g <= 12) return $g;
        }
        $c = (int) request()->cookie('chie_grade');
        if ($c >= 1 && $c <= 12) return $c;
        $s = (int) session('guest_grade');
        return ($s >= 1 && $s <= 12) ? $s : null;
    }
}

if (!function_exists('games_visible')) {
    /** v1.3.1: hiện/ẩn toàn bộ tính năng trò chơi với học sinh (Admin → Game Studio). Link trực tiếp vẫn vào được để thử. */
    function games_visible(): bool
    {
        return (bool) \App\Support\Settings::get('features.games_visible', true);
    }
}

if (!function_exists('safe_next')) {
    /** Chuyển đường dẫn "next" (request URI nội bộ) thành URL tuyệt đối an toàn; chặn chuyển hướng ra ngoài. */
    function safe_next(?string $next): ?string
    {
        if (!$next || !str_starts_with($next, '/') || str_starts_with($next, '//') || str_contains($next, '\\')) return null;
        return request()->getSchemeAndHttpHost() . $next;
    }
}
