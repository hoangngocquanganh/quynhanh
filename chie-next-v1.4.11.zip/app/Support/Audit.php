<?php

namespace App\Support;

use App\Models\AuditLog;
use Illuminate\Database\Eloquent\Model;

class Audit
{
    /** Ghi nhật ký thao tác quan trọng: ai, lúc nào, đối tượng nào, thay đổi gì. */
    public static function log(string $action, $target = null, ?array $old = null, ?array $new = null, ?string $note = null): void
    {
        $user = auth()->user();
        $type = $target instanceof Model ? class_basename($target) : (is_array($target) ? ($target[0] ?? null) : null);
        $id = $target instanceof Model ? $target->getKey() : (is_array($target) ? ($target[1] ?? null) : null);
        AuditLog::create([
            'actor_user_id' => $user?->id,
            'actor_role' => $user?->role,
            'action' => $action,
            'target_type' => $type,
            'target_id' => $id,
            'old_values' => $old ? static::scrub($old) : null,
            'new_values' => $new ? static::scrub($new) : null,
            'note' => $note ? mb_substr($note, 0, 255) : null,
            'ip_hash' => request() ? hash('sha256', (string) request()->ip() . config('app.key')) : null,
            'created_at' => now(),
        ]);
    }

    protected static function scrub(array $values): array
    {
        foreach (['password', 'remember_token', 'code_hash', 'token'] as $k) {
            if (array_key_exists($k, $values)) $values[$k] = '[ẩn]';
        }
        return $values;
    }
}
