<?php

namespace App\Support;

use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

/**
 * Cấu hình nghiệp vụ lưu trong DB (Admin chỉnh được, áp dụng cho lượt sau).
 * Giá trị mặc định nằm ở DEFAULTS; bảng settings chỉ lưu phần đã chỉnh.
 */
class Settings
{
    public const DEFAULTS = [
        // Chung
        'site.name' => 'CHIE NEXT',
        'site.tagline' => 'Học tiếng Anh mỗi ngày, từng bước nhỏ',
        'site.contact_email' => '',
        'auth.require_email_verification' => false,
        'auth.allow_teacher_signup' => true,
        'auth.grade_change_cooldown_days' => 0,
        'auth.min_self_signup_age' => 16,
        'classes.teachers_can_create' => true,
        'classes.invite_days' => 14,
        'classes.invite_max_uses' => 60,
        'leaderboard.enabled' => true,
        'content.teachers_can_author' => true,
        // Học tập
        'learn.pass_score' => 60,
        'learn.mastery_score' => 90,
        'learn.lesson_guided_ratio' => 0.4,
        'learn.srs_intervals_days' => [1, 3, 7],
        'learn.review_session_size' => 10,
        // v1.3.3 — học theo sticker
        'sticker.session_size' => 6, 'sticker.xp_new' => 2, 'sticker.xp_gold' => 3, 'sticker.xp_pack' => 20, 'sticker.xu_pack' => 10,
        // Thưởng (tách khỏi điểm thang 100)
        'reward.xp_per_correct' => 5,
        'reward.xu_per_xp' => 0.5,
        'reward.daily_xp_cap' => 1000,
        'reward.daily_xu_cap' => 500,
        'reward.repeat_2_percent' => 50,
        'reward.repeat_3_percent' => 10,
        'reward.fast_answer_ms' => 800,
        // Cửa hàng / Gacha / Đổi đồ
        'shop.sell_back_percent' => 50,
        'shop.gacha_sell_price' => 20,
        'trade.weekly_per_pair' => 3,
        'trade.new_account_days' => 7,
        'trade.curated_lock_days' => 30,
        // Nông trại
        'farm.start_plots' => 6,
        'farm.max_plots' => 48,
        'farm.plot_price_base' => 200,
        'farm.plot_price_step' => 100,
        'farm.water_speedup_percent' => 20,
        'farm.pest_chance_percent' => 8,
        'farm.pest_yield_penalty_percent' => 30,
        'farm.inner_start_capacity' => 20,
        'farm.inner_expand_step' => 10,
        'farm.inner_expand_price' => 150,
        'farm.cold_capacity' => 30,
        'farm.cold_price_per_hour' => 6,
        'farm.shield_prices' => ['4' => 40, '8' => 70, '24' => 180],
        'farm.wall_prices' => ['2' => 500, '3' => 1500, '4' => 4000, '5' => 10000],
        // Cướp trại
        'raid.enabled' => true,
        'raid.fee_xu' => 30,
        'raid.take_percent' => 8,
        'raid.daily_loss_cap_percent' => 20,
        'raid.destroy_percent' => 20,
        'raid.pair_per_day' => 1,
        'raid.pair_per_week' => 3,
        'raid.stages_by_wall' => ['1' => 3, '2' => 4, '3' => 5, '4' => 5, '5' => 6],
        'raid.seconds_per_stage' => 60,
        'raid.min_level' => 3,
        // Nghe
        'tts.default_rate' => 0.75,
        'tts.slow_rate' => 0.65,
        // Sức khỏe số
        'wellbeing.break_reminder_minutes_primary' => 20,
        'wellbeing.break_reminder_minutes_secondary' => 30,
    ];

    protected static ?array $loaded = null;

    public static function all(): array
    {
        if (static::$loaded !== null) return static::$loaded;
        $stored = [];
        try {
            if (Schema::hasTable('settings')) {
                $stored = Cache::remember('chie.settings', 300, function () {
                    return DB::table('settings')->pluck('value', 'key')->map(fn ($v) => json_decode($v, true))->all();
                });
            }
        } catch (\Throwable $e) {
            $stored = [];
        }
        return static::$loaded = array_merge(self::DEFAULTS, $stored);
    }

    public static function get(string $key, $default = null)
    {
        $all = static::all();
        return array_key_exists($key, $all) ? $all[$key] : $default;
    }

    public static function set(string $key, $value, ?int $userId = null): void
    {
        DB::table('settings')->updateOrInsert(['key' => $key], [
            'value' => json_encode($value, JSON_UNESCAPED_UNICODE), 'updated_by' => $userId, 'updated_at' => now(), 'created_at' => now(),
        ]);
        static::flush();
    }

    public static function flush(): void
    {
        Cache::forget('chie.settings');
        static::$loaded = null;
    }
}
