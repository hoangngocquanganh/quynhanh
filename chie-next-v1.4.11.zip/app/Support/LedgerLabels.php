<?php

namespace App\Support;

class LedgerLabels
{
    public const MAP = [
        'learn_reward' => 'Thưởng học tập', 'game_reward' => 'Thưởng chơi game', 'shop_buy' => 'Mua vật phẩm', 'sell_back' => 'Bán lại cho CHIE',
        'gacha_spin' => 'Quay Hòm CHIE', 'farm_seed' => 'Mua hạt giống', 'farm_sell' => 'Bán nông sản', 'farm_cook' => 'Phí nấu món', 'farm_plot' => 'Mở ô đất',
        'farm_wall' => 'Nâng cấp tường', 'farm_shield' => 'Mua khiên', 'farm_cold' => 'Thuê kho lạnh', 'farm_inner' => 'Mở rộng kho trong', 'raid_fee' => 'Phí đi cướp trại',
        'admin_adjust' => 'Điều chỉnh bởi quản trị viên', 'farm_water' => 'Thưởng chăm cây',
        'zoo_exchange' => 'Đổi Xu sang Năng lượng ϟ (Zoo Garden)', 'zoo_quiz' => 'Thưởng đố Tiếng Anh trong Nông trại 3D', 'sticker_reward' => 'Thưởng sưu tầm sticker',
    ];

    public static function label(string $type): string
    {
        return self::MAP[$type] ?? $type;
    }
}
