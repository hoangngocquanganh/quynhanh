<?php

namespace App\Support;

use App\Models\User;

/**
 * Ma trận phân quyền theo tính năng × vai trò (Admin chỉnh ở Quản trị → Người dùng → Phân quyền).
 * - Mỗi tính năng gắn với một nhóm tên route; middleware CheckFeature chặn khi vai trò bị tắt,
 *   RequireRole cho qua khi Admin đã BẬT tính năng cho vai trò đó (mở rộng ngoài mặc định).
 * - Mặc định khớp đúng hành vi cũ của hệ thống. Admin luôn có toàn quyền (để kiểm thử).
 * - Ô khóa (locked) không chỉnh được: khu Quản trị chỉ Admin; khu Giáo viên/Phụ huynh chỉ đúng vai trò đó (an toàn dữ liệu).
 * - Kiểm tra quyền sở hữu dữ liệu trong controller vẫn giữ nguyên — ma trận không mở được dữ liệu của người khác.
 */
class Permissions
{
    public const ROLES = ['admin' => 'Admin', 'student' => 'Học sinh', 'teacher' => 'Giáo viên', 'parent' => 'Phụ huynh', 'guest' => 'Khách'];

    /**
     * khóa => [nhóm, tên, mô tả, [mẫu tên route], [vai trò mặc định được phép], [vai trò bị khóa ô (không chỉnh)]]
     * Mẫu route dùng * như Str::is.
     */
    public const FEATURES = [
        'guest_play' => ['Giải trí', 'Chơi thử Thế giới & Nông trại', 'Lượt khách riêng, chỉ giữ tiến độ trong bộ nhớ, không lưu cấp độ hoặc phát XP/Xu', ['guest.play.*'], ['admin', 'student', 'teacher', 'parent', 'guest'], []],
        'guest_practice' => ['Học tập', 'Khách luyện không lưu điểm', 'Chỉ dùng luồng khách riêng; không tạo lượt làm hoặc lịch sử', ['api.guest.practice'], ['guest'], ['admin', 'student', 'teacher', 'parent']],
        'learn_view' => ['Học tập', 'Xem trang học, lộ trình, bài học', 'Trang Học tập, Lộ trình, nội dung bài, học thử bài công khai', ['learn.home', 'learn.path', 'learn.lesson', 'learn.demo', 'api.demo.*', 'learn.skills', 'learn.skill', 'learn.practice'], ['admin', 'student', 'teacher', 'parent', 'guest'], []],
        'self_study' => ['Học tập', 'Tự học (nhiệm vụ hôm nay)', 'Trang Tự học và lộ trình cả năm', ['learn.self', 'learn.self.mark'], ['admin', 'student', 'teacher', 'parent', 'guest'], []],
        'do_lessons' => ['Học tập', 'Làm bài, luyện tập, lưu kết quả', 'Bắt đầu bài học/luyện tập, trả lời và nộp bài', ['api.lesson.start', 'api.practice.start', 'api.attempt.*', 'attempt.show', 'attempt.result', 'api.question.report'], ['admin', 'student', 'teacher', 'parent'], ['guest']],
        'vocab' => ['Học tập', 'Từ vựng', 'Kho từ theo chủ đề, luyện thẻ hình', ['learn.words', 'api.words.start'], ['admin', 'student', 'teacher', 'parent', 'guest'], []],
        'grammar' => ['Học tập', 'Ngữ pháp', 'Lý thuyết, luyện cơ bản/nâng cao, ôn học kì, ôn thi', ['grammar.*', 'api.grammar.start'], ['admin', 'student', 'teacher', 'parent', 'guest'], []],
        'pronunciation' => ['Học tập', 'Phát âm', 'Bảng âm, cặp âm tối thiểu, luyện nói', ['learn.pronunciation'], ['admin', 'student', 'teacher', 'parent', 'guest'], []],
        'review' => ['Học tập', 'Ôn tập & Sổ lỗi', 'Ôn theo lịch 1–3–7 ngày, xem câu đã sai', ['learn.review', 'learn.mistakes', 'api.review.start', 'api.offline.pack'], ['admin', 'student', 'teacher', 'parent'], ['guest']],
        'stickers' => ['Học tập', 'Học theo sticker', 'Album sticker, bóc sticker theo chủ đề', ['learn.stickers', 'learn.stickers.pack', 'api.sticker.*'], ['admin', 'student', 'teacher', 'parent', 'guest'], []],
        'exam' => ['Học tập', 'Luyện đề', 'Đề 15 phút, giữa kì, cuối kì, mô phỏng', ['exam.*', 'api.exam.start'], ['admin', 'student', 'teacher', 'parent', 'guest'], []],
        'assignments' => ['Lớp học', 'Bài được giao & Lớp của tôi', 'Làm bài giáo viên giao, tham gia lớp bằng mã', ['learn.assignments', 'learn.assignment', 'learn.assignment.*', 'grade.mine'], ['admin', 'student'], ['guest']],
        'games' => ['Giải trí', 'Game học 3D & Thế giới phiêu lưu', 'Word Runner, Grammar Tower, Voice Island, Reading Escape, các màn phiêu lưu', ['game.home', 'game.play', 'api.game.start', 'world.*', 'api.world.start'], ['admin', 'student', 'guest'], []],
        'farm' => ['Giải trí', 'Nông trại & Thị trấn 3D', 'Chăm vườn, nuôi thú, đổi phút chơi, vượt tường thành', ['farm.*', 'api.farm.*', 'api.raid.*'], ['admin', 'student'], ['guest']],
        'shop' => ['Giải trí', 'Cửa hàng, Hòm quà, Phòng, Đổi đồ', 'Mua bán bằng Xu, quay hòm quà, trang trí phòng, đổi đồ 1–1', ['shop.*', 'api.shop.*', 'api.gacha.*', 'room.*', 'api.room.*', 'trade.*'], ['admin', 'student'], ['guest']],
        'duel' => ['Giải trí', 'Đấu 1–1 & Đội', 'Đấu với bạn hoặc bạn máy, đội của lớp', ['duel.*', 'api.duel.*', 'teams.index', 'teams.join', 'teams.leave'], ['admin', 'student'], ['guest']],
        'leaderboard' => ['Giải trí', 'Bảng xếp hạng', 'Điểm trung bình tuần theo lớp', ['leaderboard'], ['admin', 'student'], ['guest']],
        'family' => ['Giải trí', 'Thử thách gia đình', 'Phụ huynh tạo thử thách, con làm cùng bộ câu', ['family.*'], ['admin', 'student', 'parent'], ['guest']],
        'profile' => ['Tài khoản', 'Hồ sơ học tập, ví Xu', 'Cấp độ, danh hiệu, thống kê, huy hiệu, avatar, khung, lịch sử Xu', ['profile.show', 'profile.appearance*', 'profile.wallet', 'profile.guardian*'], ['admin', 'student'], ['guest']],
        'rewards' => ['Tài khoản', 'Nhận XP & Xu khi học', 'Cộng XP/Xu, chuỗi ngày, thưởng nhiệm vụ, thưởng thắng đấu', [], ['admin', 'student', 'parent'], ['guest']],
        'parent_area' => ['Khu vực', 'Khu Phụ huynh', 'Theo dõi con, liên kết, bài tập & nhận xét', ['parent.*'], ['admin', 'parent'], ['guest', 'student', 'teacher', 'parent']],
        'teacher_area' => ['Khu vực', 'Khu Giáo viên', 'Lớp học, giao bài, chấm, báo cáo, soạn câu', ['teacher.*'], ['admin', 'teacher'], ['guest', 'student', 'teacher', 'parent']],
        'admin_area' => ['Khu vực', 'Khu Quản trị', 'Người dùng, học liệu, hệ thống, cập nhật', ['admin.*'], ['admin'], ['guest', 'student', 'teacher', 'parent']],
    ];

    public static function defaults(): array
    {
        $m = [];
        foreach (self::ROLES as $role => $_) foreach (self::FEATURES as $f => $def) $m[$role][$f] = in_array($role, $def[4], true);
        return $m;
    }

    /** Ma trận hiệu lực = mặc định + phần Admin đã chỉnh (bỏ qua ô khóa). */
    public static function matrix(): array
    {
        static $cache = [];
        $saved = Settings::get('permissions.matrix', []);
        $ck = md5(json_encode($saved));
        if (isset($cache[$ck])) return $cache[$ck];
        $m = static::defaults();
        foreach (is_array($saved) ? $saved : [] as $role => $feats) {
            if (!isset($m[$role]) || $role === 'admin' || !is_array($feats)) continue;
            foreach ($feats as $f => $on) if (isset(self::FEATURES[$f]) && !static::locked($role, $f)) $m[$role][$f] = (bool) $on;
        }
        return $cache[$ck] = $m;
    }

    public static function locked(string $role, string $feature): bool
    {
        return $role === 'admin' || in_array($role, self::FEATURES[$feature][5] ?? [], true);
    }

    public static function roleOf(?User $u): string
    {
        return $u ? (array_key_exists($u->role, self::ROLES) ? $u->role : 'guest') : 'guest';
    }

    public static function allows(?User $u, string $feature): bool
    {
        $role = static::roleOf($u);
        if ($role === 'admin') return true;
        return static::matrix()[$role][$feature] ?? true;
    }

    /** Tính năng của một route (theo tên); null nếu route không thuộc tính năng nào. */
    public static function featureForRoute(?string $name): ?string
    {
        if (!$name) return null;
        static $memo = [];
        if (array_key_exists($name, $memo)) return $memo[$name];
        foreach (self::FEATURES as $f => $def) {
            foreach ($def[3] as $pattern) if (\Illuminate\Support\Str::is($pattern, $name)) return $memo[$name] = $f;
        }
        return $memo[$name] = null;
    }
}
