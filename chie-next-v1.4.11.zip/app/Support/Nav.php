<?php

namespace App\Support;

use App\Models\User;

/** Điều hướng theo vai trò: tối đa 4–5 mục chính, các khu phụ nằm trong ngữ cảnh. */
class Nav
{
    /** Four shortcuts plus an expandable full menu on small screens. */
    public static function mobile(array $items): array
    {
        $mobile = array_slice($items, 0, 4);
        foreach ($items as $item) {
            if ($item[1] === 'game.home') {
                if (!in_array('game.home', array_column($mobile, 1), true)) $mobile[min(2, count($mobile))] = $item;
                break;
            }
        }
        foreach (['profile.show', 'login'] as $route) {
            foreach ($items as $item) if ($item[1] === $route) { $mobile[3] = $item; break 2; }
        }
        return array_values($mobile);
    }

    public static function items(?User $u): array
    {
        $games = games_visible();   // v1.3.1: Admin bật/tắt ở Game Studio
        if (!$u) {
            return array_values(array_filter([
                ['Học tập', 'learn.home', 'book-open', ['learn.home', 'learn.path', 'learn.lesson', 'learn.demo', 'learn.stickers*', 'home']],
                ['Tự học', 'learn.self', 'calendar-check', ['learn.self']],
                ['Luyện tập', 'learn.practice', 'target', ['learn.practice', 'learn.skill*', 'learn.pronunciation']],
                ['Từ vựng', 'learn.words', 'languages', ['learn.words']],
                ['Ngữ pháp', 'grammar.index', 'puzzle', ['grammar.*']],
                ['Luyện đề', 'exam.home', 'clipboard-list', ['exam.*']],
                $games ? ['Game', 'game.home', 'gamepad-2', ['game.*']] : null,
                ['Đăng nhập', 'login', 'log-in', ['login', 'register*']],
            ]));
        }
        $items = match ($u->role) {
            'student' => [
                ['Học tập', 'learn.home', 'book-open', ['learn.home', 'learn.path', 'learn.lesson', 'learn.assignment*', 'learn.demo', 'attempt.*']],
                ['Tự học', 'learn.self', 'calendar-check', ['learn.self']],
                ['Luyện tập', 'learn.practice', 'target', ['learn.practice', 'learn.skill*', 'learn.pronunciation', 'learn.mistakes', 'learn.review']],
                ['Từ vựng', 'learn.words', 'languages', ['learn.words']],
                ['Ngữ pháp', 'grammar.index', 'puzzle', ['grammar.*']],
                ['Sticker', 'learn.stickers', 'sparkles', ['learn.stickers*']],
                $games ? ['Game đấu trường', 'game.home', 'gamepad-2', ['game.*', 'farm.*', 'shop.*', 'room.*', 'trade.*', 'leaderboard', 'world.*', 'duel.*', 'teams.*', 'family.*']] : null,
                ['Luyện đề', 'exam.home', 'clipboard-list', ['exam.*']],
                ['Hồ sơ', 'profile.show', 'user', ['profile.*', 'notifications.*', 'grade.*']],
            ],
            'parent' => [
                ['Tổng quan', 'parent.home', 'house', ['parent.home']],
                ['Tiến độ con', 'parent.progress', 'chart-column', ['parent.child', 'parent.progress']],
                ['Bài tập & nhận xét', 'parent.work', 'notebook-pen', ['parent.work']],
                ['Thử thách gia đình', 'family.index', 'heart', ['family.*']],
                ['Liên kết & cài đặt', 'parent.links', 'settings', ['parent.links', 'profile.*', 'notifications.*']],
            ],
            'teacher' => [
                ['Lớp học', 'teacher.home', 'school', ['teacher.home', 'teacher.class*', 'teacher.student']],
                ['Giao bài', 'teacher.assign', 'clipboard-list', ['teacher.assign*', 'teacher.assignment*']],
                ['Chấm & nhận xét', 'teacher.grading', 'pen-line', ['teacher.grading', 'teacher.submission*']],
                ['Báo cáo', 'teacher.reports', 'chart-column', ['teacher.reports']],
                ['Học liệu', 'teacher.content', 'layers', ['teacher.content*']],
                ['Học thử', 'learn.home', 'book-open', ['learn.*', 'exam.*']],
            ],
            'admin' => array_filter([
                ['Học tập', 'learn.home', 'book-open', ['learn.home', 'learn.path', 'learn.lesson', 'learn.demo', 'attempt.*']],
                ['Tự học', 'learn.self', 'calendar-check', ['learn.self']],
                ['Luyện tập', 'learn.practice', 'target', ['learn.practice', 'learn.skill*', 'learn.pronunciation', 'learn.review', 'learn.mistakes']],
                ['Từ vựng', 'learn.words', 'languages', ['learn.words']],
                ['Ngữ pháp', 'grammar.index', 'puzzle', ['grammar.*']],
                ['Sticker', 'learn.stickers', 'sparkles', ['learn.stickers*']],
                ['Luyện đề', 'exam.home', 'clipboard-list', ['exam.*']],
                ['Game', 'game.home', 'gamepad-2', ['game.*', 'farm.*', 'shop.*', 'room.*', 'trade.*', 'leaderboard', 'world.*', 'duel.*', 'teams.*']],
                ['Phụ huynh', 'parent.home', 'heart', ['parent.*', 'family.*']],   // Admin xem khu phụ huynh để kiểm tra
                ['Hồ sơ', 'profile.show', 'user', ['profile.*', 'notifications.*', 'grade.*']],
            ]),
            default => [],
        };
        // v1.4: ẩn mục có tính năng bị TẮT cho vai trò; thêm mục cho tính năng Admin đã BẬT thêm (ngoài mặc định)
        $items = array_values(array_filter($items, fn ($it) => $it && (!($f = Permissions::featureForRoute($it[1])) || Permissions::allows($u, $f))));
        $role = Permissions::roleOf($u);
        if ($role !== 'admin') {
            $have = array_map(fn ($it) => Permissions::featureForRoute($it[1]), $items);
            foreach (self::FEATURE_NAV as $f => $item) {
                if (!in_array($f, $have, true) && !in_array($role, Permissions::FEATURES[$f][4], true) && Permissions::allows($u, $f)) $items[] = $item;
            }
        }
        return $items;
    }

    /** Mục menu cho tính năng được Admin bật thêm cho một vai trò. */
    public const FEATURE_NAV = [
        'games' => ['Game', 'game.home', 'gamepad-2', ['game.*', 'world.*']],
        'farm' => ['Nông trại', 'farm.show', 'sprout', ['farm.*']],
        'shop' => ['Cửa hàng', 'shop.index', 'store', ['shop.*', 'room.*', 'trade.*']],
        'duel' => ['Đấu 1–1', 'duel.index', 'swords', ['duel.*', 'teams.*']],
        'leaderboard' => ['Bảng xếp hạng', 'leaderboard', 'trophy', ['leaderboard']],
        'family' => ['Thử thách gia đình', 'family.index', 'heart', ['family.*']],
        'review' => ['Ôn tập', 'learn.review', 'rotate-ccw', ['learn.review', 'learn.mistakes']],
        'assignments' => ['Bài được giao', 'learn.assignments', 'clipboard-list', ['learn.assignment*']],
        'profile' => ['Hồ sơ', 'profile.show', 'user', ['profile.*']],
    ];

    public static function admin(): array
    {
        return [
            '0 · Khu học tập' => [['Vào trang học (như học sinh)', 'learn.home', 'book-open', ['learn.*']], ['Luyện đề', 'exam.home', 'clipboard-list', ['exam.*']], ['Trò chơi (thử)', 'game.home', 'gamepad-2', ['game.*']]],
            '1 · Tổng quan' => [['Tổng quan & trực tuyến', 'admin.dashboard', 'house', ['admin.dashboard']]],
            '2 · Học liệu & đề' => [
                ['Sticker học tập', 'admin.stickers', 'sparkles', ['admin.stickers*']],
                ['Học liệu (tổng)', 'admin.content', 'layers', ['admin.content']],
                ['Cây chương trình', 'admin.curriculum', 'map', ['admin.curriculum*']],
                ['Ngân hàng câu hỏi', 'admin.questions', 'list-checks', ['admin.questions*']],
                ['Từ vựng', 'admin.lexicon', 'languages', ['admin.lexicon*']],
                ['Khung đề & link chia sẻ', 'admin.blueprints', 'clipboard-list', ['admin.blueprints*', 'admin.shares*']],
                ['Nhập dữ liệu', 'admin.import', 'upload', ['admin.import*']],
                ['Báo lỗi câu hỏi', 'admin.reports', 'flag', ['admin.reports*']],
            ],
            '3 · Game & cơ chế' => [['Game Studio (4 game học)', 'admin.games', 'gamepad-2', ['admin.games*']], ['Quản lý Zoo Garden 3D', 'admin.zoo', 'sprout', ['admin.zoo*']]],
            '4 · Kinh tế' => [['Shop, Gacha, Nông trại', 'admin.economy', 'coins', ['admin.economy', 'admin.economy.*']], ['Sổ cái Xu', 'admin.economy.ledger', 'scroll-text', ['admin.economy.ledger']]],
            '5 · Người dùng' => [
                ['Tài khoản & vai trò', 'admin.users', 'users', ['admin.users*']],
                ['Phân quyền', 'admin.permissions', 'shield', ['admin.permissions*']],
                ['Lớp học', 'admin.classes', 'school', ['admin.classes*']],
                ['Gia đình', 'admin.families', 'heart', ['admin.families*']],
            ],
            '6 · Hệ thống' => [
                ['Cấu hình', 'admin.system', 'settings', ['admin.system*']],
                ['Điều khoản', 'admin.terms', 'scroll-text', ['admin.terms*']],
                ['Bộ lọc từ', 'admin.filters', 'filter', ['admin.filters*']],
                ['Gian lận', 'admin.flags', 'shield', ['admin.flags*']],
                ['Nhật ký thao tác', 'admin.audit', 'activity', ['admin.audit']],
                ['Theo dõi lỗi', 'admin.errors', 'triangle-alert', ['admin.errors*']],
                ['Cập nhật phiên bản', 'admin.update', 'refresh-cw', ['admin.update*']],
            ],
        ];
    }

    public static function home(?User $u): string
    {
        if (!$u) return route('learn.home');
        return match ($u->role) {
            'admin' => route('learn.home'),
            'teacher' => $u->isApprovedTeacher() ? route('teacher.home') : route('teacher.pending'),
            'parent' => route('parent.home'),
            default => route('learn.home'),
        };
    }
}
