<?php
namespace App\Services;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Carbon;
use Symfony\Component\HttpFoundation\IpUtils;

class ActivityAnalytics
{
    public const RANGES = ['today'=>'Hôm nay','7d'=>'7 ngày qua','30d'=>'1 tháng qua (30 ngày)'];
    public static function available(): bool { return Schema::hasTable('activity_analytics'); }

    public static function location(Request $r): array
    {
        $geo=['country'=>'','region'=>'','city'=>''];
        $peer=(string)$r->server('REMOTE_ADDR','');
        if (!$peer || !IpUtils::checkIp($peer, config('analytics.geo_proxies',[]))) return $geo;
        $country=strtoupper((string)$r->header('CF-IPCountry',''));
        if (!preg_match('/^[A-Z]{2}$/D',$country) || $country==='XX') return $geo;
        $clean=fn($v)=>mb_substr(trim(preg_replace('/[\p{C}]/u','',rawurldecode((string)$v)) ?? ''),0,80);
        return ['country'=>$country,'region'=>$clean($r->header('CF-Region')),'city'=>$clean($r->header('CF-IPCity'))];
    }

    public static function record(Request $r, string $module, bool $page = false): void
    {
        // Guest mode does not persist activity or learning records.
        if (!$r->user() || $r->user()->status !== 'active' || !static::available()) return;
        $geo=static::location($r); $now=now();
        $key=['user_id'=>$r->user()->id,'bucket_at'=>$now->copy()->startOfHour()->toDateTimeString(),
            'module'=>array_key_exists($module,LiveStatus::MODULES)?$module:'browse',
            'geo_key'=>hash('sha256',json_encode($geo))];
        $data=$key+$geo+['role'=>$r->user()->role,'first_seen_at'=>$now,'last_seen_at'=>$now,'page_views'=>0];
        DB::table('activity_analytics')->insertOrIgnore($data);
        DB::table('activity_analytics')->where($key)->update(['last_seen_at'=>$now,'role'=>$r->user()->role,
            'page_views'=>DB::raw('page_views + '.($page?1:0))]);
    }

    public static function filters(Request $r): array
    {
        $f=$r->validate(['range'=>'nullable|in:today,7d,30d','country'=>'nullable|regex:/^[A-Z]{2}$/D',
            'region'=>'nullable|string|max:80','city'=>'nullable|string|max:80','role'=>'nullable|in:student,parent,teacher,admin']);
        return array_merge(['range'=>'7d','country'=>'','region'=>'','city'=>'','role'=>''],array_filter($f,fn($v)=>$v!==null));
    }

    private static function query(Carbon $start, Carbon $end, array $f, bool $geo = true)
    {
        $q=DB::table('activity_analytics')->where('bucket_at','>=',$start)->where('bucket_at','<',$end);
        foreach(($geo?['role','country','region','city']:['role']) as $key) if($f[$key]!=='')$q->where($key,$f[$key]);
        return $q;
    }

    public static function report(array $f): array
    {
        $days=match($f['range']){'today'=>1,'30d'=>30,default=>7};
        $end=now(); $start=today()->subDays($days-1); $exclusive=$end->copy()->addSecond();
        $base=['available'=>static::available(),'filters'=>$f,'range_label'=>self::RANGES[$f['range']],
            'start'=>$start,'end'=>$end,'timezone'=>config('app.timezone')];
        if(!$base['available'])return $base;
        $q=static::query($start,$exclusive,$f);
        $active=(clone $q)->distinct()->count('user_id');
        $views=(int)(clone $q)->sum('page_views');
        $live=DB::table('activity_analytics')->where('last_seen_at','>=',now()->subSeconds(150));
        foreach(['role','country','region','city'] as $key)if($f[$key]!=='')$live->where($key,$f[$key]);
        $online=(clone $live)->distinct()->count('user_id');
        $liveModules=(clone $live)->selectRaw('module, COUNT(DISTINCT user_id) active')->groupBy('module')->get();
        // Previous period has the same duration, including today's partial day.
        $previousStart=$start->copy()->subDays($days);$previousEnd=$exclusive->copy()->subDays($days);
        $prevQ=static::query($previousStart,$previousEnd,$f);
        $prevActive=(clone $prevQ)->distinct()->count('user_id'); $prevViews=(int)(clone $prevQ)->sum('page_views');
        $series=[];$max=1;
        $format=$days===1?'%Y-%m-%d %H:00:00':'%Y-%m-%d';
        $group=fn($builder)=>$builder->selectRaw("DATE_FORMAT(bucket_at, '$format') bucket, COUNT(DISTINCT user_id) active, SUM(page_views) views")->groupByRaw("DATE_FORMAT(bucket_at, '$format')")->get()->keyBy('bucket');
        $rows=$group(clone $q);$previous=$group(clone $prevQ);
        $n=$days===1?24:$days;
        for($i=0;$i<$n;$i++){
            $at=$start->copy();$days===1?$at->addHours($i):$at->addDays($i);
            $key=$at->format($days===1?'Y-m-d H:00:00':'Y-m-d');$old=$at->copy()->subDays($days)->format($days===1?'Y-m-d H:00:00':'Y-m-d');
            $value=(int)($rows[$key]->active??0);$pv=(int)($previous[$old]->active??0);$future=$at->gt($end);
            $series[]=['label'=>$at->format($days===1?'H:i':'d/m'),'active'=>$future?null:$value,'previous'=>$future?null:$pv,'views'=>(int)($rows[$key]->views??0)];
            $max=max($max,$value,$pv);
        }
        $regions=(clone $q)->selectRaw('country, region, city, COUNT(DISTINCT user_id) active, SUM(page_views) views')
            ->groupBy('country','region','city')->orderByDesc('active')->orderByDesc('views')->limit(50)->get();
        $modules=(clone $q)->selectRaw('module, COUNT(DISTINCT user_id) active, SUM(page_views) views')->groupBy('module')->orderByDesc('active')->get();
        $roles=(clone $q)->selectRaw('role, COUNT(DISTINCT user_id) active')->groupBy('role')->orderByDesc('active')->get();
        $known=(clone $q)->where('country','<>','')->distinct()->count('user_id');
        $options=static::query($start,$exclusive,$f,false);
        $countries=(clone $options)->where('country','<>','')->distinct()->orderBy('country')->pluck('country');
        if($f['country'])$options->where('country',$f['country']);
        $regionOptions=(clone $options)->where('region','<>','')->distinct()->orderBy('region')->pluck('region');
        if($f['region'])$options->where('region',$f['region']);
        $cityOptions=(clone $options)->where('city','<>','')->distinct()->orderBy('city')->pluck('city');
        $first=DB::table('activity_analytics')->min('first_seen_at');
        return $base+compact('active','views','online','liveModules','prevActive','prevViews','series','max','regions','modules','roles','known','countries','regionOptions','cityOptions','first');
    }
}
