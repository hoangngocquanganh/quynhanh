<?php

namespace App\Services;

use App\Models\User;
use Illuminate\Support\Facades\DB;

/**
 * Số liệu trang Hồ sơ: danh hiệu theo cấp, hạng XP trong khối lớp, XP 14 ngày,
 * tổng câu/độ chính xác, kỹ năng, từ vựng, ngữ pháp và huy hiệu.
 */
class ProfileStats
{
    /** [cấp tối thiểu, danh hiệu, emoji] */
    public const RANKS = [
        [1, 'Sắt', '⚔️'], [3, 'Đồng', '🛡️'], [5, 'Bạc', '🛡️'], [8, 'Vàng', '🏅'], [10, 'Bạch Kim', '💠'],
        [15, 'Lục Bảo', '💚'], [20, 'Kim Cương', '💎'], [30, 'Cao Thủ', '🔮'], [45, 'Đại Cao Thủ', '🔥'],
        [60, 'Thách Đấu', '👑'], [80, 'Phượng Hoàng', '🔥'], [100, 'Thiên Long', '🐉'],
    ];

    public static function rankFor(int $level): array
    {
        $cur = self::RANKS[0];
        $next = null;
        foreach (self::RANKS as $i => $r) {
            if ($level >= $r[0]) { $cur = $r; $next = self::RANKS[$i + 1] ?? null; }
        }
        return ['title' => $cur[1], 'emoji' => $cur[2], 'next' => $next ? ['title' => $next[1], 'emoji' => $next[2], 'level' => $next[0]] : null];
    }

    public static function build(User $u): array
    {
        $w = Economy::walletFor($u->id);
        $g = (int) ($u->grade_level ?: current_grade());

        // hạng XP trong cùng khối lớp (học sinh đang hoạt động)
        $peers = DB::table('wallets')->join('users', 'users.id', '=', 'wallets.user_id')
            ->where('users.role', 'student')->where('users.status', 'active')->when($g, fn ($q) => $q->where('users.grade_level', $g));
        $ahead = (clone $peers)->where('wallets.xp', '>', $w->xp)->count();
        $peerCount = (clone $peers)->count();

        // XP theo ngày (14 ngày)
        $from = now()->subDays(13)->startOfDay();
        $daily = DB::table('xu_ledger')->where('user_id', $u->id)->where('created_at', '>=', $from)->where('delta_xp', '>', 0)
            ->selectRaw('DATE(created_at) d, SUM(delta_xp) xp')->groupBy('d')->pluck('xp', 'd');
        $days = [];
        for ($i = 13; $i >= 0; $i--) {
            $d = now()->subDays($i);
            $days[] = ['label' => $d->format('d/m'), 'dow' => ['CN', 'T2', 'T3', 'T4', 'T5', 'T6', 'T7'][$d->dayOfWeek], 'xp' => (int) ($daily[$d->toDateString()] ?? 0)];
        }

        $att = DB::table('attempts')->where('user_id', $u->id)->where('status', 'submitted');
        $sum = (clone $att)->selectRaw('COUNT(*) n, COALESCE(SUM(answered),0) q, COALESCE(SUM(correct),0) c')->first();
        $studyDays = (clone $att)->where('submitted_at', '>=', now()->subDays(30))->distinct()->count(DB::raw('DATE(submitted_at)'));
        $minutes = (int) round((clone $att)->whereNotNull('started_at')
            ->selectRaw('COALESCE(SUM(GREATEST(0, LEAST(TIMESTAMPDIFF(SECOND, started_at, submitted_at), 3600))),0) s')->value('s') / 60);

        $skills = DB::table('skill_stats')->where('user_id', $u->id)->where('tag', '')->groupBy('skill')
            ->selectRaw('skill, SUM(correct) c, SUM(total) t')->get()
            ->map(fn ($r) => ['skill' => $r->skill, 'label' => \App\Models\Question::SKILLS[$r->skill] ?? $r->skill, 'correct' => (int) $r->c, 'total' => (int) $r->t,
                'pct' => $r->t ? (int) round($r->c / $r->t * 100) : 0])->sortByDesc('total')->values();

        $words = DB::table('srs_cards')->where('user_id', $u->id)->where('item_type', 'word')->selectRaw('COUNT(*) n, SUM(stage >= 3) m')->first();
        $grammar = DB::table('skill_stats')->where('user_id', $u->id)->where('tag', 'like', 'gp:%')->groupBy('tag')
            ->selectRaw('tag, SUM(correct) c, SUM(total) t')->get();
        $grammarDone = $grammar->filter(fn ($r) => $r->t >= 5 && $r->c / $r->t >= 0.8)->count();
        $lessons = DB::table('lesson_progress')->where('user_id', $u->id)->whereIn('status', ['completed', 'mastered'])->count();

        $q = (int) $sum->q;
        $acc = $q ? (int) round($sum->c / $q * 100) : null;
        $badges = Badges::sync($u, [
            'lessons' => $lessons, 'questions' => $q, 'streak' => $w->streak_days, 'level' => $w->level, 'xp' => $w->xp,
            'words' => (int) $words->n, 'words_mastered' => (int) $words->m, 'grammar_done' => $grammarDone,
            'accuracy80' => $q >= 50 && $acc >= 80 ? 1 : 0, 'accuracy90' => $q >= 100 && $acc >= 90 ? 1 : 0,
            'perfect' => (clone $att)->where('total', '>=', 5)->where('score_100', 100)->count(),
            'combo' => (int) (clone $att)->max('best_streak'),
            'reviews' => (clone $att)->where('kind', 'review')->where('ref_type', 'srs')->count(),
            'games' => (clone $att)->where('kind', 'game')->count(), 'exams' => (clone $att)->where('kind', 'exam')->count(),
        ]);

        return [
            'rank' => self::rankFor((int) $w->level),
            'position' => $u->isStudent() && $peerCount ? ['pos' => $ahead + 1, 'of' => max($peerCount, $ahead + 1)] : null,
            'days' => $days, 'week_xp' => array_sum(array_column(array_slice($days, -7), 'xp')),
            'attempts' => (int) $sum->n, 'questions' => $q, 'correct' => (int) $sum->c, 'accuracy' => $acc,
            'study_days' => $studyDays, 'minutes' => $minutes, 'skills' => $skills,
            'words' => (int) $words->n, 'words_mastered' => (int) $words->m,
            'grammar_practised' => $grammar->count(), 'grammar_done' => $grammarDone, 'lessons' => $lessons, 'badges' => $badges,
        ];
    }
}
