<?php

namespace App\Services;

use App\Models\TermsVersion;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class Accounts
{
    public static function create(array $attrs): User
    {
        return DB::transaction(function () use ($attrs) {
            $u = User::create($attrs);
            Economy::walletFor($u->id);
            return $u;
        });
    }

    public static function recordConsent(User $u, TermsVersion $t, ?Request $r = null, ?int $byUserId = null): void
    {
        DB::table('user_terms_consents')->insertOrIgnore([
            'user_id' => $u->id, 'terms_version' => $t->version, 'content_sha256' => $t->content_sha256, 'accepted_at' => now(),
            'ip_hash' => $r ? hash('sha256', (string) $r->ip() . config('app.key')) : null,
            'user_agent' => $r ? mb_substr((string) $r->userAgent(), 0, 255) : null, 'accepted_by_user_id' => $byUserId,
        ]);
    }
}
