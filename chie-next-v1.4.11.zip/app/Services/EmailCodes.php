<?php

namespace App\Services;

use App\Models\EmailVerification;
use App\Models\User;
use Illuminate\Support\Facades\Mail;

/** Mã xác minh email 6 số, hết hạn 10 phút, tối đa 5 lần nhập. */
class EmailCodes
{
    public static function send(User $u): void
    {
        if (!$u->email) return;
        EmailVerification::where('user_id', $u->id)->whereNull('used_at')->update(['used_at' => now()]);
        $code = str_pad((string) random_int(0, 999999), 6, '0', STR_PAD_LEFT);
        EmailVerification::create(['user_id' => $u->id, 'code_hash' => hash('sha256', $code . config('app.key')), 'expires_at' => now()->addMinutes(10)]);
        try {
            Mail::raw("Xin chào {$u->name},\n\nMã xác minh email CHIE NEXT của bạn là: {$code}\nMã có hiệu lực trong 10 phút.\n\nNếu bạn không đăng ký, hãy bỏ qua email này.",
                fn ($m) => $m->to($u->email)->subject('Mã xác minh CHIE NEXT: ' . $code));
        } catch (\Throwable $e) {
            report($e);
            throw new DomainError('Chưa gửi được email (máy chủ thư chưa cấu hình đúng). Vui lòng báo quản trị viên.');
        }
    }

    public static function verify(User $u, string $code): bool
    {
        $v = EmailVerification::where('user_id', $u->id)->whereNull('used_at')->latest('id')->first();
        if (!$v || $v->expires_at->isPast()) throw new DomainError('Mã đã hết hạn. Hãy bấm "Gửi lại mã".');
        if ($v->attempts >= 5) throw new DomainError('Bạn nhập sai quá nhiều lần. Hãy bấm "Gửi lại mã".');
        $v->increment('attempts');
        if (!hash_equals($v->code_hash, hash('sha256', trim($code) . config('app.key')))) return false;
        $v->update(['used_at' => now()]);
        $u->forceFill(['email_verified_at' => now()])->save();
        return true;
    }
}
