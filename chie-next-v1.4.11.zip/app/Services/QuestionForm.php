<?php

namespace App\Services;

use App\Models\Question;
use Illuminate\Http\Request;

/** Đọc/kiểm tra form soạn câu hỏi (dùng chung Admin + giáo viên). */
class QuestionForm
{
    public static function rules(): array
    {
        return [
            'grade_id' => 'required|integer|min:1|max:12',
            'skill' => 'required|in:' . implode(',', array_keys(Question::SKILLS)),
            'type' => 'required|in:mcq,listen_mcq,word_order,fill_blank,matching,writing,speaking',
            'difficulty' => 'required|integer|min:1|max:5',
            'text' => 'required|string|max:1000',
            'speak' => 'nullable|string|max:300',
            'emoji' => 'nullable|string|max:16',
            'hint_vi' => 'nullable|string|max:500',
            'example_after' => 'nullable|string|max:300',
            'options_text' => 'nullable|string|max:3000',
            'correct' => 'nullable|string|max:500',
            'accepted' => 'nullable|string|max:1000',
            'explanation_vi' => 'nullable|string|max:2000',
            'tags' => 'nullable|array', 'tags.*' => 'string|max:40',
        ];
    }

    /** @return array attributes cho Question */
    public static function parse(Request $r): array
    {
        $d = $r->validate(static::rules(), [], ['text' => 'đề bài', 'options_text' => 'các lựa chọn', 'correct' => 'đáp án đúng', 'explanation_vi' => 'giải thích']);
        $lines = array_values(array_filter(array_map('trim', preg_split('/\r?\n/', (string) ($d['options_text'] ?? ''))), fn ($x) => $x !== ''));
        $prompt = array_filter(['text' => trim($d['text']), 'speak' => $d['speak'] ?? null, 'emoji' => $d['emoji'] ?? null,
            'hint_vi' => $d['hint_vi'] ?? null, 'example_after' => $d['example_after'] ?? null], fn ($v) => $v !== null && $v !== '');
        $correct = trim((string) ($d['correct'] ?? ''));
        $options = null;
        $answer = [];
        switch ($d['type']) {
            case 'mcq':
            case 'listen_mcq':
                if (count($lines) < 2) throw new DomainError('Cần ít nhất 2 lựa chọn (mỗi dòng một lựa chọn).');
                if (!in_array($correct, $lines, true)) throw new DomainError('Đáp án đúng phải trùng khớp một dòng trong danh sách lựa chọn.');
                if (count(array_unique(array_map('mb_strtolower', $lines))) !== count($lines)) throw new DomainError('Các lựa chọn bị trùng nhau.');
                if ($d['type'] === 'listen_mcq' && empty($prompt['speak'])) throw new DomainError('Câu nghe cần nội dung để đọc (ô "Nội dung đọc").');
                $options = $lines;
                $answer = ['correct' => $correct];
                break;
            case 'word_order':
                if ($correct === '') throw new DomainError('Nhập câu đúng.');
                $options = $lines ?: preg_split('/\s+/u', $correct);
                $answer = ['correct' => $correct, 'accepted' => array_values(array_filter(array_map('trim', explode('|', (string) ($d['accepted'] ?? '')))))];
                break;
            case 'fill_blank':
                if ($correct === '') throw new DomainError('Nhập đáp án điền.');
                $answer = ['correct' => $correct, 'accepted' => array_values(array_filter(array_map('trim', explode('|', (string) ($d['accepted'] ?? '')))))];
                break;
            case 'matching':
                $pairs = [];
                foreach ($lines as $l) {
                    $parts = array_map('trim', explode('=', $l, 2));
                    if (count($parts) === 2 && $parts[0] !== '' && $parts[1] !== '') $pairs[] = $parts;
                }
                if (count($pairs) < 2) throw new DomainError('Ghép cặp: mỗi dòng dạng "English = Tiếng Việt", ít nhất 2 dòng.');
                $answer = ['pairs' => $pairs];
                break;
            default:
                $answer = ['sample' => $correct ?: null];
        }
        if (in_array($d['type'], Question::AUTO_GRADED, true) && trim((string) ($d['explanation_vi'] ?? '')) === '') {
            throw new DomainError('Cần giải thích bằng tiếng Việt (vì sao đúng, lỗi hay gặp) để học sinh học từ câu sai.');
        }
        return ['grade_id' => (int) $d['grade_id'], 'skill' => $d['skill'], 'type' => $d['type'], 'difficulty' => (int) $d['difficulty'],
            'prompt' => $prompt, 'options' => $options, 'answer' => $answer, 'explanation_vi' => $d['explanation_vi'] ?? null,
            'tags' => array_values(array_intersect($d['tags'] ?? [], array_keys(MistakeTips::TAGS)))];
    }

    public static function toForm(?Question $q): array
    {
        if (!$q) return ['grade_id' => 3, 'skill' => 'vocabulary', 'type' => 'mcq', 'difficulty' => 1, 'text' => '', 'options_text' => '', 'correct' => ''];
        $opts = $q->type === 'matching' ? implode("\n", array_map(fn ($p) => $p[0] . ' = ' . $p[1], $q->answer['pairs'] ?? [])) : implode("\n", $q->options ?? []);
        return ['grade_id' => $q->grade_id, 'skill' => $q->skill, 'type' => $q->type, 'difficulty' => $q->difficulty, 'text' => $q->prompt['text'] ?? '',
            'speak' => $q->prompt['speak'] ?? '', 'emoji' => $q->prompt['emoji'] ?? '', 'hint_vi' => $q->prompt['hint_vi'] ?? '', 'example_after' => $q->prompt['example_after'] ?? '',
            'options_text' => $opts, 'correct' => $q->answer['correct'] ?? ($q->answer['sample'] ?? ''), 'accepted' => implode(' | ', $q->answer['accepted'] ?? []),
            'explanation_vi' => $q->explanation_vi, 'tags' => $q->tags ?? []];
    }
}
