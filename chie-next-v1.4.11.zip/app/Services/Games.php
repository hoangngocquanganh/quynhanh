<?php

namespace App\Services;

use App\Models\GameConfig;

/** Danh mục 4 game học + cách chọn câu hỏi cho từng game (dùng chung ngân hàng câu đã duyệt đúng lớp). */
class Games
{
    public const LIST = [
        'word_runner' => ['icon' => 'zap', 'tone' => '', 'skill' => 'Từ vựng · phản xạ', 'desc' => 'Chạy qua 3 làn, lao vào cổng có đáp án đúng. Sai mất tim, đúng liên tiếp được chuỗi.',
            'pick' => ['skills' => ['vocabulary'], 'types' => ['mcq', 'listen_mcq']], 'max_options' => 3],
        'grammar_tower' => ['icon' => 'castle', 'tone' => 'info', 'skill' => 'Ngữ pháp', 'desc' => 'Quái mang câu sai tiến về thành. Chọn đáp án đúng để tháp bắn hạ, xây 6 loại tháp.',
            'pick' => ['skills' => ['grammar', 'communication'], 'types' => ['mcq']], 'max_options' => 4],
        'voice_island' => ['icon' => 'headphones', 'tone' => 'success', 'skill' => 'Nghe · phát âm · nói', 'desc' => 'Nghe chậm, bắt từ rơi theo nhịp; luyện nói đuổi (shadowing) và tự nghe lại giọng mình.',
            'pick' => ['skills' => ['listening', 'pronunciation'], 'types' => ['listen_mcq', 'mcq']], 'max_options' => 4],
        'reading_escape' => ['icon' => 'book-open', 'tone' => 'accent', 'skill' => 'Đọc hiểu · viết câu', 'desc' => 'Tìm manh mối trong thư viện bí ẩn, trả lời câu đọc hiểu và ghép câu để mở cửa.',
            'pick' => ['skills' => ['reading', 'communication', 'writing'], 'types' => ['mcq', 'word_order']], 'max_options' => 4],
    ];

    public static function config(string $code): ?GameConfig
    {
        return GameConfig::where('game_code', $code)->first();
    }

    public static function available(string $code, int $grade): int
    {
        $d = self::LIST[$code];
        return \App\Models\Question::published()->where('grade_id', $grade)->whereIn('skill', $d['pick']['skills'])->whereIn('type', $d['pick']['types'])->count();
    }

    // ------------------------------------------------------------------ v1.3: đọc khai báo từ modules/games/*/module.json

    /** module.json của game (hoặc null nếu chưa có thư mục module). */
    public static function module(string $code): ?array
    {
        static $cache = null;
        if ($cache === null) {
            $cache = [];
            try { $cache = ModuleRegistry::allGames(); } catch (\Throwable $e) { $cache = []; }
        }
        return $cache[$code] ?? null;
    }

    /** Đường dẫn JS 2D/3D mà trang chơi nạp (chỉ cho phép tệp trong assets/ và có thật). */
    public static function entries(string $code): array
    {
        $m = static::module($code) ?? [];
        $pick = function (?string $path, string $fallback) {
            $path = ltrim(str_replace('\\', '/', (string) $path), '/');
            return ($path !== '' && str_starts_with($path, 'assets/') && !str_contains($path, '..') && str_ends_with($path, '.js') && is_file(base_path($path))) ? $path : $fallback;
        };
        return [
            '2d' => $pick($m['entry_2d'] ?? null, 'assets/js/games/' . $code . '.js'),
            '3d' => $pick($m['entry_3d'] ?? null, 'assets/js/games3d/' . $code . '.js'),
        ];
    }

    /** Ô cấu hình trong Game Studio: ưu tiên "schema" của module, thiếu thì dùng bảng gốc. */
    public static function schema(string $code): array
    {
        $base = \App\Http\Controllers\Admin\GameAdminController::SCHEMA[$code] ?? [];
        $mod = static::module($code)['schema'] ?? null;
        if (!is_array($mod)) return $base;
        $out = [];
        foreach ($mod as $k => $def) {
            if (!is_string($k) || !preg_match('/^[a-z0-9_]{1,40}$/', $k) || !is_array($def) || count($def) < 2) continue;
            $type = in_array($def[1], ['int', 'float', 'bool'], true) ? $def[1] : null;
            if (!$type) continue;
            $out[$k] = $type === 'bool' ? [(string) $def[0], 'bool'] : [(string) $def[0], $type, (float) ($def[2] ?? 0), (float) ($def[3] ?? 1000000)];
        }
        return $out ?: $base;
    }

    /** Giá trị mặc định khai báo trong module (dùng cho nút "Khôi phục mặc định của module"). */
    public static function moduleDefaults(string $code): array
    {
        $d = static::module($code)['defaults'] ?? [];
        return is_array($d) ? $d : [];
    }
}
