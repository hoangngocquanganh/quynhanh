<?php

namespace App\Services;

use App\Models\ImportRun;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

/**
 * Công cụ nhập học liệu từ gói JSON chuẩn hóa (database/content/*.json).
 * - Kiểm tra lại từng mục ở máy chủ (đáp án nằm trong lựa chọn, đủ trường, đúng lớp...).
 * - Idempotent: khóa nội dung (content_hash / source_key / word_key) → chạy lại không nhân đôi, KHÔNG ghi đè bản Admin đã sửa.
 * - Mục nghi vấn → trạng thái "review" (chờ duyệt), không tự xuất bản.
 * - Ghi báo cáo vào import_runs.
 */
class ContentImporter
{
    protected array $stats = [];
    protected array $notes = [];

    public static function packages(): array
    {
        $out = [];
        foreach (glob(database_path('content/*.json')) as $f) {
            $head = json_decode(file_get_contents($f), true);
            if (($head['format'] ?? null) !== 'chie-content') continue;
            $out[basename($f)] = ['file' => $f, 'title' => $head['title'] ?? basename($f), 'source' => $head['generated_from'] ?? null,
                'counts' => ['units' => count($head['units'] ?? []), 'lessons' => count($head['lessons'] ?? []), 'questions' => count($head['questions'] ?? []), 'lexicon' => count($head['lexicon'] ?? []), 'grammar_topics' => count($head['grammar_topics'] ?? [])]];
        }
        return $out;
    }

    public function run(string $file, bool $dryRun = false, ?int $actorId = null): ImportRun
    {
        $raw = file_get_contents($file);
        $pkg = json_decode($raw, true);
        if (($pkg['format'] ?? null) !== 'chie-content') throw new DomainError('Tệp không đúng định dạng gói nội dung CHIE.');
        $run = ImportRun::create(['source' => basename($file), 'source_sha256' => hash('sha256', $raw), 'actor_user_id' => $actorId, 'dry_run' => $dryRun, 'started_at' => now()]);
        $this->stats = [];
        $this->notes = [];
        $subjectId = (int) DB::table('subjects')->where('code', 'en')->value('id');
        if (!$subjectId) throw new DomainError('Chưa có dữ liệu nền (môn Tiếng Anh). Hãy chạy cài đặt trước.');

        DB::beginTransaction();
        try {
            $unitIds = $this->importUnits($pkg['units'] ?? []);
            $wordIds = $this->importLexicon($pkg['lexicon'] ?? [], $subjectId);
            $qIds = $this->importQuestions($pkg['questions'] ?? [], $subjectId);
            $this->importLessons($pkg['lessons'] ?? [], $unitIds, $qIds, $pkg['questions'] ?? []);
            $this->importPassages($pkg['passages'] ?? []);
            $this->importGrammarTopics($pkg['grammar_topics'] ?? []);   // v1.4: chủ điểm ngữ pháp (lý thuyết + mạch ôn thi)
            $this->importBlueprints($pkg['exam_blueprints'] ?? []);   // v1.3: ma trận đề theo lớp (modules/grades/*/exam_blueprints.json)
            if (!empty($pkg['game'])) $this->importGame($pkg['game']);
            if ($dryRun) DB::rollBack(); else DB::commit();
        } catch (\Throwable $e) {
            DB::rollBack();
            $run->update(['finished_at' => now(), 'stats' => $this->stats, 'report' => 'LỖI: ' . $e->getMessage()]);
            throw $e;
        }
        Curriculum::flush();
        $run->update(['finished_at' => now(), 'stats' => $this->stats, 'report' => $this->report($pkg)]);
        return $run;
    }

    protected function inc(string $k, int $by = 1): void { $this->stats[$k] = ($this->stats[$k] ?? 0) + $by; }
    protected function note(string $k, string $msg): void { if (count($this->notes[$k] ?? []) < 8) $this->notes[$k][] = $msg; }

    protected function status(?string $hint, array $flags): string
    {
        $s = in_array($hint, ['draft', 'review', 'published'], true) ? $hint : 'review';
        return ($flags && $s === 'published') ? 'review' : $s;
    }

    protected function importUnits(array $units): array
    {
        $ids = [];
        foreach ($units as $u) {
            $key = $u['key'] ?? null;
            $g = (int) ($u['grade'] ?? 0);
            if (!$key || $g < 1 || $g > 12 || empty($u['title_vi'])) { $this->inc('unit_bo_qua_loi'); $this->note('unit', 'Thiếu khóa/lớp/tên: ' . json_encode($u, JSON_UNESCAPED_UNICODE)); continue; }
            $existing = DB::table('units')->where('source_key', $key)->first();
            if ($existing) { $ids[$key] = $existing->id; $this->inc('unit_da_co'); continue; }
            $ids[$key] = DB::table('units')->insertGetId([
                'grade_id' => $g, 'grade_to' => $u['grade_to'] ?? null, 'semester' => (int) ($u['semester'] ?? 1), 'sort' => (int) ($u['sort'] ?? 0),
                'title_vi' => mb_substr($u['title_vi'], 0, 190), 'title_en' => isset($u['title_en']) ? mb_substr($u['title_en'], 0, 190) : null,
                'kind' => $u['kind'] ?? 'core', 'description' => $u['description'] ?? null,
                'status' => $this->status($u['status_hint'] ?? 'draft', $u['flags'] ?? []), 'source' => $u['source'] ?? null, 'source_key' => $key,
                'flags' => !empty($u['flags']) ? json_encode($u['flags']) : null, 'created_at' => now(), 'updated_at' => now(),
            ]);
            $this->inc('unit_nhap_moi');
        }
        return $ids;
    }

    /** v1.3: khung đề (exam_blueprints) — idempotent theo code, không ghi đè khung Admin đã sửa. */
    /** v1.4: chủ điểm ngữ pháp. Đã có mã → giữ nguyên (không ghi đè bản Admin đã sửa). */
    protected function importGrammarTopics(array $topics): void
    {
        if (!$topics || !\Illuminate\Support\Facades\Schema::hasTable('grammar_topics')) return;
        foreach ($topics as $t) {
            $code = $t['code'] ?? null;
            $g = (int) ($t['grade'] ?? 0);
            if (!$code || $g < 1 || $g > 12 || empty($t['title_vi'])) { $this->inc('chu_diem_bo_qua_loi'); continue; }
            if (DB::table('grammar_topics')->where('code', $code)->exists()) { $this->inc('chu_diem_da_co'); continue; }
            DB::table('grammar_topics')->insert([
                'code' => $code, 'grade_id' => $g, 'semester' => (int) ($t['semester'] ?? 1), 'track' => in_array($t['track'] ?? 'core', ['core', 'exam10', 'examgrad'], true) ? $t['track'] : 'core',
                'sort' => (int) ($t['sort'] ?? 0), 'title_vi' => $t['title_vi'], 'title_en' => $t['title_en'] ?? null, 'summary_vi' => $t['summary_vi'] ?? null,
                'theory' => isset($t['theory']) ? json_encode($t['theory'], JSON_UNESCAPED_UNICODE) : null,
                'status' => in_array($t['status'] ?? 'published', ['draft', 'review', 'published'], true) ? ($t['status'] ?? 'published') : 'published',
                'source' => $t['source'] ?? null, 'created_at' => now(), 'updated_at' => now(),
            ]);
            $this->inc('chu_diem_nhap_moi');
        }
    }

    protected function importBlueprints(array $items): void
    {
        $skills = array_keys(\App\Models\Question::SKILLS);
        foreach ($items as $b) {
            $code = preg_replace('/[^A-Za-z0-9_\-]/', '', (string) ($b['code'] ?? ''));
            $count = (int) ($b['question_count'] ?? 0);
            if ($code === '' || empty($b['title']) || $count < 1 || $count > 100) { $this->inc('khung_de_bo_qua_loi'); continue; }
            if (DB::table('exam_blueprints')->where('code', mb_substr($code, 0, 40))->exists()) { $this->inc('khung_de_da_co'); continue; }
            $mix = [];
            foreach ((array) ($b['skill_mix'] ?? []) as $k => $v) if (in_array($k, $skills, true) && (int) $v > 0) $mix[$k] = (int) $v;
            DB::table('exam_blueprints')->insert([
                'code' => mb_substr($code, 0, 40), 'title' => mb_substr((string) $b['title'], 0, 190), 'type' => mb_substr((string) ($b['type'] ?? 'custom'), 0, 20),
                'grade_from' => max(1, min(12, (int) ($b['grade_from'] ?? 1))), 'grade_to' => max(1, min(12, (int) ($b['grade_to'] ?? 12))),
                'question_count' => $count, 'duration_min' => max(1, min(240, (int) ($b['duration_min'] ?? $count))),
                'skill_mix' => $mix ? json_encode($mix) : null, 'note' => $b['note'] ?? null, 'is_active' => (bool) ($b['is_active'] ?? true),
                'sort' => (int) ($b['sort'] ?? 100), 'created_at' => now(), 'updated_at' => now(),
            ]);
            $this->inc('khung_de_nhap_moi');
        }
    }

    protected function importLexicon(array $items, int $subjectId): array
    {
        $ids = [];
        foreach ($items as $w) {
            $word = trim((string) ($w['word'] ?? ''));
            if ($word === '' || empty($w['meaning_vi'])) { $this->inc('tu_bo_qua_thieu_truong'); continue; }
            $key = Str::lower(preg_replace('/\s+/', ' ', $word));
            $existing = DB::table('lexicon_items')->where('word_key', $key)->value('id');
            if ($existing) { $ids[$key] = $existing; $this->inc('tu_da_co'); continue; }
            $flags = $w['flags'] ?? [];
            $ipa = trim((string) ($w['ipa'] ?? ''));
            if ($ipa !== '' && !preg_match('#^/[^/]+/$#u', $ipa)) $flags[] = 'ipa_sai_dinh_dang';
            $ids[$key] = DB::table('lexicon_items')->insertGetId([
                'subject_id' => $subjectId, 'word' => mb_substr($word, 0, 120), 'word_key' => mb_substr($key, 0, 120), 'pos' => $w['pos'] ?? null,
                'ipa_uk' => $ipa ?: null, 'ipa_us' => $w['ipa_us'] ?? ($ipa ?: null), 'meaning_vi' => mb_substr($w['meaning_vi'], 0, 190),
                'example_en' => !empty($w['example_en']) ? mb_substr($w['example_en'], 0, 255) : null, 'example_vi' => $w['example_vi'] ?? null,
                'emoji' => $w['emoji'] ?? null, 'topic' => $w['topic'] ?? null, 'grade_id' => max(1, min(12, (int) ($w['grade'] ?? 3))),
                'status' => $this->status($w['status_hint'] ?? 'published', array_values(array_unique($flags))), 'source' => $w['source'] ?? null,
                'flags' => $flags ? json_encode(array_values(array_unique($flags))) : null, 'created_at' => now(), 'updated_at' => now(),
            ]);
            $this->inc('tu_nhap_moi');
            if ($flags) $this->inc('tu_cho_duyet');
        }
        return $ids;
    }

    /** Kiểm tra lại một câu ở máy chủ. Trả về [ok, flags thêm, lý do bỏ qua]. */
    protected function validateQuestion(array $q): array
    {
        $flags = [];
        $type = $q['type'] ?? '';
        if (!array_key_exists($type, \App\Models\Question::TYPES)) return [false, [], 'loại câu không hỗ trợ'];
        if (!array_key_exists($q['skill'] ?? '', \App\Models\Question::SKILLS)) return [false, [], 'kỹ năng không hợp lệ'];
        $g = (int) ($q['grade'] ?? 0);
        if ($g < 1 || $g > 12) return [false, [], 'lớp không hợp lệ'];
        if (trim((string) ($q['prompt']['text'] ?? '')) === '') return [false, [], 'thiếu đề bài'];
        $ans = $q['answer'] ?? [];
        if (in_array($type, ['mcq', 'listen_mcq'], true)) {
            $opts = $q['options'] ?? [];
            if (!is_array($opts) || count($opts) < 2) return [false, [], 'ít hơn 2 lựa chọn'];
            if (!in_array($ans['correct'] ?? null, $opts, true)) return [false, [], 'đáp án không nằm trong lựa chọn'];
            if (count(array_unique(array_map('mb_strtolower', $opts))) !== count($opts)) $flags[] = 'lua_chon_trung';
            if ($type === 'listen_mcq' && empty($q['prompt']['speak'])) return [false, [], 'câu nghe thiếu nội dung phát âm'];
        } elseif ($type === 'word_order') {
            if (empty($ans['correct']) || empty($q['options'])) return [false, [], 'thiếu mảnh từ/câu đúng'];
        } elseif ($type === 'matching') {
            if (empty($ans['pairs']) || count($ans['pairs']) < 2) return [false, [], 'thiếu cặp ghép'];
        } elseif ($type === 'fill_blank') {
            if (empty($ans['correct'])) return [false, [], 'thiếu đáp án điền'];
        }
        if (trim((string) ($q['explanation_vi'] ?? '')) === '' && in_array($type, \App\Models\Question::AUTO_GRADED, true)) $flags[] = 'thieu_giai_thich';
        return [true, $flags, null];
    }

    protected function importQuestions(array $questions, int $subjectId): array
    {
        $ids = [];
        foreach ($questions as $q) {
            [$ok, $extraFlags, $why] = $this->validateQuestion($q);
            if (!$ok) { $this->inc('cau_bo_qua_loi'); $this->note('cau_loi', ($q['source_ref'] ?? '?') . ': ' . $why); continue; }
            $hash = $q['key'] ?? \App\Models\Question::hashContent($q['prompt']['text'], $q['options'] ?? [], $q['answer']);
            $existing = DB::table('questions')->where('content_hash', $hash)->value('id');
            if ($existing) { $ids[$hash] = $existing; $this->inc('cau_da_co'); continue; }
            $flags = array_values(array_unique(array_merge($q['flags'] ?? [], $extraFlags)));
            $tags = $q['tags'] ?? [];
            $tags = array_values(array_unique(array_merge($tags, MistakeTips::inferTags(($q['explanation_vi'] ?? '') . ' ' . ($q['prompt']['text'] ?? ''), $q['skill']))));
            $status = $this->status($q['status_hint'] ?? 'review', $flags);
            $id = DB::table('questions')->insertGetId([
                'subject_id' => $subjectId, 'grade_id' => (int) $q['grade'], 'unit_id' => null, 'skill' => $q['skill'], 'type' => $q['type'],
                'difficulty' => max(1, min(5, (int) ($q['difficulty'] ?? 1))),
                'prompt' => json_encode($q['prompt'], JSON_UNESCAPED_UNICODE), 'options' => isset($q['options']) ? json_encode($q['options'], JSON_UNESCAPED_UNICODE) : null,
                'answer' => json_encode($q['answer'], JSON_UNESCAPED_UNICODE), 'explanation_vi' => $q['explanation_vi'] ?? null,
                'tags' => $tags ? json_encode($tags) : null, 'status' => $status, 'version' => 1, 'content_hash' => $hash,
                'source' => $q['source'] ?? null, 'source_ref' => $q['source_ref'] ?? null, 'flags' => $flags ? json_encode($flags) : null,
                'reviewed_at' => $status === 'published' ? now() : null, 'created_at' => now(), 'updated_at' => now(),
            ]);
            DB::table('question_versions')->insert(['question_id' => $id, 'version' => 1, 'snapshot' => json_encode(['prompt' => $q['prompt'], 'options' => $q['options'] ?? null, 'answer' => $q['answer'], 'explanation_vi' => $q['explanation_vi'] ?? null], JSON_UNESCAPED_UNICODE), 'created_at' => now()]);
            $ids[$hash] = $id;
            $this->inc('cau_nhap_moi');
            $this->inc('cau_trang_thai_' . $status);
            foreach ($q['fixes'] ?? [] as $f) $this->inc('cau_da_chuan_hoa_' . $f);
            if ($flags) $this->note('cau_cho_duyet', ($q['source_ref'] ?? '') . ' → ' . implode(', ', $flags));
        }
        return $ids;
    }

    protected function importLessons(array $lessons, array $unitIds, array $qIds, array $questions): void
    {
        $byKey = collect($questions)->keyBy('key');
        $publicCount = [];
        foreach ($lessons as $l) {
            $key = $l['key'] ?? null;
            $unitId = $unitIds[$l['unit_key'] ?? ''] ?? null;
            if (!$key || !$unitId) { $this->inc('bai_bo_qua_loi'); continue; }
            if (DB::table('lessons')->where('source_key', $key)->exists()) { $this->inc('bai_da_co'); continue; }
            $qKeys = array_values(array_filter($l['question_keys'] ?? [], fn ($k) => isset($qIds[$k])));
            if (!$qKeys) { $this->inc('bai_bo_qua_khong_co_cau'); $this->note('bai', $key . ': không có câu hỏi hợp lệ'); continue; }
            $content = $l['content'] ?? $this->deriveContent(array_map(fn ($k) => $byKey[$k] ?? null, $qKeys));
            $unit = DB::table('units')->find($unitId);
            $g = (int) $unit->grade_id;
            $publicCount[$g] = $publicCount[$g] ?? DB::table('lessons')->join('units', 'units.id', '=', 'lessons.unit_id')->where('units.grade_id', $g)->where('lessons.is_public', true)->count();
            $isPublic = $l['is_public'] ?? ($publicCount[$g] < 2 && $unit->kind === 'core');
            if ($isPublic) $publicCount[$g]++;
            $lessonId = DB::table('lessons')->insertGetId([
                'unit_id' => $unitId, 'sort' => (int) ($l['sort'] ?? 0), 'title_vi' => mb_substr($l['title_vi'], 0, 190), 'title_en' => $l['title_en'] ?? null,
                'lesson_type' => $l['lesson_type'] ?? (!empty($l['is_review']) ? 'review' : 'core'), 'difficulty' => (int) ($l['difficulty'] ?? 1),
                'objectives' => json_encode($l['objectives'] ?? $this->objectives($l['title_vi'], !empty($l['is_review'])), JSON_UNESCAPED_UNICODE),
                'content' => json_encode($content, JSON_UNESCAPED_UNICODE), 'is_public' => $isPublic,
                'status' => $this->status($l['status_hint'] ?? $unit->status, []), 'version' => 1, 'source' => $l['source'] ?? null, 'source_key' => $key,
                'created_at' => now(), 'updated_at' => now(),
            ]);
            foreach ($qKeys as $i => $k) {
                DB::table('lesson_question')->insertOrIgnore(['lesson_id' => $lessonId, 'question_id' => $qIds[$k], 'sort' => $i]);
                DB::table('questions')->where('id', $qIds[$k])->whereNull('unit_id')->update(['unit_id' => $unitId]);
            }
            $this->inc('bai_nhap_moi');
        }
    }

    protected function objectives(string $title, bool $review): array
    {
        return $review
            ? ['Ôn lại từ vựng và mẫu câu của cả chủ điểm', 'Tự làm bài tổng hợp, sửa các lỗi còn mắc']
            : ['Hiểu và dùng được từ, mẫu câu của bài “' . $title . '”', 'Nghe và nói lại câu mẫu', 'Tự làm đúng ít nhất 60% câu luyện'];
    }

    /** Dựng phần "Làm quen / Nghe mẫu" từ chính dữ liệu câu hỏi của bài (không bịa nội dung mới). */
    protected function deriveContent(array $qs): array
    {
        $words = [];
        $examples = [];
        $notes = [];
        foreach (array_filter($qs) as $q) {
            $p = $q['prompt'] ?? [];
            if (($q['type'] ?? '') === 'matching') foreach ($q['answer']['pairs'] ?? [] as $pair) $words[] = $pair[0];
            if (preg_match('/“([^”]{1,40})”/u', $p['text'] ?? '', $m)) $words[] = $m[1];
            if (!empty($p['speak_word'])) $words[] = $p['speak_word'];
            if (($q['type'] ?? '') === 'word_order' && !empty($q['answer']['correct'])) $examples[] = rtrim($q['answer']['correct'], '.!?') . '.';
            if (($q['type'] ?? '') === 'listen_mcq' && !empty($p['speak']) && str_contains($p['speak'], ' ')) $examples[] = rtrim($p['speak'], '.!?') . '.';
            if (($q['skill'] ?? '') === 'grammar' && !empty($q['explanation_vi'])) $notes[] = $q['explanation_vi'];
        }
        $ids = [];
        foreach (array_unique($words) as $w) {
            $id = DB::table('lexicon_items')->where('word_key', Str::lower(trim($w)))->value('id');
            if ($id) $ids[] = $id;
        }
        return [
            'vocab_ids' => array_slice(array_values(array_unique($ids)), 0, 8),
            'examples' => array_map(fn ($e) => ['en' => $e], array_slice(array_values(array_unique($examples)), 0, 6)),
            'grammar_note_vi' => $notes ? implode("\n", array_slice(array_values(array_unique($notes)), 0, 3)) : null,
            'derived_from_questions' => true,
        ];
    }

    protected function importPassages(array $passages): void
    {
        foreach ($passages as $p) {
            if (DB::table('reading_passages')->where('grade_id', $p['grade'])->where('title', $p['title'])->exists()) { $this->inc('bai_doc_da_co'); continue; }
            DB::table('reading_passages')->insert(['grade_id' => $p['grade'], 'title' => $p['title'], 'body_en' => $p['body_en'], 'word_count' => str_word_count($p['body_en']),
                'status' => $this->status($p['status_hint'] ?? 'review', $p['flags'] ?? []), 'source' => $p['source'] ?? null, 'flags' => json_encode($p['flags'] ?? []), 'created_at' => now(), 'updated_at' => now()]);
            $this->inc('bai_doc_nhap_moi');
        }
    }

    protected function importGame(array $game): void
    {
        if (!empty($game['world'])) {
            $w = $game['world'];
            DB::table('worlds')->updateOrInsert(['code' => $w['code']], ['title' => $w['title'], 'description' => $w['description'] ?? null, 'is_active' => true, 'updated_at' => now(), 'created_at' => now()]);
            $wid = DB::table('worlds')->where('code', $w['code'])->value('id');
            foreach ($game['levels'] ?? [] as $lv) {
                if (DB::table('world_levels')->where('code', $lv['code'])->exists()) { $this->inc('man_choi_da_co'); continue; }
                DB::table('world_levels')->insert(['world_id' => $wid, 'code' => $lv['code'], 'chapter' => $lv['chapter'], 'title' => $lv['title'], 'description' => $lv['description'] ?? null,
                    'sort' => (int) $lv['sort_order'], 'difficulty' => (int) $lv['difficulty'], 'mode' => $lv['game_mode'], 'question_count' => max(5, (int) $lv['min_questions']),
                    'unlock_rule' => $lv['unlock_rule'], 'pass_score' => 60, 'is_active' => true, 'created_at' => now(), 'updated_at' => now()]);
                $this->inc('man_choi_nhap_moi');
            }
        }
    }

    protected function report(array $pkg): string
    {
        $lines = ['# Báo cáo nhập dữ liệu', '', 'Nguồn: ' . ($pkg['generated_from'] ?? 'không rõ'), ''];
        if (!empty($pkg['stats'])) {
            $lines[] = '## Thống kê trích xuất từ ZIP (trước khi nhập)';
            foreach ($pkg['stats'] as $k => $v) $lines[] = "- {$k}: {$v}";
            $lines[] = '';
        }
        $lines[] = '## Kết quả nhập vào CSDL';
        ksort($this->stats);
        foreach ($this->stats as $k => $v) $lines[] = "- {$k}: {$v}";
        foreach ($this->notes as $k => $arr) {
            $lines[] = '';
            $lines[] = "### Ví dụ: {$k}";
            foreach ($arr as $a) $lines[] = '- ' . $a;
        }
        return implode("\n", $lines);
    }
}
