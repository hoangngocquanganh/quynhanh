<?php

namespace App\Services;

use App\Models\Question;

/**
 * Dựng phần hiển thị (đã xáo trộn) + khóa chấm cho từng câu, và chấm câu trả lời trên máy chủ.
 * Đáp án KHÔNG bao giờ nằm trong phần gửi cho trình duyệt trước khi trả lời.
 */
class Grader
{
    /** Xáo trộn Fisher–Yates bằng RNG mật mã. */
    public static function shuffle(array $items): array
    {
        $items = array_values($items);
        for ($i = count($items) - 1; $i > 0; $i--) {
            $j = random_int(0, $i);
            [$items[$i], $items[$j]] = [$items[$j], $items[$i]];
        }
        return $items;
    }

    public static function normalizeText(string $s): string
    {
        $s = \Normalizer::normalize($s, \Normalizer::FORM_C) ?: $s;
        $s = mb_strtolower(trim($s));
        $s = str_replace(["\u{2019}", "\u{2018}", '`'], "'", $s);
        $s = preg_replace("/[.,!?;:\"“”()]/u", ' ', $s);
        $map = [
            "/\\bdon't\\b/" => 'do not', "/\\bdoesn't\\b/" => 'does not', "/\\bdidn't\\b/" => 'did not',
            "/\\bisn't\\b/" => 'is not', "/\\baren't\\b/" => 'are not', "/\\bwasn't\\b/" => 'was not', "/\\bweren't\\b/" => 'were not',
            "/\\bcan't\\b/" => 'can not', "/\\bcannot\\b/" => 'can not', "/\\bwon't\\b/" => 'will not', "/\\bhaven't\\b/" => 'have not',
            "/\\bhasn't\\b/" => 'has not', "/\\bi'm\\b/" => 'i am', "/\\byou're\\b/" => 'you are', "/\\bwe're\\b/" => 'we are',
            "/\\bthey're\\b/" => 'they are', "/\\bit's\\b/" => 'it is', "/\\bhe's\\b/" => 'he is', "/\\bshe's\\b/" => 'she is',
            "/\\bthat's\\b/" => 'that is', "/\\bi'll\\b/" => 'i will', "/\\bi've\\b/" => 'i have', "/\\bwhat's\\b/" => 'what is',
        ];
        foreach ($map as $re => $rep) $s = preg_replace($re . 'u', $rep, $s);
        return trim(preg_replace('/\s+/u', ' ', $s));
    }

    /** Tạo snapshot cho một lượt (display đã xáo + key chấm). */
    public static function build(Question $q, ?int $maxOptions = null): array
    {
        $snap = $q->snapshot();
        $answer = $q->answer ?? [];
        $display = [];
        $key = [];
        switch ($q->type) {
            case 'mcq':
            case 'listen_mcq':
                $all = $q->options ?? [];
                if ($maxOptions && count($all) > $maxOptions) {
                    $wrong = array_values(array_filter($all, fn ($o) => $o !== $answer['correct']));
                    $all = array_merge([$answer['correct']], array_slice(self::shuffle($wrong), 0, $maxOptions - 1));
                }
                $opts = self::shuffle($all);
                $display['options'] = $opts;
                $key['correct_index'] = array_search($answer['correct'], $opts, true);
                $key['correct_text'] = $answer['correct'];
                break;
            case 'word_order':
                $tokens = $q->options ?: preg_split('/\s+/u', trim((string) $answer['correct']));
                // xáo đến khi khác thứ tự đúng (nếu có thể)
                $shuffled = $tokens;
                for ($try = 0; $try < 6; $try++) {
                    $shuffled = self::shuffle($tokens);
                    if (self::normalizeText(implode(' ', $shuffled)) !== self::normalizeText($answer['correct'])) break;
                }
                $display['tokens'] = $shuffled;
                $key['accepted'] = array_values(array_unique(array_merge([$answer['correct']], $answer['accepted'] ?? [])));
                $key['correct_text'] = $answer['correct'];
                break;
            case 'matching':
                $pairs = $answer['pairs'] ?? [];
                $left = array_map(fn ($p) => $p[0], $pairs);
                $right = self::shuffle(array_map(fn ($p) => $p[1], $pairs));
                $display['left'] = $left;
                $display['right'] = $right;
                $map = [];
                foreach ($pairs as $i => $p) $map[$i] = array_search($p[1], $right, true);
                $key['map'] = $map;
                $key['correct_text'] = implode('; ', array_map(fn ($p) => $p[0] . ' = ' . $p[1], $pairs));
                break;
            case 'fill_blank':
                $key['accepted'] = array_values(array_unique(array_merge([$answer['correct']], $answer['accepted'] ?? [])));
                $key['correct_text'] = $answer['correct'];
                break;
            default: // writing, speaking
                $key['correct_text'] = $answer['sample'] ?? null;
        }
        $snap['display'] = $display;
        $snap['key'] = $key;
        unset($snap['answer'], $snap['options']);
        return $snap;
    }

    /**
     * Câu ôn từ vựng sinh từ Kho từ đã duyệt (không lưu thành câu hỏi): chọn nghĩa đúng / chọn từ đúng.
     * @param \App\Models\LexiconItem $w
     * @param \Illuminate\Support\Collection $pool các từ khác cùng lớp để làm phương án nhiễu
     */
    public static function buildWord($w, $pool, bool $reverse = false): array
    {
        $others = $pool->where('id', '<>', $w->id)->shuffle()->take(3);
        if ($reverse) {
            $opts = self::shuffle(array_merge([$w->word], $others->pluck('word')->all()));
            $prompt = ['text' => 'Đâu là “' . $w->meaning_vi . '”?', 'emoji' => $w->emoji, 'example_after' => $w->example_en];
            $correct = $w->word;
        } else {
            $opts = self::shuffle(array_merge([$w->meaning_vi], $others->pluck('meaning_vi')->all()));
            $prompt = ['text' => 'Từ “' . $w->word . '” có nghĩa là gì?', 'speak_word' => $w->word, 'ipa' => $w->ipa_uk, 'example_after' => $w->example_en];
            $correct = $w->meaning_vi;
        }
        return [
            'id' => null, 'word_id' => $w->id, 'version' => 1, 'skill' => 'vocabulary', 'type' => 'mcq', 'difficulty' => 1,
            'prompt' => array_filter($prompt), 'display' => ['options' => $opts],
            'key' => ['correct_index' => array_search($correct, $opts, true), 'correct_text' => $correct],
            'explanation_vi' => $w->word . ($w->ipa_uk ? ' ' . $w->ipa_uk : '') . ': ' . $w->meaning_vi . '.', 'tags' => [],
        ];
    }

    /**
     * Hình (emoji trong Kho từ) cho từng phương án — để hiện thẻ hình kiểu "Đâu là …?".
     * Chỉ trả về khi MỌI phương án đều có hình và các hình khác nhau; nếu không thì giữ dạng chữ.
     */
    public static function optionPics(array $opts): ?array
    {
        static $cache = [];
        if (count($opts) < 2 || count($opts) > 4) return null;
        $keys = array_map(fn ($o) => mb_strtolower(trim((string) $o)), $opts);
        $missing = array_values(array_diff($keys, array_keys($cache)));
        if ($missing) {
            foreach ($missing as $k) $cache[$k] = null;
            \App\Models\LexiconItem::where('status', 'published')->whereNotNull('emoji')->where('emoji', '<>', '')
                ->where(fn ($q) => $q->whereIn('word', $missing)->orWhereIn('meaning_vi', $missing))
                ->get(['word', 'meaning_vi', 'emoji'])
                ->each(function ($w) use (&$cache, $missing) {
                    foreach ([mb_strtolower($w->word), mb_strtolower($w->meaning_vi)] as $k) {
                        if (in_array($k, $missing, true) && $cache[$k] === null) $cache[$k] = $w->emoji;
                    }
                });
        }
        $pics = array_map(fn ($k) => $cache[$k], $keys);
        if (in_array(null, $pics, true) || count(array_unique($pics)) !== count($pics)) return null;
        return $pics;
    }

    /** Phần được phép gửi cho trình duyệt. */
    public static function publicView(array $snap, bool $revealed): array
    {
        $out = [
            'type' => $snap['type'], 'skill' => $snap['skill'],
            'prompt' => array_diff_key($snap['prompt'] ?? [], array_flip($revealed ? [] : ['example_after'])),
            'display' => $snap['display'] ?? [],
        ];
        // Không đưa hình gợi đáp án hoặc giọng đọc đáp án vào câu hỏi thông thường.
        unset($out['prompt']['emoji'], $out['display']['pics']);
        if (!in_array($snap['type'], ['listen_mcq', 'speaking'], true)) {
            unset($out['prompt']['speak'], $out['prompt']['speak_word'], $out['prompt']['audio_url']);
        }
        if ($revealed) {
            $out['correct_text'] = $snap['key']['correct_text'] ?? null;
            $out['correct_index'] = $snap['key']['correct_index'] ?? null;
            $out['explanation_vi'] = $snap['explanation_vi'] ?? null;
        }
        return $out;
    }

    /** Chấm. Trả về [is_correct|null, chuẩn hóa response, chosen_text]. */
    public static function grade(array $snap, array $response): array
    {
        $key = $snap['key'] ?? [];
        switch ($snap['type']) {
            case 'mcq':
            case 'listen_mcq':
                $choice = $response['choice'] ?? null;
                if (!is_int($choice) && !(is_string($choice) && ctype_digit($choice))) return [false, ['choice' => null], null];
                $choice = (int) $choice;
                $opts = $snap['display']['options'] ?? [];
                if ($choice < 0 || $choice >= count($opts)) return [false, ['choice' => null], null];
                return [$choice === (int) $key['correct_index'], ['choice' => $choice], $opts[$choice]];
            case 'word_order':
                $order = $response['order'] ?? [];
                $tokens = $snap['display']['tokens'] ?? [];
                if (!is_array($order)) return [false, ['order' => []], ''];
                $order = array_values(array_filter(array_map('intval', $order), fn ($i) => $i >= 0 && $i < count($tokens)));
                if (count($order) !== count(array_unique($order))) return [false, ['order' => $order], ''];
                $sentence = implode(' ', array_map(fn ($i) => $tokens[$i], $order));
                $ok = false;
                foreach ($key['accepted'] ?? [] as $acc) {
                    if (self::normalizeText($sentence) === self::normalizeText($acc)) { $ok = true; break; }
                }
                return [$ok, ['order' => $order], $sentence];
            case 'matching':
                $pairs = $response['pairs'] ?? [];
                if (!is_array($pairs)) return [false, ['pairs' => []], null];
                $clean = [];
                foreach ($pairs as $l => $r) $clean[(int) $l] = (int) $r;
                $ok = count($clean) === count($key['map'] ?? []);
                foreach ($key['map'] ?? [] as $l => $r) {
                    if (!isset($clean[$l]) || $clean[$l] !== (int) $r) { $ok = false; break; }
                }
                return [$ok, ['pairs' => $clean], null];
            case 'fill_blank':
                $text = mb_substr((string) ($response['text'] ?? ''), 0, 200);
                $ok = false;
                foreach ($key['accepted'] ?? [] as $acc) {
                    if (self::normalizeText($text) === self::normalizeText($acc)) { $ok = true; break; }
                }
                return [$ok, ['text' => $text], $text];
            case 'writing':
                return [null, ['text' => mb_substr((string) ($response['text'] ?? ''), 0, 5000)], null];
            case 'speaking':
                $self = in_array($response['self'] ?? null, ['tot', 'kha', 'can_luyen'], true) ? $response['self'] : null;
                return [null, ['self' => $self, 'heard' => mb_substr((string) ($response['heard'] ?? ''), 0, 300)], null];
        }
        return [false, [], null];
    }
}
