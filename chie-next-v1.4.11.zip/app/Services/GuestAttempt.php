<?php

namespace App\Services;

use App\Support\Permissions;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Crypt;

/** Lượt khách: đề được mã hóa, trả lời chỉ trong bộ nhớ trang; không ghi DB hoặc phiên. */
class GuestAttempt
{
    public static function create($questions, string $title, string $feature, ?int $maxOptions = null): array
    {
        abort_unless(Permissions::allows(null, $feature), 403);
        $items = collect($questions)->take(30)->map(fn ($q) => is_array($q) ? $q : Grader::build($q, $maxOptions))->values()->all();
        if (!$items) throw new DomainError('Phần này chưa có câu hỏi đã duyệt. Hãy chọn phần khác nhé!');
        $packet = ['expires' => time() + 7200, 'title' => $title, 'feature' => $feature, 'items' => $items];
        $token = Crypt::encryptString(json_encode($packet, JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR));
        return ['guest_token' => $token, 'attempt' => static::view($packet), 'redirect' => route('learn.demo') . '#' . $token];
    }

    protected static function packet(Request $r): array
    {
        $data = $r->validate(['guest_token' => 'required|string|max:300000']);
        try { $p = json_decode(Crypt::decryptString($data['guest_token']), true, 512, JSON_THROW_ON_ERROR); }
        catch (\Throwable $e) { throw new DomainError('Lượt học thử không hợp lệ. Hãy bắt đầu lại.'); }
        if (($p['expires'] ?? 0) < time() || empty($p['items'])) throw new DomainError('Lượt học thử đã hết hạn. Hãy bắt đầu lại.');
        abort_unless(Permissions::allows(null, $p['feature']), 403);
        return $p;
    }

    public static function view(array $p): array
    {
        $items = [];
        foreach ($p['items'] as $i => $snap) $items[] = Grader::publicView($snap, false) + ['position' => $i, 'phase' => 'independent', 'answered' => false, 'response' => null];
        return ['id' => 'guest', 'kind' => 'demo', 'title' => $p['title'], 'status' => 'in_progress', 'total' => count($items), 'answered' => 0,
            'correct' => 0, 'feedback' => 'immediate', 'items' => $items, 'seconds_left' => null, 'result' => null];
    }

    public static function show(Request $r): array { return static::view(static::packet($r)); }

    public static function answer(Request $r): array
    {
        $p = static::packet($r);
        $d = $r->validate(['position' => 'required|integer|min:0|max:29', 'response' => 'present|array', 'responses' => 'nullable|array|max:30', 'responses.*' => 'array']);
        $i = (int) $d['position'];
        abort_unless(isset($p['items'][$i]), 404);
        $snap = $p['items'][$i];
        [$ok, $clean] = Grader::grade($snap, $d['response']);
        $responses = $d['responses'] ?? []; $responses[$i] = $clean;
        $answered = 0; $correct = 0; $streak = 0;
        foreach ($p['items'] as $k => $s) {
            if (!array_key_exists($k, $responses)) continue;
            [$right] = Grader::grade($s, $responses[$k]);
            $answered++; $correct += $right ? 1 : 0; $streak = $right ? $streak + 1 : 0;
        }
        return ['position' => $i, 'answered' => true, 'is_correct' => $ok, 'correct_text' => $snap['key']['correct_text'] ?? null,
            'correct_index' => $snap['key']['correct_index'] ?? null, 'explanation_vi' => $snap['explanation_vi'] ?? null,
            'example_after' => $snap['prompt']['example_after'] ?? null, 'tips' => $ok ? [] : MistakeTips::forTags($snap['tags'] ?? []),
            'answered_count' => $answered, 'total' => count($p['items']), 'streak' => $streak,
            'demo_done' => $answered === count($p['items']), 'demo_correct' => $correct];
    }
}
