<?php

namespace App\Services;

/**
 * Lỗi nghiệp vụ có thông báo tiếng Việt an toàn để hiển thị cho người dùng (HTTP 422).
 */
class DomainError extends \RuntimeException
{
    public function render($request)
    {
        if ($request->expectsJson() || $request->is('api/*')) {
            return response()->json(['message' => $this->getMessage()], 422);
        }
        return back()->withInput()->with('error', $this->getMessage());
    }
}
