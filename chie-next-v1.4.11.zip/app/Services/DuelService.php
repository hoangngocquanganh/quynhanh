<?php

namespace App\Services;

use App\Models\Attempt;
use App\Models\AttemptItem;
use App\Models\DuelMatch;
use App\Models\User;
use App\Support\Settings;
use Illuminate\Support\Facades\DB;

/**
 * Đấu 1–1: hai người làm CÙNG một bộ câu (đã xáo sẵn), máy chủ chấm từng câu; ai đúng nhiều hơn thắng,
 * bằng điểm thì ai làm nhanh hơn thắng. Không có trò chuyện, chỉ hiện tên hiển thị.
 * Không cần WebSocket: trình duyệt hỏi trạng thái mỗi ~1,5 giây (chạy được trên hosting chia sẻ).
 * Không có ai cùng tìm trận → có thể đấu với "Quái Nhỏ" (máy, độ chính xác giới hạn), không có thưởng thắng.
 */
class DuelService
{
    public static function questionCount(): int { return (int) Settings::get('duel.question_count', 8); }
    public static function seconds(): int { return (int) Settings::get('duel.seconds', 150); }

    protected static function buildSnapshots(int $grade, int $forUser): array
    {
        $qs = QuestionPicker::pick($grade, static::questionCount(), $forUser, [], ['types' => ['mcq', 'listen_mcq']]);
        if ($qs->count() < 5) throw new DomainError('Lớp của bạn chưa có đủ câu hỏi đã duyệt để đấu (cần ít nhất 5 câu trắc nghiệm).');
        return $qs->map(fn ($q) => Grader::build($q, 4))->values()->all();
    }

    /** Bạn máy theo cấp học: tên, độ chính xác cơ bản [min, max], thời gian mỗi câu (ms) [min, max]. */
    public const BOTS = [
        'tieu_hoc' => ['name' => 'Mầm Nhí', 'emoji' => '🐣', 'acc' => [50, 72], 'ms' => [7000, 14000]],
        'thcs' => ['name' => 'Chồi Xanh', 'emoji' => '🦊', 'acc' => [58, 80], 'ms' => [5500, 11500]],
        'thpt' => ['name' => 'Cú Thông Thái', 'emoji' => '🦉', 'acc' => [62, 85], 'ms' => [4500, 9500]],
    ];

    /** Sau bao nhiêu giây chờ mà không có ai thì tự ghép bạn máy. */
    public static function autoBotSeconds(): int { return max(5, (int) Settings::get('duel.auto_bot_seconds', 15)); }

    public static function botFor(int $grade): array
    {
        return self::BOTS[$grade <= 5 ? 'tieu_hoc' : ($grade <= 9 ? 'thcs' : 'thpt')];
    }

    /**
     * Kế hoạch trả lời của bạn máy: hợp lứa tuổi (tốc độ, độ chính xác theo cấp học) và sát trình độ người chơi
     * (lấy tỉ lệ đúng gần đây của học sinh ±10%) để trận đấu cân bằng, không quá dễ cũng không quá khó.
     */
    protected static function botPlan(array $items, int $grade, ?int $userId = null): array
    {
        $bot = static::botFor($grade);
        [$lo, $hi] = $bot['acc'];
        if ($userId) {
            $s = DB::table('skill_stats')->where('user_id', $userId)->where('grade_level', $grade)->where('tag', '')->selectRaw('SUM(correct) c, SUM(total) t')->first();
            if ($s && $s->t >= 10) {
                $mine = (int) round($s->c / $s->t * 100);
                [$lo, $hi] = [max($lo - 10, $mine - 10), min($hi + 5, $mine + 8)];
                if ($lo > $hi) [$lo, $hi] = [$hi, $lo];
            }
        }
        $acc = random_int(max(30, $lo), min(95, max($lo, $hi)));
        [$msLo, $msHi] = $bot['ms'];
        // số câu đúng bám sát độ chính xác đã chọn (bộ câu ngắn, tung xúc xắc từng câu dễ ra 0% hoặc 100%)
        $n = count($items);
        $right = array_merge(array_fill(0, (int) round($n * $acc / 100), true), array_fill(0, $n - (int) round($n * $acc / 100), false));
        shuffle($right);
        $plan = []; $t = 0;
        foreach (array_values($items) as $i => $it) {
            $slow = ($it['type'] ?? '') === 'listen_mcq' ? 2500 : 0;   // câu nghe: máy cũng "nghe" xong mới chọn
            $t += random_int($msLo, $msHi) + $slow;
            $plan[] = [$t, $right[$i]];
        }
        return $plan;
    }

    public static function quick(User $u): DuelMatch
    {
        $g = (int) $u->grade_level;
        return DB::transaction(function () use ($u, $g) {
            static::expireOld();
            $mine = DuelMatch::where('player_a', $u->id)->whereIn('status', ['waiting', 'active'])->lockForUpdate()->first()
                ?? DuelMatch::where('player_b', $u->id)->where('status', 'active')->lockForUpdate()->first();
            if ($mine) return $mine;
            $open = DuelMatch::where('mode', 'quick')->where('status', 'waiting')->where('grade_level', $g)->whereNull('player_b')
                ->where('player_a', '<>', $u->id)->where('created_at', '>=', now()->subMinutes(2))->orderBy('id')->lockForUpdate()->first();
            if ($open) { static::activate($open, $u); return $open->fresh(); }
            return DuelMatch::create(['player_a' => $u->id, 'mode' => 'quick', 'grade_level' => $g, 'status' => 'waiting',
                'snapshots' => ['items' => static::buildSnapshots($g, $u->id)]]);
        });
    }

    public static function challenge(User $u, int $friendId): DuelMatch
    {
        $friend = TradeService::partners($u)->firstWhere('user.id', $friendId);
        if (!$friend) throw new DomainError('Chỉ thách đấu được bạn cùng lớp hoặc người trong gia đình.');
        $f = $friend['user'];
        if (DuelMatch::where('player_a', $u->id)->where('player_b', $f->id)->where('status', 'waiting')->exists()) throw new DomainError('Bạn đã gửi lời thách đấu cho bạn ấy rồi.');
        // dùng câu theo lớp của người được thách (thấp hơn thì công bằng hơn với người nhỏ tuổi)
        $g = min((int) $u->grade_level, (int) $f->grade_level);
        $m = DuelMatch::create(['player_a' => $u->id, 'player_b' => $f->id, 'mode' => 'challenge', 'grade_level' => $g, 'status' => 'waiting',
            'snapshots' => ['items' => static::buildSnapshots($g, $u->id)]]);
        Notifier::send($f->id, 'duel', $u->name . ' thách đấu bạn 1–1!', 'Vào Game đấu trường → Đấu 1–1 để nhận lời (trong 30 phút).', route('duel.show', $m));
        return $m;
    }

    public static function accept(User $u, DuelMatch $m): DuelMatch
    {
        return DB::transaction(function () use ($u, $m) {
            $m = DuelMatch::whereKey($m->id)->lockForUpdate()->first();
            if ($m->mode !== 'challenge' || $m->player_b !== $u->id) abort(404);
            if ($m->status !== 'waiting' || $m->created_at->lt(now()->subMinutes(30))) throw new DomainError('Lời thách đấu đã hết hạn hoặc đã được xử lý.');
            static::activate($m, $u);
            return $m->fresh();
        });
    }

    public static function vsBot(User $u, DuelMatch $m): DuelMatch
    {
        return DB::transaction(function () use ($u, $m) {
            $m = DuelMatch::whereKey($m->id)->lockForUpdate()->first();
            if ($m->player_a !== $u->id || $m->mode !== 'quick' || $m->status !== 'waiting') throw new DomainError('Trận này không thể chuyển sang đấu với máy.');
            $bot = static::botFor((int) $m->grade_level);
            $snap = $m->snapshots; $snap['bot'] = static::botPlan($snap['items'], (int) $m->grade_level, $u->id);
            $snap['bot_name'] = $bot['emoji'] . ' ' . $bot['name'] . ' (bạn máy)'; $m->snapshots = $snap; $m->save();
            static::activate($m, null);
            return $m->fresh();
        });
    }

    protected static function activate(DuelMatch $m, ?User $b): void
    {
        $a = User::findOrFail($m->player_a);
        $items = collect($m->snapshots['items']);
        $title = 'Đấu 1–1';
        $opts = ['title' => $title, 'feedback' => 'immediate', 'meta' => ['mode' => 'duel', 'duel_id' => $m->id]];
        $attA = AttemptService::create($a, 'duel', 'duel', $m->id, $m->grade_level, $items, $opts);
        $attB = $b ? AttemptService::create($b, 'duel', 'duel', $m->id, $m->grade_level, $items, $opts) : null;
        $m->player_b = $b?->id; $m->attempt_a = $attA->id; $m->attempt_b = $attB?->id;
        $snap = $m->snapshots;
        $snap['appearance_a'] = ProfileCosmetics::appearance($a);
        $snap['appearance_b'] = $b ? ProfileCosmetics::appearance($b) : ['symbol' => static::botFor((int) $m->grade_level)['emoji'], 'color' => 'blush', 'style' => 'coral', 'badge_icon' => null];
        $m->snapshots = $snap;
        $m->status = 'active'; $m->started_at = now(); $m->ends_at = now()->addSeconds(static::seconds());
        $m->save();
    }

    public static function cancel(User $u, DuelMatch $m): void
    {
        DB::transaction(function () use ($u, $m) {
            $m = DuelMatch::whereKey($m->id)->lockForUpdate()->first();
            if (!in_array($u->id, [$m->player_a, $m->player_b], true)) abort(404);
            if ($m->status !== 'waiting') throw new DomainError('Trận đã bắt đầu, không hủy được.');
            $m->update(['status' => 'cancelled', 'finished_at' => now()]);
        });
    }

    public static function expireOld(): void
    {
        DuelMatch::where('status', 'waiting')->where('mode', 'quick')->where('created_at', '<', now()->subMinutes(3))->update(['status' => 'expired']);
        DuelMatch::where('status', 'waiting')->where('mode', 'challenge')->where('created_at', '<', now()->subMinutes(30))->update(['status' => 'expired']);
    }

    protected static function progress(?int $attemptId): array
    {
        if (!$attemptId) return ['answered' => 0, 'correct' => 0, 'ms' => 0];
        $rows = AttemptItem::where('attempt_id', $attemptId)->whereNotNull('answered_at')->get(['is_correct', 'time_ms']);
        return ['answered' => $rows->count(), 'correct' => $rows->where('is_correct', true)->count(), 'ms' => (int) $rows->sum('time_ms')];
    }

    protected static function botProgress(DuelMatch $m): array
    {
        $plan = $m->snapshots['bot'] ?? [];
        $el = $m->started_at ? (int) (now()->diffInMilliseconds($m->started_at, true)) : 0;
        if ($m->status === 'finished') $el = PHP_INT_MAX;
        $done = array_values(array_filter($plan, fn ($p) => $p[0] <= $el));
        return ['answered' => count($done), 'correct' => count(array_filter($done, fn ($p) => $p[1])), 'ms' => $done ? end($done)[0] : 0];
    }

    /** Trạng thái cho người chơi u; tự kết thúc trận khi cả hai xong hoặc hết giờ. */
    public static function state(User $u, DuelMatch $m): array
    {
        if (!in_array($u->id, [$m->player_a, $m->player_b], true)) abort(404);
        if ($m->status === 'active') {
            $n = count($m->snapshots['items']);
            $pa = static::progress($m->attempt_a);
            $pb = $m->player_b ? static::progress($m->attempt_b) : static::botProgress($m);
            if (($pa['answered'] >= $n && $pb['answered'] >= $n) || $m->ends_at->isPast()) $m = static::finish($m);
        } elseif ($m->status === 'waiting') {
            static::expireOld(); $m->refresh();
            // không có ai cùng tìm trận sau vài giây → tự ghép bạn máy hợp lứa tuổi (người tạo trận mới kích hoạt được)
            if ($m->status === 'waiting' && $m->mode === 'quick' && !$m->player_b && $m->player_a === $u->id
                && $m->created_at->lte(now()->subSeconds(static::autoBotSeconds()))) {
                try { $m = static::vsBot($u, $m); } catch (DomainError $e) { $m->refresh(); }
            }
        }
        $isA = $m->player_a === $u->id;
        $pa = static::progress($m->attempt_a);
        $pb = $m->player_b ? static::progress($m->attempt_b) : ($m->status === 'waiting' ? ['answered' => 0, 'correct' => 0, 'ms' => 0] : static::botProgress($m));
        $me = $isA ? $pa : $pb; $op = $isA ? $pb : $pa;
        $opName = $isA ? ($m->player_b ? User::find($m->player_b)->name : ($m->status === 'waiting' ? null : ($m->snapshots['bot_name'] ?? 'Quái Nhỏ (bạn máy)'))) : User::find($m->player_a)->name;
        return [
            'id' => $m->id, 'status' => $m->status, 'mode' => $m->mode, 'total' => count($m->snapshots['items']),
            'me' => $me, 'opponent' => ['name' => $opName, 'answered' => $op['answered'], 'correct' => $op['correct'], 'bot' => !$m->player_b && $m->status !== 'waiting', 'appearance' => $m->snapshots[$isA ? 'appearance_b' : 'appearance_a'] ?? null],
            'my_attempt' => $isA ? $m->attempt_a : $m->attempt_b, 'can_accept' => $m->status === 'waiting' && $m->mode === 'challenge' && $m->player_b === $u->id,
            'auto_bot_in' => $m->status === 'waiting' && $m->mode === 'quick' ? max(0, static::autoBotSeconds() - (int) $m->created_at->diffInSeconds(now(), true)) : null,
            'bot_preview' => static::botFor((int) $m->grade_level)['emoji'] . ' ' . static::botFor((int) $m->grade_level)['name'],
            'seconds_left' => $m->ends_at ? max(0, now()->diffInSeconds($m->ends_at, false)) : null,
            'winner' => static::outcome($m, $u->id),
            'answer_url' => ($isA ? $m->attempt_a : $m->attempt_b) ? route('api.attempt.answer', $isA ? $m->attempt_a : $m->attempt_b) : null,
        ];
    }

    public static function outcome(DuelMatch $m, int $userId): ?string
    {
        if ($m->status !== 'finished') return null;
        if ($m->winner_id !== null) return $m->winner_id === $userId ? 'me' : 'opponent';
        if ($m->player_b) return 'draw';
        // winner_id null cũng có thể là bạn máy thắng, không chỉ hòa.
        if ($m->score_a !== $m->score_b) return $m->score_a > $m->score_b ? 'me' : 'opponent';
        if ($m->score_a > 0) {
            $a = static::progress($m->attempt_a); $b = static::botProgress($m);
            if ($a['ms'] !== $b['ms']) return $a['ms'] < $b['ms'] ? 'me' : 'opponent';
        }
        return 'draw';
    }

    public static function finish(DuelMatch $m): DuelMatch
    {
        return DB::transaction(function () use ($m) {
            $m = DuelMatch::whereKey($m->id)->lockForUpdate()->first();
            if ($m->status !== 'active') return $m;
            foreach ([$m->attempt_a, $m->attempt_b] as $aid) if ($aid && ($a = Attempt::find($aid))) AttemptService::submit($a, true);
            $pa = static::progress($m->attempt_a);
            $pb = $m->player_b ? static::progress($m->attempt_b) : static::botProgress($m);
            $m->score_a = $pa['correct']; $m->score_b = $pb['correct'];
            $bWho = $m->player_b; // null = máy
            if ($pa['correct'] !== $pb['correct']) $win = $pa['correct'] > $pb['correct'] ? $m->player_a : $bWho;
            elseif ($pa['correct'] > 0 && $pa['ms'] !== $pb['ms']) $win = $pa['ms'] < $pb['ms'] ? $m->player_a : $bWho;
            else $win = null;
            $m->winner_id = $win; $m->status = 'finished'; $m->finished_at = now(); $m->save();
            // thưởng thắng nhỏ chỉ khi đấu với người thật (chống "cày" với máy), qua trần ngày
            if ($win && $m->player_b) {
                [$xp, $xu] = Economy::applyDailyCap($win, 10, (int) Settings::get('duel.win_xu', 10));
                if ($xp || $xu) { Economy::grant($win, $xp, $xu, 'duel_win', 'duel:' . $m->id . ':win', 'duel:' . $m->id); Economy::bump($win, 'xp_earned', $xp); Economy::bump($win, 'xu_earned', $xu); }
            }
            return $m;
        });
    }
}
