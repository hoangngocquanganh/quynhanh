<?php

namespace App\Services;

use App\Models\Attempt;
use App\Models\FarmRaid;
use App\Models\User;
use App\Support\Settings;
use Illuminate\Support\Facades\DB;

/**
 * Cướp trại = thi tiếng Anh vượt Tường Thành. Phí đi cướp bị ĐỐT ngay (không vào ví ai).
 * Thắng: lấy tối đa 8% từng loại ở Kho Ngoài; chủ trại mất tối đa 20%/ngày; 80% về Kho Ngoài người thắng, 20% hỏng.
 * Không lấy Xu, đồ Gacha, đồ trang trí, cây đang trồng, Kho Trong/Kho Lạnh. Không cướp người cùng gia đình, trại có khiên.
 * Giới hạn cặp: 1 lần/ngày, 3 lần/tuần. Câu hỏi theo lớp của NGƯỜI ĐI CƯỚP (công bằng).
 */
class RaidService
{
    public static function familyIds(int $userId): array
    {
        $parents = DB::table('guardian_links')->where('student_id', $userId)->where('status', 'active')->pluck('parent_id');
        $siblings = DB::table('guardian_links')->whereIn('parent_id', $parents)->where('status', 'active')->pluck('student_id');
        return $parents->merge($siblings)->push($userId)->unique()->values()->all();
    }

    public static function candidates(User $u, int $limit = 6)
    {
        $minLevel = (int) Settings::get('raid.min_level', 3);
        $exclude = static::familyIds($u->id);
        $perDay = (int) Settings::get('raid.pair_per_day', 1);
        $perWeek = (int) Settings::get('raid.pair_per_week', 3);
        $todayHit = DB::table('farm_raids')->where('attacker_id', $u->id)->where('created_at', '>=', today())->groupBy('defender_id')->havingRaw('COUNT(*) >= ?', [$perDay])->pluck('defender_id');
        $weekHit = DB::table('farm_raids')->where('attacker_id', $u->id)->where('created_at', '>=', now()->subDays(7))->groupBy('defender_id')->havingRaw('COUNT(*) >= ?', [$perWeek])->pluck('defender_id');
        return DB::table('users')->join('wallets', 'wallets.user_id', '=', 'users.id')->join('farms', 'farms.user_id', '=', 'users.id')
            ->where('users.role', 'student')->where('users.status', 'active')->whereNotIn('users.id', array_merge($exclude, $todayHit->all(), $weekHit->all()))
            ->where('wallets.level', '>=', $minLevel)
            ->where(fn ($q) => $q->whereNull('farms.shield_until')->orWhere('farms.shield_until', '<', now()))
            ->whereExists(fn ($e) => $e->from('farm_storage')->whereColumn('farm_storage.user_id', 'users.id')->where('location', 'outer')->where('qty', '>', 0))
            ->inRandomOrder()->limit($limit)->get(['users.id', 'users.name', 'users.grade_level', 'farms.wall_level', 'farms.name as farm_name', 'wallets.level']);
    }

    public static function start(User $u, int $defenderId): FarmRaid
    {
        if (!Settings::get('raid.enabled', true)) throw new DomainError('Tính năng cướp trại đang tạm tắt.');
        $w = Economy::walletFor($u->id);
        if ($w->level < (int) Settings::get('raid.min_level', 3)) throw new DomainError('Cần đạt cấp ' . Settings::get('raid.min_level', 3) . ' để tham gia cướp trại.');
        if (FarmRaid::where('attacker_id', $u->id)->where('status', 'in_progress')->where('expires_at', '>', now())->exists()) throw new DomainError('Bạn đang có một trận chưa xong.');
        $ok = static::candidates($u, 500)->pluck('id')->contains($defenderId);
        if (!$ok) throw new DomainError('Không thể cướp trại này lúc này (có khiên, cùng gia đình, kho trống hoặc đã đủ lượt).');
        $def = FarmService::farm($defenderId);
        $stages = (int) (Settings::get('raid.stages_by_wall', [])[(string) $def->wall_level] ?? 3);
        $count = $stages * 2;
        $g = (int) ($u->grade_level ?: 3);
        $qs = QuestionPicker::pick($g, $count, $u->id);
        if ($qs->count() < $count) throw new DomainError('Lớp của bạn chưa đủ câu hỏi đã duyệt để mở trận cướp.');
        return DB::transaction(function () use ($u, $defenderId, $def, $stages, $qs, $g) {
            $fee = (int) Settings::get('raid.fee_xu', 30);
            $raid = FarmRaid::create(['attacker_id' => $u->id, 'defender_id' => $defenderId, 'wall_level' => $def->wall_level, 'fee_burned' => $fee, 'status' => 'in_progress',
                'expires_at' => now()->addSeconds($stages * (int) Settings::get('raid.seconds_per_stage', 60) + 30)]);
            Economy::spend($u->id, $fee, 'raid_fee', 'raid:' . $raid->id . ':fee', 'raid:' . $raid->id);
            $a = AttemptService::create($u, 'raid', 'raid', $raid->id, $g, $qs, ['title' => 'Vượt tường thành cấp ' . $def->wall_level, 'feedback' => 'immediate',
                'duration_min' => (int) ceil($stages * (int) Settings::get('raid.seconds_per_stage', 60) / 60), 'meta' => ['mode' => 'raid', 'raid_id' => $raid->id]]);
            $raid->attempt_id = $a->id;
            $raid->save();
            return $raid;
        });
    }

    public static function finish(User $u, FarmRaid $raid): FarmRaid
    {
        if ($raid->attacker_id !== $u->id) abort(404);
        $a = Attempt::find($raid->attempt_id);
        if ($a && $a->status === 'in_progress') AttemptService::submit($a, $raid->expires_at->isPast());
        return DB::transaction(function () use ($raid) {
            $raid = FarmRaid::whereKey($raid->id)->lockForUpdate()->first();
            if ($raid->status !== 'in_progress') return $raid;
            $a = Attempt::find($raid->attempt_id);
            $won = $a && (int) $a->score_100 >= 70;
            if (!$won) {
                $raid->update(['status' => 'lost', 'finished_at' => now()]);
                Notifier::send($raid->defender_id, 'raid', 'Nông trại của bạn đã phòng thủ thành công!', 'Một bạn đã thử vượt tường thành nhưng chưa trả lời đủ câu đúng.', route('farm.show'));
                return $raid;
            }
            $defId = $raid->defender_id;
            FarmService::lockFarm($defId);
            $outer = DB::table('farm_storage')->where('user_id', $defId)->where('location', 'outer')->where('qty', '>', 0)->lockForUpdate()->pluck('qty', 'item_code')->map(fn ($v) => (int) $v)->all();
            $day = today()->toDateString();
            $loss = DB::table('farm_daily_losses')->where('user_id', $defId)->where('day', $day)->lockForUpdate()->first();
            if (!$loss) {
                DB::table('farm_daily_losses')->insert(['user_id' => $defId, 'day' => $day, 'baseline_units' => array_sum($outer), 'lost_units' => 0]);
                $loss = (object) ['baseline_units' => array_sum($outer), 'lost_units' => 0];
            }
            $capLeft = max(0, (int) floor($loss->baseline_units * (int) Settings::get('raid.daily_loss_cap_percent', 20) / 100) - $loss->lost_units);
            $pct = (int) Settings::get('raid.take_percent', 8);
            $taken = [];
            foreach ($outer as $code => $qty) {
                if ($capLeft <= 0) break;
                $t = (int) floor($qty * $pct / 100);
                if ($t === 0 && $qty >= 3) $t = 1;
                $t = min($t, $capLeft);
                if ($t > 0) { $taken[$code] = $t; $capLeft -= $t; }
            }
            $recv = []; $dest = [];
            $destroyPct = (int) Settings::get('raid.destroy_percent', 20);
            foreach ($taken as $code => $t) {
                FarmService::addStorage($defId, 'outer', $code, -$t);
                $r80 = (int) floor($t * (100 - $destroyPct) / 100);
                if ($r80 > 0) FarmService::addStorage($raid->attacker_id, 'outer', $code, $r80);
                $recv[$code] = $r80;
                $dest[$code] = $t - $r80;
            }
            DB::table('farm_daily_losses')->where('user_id', $defId)->where('day', $day)->increment('lost_units', array_sum($taken));
            $raid->update(['status' => 'won', 'loot_taken' => $taken, 'loot_received' => $recv, 'loot_destroyed' => $dest, 'finished_at' => now()]);
            $desc = $taken ? collect($taken)->map(fn ($n, $c) => $n . ' ' . FarmService::itemInfo($c)['vi'])->implode(', ') : 'không có gì (đã chạm giới hạn mất trong ngày)';
            Notifier::send($defId, 'raid', 'Kho Ngoài của bạn vừa bị vượt tường', 'Bị lấy: ' . $desc . '. Mẹo: chuyển nông sản vào Kho Trong, mua Khiên hoặc nâng Tường.', route('farm.show'));
            return $raid;
        });
    }
}
