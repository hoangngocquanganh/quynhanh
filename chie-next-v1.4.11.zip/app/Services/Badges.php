<?php

namespace App\Services;

use App\Models\User;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

/** Huy hiệu đã đạt được giữ vĩnh viễn; không phát Xu/XP khi chỉ mở Hồ sơ. */
class Badges
{
    /** code => [hình, tên, điều kiện, nhóm, chỉ số, mốc] */
    public const CATALOG = [
        'first-lesson' => ['🎒', 'Bước đầu tiên', 'Hoàn thành 1 bài học', 'Bài học', 'lessons', 1],
        'lessons-10' => ['📗', 'Chăm học', 'Hoàn thành 10 bài học', 'Bài học', 'lessons', 10],
        'lessons-30' => ['📘', 'Vượt chặng', 'Hoàn thành 30 bài học', 'Bài học', 'lessons', 30],
        'lessons-100' => ['🏫', 'Hành trang vững', 'Hoàn thành 100 bài học', 'Bài học', 'lessons', 100],
        'questions-25' => ['✏️', 'Khởi động', 'Trả lời 25 câu', 'Luyện tập', 'questions', 25],
        'questions-100' => ['💯', 'Trăm câu', 'Trả lời 100 câu', 'Luyện tập', 'questions', 100],
        'questions-500' => ['🎖️', 'Bền bỉ', 'Trả lời 500 câu', 'Luyện tập', 'questions', 500],
        'questions-1000' => ['🏆', 'Nghìn câu', 'Trả lời 1.000 câu', 'Luyện tập', 'questions', 1000],
        'questions-5000' => ['💎', 'Năm nghìn thử thách', 'Trả lời 5.000 câu', 'Luyện tập', 'questions', 5000],
        'accuracy-80' => ['🎯', 'Thiện xạ', 'Đúng từ 80% sau ít nhất 50 câu', 'Luyện tập', 'accuracy80', 1],
        'accuracy-90' => ['🦅', 'Mắt đại bàng', 'Đúng từ 90% sau ít nhất 100 câu', 'Luyện tập', 'accuracy90', 1],
        'perfect-1' => ['🌟', 'Trọn vẹn', 'Đạt 100 điểm trong 1 lượt ít nhất 5 câu', 'Luyện tập', 'perfect', 1],
        'perfect-10' => ['🌠', 'Mười lần hoàn hảo', 'Đạt 100 điểm trong 10 lượt ít nhất 5 câu', 'Luyện tập', 'perfect', 10],
        'combo-5' => ['⚡', 'Bắt nhịp', 'Đúng liên tiếp 5 câu trong một lượt', 'Luyện tập', 'combo', 5],
        'combo-10' => ['🚀', 'Bứt phá', 'Đúng liên tiếp 10 câu trong một lượt', 'Luyện tập', 'combo', 10],
        'streak-3' => ['🕯️', 'Ba ngày đều đặn', 'Giữ chuỗi học 3 ngày', 'Kiên trì', 'streak', 3],
        'streak-7' => ['🔥', 'Chăm chỉ 7 ngày', 'Giữ chuỗi học 7 ngày', 'Kiên trì', 'streak', 7],
        'streak-14' => ['🌻', 'Hai tuần nỗ lực', 'Giữ chuỗi học 14 ngày', 'Kiên trì', 'streak', 14],
        'streak-30' => ['☀️', 'Một tháng rực rỡ', 'Giữ chuỗi học 30 ngày', 'Kiên trì', 'streak', 30],
        'streak-100' => ['👑', 'Trăm ngày kiên trì', 'Giữ chuỗi học 100 ngày', 'Kiên trì', 'streak', 100],
        'words-10' => ['🌱', 'Mười từ đầu tiên', 'Học 10 từ vựng', 'Từ vựng', 'words', 10],
        'words-50' => ['📚', 'Kho từ 50', 'Học 50 từ vựng', 'Từ vựng', 'words', 50],
        'words-100' => ['🗂️', 'Kho từ 100', 'Học 100 từ vựng', 'Từ vựng', 'words', 100],
        'words-300' => ['🧠', 'Kho từ phong phú', 'Học 300 từ vựng', 'Từ vựng', 'words', 300],
        'mastered-50' => ['🦉', 'Nhớ thật lâu', 'Có 50 từ vựng thuộc lòng', 'Từ vựng', 'words_mastered', 50],
        'grammar-1' => ['🧩', 'Mảnh ghép đầu', 'Thành thạo 1 chủ điểm ngữ pháp', 'Ngữ pháp', 'grammar_done', 1],
        'grammar-5' => ['🔑', 'Nhà ngữ pháp', 'Thành thạo 5 chủ điểm ngữ pháp', 'Ngữ pháp', 'grammar_done', 5],
        'grammar-15' => ['🏛️', 'Kiến trúc sư câu', 'Thành thạo 15 chủ điểm ngữ pháp', 'Ngữ pháp', 'grammar_done', 15],
        'grammar-30' => ['🎓', 'Bậc thầy cấu trúc', 'Thành thạo 30 chủ điểm ngữ pháp', 'Ngữ pháp', 'grammar_done', 30],
        'reviews-5' => ['🔁', 'Ôn đúng nhịp', 'Hoàn thành 5 lượt ôn theo lịch', 'Khám phá', 'reviews', 5],
        'reviews-30' => ['📆', 'Bạn của trí nhớ', 'Hoàn thành 30 lượt ôn theo lịch', 'Khám phá', 'reviews', 30],
        'games-5' => ['🎮', 'Học mà chơi', 'Hoàn thành 5 lượt game học', 'Khám phá', 'games', 5],
        'games-25' => ['🕹️', 'Nhà thám hiểm', 'Hoàn thành 25 lượt game học', 'Khám phá', 'games', 25],
        'exams-5' => ['📝', 'Sẵn sàng thử sức', 'Hoàn thành 5 đề luyện', 'Khám phá', 'exams', 5],
        'level-5' => ['⭐', 'Cấp 5', 'Đạt cấp 5', 'Cấp độ', 'level', 5],
        'level-10' => ['🌈', 'Cấp 10', 'Đạt cấp 10', 'Cấp độ', 'level', 10],
        'level-20' => ['🦁', 'Cấp 20', 'Đạt cấp 20', 'Cấp độ', 'level', 20],
        'level-30' => ['🐉', 'Cấp 30', 'Đạt cấp 30', 'Cấp độ', 'level', 30],
        'xp-1000' => ['🔋', 'Nghìn năng lượng', 'Tích lũy 1.000 XP', 'Cấp độ', 'xp', 1000],
        'xp-10000' => ['🏅', 'Vạn năng lượng', 'Tích lũy 10.000 XP', 'Cấp độ', 'xp', 10000],
    ];

    public static function earned(User $u): array
    {
        return Schema::hasTable('user_badges') ? DB::table('user_badges')->where('user_id', $u->id)->pluck('earned_at', 'code')->all() : [];
    }

    public static function sync(User $u, array $metrics): array
    {
        $earned = static::earned($u);
        $store = Schema::hasTable('user_badges'); $rows = []; $now = now(); $out = [];
        foreach (self::CATALOG as $code => [$icon, $name, $how, $group, $metric, $goal]) {
            $value = max(0, (int) ($metrics[$metric] ?? 0));
            if ($value >= $goal && !isset($earned[$code])) {
                $earned[$code] = $now->toDateTimeString();
                $rows[] = ['user_id' => $u->id, 'code' => $code, 'earned_at' => $now];
            }
            $out[] = ['code' => $code, 'icon' => $icon, 'name' => $name, 'description' => $how, 'group' => $group,
                'earned' => isset($earned[$code]), 'earned_at' => $earned[$code] ?? null, 'value' => min($value, $goal), 'goal' => $goal,
                'percent' => isset($earned[$code]) ? 100 : min(100, (int) floor($value / $goal * 100))];
        }
        if ($store && $rows) DB::table('user_badges')->insertOrIgnore($rows);
        return $out;
    }
}
