<?php

namespace App\Services;

use App\Models\Wallet;
use App\Models\XuLedger;
use App\Support\Settings;
use Illuminate\Support\Facades\DB;

/**
 * Hệ ví DUY NHẤT: wallets (số dư) + xu_ledger (sổ cái, idempotency_key UNIQUE).
 * Mọi cộng/trừ đều trong transaction với khóa dòng ví (SELECT ... FOR UPDATE).
 */
class Economy
{
    public static function xpForLevel(int $level): int
    {
        return 50 * $level * ($level - 1);   // L2=100, L5=1.000, L10=4.500, L20=19.000
    }

    public static function levelForXp(int $xp): int
    {
        $l = 1;
        while ($l < 200 && $xp >= static::xpForLevel($l + 1)) $l++;
        return $l;
    }

    public static function walletFor(int $userId): Wallet
    {
        $w = Wallet::find($userId);
        if (!$w) {
            DB::table('wallets')->insertOrIgnore(['user_id' => $userId, 'created_at' => now(), 'updated_at' => now()]);
            $w = Wallet::find($userId);
        }
        return $w;
    }

    /** Khóa ví trong transaction hiện tại. */
    public static function lock(int $userId): Wallet
    {
        static::walletFor($userId);
        return Wallet::where('user_id', $userId)->lockForUpdate()->first();
    }

    public static function ledgerExists(string $key): ?XuLedger
    {
        return XuLedger::where('idempotency_key', $key)->first();
    }

    /**
     * Cộng XP/Xu. Gọi trong DB::transaction. Trả về dòng ledger (hoặc dòng cũ nếu trùng key).
     */
    public static function grant(int $userId, int $xp, int $xu, string $type, string $key, ?string $ref = null, array $meta = [], ?int $actorId = null): XuLedger
    {
        if ($existing = static::ledgerExists($key)) return $existing;
        $w = static::lock($userId);
        $w->xp += max(0, $xp);
        $w->xu += max(0, $xu);
        $w->level = static::levelForXp((int) $w->xp);
        $w->save();
        return XuLedger::create([
            'user_id' => $userId, 'delta_xu' => $xu, 'delta_xp' => $xp, 'balance_after' => $w->xu, 'type' => $type,
            'ref' => $ref, 'idempotency_key' => $key, 'meta' => $meta ?: null, 'actor_user_id' => $actorId, 'created_at' => now(),
        ]);
    }

    /**
     * Trừ Xu (đốt hoặc mua). Ném InsufficientXu nếu không đủ. Gọi trong DB::transaction.
     */
    public static function spend(int $userId, int $xu, string $type, string $key, ?string $ref = null, array $meta = []): XuLedger
    {
        if ($existing = static::ledgerExists($key)) return $existing;
        $w = static::lock($userId);
        if ($xu < 0) throw new \InvalidArgumentException('Số Xu không hợp lệ.');
        if ($w->xu < $xu) throw new InsufficientXu($xu, (int) $w->xu);
        $w->xu -= $xu;
        $w->save();
        return XuLedger::create([
            'user_id' => $userId, 'delta_xu' => -$xu, 'delta_xp' => 0, 'balance_after' => $w->xu, 'type' => $type,
            'ref' => $ref, 'idempotency_key' => $key, 'meta' => $meta ?: null, 'created_at' => now(),
        ]);
    }

    /** Điều chỉnh của Admin (bắt buộc lý do) — ghi ledger với actor. */
    public static function adminAdjust(int $userId, int $deltaXu, string $reason, int $actorId): XuLedger
    {
        return DB::transaction(function () use ($userId, $deltaXu, $reason, $actorId) {
            $w = static::lock($userId);
            if ($w->xu + $deltaXu < 0) throw new InsufficientXu(-$deltaXu, (int) $w->xu);
            $w->xu += $deltaXu;
            $w->save();
            return XuLedger::create([
                'user_id' => $userId, 'delta_xu' => $deltaXu, 'delta_xp' => 0, 'balance_after' => $w->xu, 'type' => 'admin_adjust',
                'ref' => null, 'idempotency_key' => 'admin:' . $actorId . ':' . bin2hex(random_bytes(8)), 'meta' => ['reason' => $reason],
                'actor_user_id' => $actorId, 'created_at' => now(),
            ]);
        });
    }

    /** Bộ đếm theo ngày (cap thưởng, giới hạn lượt quay...). */
    public static function counter(int $userId, string $key, ?string $day = null): int
    {
        return (int) DB::table('daily_counters')->where('user_id', $userId)->where('day', $day ?? today()->toDateString())
            ->where('key', $key)->value('value');
    }

    public static function bump(int $userId, string $key, int $by = 1): void
    {
        $day = today()->toDateString();
        DB::statement('INSERT INTO daily_counters (user_id, day, `key`, value) VALUES (?, ?, ?, ?) ON DUPLICATE KEY UPDATE value = value + VALUES(value)',
            [$userId, $day, $key, $by]);
    }

    /** Áp trần XP/Xu theo ngày cho thưởng học tập + game (mọi lớp như nhau). */
    public static function applyDailyCap(int $userId, int $xp, int $xu): array
    {
        $xpCap = (int) Settings::get('reward.daily_xp_cap', 1000);
        $xuCap = (int) Settings::get('reward.daily_xu_cap', 500);
        $xpLeft = max(0, $xpCap - static::counter($userId, 'xp_earned'));
        $xuLeft = max(0, $xuCap - static::counter($userId, 'xu_earned'));
        $xp2 = min($xp, $xpLeft);
        $xu2 = min($xu, $xuLeft);
        return [$xp2, $xu2, $xp2 < $xp || $xu2 < $xu];
    }

    /** Cập nhật chuỗi ngày học (không tước tài sản khi nghỉ; có 1 ngày "cứu chuỗi" miễn phí mỗi tuần). */
    public static function touchStreak(int $userId): void
    {
        $w = static::lock($userId);
        $today = today();
        if ($w->last_active_date && $w->last_active_date->isSameDay($today)) return;
        if ($w->last_active_date && $w->last_active_date->copy()->addDay()->isSameDay($today)) {
            $w->streak_days += 1;
        } elseif ($w->last_active_date && $w->last_active_date->copy()->addDays(2)->isSameDay($today)
            && static::counter($userId, 'streak_freeze_week:' . $today->format('oW'), $today->copy()->startOfWeek()->toDateString()) === 0) {
            DB::table('daily_counters')->insertOrIgnore(['user_id' => $userId, 'day' => $today->copy()->startOfWeek()->toDateString(), 'key' => 'streak_freeze_week:' . $today->format('oW'), 'value' => 1]);
            $w->streak_days += 1;
        } else {
            $w->streak_days = 1;
        }
        $w->last_active_date = $today;
        $w->save();
    }
}
