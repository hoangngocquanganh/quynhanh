<?php

namespace App\Services;

use App\Models\Sticker;
use App\Models\StickerPack;
use App\Models\User;
use App\Models\UserSticker;
use App\Support\Settings;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;

/**
 * v1.3.3 — Học theo sticker.
 * Mỗi gói (pack) là một chủ đề gần gũi (Tết, Trung thu, món ăn, chợ quê…), gắn với một khoảng lớp.
 * Học sinh "bóc" sticker bằng cách xem thẻ → nghe → trả lời đúng. Sticker lên hạng đồng → bạc → vàng
 * khi trả lời đúng vào các NGÀY khác nhau (ôn cách quãng). Trả lời sai → sticker vào danh sách "cần ôn".
 */
class StickerService
{
    public static function available(): bool
    {
        foreach (['sticker_packs', 'stickers', 'user_stickers'] as $table) {
            if (!\Illuminate\Support\Facades\Schema::hasTable($table)) return false;
        }
        return true;
    }

    public const LEVELS = [0 => 'Chưa có', 1 => 'Đồng', 2 => 'Bạc', 3 => 'Vàng'];

    /** Nhập gói sticker từ JSON. Chỉ thêm gói/sticker còn thiếu, không ghi đè bản Admin đã sửa. */
    public static function importFile(string $path): array
    {
        if (!is_file($path)) return [0, 0];
        $data = json_decode((string) file_get_contents($path), true);
        if (!is_array($data) || ($data['format'] ?? '') !== 'chie-stickers') throw new DomainError('Tệp không phải gói sticker của CHIE NEXT.');
        $packs = 0; $stickers = 0;
        DB::transaction(function () use ($data, &$packs, &$stickers) {
            foreach ($data['packs'] ?? [] as $p) {
                $pack = StickerPack::where('code', $p['code'])->first();
                if (!$pack) {
                    $pack = StickerPack::create([
                        'code' => $p['code'], 'title_vi' => $p['title_vi'], 'title_en' => $p['title_en'] ?? null, 'emoji' => $p['emoji'] ?? null,
                        'color' => $p['color'] ?? 'green', 'theme' => $p['theme'] ?? 'everyday', 'description' => $p['description'] ?? null,
                        'grade_from' => (int) ($p['grade_from'] ?? 1), 'grade_to' => (int) ($p['grade_to'] ?? 12), 'sort' => (int) ($p['sort'] ?? 0),
                        'status' => 'published', 'source' => mb_substr((string) ($data['source'] ?? 'import'), 0, 120),
                    ]);
                    $packs++;
                }
                foreach ($p['stickers'] ?? [] as $s) {
                    if (Sticker::where('code', $s['code'])->exists()) continue;
                    Sticker::create([
                        'pack_id' => $pack->id, 'code' => $s['code'], 'emoji' => $s['emoji'], 'word' => $s['word'], 'ipa' => $s['ipa'] ?? null,
                        'meaning_vi' => $s['meaning_vi'], 'example_en' => $s['example_en'] ?? null, 'example_vi' => $s['example_vi'] ?? null,
                        'note_vi' => $s['note_vi'] ?? null, 'sort' => (int) ($s['sort'] ?? 0), 'is_active' => true,
                    ]);
                    $stickers++;
                }
            }
        });
        return [$packs, $stickers];
    }

    /** Các gói đang mở, kèm thống kê của người dùng. Gói hợp lớp hiện tại xếp trước. */
    public static function packs(?User $u, ?int $grade): Collection
    {
        $packs = StickerPack::where('status', 'published')->orderBy('sort')->orderBy('id')->get();
        $totals = Sticker::where('is_active', true)->groupBy('pack_id')->select('pack_id', DB::raw('COUNT(*) AS n'))->pluck('n', 'pack_id');
        $mine = collect();
        if ($u) {
            $mine = DB::table('user_stickers')->join('stickers', 'stickers.id', '=', 'user_stickers.sticker_id')
                ->where('user_stickers.user_id', $u->id)->where('stickers.is_active', true)
                ->groupBy('stickers.pack_id')
                ->select('stickers.pack_id',
                    DB::raw('SUM(CASE WHEN user_stickers.level >= 1 THEN 1 ELSE 0 END) AS got'),
                    DB::raw('SUM(CASE WHEN user_stickers.level >= 3 THEN 1 ELSE 0 END) AS gold'),
                    DB::raw('SUM(CASE WHEN user_stickers.due_at IS NOT NULL AND user_stickers.due_at <= NOW() THEN 1 ELSE 0 END) AS due'))
                ->get()->keyBy(fn ($r) => (int) $r->pack_id);
        }
        return $packs->map(function (StickerPack $p) use ($totals, $mine, $grade) {
            $m = $mine->get($p->id);
            $p->setAttribute('total', (int) ($totals[$p->id] ?? 0));
            $p->setAttribute('got', (int) ($m->got ?? 0));
            $p->setAttribute('gold', (int) ($m->gold ?? 0));
            $p->setAttribute('due', (int) ($m->due ?? 0));
            $p->setAttribute('fits', $p->fitsGrade($grade));
            return $p;
        })->filter(fn ($p) => $p->total > 0)->sortBy(fn ($p) => [$p->fits ? 0 : 1, $p->sort])->values();
    }

    /** Sticker trong gói + trạng thái của người dùng (theo sticker_id). */
    public static function album(StickerPack $pack, ?User $u): array
    {
        $stickers = $pack->stickers()->where('is_active', true)->get();
        $mine = $u ? UserSticker::where('user_id', $u->id)->whereIn('sticker_id', $stickers->pluck('id'))->get()->keyBy('sticker_id') : collect();
        return [$stickers, $mine];
    }

    /** "Sticker của ngày" — giống nhau cho mọi người trong cùng một ngày và cùng lớp. */
    public static function ofTheDay(?int $grade): ?Sticker
    {
        $q = Sticker::query()->where('is_active', true)->whereHas('pack', function ($p) use ($grade) {
            $p->where('status', 'published');
            if ($grade) $p->where('grade_from', '<=', $grade)->where('grade_to', '>=', $grade);
        });
        $n = (clone $q)->count();
        if (!$n) return null;
        $idx = crc32(today()->toDateString() . ':' . ($grade ?? 0)) % $n;
        return $q->with('pack')->orderBy('id')->skip($idx)->first();
    }

    public static function totals(User $u): array
    {
        $row = DB::table('user_stickers')->where('user_id', $u->id)
            ->selectRaw('SUM(CASE WHEN level >= 1 THEN 1 ELSE 0 END) AS got, SUM(CASE WHEN level >= 3 THEN 1 ELSE 0 END) AS gold, SUM(CASE WHEN due_at IS NOT NULL AND due_at <= NOW() THEN 1 ELSE 0 END) AS due')
            ->first();
        return ['got' => (int) ($row->got ?? 0), 'gold' => (int) ($row->gold ?? 0), 'due' => (int) ($row->due ?? 0), 'all' => Sticker::where('is_active', true)->count()];
    }

    /**
     * Tạo một lượt học. mode: learn (bóc sticker mới) · review (ôn sticker cần ôn) · listen (nghe và chọn hình).
     * Trả về danh sách câu; mỗi câu có sticker (thẻ học) + kiểu hỏi + 4 phương án (id sticker).
     */
    public static function session(User $u, ?StickerPack $pack, string $mode, ?int $grade): array
    {
        $size = max(4, min(12, (int) Settings::get('sticker.session_size', 6)));
        $base = Sticker::query()->where('is_active', true)
            ->whereHas('pack', fn ($p) => $p->where('status', 'published'))
            ->when($pack, fn ($q) => $q->where('pack_id', $pack->id));
        $mine = UserSticker::where('user_id', $u->id)->get()->keyBy('sticker_id');

        if ($mode === 'review') {
            $ids = $mine->filter(fn ($m) => $m->due_at && $m->due_at->lte(now()))->keys();
            $pick = (clone $base)->whereIn('id', $ids)->inRandomOrder()->limit($size)->get();
            if ($pick->isEmpty()) {
                // không có sticker cần ôn → ôn các sticker chưa lên vàng
                $ids = $mine->filter(fn ($m) => $m->level >= 1 && $m->level < 3)->keys();
                $pick = (clone $base)->whereIn('id', $ids)->inRandomOrder()->limit($size)->get();
            }
            if ($pick->isEmpty()) throw new DomainError('Chưa có sticker nào cần ôn. Hãy bóc sticker mới nhé!');
        } else {
            $all = (clone $base)->orderBy('sort')->orderBy('id')->get();
            if ($all->isEmpty()) throw new DomainError('Gói sticker này chưa có nội dung.');
            $rank = fn (Sticker $s) => match (true) {
                !isset($mine[$s->id]) || (int) $mine[$s->id]->level === 0 => 0,                 // chưa có
                $mine[$s->id]->due_at && $mine[$s->id]->due_at->lte(now()) => 1,                  // cần ôn
                default => 2 + (int) $mine[$s->id]->level,                                         // đồng → bạc → vàng
            };
            $pick = $all->sortBy(fn ($s) => [$rank($s), $s->sort])->take($size)->shuffle()->values();
        }

        // phương án nhiễu: ưu tiên cùng gói, thiếu thì lấy gói hợp lớp
        $pool = $pack ? Sticker::where('pack_id', $pack->id)->where('is_active', true)->get() : collect();
        if ($pool->count() < 4) {
            $pool = $pool->merge(Sticker::where('is_active', true)->whereIn('pack_id', $pick->pluck('pack_id')->unique())->get())->unique('id');
        }
        if ($pool->count() < 4) {
            $pool = $pool->merge(Sticker::where('is_active', true)->whereHas('pack', function ($p) use ($grade) {
                $p->where('status', 'published');
                if ($grade) $p->where('grade_from', '<=', $grade)->where('grade_to', '>=', $grade);
            })->inRandomOrder()->limit(30)->get())->unique('id');
        }

        $items = [];
        foreach ($pick as $s) {
            $isPhrase = $s->ipa === null && str_word_count($s->word) > 3;          // thành ngữ: chỉ hỏi nghĩa
            $types = $isPhrase ? ['pick_vi', 'pick_en'] : ($mode === 'listen' ? ['listen'] : ['pick_word', 'pick_vi', 'listen', 'pick_en']);
            $type = $types[array_rand($types)];
            $label = fn ($o) => $type === 'listen' ? $o->emoji : ($type === 'pick_vi' ? mb_strtolower($o->meaning_vi) : mb_strtolower($o->word));
            $others = $pool->where('id', '<>', $s->id)->filter(fn ($o) => $label($o) !== $label($s))
                ->unique(fn ($o) => $type === 'listen' ? $o->emoji : ($type === 'pick_vi' ? $o->meaning_vi : mb_strtolower($o->word)))
                ->shuffle()->take(3);
            $opts = $others->push($s)->shuffle()->map(fn ($o) => ['id' => $o->id, 'label' => match ($type) {
                'listen' => $o->emoji, 'pick_vi' => $o->meaning_vi, default => $o->word,
            }])->values()->all();
            $m = $mine[$s->id] ?? null;
            $items[] = ['sticker' => $s->card(), 'type' => $type, 'options' => $opts, 'is_new' => !$m || (int) $m->level === 0, 'level' => $m ? (int) $m->level : 0];
        }
        return ['items' => $items, 'mode' => $mode];
    }

    /** Chấm một câu, cập nhật album, phát thưởng nhỏ (chỉ lần đầu bóc + hoàn thành gói). */
    public static function answer(User $u, int $stickerId, int $choiceId): array
    {
        $s = Sticker::with('pack')->where('is_active', true)
            ->whereHas('pack', fn ($q) => $q->where('status', 'published'))->findOrFail($stickerId);
        $correct = $choiceId === $s->id;
        $today = today();
        return DB::transaction(function () use ($u, $s, $correct, $today) {
            $m = UserSticker::where('user_id', $u->id)->where('sticker_id', $s->id)->lockForUpdate()->first()
                ?? new UserSticker(['user_id' => $u->id, 'sticker_id' => $s->id, 'level' => 0, 'correct' => 0, 'wrong' => 0]);
            $before = (int) $m->level;
            $new = false; $up = false;
            if ($correct) {
                $m->correct = (int) $m->correct + 1;
                if ($before === 0) { $m->level = 1; $m->collected_at = now(); $new = true; }
                elseif ($before < 3 && (!$m->last_correct_on || !$m->last_correct_on->isSameDay($today))) { $m->level = $before + 1; $up = true; }
                $m->last_correct_on = $today;
                $m->due_at = null;
            } else {
                $m->wrong = (int) $m->wrong + 1;
                $m->due_at = now();
            }
            $m->save();

            $xp = 0; $xu = 0; $packDone = false; $note = null;
            if (Rewards::eligible($u)) {
                if ($new) [$xp, $xu] = static::grant($u, (int) Settings::get('sticker.xp_new', 2), 0, 'sticker:' . $u->id . ':' . $s->id);
                if ($up && (int) $m->level === 3) {
                    [$x2, $u2] = static::grant($u, (int) Settings::get('sticker.xp_gold', 3), 0, 'sticker_gold:' . $u->id . ':' . $s->id);
                    $xp += $x2; $xu += $u2;
                }
                if ($new) {
                    $total = Sticker::where('pack_id', $s->pack_id)->where('is_active', true)->count();
                    $got = UserSticker::where('user_id', $u->id)->where('level', '>=', 1)
                        ->whereIn('sticker_id', Sticker::where('pack_id', $s->pack_id)->where('is_active', true)->select('id'))->count();
                    if ($total > 0 && $got >= $total) {
                        $packDone = true;
                        [$x3, $u3] = static::grant($u, (int) Settings::get('sticker.xp_pack', 20), (int) Settings::get('sticker.xu_pack', 10), 'sticker_pack:' . $u->id . ':' . $s->pack_id);
                        $xp += $x3; $xu += $u3;
                        $note = 'Bạn đã sưu tầm đủ gói "' . $s->pack->title_vi . '"!';
                    }
                }
                if ($correct) Economy::touchStreak($u->id);
            }
            return ['correct' => $correct, 'answer_id' => $s->id, 'level' => (int) $m->level, 'new' => $new, 'level_up' => $up,
                'pack_done' => $packDone, 'xp' => $xp, 'xu' => $xu, 'note' => $note, 'sticker' => $s->card()];
        });
    }

    protected static function grant(User $u, int $xp, int $xu, string $key): array
    {
        if (($xp <= 0 && $xu <= 0) || Economy::ledgerExists($key)) return [0, 0];
        [$xp, $xu] = Economy::applyDailyCap($u->id, $xp, $xu);
        if ($xp <= 0 && $xu <= 0) return [0, 0];
        Economy::grant($u->id, $xp, $xu, 'sticker_reward', $key, 'sticker');
        Economy::bump($u->id, 'xp_earned', $xp);
        if ($xu > 0) Economy::bump($u->id, 'xu_earned', $xu);
        return [$xp, $xu];
    }
}
