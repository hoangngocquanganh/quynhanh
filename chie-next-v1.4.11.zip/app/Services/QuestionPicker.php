<?php

namespace App\Services;

use App\Models\Question;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;

/**
 * Chọn câu hỏi ĐÃ XUẤT BẢN, ĐÚNG LỚP. Không bao giờ lấy câu lớp khác để bù chỗ thiếu.
 * Ưu tiên câu người học chưa gặp gần đây; không lặp câu trong một lượt.
 */
class QuestionPicker
{
    public static function autoTypes(): array
    {
        return Question::AUTO_GRADED;
    }

    public static function availableCount(int $grade, array $skills = [], bool $autoOnly = true): int
    {
        $q = Question::published()->where('grade_id', $grade);
        if ($skills) $q->whereIn('skill', $skills);
        if ($autoOnly) $q->whereIn('type', self::autoTypes());
        return $q->count();
    }

    /**
     * @param array $mix  ['vocabulary' => 40, 'grammar' => 30, ...] phần trăm (tùy chọn)
     */
    public static function pick(int $grade, int $count, ?int $userId = null, array $mix = [], array $opts = []): Collection
    {
        $types = $opts['types'] ?? self::autoTypes();
        $exclude = $opts['exclude'] ?? [];
        $recent = $userId ? self::recentIds($userId, $opts['recent_days'] ?? 7) : [];

        $base = fn () => Question::published()->where('grade_id', $grade)->whereIn('type', $types)
            ->when($exclude, fn ($q) => $q->whereNotIn('id', $exclude))
            ->when(!empty($opts['unit_id']), fn ($q) => $q->where('unit_id', $opts['unit_id']))
            ->when(!empty($opts['skills']), fn ($q) => $q->whereIn('skill', $opts['skills']))
            ->when(!empty($opts['tags']), function ($q) use ($opts) {
                $q->where(function ($w) use ($opts) {
                    foreach ($opts['tags'] as $tag) $w->orWhereJsonContains('tags', $tag);
                });
            });

        $picked = collect();
        if ($mix) {
            $sum = array_sum($mix) ?: 1;
            foreach ($mix as $skill => $pct) {
                $n = (int) round($count * $pct / $sum);
                if ($n <= 0) continue;
                $picked = $picked->merge(self::takeFresh($base()->where('skill', $skill), $n, $recent, $picked->pluck('id')->all()));
            }
        }
        if ($picked->count() < $count) {
            $picked = $picked->merge(self::takeFresh($base(), $count - $picked->count(), $recent, $picked->pluck('id')->all()));
        }
        return collect(Grader::shuffle($picked->unique('id')->take($count)->all()));
    }

    protected static function takeFresh($query, int $n, array $recent, array $already): Collection
    {
        $q1 = (clone $query)->when($already, fn ($q) => $q->whereNotIn('id', $already));
        $fresh = (clone $q1)->when($recent, fn ($q) => $q->whereNotIn('id', $recent))->inRandomOrder()->limit($n)->get();
        if ($fresh->count() >= $n) return $fresh;
        $more = (clone $q1)->whereNotIn('id', array_merge($fresh->pluck('id')->all(), [0]))->inRandomOrder()->limit($n - $fresh->count())->get();
        return $fresh->merge($more);
    }

    public static function recentIds(int $userId, int $days): array
    {
        return DB::table('attempt_items')->join('attempts', 'attempts.id', '=', 'attempt_items.attempt_id')
            ->where('attempts.user_id', $userId)->where('attempts.started_at', '>=', now()->subDays($days))
            ->whereNotNull('attempt_items.question_id')->distinct()->pluck('attempt_items.question_id')->all();
    }
}
