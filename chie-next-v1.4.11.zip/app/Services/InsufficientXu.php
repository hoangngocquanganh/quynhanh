<?php

namespace App\Services;

class InsufficientXu extends DomainError
{
    public function __construct(public int $need, public int $have)
    {
        parent::__construct("Bạn chưa đủ Xu (cần {$need}, đang có {$have}). Học thêm một bài để kiếm Xu nhé!");
    }
}
