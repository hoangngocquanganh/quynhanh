<?php

namespace App\Services;

/**
 * Bảng IPA 44 âm + cặp âm dễ nhầm + chuyên đề phát âm cho người Việt.
 * Nội dung do CHIE NEXT biên soạn; mô tả khẩu hình bằng tiếng Việt, KHÔNG dùng cách viết kiểu tiếng Việt làm chuẩn phát âm.
 * Ký hiệu IPA là hệ ký hiệu quốc tế dùng tự do.
 */
class Pronunciation
{
    public static function chart(): array
    {
        $v = fn ($s, $ex, $tip) => ['ipa' => $s, 'examples' => $ex, 'tip' => $tip];
        return [
            'Nguyên âm đơn' => [
                $v('iː', ['see', 'tree', 'green'], 'Môi kéo căng sang hai bên như đang cười, lưỡi nâng cao phía trước. Âm DÀI.'),
                $v('ɪ', ['sit', 'big', 'fish'], 'Giống /iː/ nhưng NGẮN và thả lỏng hơn, miệng mở nhẹ hơn một chút.'),
                $v('e', ['bed', 'red', 'pen'], 'Miệng mở vừa, lưỡi ở giữa phía trước, môi hơi dẹt.'),
                $v('æ', ['cat', 'apple', 'black'], 'Miệng mở rộng, hàm hạ xuống, lưỡi thấp và dẹt phía trước. Rộng hơn /e/.'),
                $v('ɑː', ['car', 'father', 'start'], 'Mở miệng to, lưỡi thấp và lùi về sau. Âm DÀI.'),
                $v('ɒ', ['hot', 'dog', 'stop'], 'Miệng mở tròn, lưỡi thấp phía sau, âm NGẮN (giọng Anh-Anh).'),
                $v('ɔː', ['saw', 'ball', 'door'], 'Môi tròn, hơi đưa ra trước, lưỡi lùi sau. Âm DÀI.'),
                $v('ʊ', ['book', 'good', 'put'], 'Môi tròn nhẹ, thả lỏng, âm NGẮN.'),
                $v('uː', ['food', 'blue', 'school'], 'Môi tròn, chụm mạnh về phía trước, lưỡi lùi sau. Âm DÀI.'),
                $v('ʌ', ['cup', 'sun', 'mother'], 'Miệng mở vừa, lưỡi ở giữa, âm ngắn và dứt khoát.'),
                $v('ɜː', ['bird', 'girl', 'learn'], 'Môi thả lỏng, lưỡi ở giữa khoang miệng, âm DÀI.'),
                $v('ə', ['about', 'teacher', 'banana'], 'Âm "lướt" rất nhẹ ở âm tiết không nhấn. Miệng thả lỏng hoàn toàn.'),
            ],
            'Nguyên âm đôi' => [
                $v('eɪ', ['day', 'name', 'rain'], 'Bắt đầu ở /e/ rồi trượt nhanh lên /ɪ/.'),
                $v('aɪ', ['my', 'nine', 'light'], 'Bắt đầu miệng mở rộng rồi trượt về /ɪ/.'),
                $v('ɔɪ', ['boy', 'toy', 'coin'], 'Bắt đầu môi tròn /ɔ/ rồi trượt sang /ɪ/.'),
                $v('aʊ', ['now', 'house', 'brown'], 'Bắt đầu miệng mở rộng rồi tròn môi dần sang /ʊ/.'),
                $v('əʊ', ['go', 'home', 'phone'], 'Bắt đầu thả lỏng /ə/ rồi tròn môi sang /ʊ/.'),
                $v('ɪə', ['near', 'here', 'idea'], 'Từ /ɪ/ trượt về /ə/ nhẹ.'),
                $v('eə', ['hair', 'where', 'chair'], 'Từ /e/ trượt về /ə/.'),
                $v('ʊə', ['tour', 'pure', 'cure'], 'Từ /ʊ/ trượt về /ə/ (nhiều người nói gần với /ɔː/).'),
            ],
            'Phụ âm' => [
                $v('p', ['pen', 'happy', 'cup'], 'Hai môi khép rồi bật hơi mạnh. Ở cuối từ vẫn phải khép môi rõ (cup).'),
                $v('b', ['book', 'rabbit', 'job'], 'Hai môi khép, dây thanh rung. Cặp hữu thanh của /p/.'),
                $v('t', ['ten', 'water', 'cat'], 'Đầu lưỡi chạm lợi trên rồi bật hơi. Đừng bỏ /t/ ở cuối từ (cat ≠ ca).'),
                $v('d', ['dog', 'ladder', 'bed'], 'Như /t/ nhưng dây thanh rung.'),
                $v('k', ['cat', 'school', 'book'], 'Cuống lưỡi chạm ngạc mềm rồi bật hơi.'),
                $v('ɡ', ['go', 'bigger', 'bag'], 'Như /k/ nhưng dây thanh rung.'),
                $v('f', ['fish', 'coffee', 'leaf'], 'Răng trên chạm nhẹ môi dưới, thổi hơi.'),
                $v('v', ['very', 'seven', 'love'], 'Như /f/ nhưng dây thanh rung — đặt tay lên cổ sẽ thấy rung.'),
                $v('θ', ['think', 'three', 'mouth'], 'Đầu lưỡi đặt giữa hai hàm răng, thổi hơi nhẹ. Khác /t/ và /s/.'),
                $v('ð', ['this', 'mother', 'with'], 'Như /θ/ nhưng dây thanh rung.'),
                $v('s', ['sun', 'bus', 'class'], 'Đầu lưỡi gần lợi trên, hơi thoát ra tạo tiếng xì. Giữ âm này ở cuối từ.'),
                $v('z', ['zoo', 'busy', 'rose'], 'Như /s/ nhưng dây thanh rung.'),
                $v('ʃ', ['she', 'fish', 'station'], 'Môi hơi tròn, đẩy ra trước, lưỡi lùi sau hơn /s/.'),
                $v('ʒ', ['television', 'usually', 'garage'], 'Như /ʃ/ nhưng dây thanh rung.'),
                $v('h', ['hat', 'happy', 'behind'], 'Chỉ là hơi thở nhẹ thoát ra từ cổ họng.'),
                $v('tʃ', ['chair', 'teacher', 'watch'], 'Bắt đầu như /t/ rồi chuyển ngay sang /ʃ/.'),
                $v('dʒ', ['jump', 'orange', 'bridge'], 'Bắt đầu như /d/ rồi chuyển ngay sang /ʒ/.'),
                $v('m', ['milk', 'summer', 'room'], 'Hai môi khép, hơi đi qua mũi.'),
                $v('n', ['nose', 'dinner', 'sun'], 'Đầu lưỡi chạm lợi trên, hơi đi qua mũi.'),
                $v('ŋ', ['sing', 'English', 'long'], 'Cuống lưỡi chạm ngạc mềm, hơi qua mũi. Không thêm /ɡ/ phía sau.'),
                $v('l', ['leg', 'yellow', 'ball'], 'Đầu lưỡi chạm lợi trên. /l/ cuối từ (ball) lưỡi giữ lâu hơn, không bỏ đi.'),
                $v('r', ['red', 'carry', 'right'], 'Đầu lưỡi cong nhẹ về sau, KHÔNG chạm vòm miệng, môi hơi tròn.'),
                $v('w', ['we', 'window', 'swim'], 'Môi tròn chụm rồi mở nhanh.'),
                $v('j', ['yes', 'yellow', 'music'], 'Lưỡi nâng cao giống /iː/ rồi chuyển nhanh sang nguyên âm sau.'),
            ],
        ];
    }

    public static function minimalPairs(): array
    {
        return [
            ['ship', 'sheep', '/ɪ/ ngắn – /iː/ dài'], ['sit', 'seat', '/ɪ/ – /iː/'], ['full', 'fool', '/ʊ/ – /uː/'],
            ['bed', 'bad', '/e/ – /æ/'], ['cat', 'cut', '/æ/ – /ʌ/'], ['thin', 'tin', '/θ/ – /t/'], ['think', 'sink', '/θ/ – /s/'],
            ['they', 'day', '/ð/ – /d/'], ['sea', 'she', '/s/ – /ʃ/'], ['sip', 'ship', '/s/ – /ʃ/'], ['fan', 'van', '/f/ – /v/'],
            ['light', 'right', '/l/ – /r/'], ['cap', 'cab', 'âm cuối /p/ – /b/'], ['back', 'bag', 'âm cuối /k/ – /ɡ/'],
            ['rice', 'rise', 'âm cuối /s/ – /z/'], ['white', 'wide', 'âm cuối /t/ – /d/'], ['play', 'played', 'đuôi quá khứ /d/'],
            ['card', 'cards', 'đuôi số nhiều /z/'], ['wash', 'watch', '/ʃ/ – /tʃ/'], ['mine', 'mind', 'cụm âm cuối /nd/'],
        ];
    }

    /** Chuyên đề cho người Việt: lỗi phổ biến + cách sửa + ví dụ có giọng mẫu. */
    public static function vietnameseFocus(): array
    {
        return [
            ['title' => 'Âm cuối (ending sounds)', 'tag' => 'final_consonant',
             'body' => 'Tiếng Việt thường kết thúc âm tiết nhẹ, nên người Việt hay bỏ âm cuối tiếng Anh. Nhưng âm cuối làm thay đổi nghĩa: like /laɪk/ – line /laɪn/ – light /laɪt/. Hãy đọc chậm, giữ khẩu hình đến hết âm cuối.',
             'examples' => ['I like rice.', 'She has a black cat.', 'My dad drives a red bus.']],
            ['title' => 'Cụm phụ âm (consonant clusters)', 'tag' => 'consonant_cluster',
             'body' => 'Không chèn nguyên âm vào giữa hai phụ âm: "street" có cụm /str/ đọc liền. Ở cuối từ cũng vậy: "texts" /teksts/, "months" /mʌnθs/.',
             'examples' => ['The street is crowded.', 'Spring is my favourite season.', 'He asked three questions.']],
            ['title' => 'Đuôi -s/-es', 'tag' => 'plural_s',
             'body' => 'Đọc /s/ sau âm vô thanh (books, cats), /z/ sau âm hữu thanh (dogs, pens), /ɪz/ sau /s, z, ʃ, tʃ, dʒ/ (buses, watches). Đuôi -s xuất hiện ở số nhiều VÀ ở động từ ngôi thứ ba số ít.',
             'examples' => ['She watches two films every week.', 'My brother likes dogs.', 'The buses stop here.']],
            ['title' => 'Đuôi -ed', 'tag' => 'past_ed',
             'body' => 'Đọc /t/ sau âm vô thanh (walked, watched), /d/ sau âm hữu thanh (played, cleaned), /ɪd/ sau /t/ và /d/ (wanted, needed). Không đọc thành một âm tiết "ed" riêng trong mọi trường hợp.',
             'examples' => ['I walked to school yesterday.', 'We played football after class.', 'She wanted a new bike.']],
            ['title' => 'Trọng âm từ (word stress)', 'tag' => 'word_stress',
             'body' => 'Âm tiết có dấu ˈ được đọc to hơn, dài hơn, cao hơn. Ví dụ: ˈteacher, beˈcause, ˈbeautiful, enˈvironment. Nhấn sai trọng âm khiến người nghe khó hiểu hơn cả phát âm sai một âm.',
             'examples' => ['My teacher is beautiful.', 'We protect the environment.', 'This is a photograph.']],
            ['title' => 'Trọng âm câu & nhịp', 'tag' => 'sentence_stress',
             'body' => 'Tiếng Anh có nhịp: từ mang nghĩa (danh từ, động từ chính, tính từ) được nhấn; từ chức năng (a, the, to, of, and) đọc lướt. Đừng đọc đều từng từ như đánh vần.',
             'examples' => ['I WANT to GO to the PARK.', 'She is READING a BOOK.', 'What do you WANT to EAT?']],
        ];
    }
}
