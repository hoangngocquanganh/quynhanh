<?php

namespace App\Services;

use App\Models\User;
use App\Support\Settings;
use Illuminate\Support\Facades\DB;

/**
 * Nhiệm vụ hằng ngày (tính từ hoạt động hôm nay) + thưởng khi xong cả 3 — mỗi ngày nhận 1 lần (khóa idempotency trong sổ cái).
 */
class DailyQuests
{
    /** Các loại lượt được tính là "một bài" cho nhiệm vụ hoàn thành bài. */
    public const SESSION_KINDS = ['lesson', 'review', 'exam', 'assignment', 'game', 'duel'];

    public static function bonus(): array
    {
        return ['xp' => (int) Settings::get('reward.quest_bonus_xp', 15), 'xu' => (int) Settings::get('reward.quest_bonus_xu', 10)];
    }

    public static function forUser(int $userId): array
    {
        $today = DB::table('attempts')->where('user_id', $userId)->where('status', 'submitted')->where('submitted_at', '>=', today());
        return [
            ['icon' => 'zap', 'label' => 'Kiếm 20 XP', 'value' => Economy::counter($userId, 'xp_earned'), 'goal' => 20],
            ['icon' => 'book-check', 'label' => 'Hoàn thành 2 bài', 'value' => (clone $today)->whereIn('kind', self::SESSION_KINDS)->count(), 'goal' => 2],
            ['icon' => 'target', 'label' => 'Trả lời đúng 15 câu', 'value' => (int) (clone $today)->sum('correct'), 'goal' => 15],
        ];
    }

    public static function claimKey(int $userId): string
    {
        return 'quest:' . $userId . ':' . today()->toDateString();
    }

    public static function claimed(int $userId): bool
    {
        return Economy::ledgerExists(static::claimKey($userId)) !== null;
    }

    /** Gọi sau khi cộng thưởng một lượt (trong transaction nộp bài). Trả về phần thưởng nếu vừa nhận. */
    public static function claimIfComplete(User $u): ?array
    {
        if (static::claimed($u->id)) return null;
        foreach (static::forUser($u->id) as $q) if ($q['value'] < $q['goal']) return null;
        $b = static::bonus();
        Economy::grant($u->id, $b['xp'], $b['xu'], 'quest_bonus', static::claimKey($u->id), 'daily_quests', ['day' => today()->toDateString()]);
        Economy::bump($u->id, 'xp_earned', $b['xp']);
        Economy::bump($u->id, 'xu_earned', $b['xu']);
        return $b;
    }
}
