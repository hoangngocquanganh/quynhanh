<?php

namespace App\Services;

use App\Models\Assignment;
use App\Models\AssignmentSubmission;
use App\Models\Attempt;
use App\Models\Lesson;
use App\Models\LessonProgress;
use App\Models\SrsCard;
use App\Models\User;
use App\Support\Settings;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;

/**
 * Hệ quả học tập sau khi nộp: thống kê kỹ năng, Sổ lỗi + lịch ôn SRS 1/3/7 ngày, tiến độ bài, bài nộp được giao.
 */
class Learning
{
    public static function intervals(): array
    {
        $iv = Settings::get('learn.srs_intervals_days', [1, 3, 7]);
        return array_values(array_map('intval', is_array($iv) ? $iv : [1, 3, 7]));
    }

    public static function afterSubmit(Attempt $a, Collection $items, User $user): void
    {
        if ($a->kind === 'demo') return;
        $grade = $a->grade_level;
        $now = now();
        $iv = static::intervals();
        foreach ($items as $it) {
            $snap = $it->snapshot;
            if (!in_array($snap['type'], \App\Models\Question::AUTO_GRADED, true)) continue;
            $ok = $it->is_correct === true;
            // thống kê kỹ năng + nhãn lỗi
            $keys = array_merge([''], array_filter($snap['tags'] ?? [], fn ($t) => !str_starts_with($t, 'gp-level:')));   // nhãn mức độ không cần thống kê
            foreach ($keys as $tag) {
                DB::statement('INSERT INTO skill_stats (user_id, grade_level, skill, tag, correct, total, created_at, updated_at) VALUES (?,?,?,?,?,1,?,?)
                    ON DUPLICATE KEY UPDATE correct = correct + VALUES(correct), total = total + 1, updated_at = VALUES(updated_at)',
                    [$user->id, $grade, $snap['skill'], mb_substr($tag, 0, 40), $ok ? 1 : 0, $now, $now]);
            }
            // Sổ lỗi + SRS
            $type = isset($snap['word_id']) ? 'word' : 'question';
            $itemId = $snap['word_id'] ?? $it->question_id;
            if (!$itemId) continue;
            $card = SrsCard::where('user_id', $user->id)->where('item_type', $type)->where('item_id', $itemId)->first();
            if (!$ok) {
                SrsCard::updateOrCreate(['user_id' => $user->id, 'item_type' => $type, 'item_id' => $itemId], [
                    'grade_level' => $grade, 'stage' => 0, 'lapses' => ($card->lapses ?? 0) + ($card ? 1 : 0),
                    'due_at' => $now->copy()->addDays($iv[0] ?? 1), 'last_reviewed_at' => $now, 'last_correct' => false,
                ]);
            } elseif ($card && ($a->kind === 'review' || $card->due_at->lte($now))) {
                $stage = min(3, $card->stage + 1);
                $card->stage = $stage;
                $card->due_at = $stage >= 3 ? $now->copy()->addDays(30) : $now->copy()->addDays($iv[$stage] ?? 7);
                $card->last_reviewed_at = $now;
                $card->last_correct = true;
                $card->save();
            } elseif (!$card && $type === 'word') {
                // từ mới học đúng ngay lần đầu (luyện theo chủ đề): đưa vào lịch ôn để không quên
                SrsCard::create(['user_id' => $user->id, 'item_type' => 'word', 'item_id' => $itemId, 'grade_level' => $grade, 'stage' => 0,
                    'due_at' => $now->copy()->addDays($iv[0] ?? 1), 'last_reviewed_at' => $now, 'last_correct' => true]);
            }
        }

        if ($a->kind === 'lesson' && $a->ref_type === 'lesson') {
            static::updateLessonProgress($a, $user);
        }
        if ($a->kind === 'game' && $a->ref_type === 'world_level') {
            static::updateWorldProgress($a, $user);
        }
        if ($a->assignment_id) {
            static::updateAssignmentSubmission($a);
        }
    }

    protected static function updateLessonProgress(Attempt $a, User $user): void
    {
        $lesson = Lesson::find($a->ref_id);
        if (!$lesson) return;
        $pass = (int) Settings::get('learn.pass_score', 60);
        $mastery = (int) Settings::get('learn.mastery_score', 90);
        $indep = (int) ($a->meta['independent_score'] ?? $a->score_100 ?? 0);
        $p = LessonProgress::firstOrNew(['user_id' => $user->id, 'lesson_id' => $lesson->id, 'grade_level' => $a->grade_level]);
        $p->attempts_count = ($p->attempts_count ?? 0) + 1;
        $p->best_score = max((int) $p->best_score, (int) $a->score_100);
        $p->last_attempt_at = now();
        $rank = ['in_progress' => 0, 'completed' => 1, 'mastered' => 2];
        $new = $indep >= $mastery ? 'mastered' : ($indep >= $pass ? 'completed' : 'in_progress');
        if (!$p->exists || $rank[$new] > $rank[$p->status ?? 'in_progress']) $p->status = $new;
        if (in_array($p->status, ['completed', 'mastered']) && !$p->completed_at) $p->completed_at = now();
        $p->save();

        // Đưa từ vựng của bài vào lịch ôn từ khi đã học đạt
        if ($indep >= $pass) {
            $now = now();
            foreach (($lesson->content['vocab_ids'] ?? []) as $wid) {
                DB::table('srs_cards')->insertOrIgnore([
                    'user_id' => $user->id, 'item_type' => 'word', 'item_id' => (int) $wid, 'grade_level' => $a->grade_level,
                    'stage' => 0, 'lapses' => 0, 'due_at' => $now->copy()->addDays(static::intervals()[0] ?? 1),
                    'created_at' => $now, 'updated_at' => $now,
                ]);
            }
        }
    }

    protected static function updateWorldProgress(Attempt $a, User $user): void
    {
        $lv = \App\Models\WorldLevel::find($a->ref_id);
        if (!$lv) return;
        $score = (int) $a->score_100;
        $p = \App\Models\WorldProgress::firstOrNew(['user_id' => $user->id, 'world_level_id' => $lv->id, 'grade_level' => $a->grade_level]);
        $p->best_score = max((int) $p->best_score, $score);
        $p->stars = max((int) $p->stars, $score >= 90 ? 3 : ($score >= 75 ? 2 : ($score >= $lv->pass_score ? 1 : 0)));
        $p->passed = $p->passed || $score >= $lv->pass_score;
        $p->save();
    }

    protected static function updateAssignmentSubmission(Attempt $a): void
    {
        $as = Assignment::find($a->assignment_id);
        if (!$as) return;
        $sub = AssignmentSubmission::firstOrNew(['assignment_id' => $as->id, 'student_id' => $a->user_id]);
        // Giữ lượt tốt nhất
        if ($sub->exists && $sub->auto_score !== null && $sub->auto_score >= (int) $a->score_100 && $sub->status !== 'in_progress') return;
        $sub->attempt_id = $a->id;
        $sub->auto_score = $a->score_100;
        if (!in_array($sub->status, ['graded', 'returned'], true)) $sub->status = 'submitted';
        $sub->submitted_at = now();
        $sub->is_late = $as->due_at && now()->gt($as->due_at);
        $sub->save();
    }
}
