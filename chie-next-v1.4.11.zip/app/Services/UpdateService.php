<?php

namespace App\Services;

use App\Models\AppUpdate;
use App\Models\User;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\File;

/**
 * Cập nhật một chạm từ gói phát hành chính thức (ZIP có tệp chie-release.json liệt kê SHA-256 từng tệp).
 * - Kiểm tra: đúng ứng dụng, phiên bản mới hơn, đường dẫn an toàn, KHÔNG đụng tới .env / storage / bootstrap/cache,
 *   mọi tệp khớp mã băm trong danh sách.
 * - Sao lưu mọi tệp sắp bị ghi đè vào storage/app/backups/…, rồi chép tệp mới, chạy migrate, xóa bộ đệm giao diện.
 * - Lỗi giữa chừng → tự khôi phục từ bản sao lưu. Có nút "Hoàn tác" cho lần cập nhật gần nhất (không hoàn tác thay đổi CSDL).
 */
class UpdateService
{
    public const MANIFEST = 'chie-release.json';
    protected const PROTECTED = ['.env', 'storage/', 'assets/chie-releases/', 'bootstrap/cache/', 'bootstrap/chie-release.json', '.htaccess.local'];

    public static function currentVersion(): string { return (string) config('chie.version'); }

    /** Gói đã đặt sẵn trong storage/app/updates/ (tải qua File Manager khi tệp lớn hơn giới hạn tải lên). */
    public static function localPackages(): array
    {
        return array_values(array_map('basename', glob(storage_path('app/updates/*.zip')) ?: []));
    }

    protected static function safePath(string $p): bool
    {
        if ($p === '' || str_starts_with($p, '/') || str_contains($p, '\\') || preg_match('#(^|/)\.\.(/|$)#', $p) || str_contains($p, "\0")) return false;
        foreach (static::PROTECTED as $x) {
            if (str_ends_with($x, '/') ? ($p === rtrim($x, '/') || str_starts_with($p, $x)) : $p === $x) return false;   // thư mục: theo tiền tố; tệp: đúng tên
        }
        return true;
    }

    /** Đọc và kiểm tra gói; trả về thông tin hoặc ném DomainError với lý do rõ ràng. */
    public static function inspect(string $zipPath): array
    {
        if (!class_exists(\ZipArchive::class)) throw new DomainError('Máy chủ chưa bật tiện ích PHP "zip". Hãy bật trong cPanel → Select PHP Version → Extensions.');
        $z = new \ZipArchive();
        if ($z->open($zipPath) !== true) throw new DomainError('Không mở được tệp ZIP.');
        try {
            $raw = $z->getFromName(static::MANIFEST);
            if ($raw === false) throw new DomainError('Gói thiếu tệp ' . static::MANIFEST . ' — đây không phải gói phát hành CHIE NEXT.');
            $m = json_decode($raw, true);
            if (($m['app'] ?? null) !== 'chie-next' || empty($m['version']) || empty($m['files']) || !is_array($m['files'])) throw new DomainError('Tệp mô tả gói không hợp lệ.');
            if (version_compare($m['version'], static::currentVersion(), '<=')) throw new DomainError('Gói có phiên bản ' . $m['version'] . ', không mới hơn bản đang chạy (' . static::currentVersion() . ').');
            if (!empty($m['min_from']) && version_compare(static::currentVersion(), $m['min_from'], '<')) throw new DomainError('Cần cập nhật lên ' . $m['min_from'] . ' trước khi lên ' . $m['version'] . '.');
            $total = 0; $new = 0; $changed = 0;
            foreach ($m['files'] as $path => $hash) {
                if (!static::safePath($path)) throw new DomainError('Gói chứa đường dẫn không an toàn hoặc bị cấm: ' . $path);
                $st = $z->statName($path);
                $dest = base_path($path);
                if ($st === false) {
                    // gói rút gọn (chỉ chứa tệp thay đổi): tệp vắng mặt phải giống hệt tệp đang cài
                    if (is_file($dest) && hash_file('sha256', $dest) === $hash) continue;
                    throw new DomainError('Gói rút gọn thiếu tệp ' . $path . ' (tệp đang cài khác với bản gốc của gói). Hãy dùng gói đầy đủ.');
                }
                $data = $z->getFromName($path);
                if (!hash_equals((string) $hash, hash('sha256', $data))) throw new DomainError('Tệp bị sửa đổi hoặc hỏng (sai mã băm): ' . $path);
                $total += $st['size'];
                if (!is_file($dest)) $new++; elseif (hash_file('sha256', $dest) !== $hash) $changed++;
            }
            // không cho phép tệp lạ ngoài danh sách
            for ($i = 0; $i < $z->numFiles; $i++) {
                $n = $z->getNameIndex($i);
                if (str_ends_with($n, '/') || $n === static::MANIFEST) continue;
                if (!isset($m['files'][$n])) throw new DomainError('Gói chứa tệp không có trong danh sách: ' . $n);
            }
            return ['version' => $m['version'], 'notes' => $m['notes'] ?? null, 'files' => count($m['files']), 'new' => $new, 'changed' => $changed, 'bytes' => $total];
        } finally { $z->close(); }
    }

    public static function apply(string $zipPath, User $actor): AppUpdate
    {
        if (defined('CHIE_SHARED_ROOT')) return LiveRelease::apply($zipPath,$actor);
        $info = static::inspect($zipPath);
        $from = static::currentVersion();
        $stamp = now()->format('Ymd-His');
        $backup = storage_path('app/backups/' . $stamp . '-' . $from);
        File::ensureDirectoryExists($backup);
        $log = ['info' => $info, 'replaced' => [], 'created' => []];
        $upd = AppUpdate::create(['version_from' => $from, 'version_to' => $info['version'], 'file_sha256' => hash_file('sha256', $zipPath), 'status' => 'checked',
            'backup_path' => 'storage/app/backups/' . basename($backup), 'actor_user_id' => $actor->id]);
        $z = new \ZipArchive(); $z->open($zipPath);
        $m = json_decode($z->getFromName(static::MANIFEST), true);
        // v1.3: module game/khối lớp đã được cập nhật riêng (phiên bản đang cài MỚI HƠN bản trong gói lõi) thì giữ nguyên.
        $keepModules = [];
        foreach (array_keys($m['files']) as $path) {
            if (!preg_match('#^(modules/(games|grades)/[A-Za-z0-9_\-]+)/module\.json$#', $path, $mm)) continue;
            $local = ModuleRegistry::localVersion($mm[1]);
            $pkg = json_decode((string) $z->getFromName($path), true)['version'] ?? null;
            if ($local && $pkg && version_compare($local, (string) $pkg, '>')) $keepModules[] = $mm[1] . '/';
        }
        $log['kept_modules'] = $keepModules;
        try {
            foreach ($m['files'] as $path => $hash) {
                foreach ($keepModules as $prefix) if (str_starts_with($path, $prefix)) continue 2;
                $dest = base_path($path);
                if ($z->statName($path) === false) continue;   // gói rút gọn: tệp không đổi
                if (is_file($dest)) {
                    if (hash_file('sha256', $dest) === $hash) continue;     // không đổi
                    File::ensureDirectoryExists(dirname($backup . '/' . $path));
                    if (!copy($dest, $backup . '/' . $path)) throw new DomainError('Không sao lưu được tệp: ' . $path);
                    $log['replaced'][] = $path;
                } else {
                    $log['created'][] = $path;
                }
                File::ensureDirectoryExists(dirname($dest));
                $tmp = $dest . '.chie-tmp';
                $data = $z->getFromName($path);
                if ($data === false || file_put_contents($tmp, $data) !== strlen($data)) throw new DomainError('Không ghi được tệp: ' . $path);
                if (!rename($tmp, $dest) || hash_file('sha256', $dest) !== $hash) throw new DomainError('Không thay thế được tệp: ' . $path);
            }
            $z->close(); $z = null;
            foreach ($keepModules as $prefix) {
                if (str_starts_with($prefix, 'modules/games/')) $log['redeployed'][$prefix] = ModuleRegistry::redeploy(basename(rtrim($prefix, '/')));
            }
            if (function_exists('opcache_reset')) @opcache_reset();
            $log['migrate'] = static::migrateDatabase();
            static::clearRuntimeCaches();
            $upd->update(['status' => 'applied', 'log' => $log]);
        } catch (\Throwable $e) {
            if ($z !== null) { try { $z->close(); } catch (\Throwable $ignored) {} }
            static::restore($backup, $log);
            $log['error'] = $e->getMessage();
            $upd->update(['status' => 'failed', 'log' => $log]);
            report($e);
            throw new DomainError('Cập nhật thất bại, đã tự khôi phục các tệp cũ. Lỗi: ' . $e->getMessage());
        }
        return $upd;
    }

    public static function migrateDatabase(): string
    {
        $code = Artisan::call('migrate', ['--force' => true]);
        $output = trim(Artisan::output());
        if ($code !== 0) throw new DomainError('Cập nhật CSDL thất bại: ' . $output);
        $migrator = app('migrator');
        $files = $migrator->getMigrationFiles([database_path('migrations')]);
        $pending = array_diff(array_keys($files), $migrator->getRepository()->getRan());
        if ($pending) throw new DomainError('CSDL còn bước chưa chạy: ' . implode(', ', $pending));
        return $output;
    }

    public static function clearRuntimeCaches(): void
    {
        foreach (['config:clear', 'route:clear', 'view:clear'] as $command) {
            if (Artisan::call($command) !== 0) throw new DomainError('Không xóa được bộ đệm: ' . $command . '. ' . trim(Artisan::output()));
        }
        \App\Support\Settings::flush();
        if (function_exists('opcache_reset')) @opcache_reset();
    }

    protected static function restore(string $backup, array $log): void
    {
        foreach ($log['replaced'] ?? [] as $p) if (is_file($backup . '/' . $p)) copy($backup . '/' . $p, base_path($p));
        foreach ($log['created'] ?? [] as $p) if (is_file(base_path($p))) @unlink(base_path($p));
        if (function_exists('opcache_reset')) @opcache_reset();
    }

    public static function rollback(AppUpdate $u): AppUpdate
    {
        if (defined('CHIE_SHARED_ROOT') && ($u->log['mode'] ?? null) !== 'live') throw new DomainError('Bản sao lưu này dùng cơ chế cũ. Chỉ khôi phục thủ công khi bảo trì, không chép đè khi đang có người chơi.');
        if ($u->status !== 'applied') throw new DomainError('Chỉ hoàn tác được lần cập nhật đã áp dụng.');
        if (AppUpdate::where('status', 'applied')->where('id', '>', $u->id)->exists()) throw new DomainError('Hãy hoàn tác lần cập nhật mới hơn trước.');
        if (($u->log['mode'] ?? null) === 'live') {
            return LiveRelease::rollback($u);
        }
        static::restore(base_path($u->backup_path), $u->log ?? []);
        Artisan::call('view:clear');
        $u->update(['status' => 'rolled_back']);
        return $u;
    }
}
