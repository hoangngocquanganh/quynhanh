<?php
namespace App\Services;

use App\Models\AppUpdate;
use App\Models\User;
use Illuminate\Support\Facades\File;

/** Immutable releases + shared .env/storage; only the tiny active pointer changes. */
class LiveRelease
{
    public static function root(): string { return defined('CHIE_SHARED_ROOT') ? CHIE_SHARED_ROOT : base_path(); }

    public static function switchTo(string $root, ?array $state): void
    {
        File::ensureDirectoryExists($root.'/storage/app/deploy');
        $dest=$root.'/storage/app/deploy/active.json';$tmp=$dest.'.'.bin2hex(random_bytes(5)).'.tmp';
        if(file_put_contents($tmp,json_encode($state ?? ['release'=>'root'],JSON_THROW_ON_ERROR),LOCK_EX)===false || !rename($tmp,$dest))throw new DomainError('Không chuyển được phiên bản hoạt động.');
        clearstatcache(true,$dest);
    }

    public static function apply(string $zipPath, User $actor): AppUpdate
    {
        $root=static::root();File::ensureDirectoryExists($root.'/storage/app/deploy');
        $lock=fopen($root.'/storage/app/deploy/update.lock','c');
        if(!$lock || !flock($lock,LOCK_EX|LOCK_NB))throw new DomainError('Một quản trị viên khác đang cập nhật. Hãy chờ hoàn tất.');
        $z=null;$update=null;
        try {
            $info=UpdateService::inspect($zipPath);
            $free=@disk_free_space($root);
            if($free!==false && $free < $info['bytes']*2+33554432)throw new DomainError('Hosting chưa đủ dung lượng để giữ bản cũ và chuẩn bị bản mới. Bản hiện tại vẫn hoạt động.');
            $z=new \ZipArchive();if($z->open($zipPath)!==true)throw new DomainError('Không mở được gói cập nhật.');
            $m=json_decode($z->getFromName(UpdateService::MANIFEST),true,512,JSON_THROW_ON_ERROR);
            foreach(array_keys($m['files']) as $path) {
                if(!preg_match('#^(modules/(games|grades)/[A-Za-z0-9_-]+)/module\.json$#',$path,$module))continue;
                $local=ModuleRegistry::localVersion($module[1]);$pack=json_decode((string)$z->getFromName($path),true)['version']??null;
                if($local && $pack && version_compare($local,(string)$pack,'>'))throw new DomainError('Gói chứa module cũ hơn bản đang dùng: '.$module[1].'. Hãy gộp module hiện tại vào bản phát hành mới.');
            }
            if(($m['live_update']['protocol']??null)!==1 || ($m['live_update']['schema']??null)!=='unchanged')throw new DomainError('Gói này chưa được xác nhận tương thích cập nhật nóng. Hãy dùng gói có giao thức 1 và không thay đổi CSDL.');
            foreach(['config/session.php','config/auth.php','config/app.php'] as $path) {
                if (!isset($m['files'][$path]) && !is_file(base_path($path))) continue;
                if(!isset($m['files'][$path]) || !is_file(base_path($path)) || hash_file('sha256',base_path($path))!==$m['files'][$path])throw new DomainError('Gói thay đổi cấu hình đăng nhập/phiên. Không áp dụng nóng để bảo vệ người đang dùng.');
            }
            foreach(['index.php','artisan','release-loader.php','.htaccess','sw.js'] as $path) {
                if(!isset($m['files'][$path]) || !is_file($root.'/'.$path) || hash_file('sha256',$root.'/'.$path)!==$m['files'][$path])throw new DomainError('Gói thay đổi cầu chuyển phiên bản hoặc cấu hình phục vụ: '.$path.'. Cần triển khai riêng trong thời gian bảo trì.');
            }
            $migrator=app('migrator');$ran=$migrator->getRepository()->getRan();
            foreach(array_keys($m['files']) as $path)if(preg_match('#^database/migrations/([^/]+)\.php$#',$path,$match) && !in_array($match[1],$ran,true))throw new DomainError('Gói còn bước CSDL chưa chạy: '.$match[1].'. Cần triển khai CSDL tương thích trước khi cập nhật nóng.');
            $id='r-'.str_replace('.','-',$m['version']).'-'.bin2hex(random_bytes(5));
            $dest=$root.'/storage/app/deploy/releases/'.$id;
            $public=$root.'/assets/chie-releases/'.$id;
            $old=json_decode((string)@file_get_contents($root.'/storage/app/deploy/active.json'),true)?:['release'=>'root'];
            $update=AppUpdate::create(['version_from'=>UpdateService::currentVersion(),'version_to'=>$m['version'],'file_sha256'=>hash_file('sha256',$zipPath),'status'=>'checked','backup_path'=>'storage/app/deploy/releases/'.$id,'actor_user_id'=>$actor->id]);
            foreach($m['files'] as $path=>$hash){
                $bytes=$z->statName($path)!==false?$z->getFromName($path):(is_file(base_path($path))?file_get_contents(base_path($path)):false);
                if($bytes===false || !hash_equals($hash,hash('sha256',$bytes)))throw new DomainError('Tệp không hợp lệ khi chuẩn bị: '.$path);
                File::ensureDirectoryExists(dirname($dest.'/'.$path));
                if(file_put_contents($dest.'/'.$path,$bytes)!==strlen($bytes))throw new DomainError('Không chuẩn bị được: '.$path);
                if(str_starts_with($path,'assets/')){
                    if(preg_match('/\.(php\d*|phtml|phar)$/i',$path) || basename($path)==='.htaccess')throw new DomainError('Không cho mã thực thi trong tài nguyên công khai.');
                    File::ensureDirectoryExists(dirname($public.'/'.$path));
                    if(file_put_contents($public.'/'.$path,$bytes)!==strlen($bytes))throw new DomainError('Không chuẩn bị được tài nguyên: '.$path);
                }
            }
            foreach(['index.php','artisan','release-loader.php','bootstrap/app.php','vendor/autoload.php'] as $required)if(!is_file($dest.'/'.$required))throw new DomainError('Gói thiếu tệp khởi động: '.$required);
            File::ensureDirectoryExists($dest.'/bootstrap/cache');
            // A complete marker is written last; API pins cannot select unfinished code.
            $metadata=['shared_root'=>$root,'version'=>$m['version'],'release'=>$id,'ready'=>false];
            file_put_contents($dest.'/bootstrap/chie-release.json',json_encode($metadata,JSON_THROW_ON_ERROR),LOCK_EX);
            if(!function_exists('proc_open'))throw new DomainError('Hosting cần cho phép proc_open để kiểm tra bản mới bằng PHP CLI. Chưa chuyển phiên bản.');
            $php=(new \Symfony\Component\Process\PhpExecutableFinder())->find(false) ?: PHP_BINARY;
            $probe=new \Symfony\Component\Process\Process([$php,$dest.'/artisan','about','--only=environment','--no-interaction'], $dest);
            $probe->setTimeout(90);$probe->run();
            if(!$probe->isSuccessful())throw new DomainError('Bản mới không khởi động được trong bước kiểm tra. '.mb_substr($probe->getErrorOutput(),0,350));
            $metadata['ready']=true;
            file_put_contents($dest.'/bootstrap/chie-release.json',json_encode($metadata,JSON_THROW_ON_ERROR),LOCK_EX);
            $log=['mode'=>'live','release'=>$id,'previous'=>$old,'info'=>$info,'boot_check'=>'passed'];
            $update->update(['log'=>$log]);
            static::switchTo($root,['release'=>$id,'version'=>$m['version'],'at'=>now()->toIso8601String()]);
            // No session/cache flush, maintenance mode, opcache reset, migration or old file deletion.
            $update->update(['status'=>'applied']);
            return $update;
        }catch(\Throwable $e){
            if($update && isset($old,$id)) {
                $active=json_decode((string)@file_get_contents($root.'/storage/app/deploy/active.json'),true);
                if(($active['release']??null)===$id)static::switchTo($root,$old);
                $update->update(['status'=>'failed','log'=>['mode'=>'live','error'=>$e->getMessage()]]);
            }
            if($e instanceof DomainError)throw $e;
            report($e);throw new DomainError('Chưa chuyển sang bản mới; bản đang chạy được giữ nguyên. '.$e->getMessage());
        }finally{if($z)$z->close();if($lock){flock($lock,LOCK_UN);fclose($lock);}}
    }

    public static function rollback(AppUpdate $update): AppUpdate
    {
        $root=static::root();$lock=fopen($root.'/storage/app/deploy/update.lock','c');
        if(!$lock || !flock($lock,LOCK_EX|LOCK_NB))throw new DomainError('Một quản trị viên khác đang cập nhật.');
        try {
            $update->refresh();
            $state=json_decode((string)@file_get_contents($root.'/storage/app/deploy/active.json'),true);
            if($update->status!=='applied' || ($state['release']??null)!==($update->log['release']??null))throw new DomainError('Chỉ hoàn tác bản đang hoạt động.');
            static::switchTo($root,$update->log['previous']??null);
            $update->update(['status'=>'rolled_back']);return $update;
        }finally{flock($lock,LOCK_UN);fclose($lock);}
    }
}
