<?php

namespace App\Services;

use App\Models\GachaLog;
use App\Models\GachaPool;
use App\Models\InventoryItem;
use App\Models\ShopItem;
use App\Models\User;
use App\Support\Settings;
use Illuminate\Support\Facades\DB;

/**
 * Cửa hàng + Gacha + bán lại cho CHIE. Mọi thay đổi Xu/vật phẩm trong 1 transaction, khóa ví, idempotency_key.
 * Không bán đáp án/điểm/lượt; vật phẩm chỉ để trang trí, không ảnh hưởng điểm học.
 */
class ShopService
{
    public static function buy(User $u, int $itemId, string $idem): InventoryItem
    {
        return DB::transaction(function () use ($u, $itemId, $idem) {
            if ($l = Economy::ledgerExists('buy:' . $u->id . ':' . $idem)) {
                return InventoryItem::where('user_id', $u->id)->findOrFail($l->meta['inventory_id']);
            }
            $item = ShopItem::where('is_active', true)->whereNotNull('price_xu')->where('category', '<>', 'gacha_only')->findOrFail($itemId);
            if ($item->isSeasonExpired()) throw new DomainError('Vật phẩm theo mùa này đã hết hạn bán.');
            $w = Economy::lock($u->id);
            if ($w->level < $item->min_level) throw new DomainError("Cần đạt cấp {$item->min_level} để mua vật phẩm này (bạn đang cấp {$w->level}).");
            if (in_array($item->category, ['avatar_frame', 'title'], true) && InventoryItem::where('user_id', $u->id)->where('shop_item_id', $item->id)->exists()) {
                throw new DomainError('Bạn đã sở hữu vật phẩm này.');
            }
            $inv = InventoryItem::create(['user_id' => $u->id, 'shop_item_id' => $item->id, 'source' => 'shop', 'acquired_price' => $item->price_xu]);
            Economy::spend($u->id, (int) $item->price_xu, 'shop_buy', 'buy:' . $u->id . ':' . $idem, 'item:' . $item->code, ['inventory_id' => $inv->id]);
            return $inv;
        });
    }

    public static function sellPrice(InventoryItem $inv): int
    {
        if ($inv->source === 'gacha') return (int) Settings::get('shop.gacha_sell_price', 20);
        if ($inv->source === 'shop') return (int) floor($inv->acquired_price * (int) Settings::get('shop.sell_back_percent', 50) / 100);
        return (int) floor(($inv->item->price_xu ?? 40) * 0.25);
    }

    /** Bán lại cho CHIE (nút duy nhất). Đồ mua: 50%; đồ Gacha: 20 Xu cố định. */
    public static function sell(User $u, int $inventoryId, string $idem): int
    {
        return DB::transaction(function () use ($u, $inventoryId, $idem) {
            if ($l = Economy::ledgerExists('sell:' . $u->id . ':' . $idem)) return (int) $l->delta_xu;
            Economy::lock($u->id);
            $inv = InventoryItem::with('item')->where('user_id', $u->id)->lockForUpdate()->findOrFail($inventoryId);
            if ($inv->placed) throw new DomainError('Hãy cất vật phẩm khỏi phòng trước khi bán.');
            if (DB::table('trade_offers')->where('status', 'pending')->where(fn ($q) => $q->where('sender_inventory_id', $inv->id)->orWhere('receiver_inventory_id', $inv->id))->exists()) {
                throw new DomainError('Vật phẩm đang nằm trong một lời mời đổi đồ. Hãy hủy lời mời trước.');
            }
            $price = static::sellPrice($inv);
            $code = $inv->item->code;
            $inv->delete();
            Economy::grant($u->id, 0, $price, 'sell_back', 'sell:' . $u->id . ':' . $idem, 'item:' . $code);
            return $price;
        });
    }

    public static function gachaStatus(User $u, GachaPool $pool): array
    {
        $w = Economy::walletFor($u->id);
        return ['pity' => (int) $w->gacha_pity, 'pity_threshold' => (int) $pool->pity_threshold, 'spins_today' => Economy::counter($u->id, 'gacha_spins'),
            'daily_limit' => (int) $pool->daily_limit, 'price' => (int) $pool->price_xu, 'rates' => $pool->rates];
    }

    /**
     * Quay Gacha trên máy chủ: khóa ví, kiểm đủ Xu, trừ Xu, random_int mật mã học, ghi vật phẩm + sổ cái + nhật ký
     * trong CÙNG MỘT transaction. Gửi lại cùng idempotency_key → trả lại đúng kết quả cũ.
     */
    public static function spin(User $u, GachaPool $pool, string $idem): array
    {
        $key = 'gacha:' . $u->id . ':' . $idem;
        return DB::transaction(function () use ($u, $pool, $key) {
            if ($log = GachaLog::where('idempotency_key', $key)->first()) {
                return ['item' => $log->item, 'rarity' => $log->rarity, 'was_pity' => $log->was_pity, 'replayed' => true, 'pity' => (int) Economy::walletFor($u->id)->gacha_pity];
            }
            if (!$pool->is_active) throw new DomainError('Hòm quà đang tạm đóng.');
            $w = Economy::lock($u->id);
            if (Economy::counter($u->id, 'gacha_spins') >= $pool->daily_limit) throw new DomainError("Hôm nay bạn đã quay đủ {$pool->daily_limit} lượt. Mai quay tiếp nhé!");
            if ($w->xu < $pool->price_xu) throw new InsufficientXu((int) $pool->price_xu, (int) $w->xu);
            $rates = $pool->rates;
            $sum = array_sum($rates);
            if (abs($sum - 100) > 0.0001) throw new DomainError('Bảng tỉ lệ đang lỗi (tổng khác 100%). Vui lòng báo quản trị viên.');
            $pityHit = ($w->gacha_pity + 1) >= $pool->pity_threshold;
            $roll = random_int(1, 1000000);
            if ($pityHit) {
                $rarity = 'curated';
            } else {
                $acc = 0; $rarity = 'common';
                foreach (['curated', 'epic', 'rare', 'common'] as $tier) {
                    $acc += (int) round(($rates[$tier] ?? 0) * 10000);
                    if ($roll <= $acc) { $rarity = $tier; break; }
                }
            }
            $candidates = $pool->items()->where('shop_items.is_active', true)->where('rarity', $rarity)->pluck('shop_items.id')->all();
            if (!$candidates) {
                // không có vật phẩm của bậc này trong bể → hạ dần bậc (ghi rõ trong nhật ký)
                foreach (['epic', 'rare', 'common'] as $fb) {
                    $candidates = $pool->items()->where('shop_items.is_active', true)->where('rarity', $fb)->pluck('shop_items.id')->all();
                    if ($candidates) { $rarity = $fb; break; }
                }
            }
            if (!$candidates) throw new DomainError('Hòm quà chưa có vật phẩm.');
            $itemId = $candidates[random_int(0, count($candidates) - 1)];
            $item = ShopItem::find($itemId);
            Economy::spend($u->id, (int) $pool->price_xu, 'gacha_spin', $key, 'pool:' . $pool->code, ['roll' => $roll, 'rarity' => $rarity]);
            $w = Economy::lock($u->id);
            $w->gacha_pity = $rarity === 'curated' ? 0 : $w->gacha_pity + 1;
            $w->save();
            $lockDays = $rarity === 'curated' ? (int) Settings::get('trade.curated_lock_days', 30) : 0;
            $inv = InventoryItem::create(['user_id' => $u->id, 'shop_item_id' => $item->id, 'source' => 'gacha', 'acquired_price' => 0,
                'trade_locked_until' => $lockDays ? now()->addDays($lockDays) : null]);
            GachaLog::create(['user_id' => $u->id, 'gacha_pool_id' => $pool->id, 'shop_item_id' => $item->id, 'inventory_item_id' => $inv->id, 'rarity' => $rarity,
                'was_pity' => $pityHit, 'roll' => $roll, 'xu_spent' => $pool->price_xu, 'idempotency_key' => $key, 'created_at' => now()]);
            Economy::bump($u->id, 'gacha_spins');
            return ['item' => $item, 'rarity' => $rarity, 'was_pity' => $pityHit, 'replayed' => false, 'pity' => (int) $w->gacha_pity];
        });
    }

    public static function beauty(int $userId): int
    {
        return (int) DB::table('inventory_items')->join('shop_items', 'shop_items.id', '=', 'inventory_items.shop_item_id')
            ->where('inventory_items.user_id', $userId)->where('placed', true)->sum('shop_items.beauty');
    }
}
