<?php

namespace App\Services;

use App\Support\Audit;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\File;
use ZipArchive;

/**
 * v1.3 — Module độc lập: modules/games/* (5 game) và modules/grades/grade-01..12 (học liệu theo khối lớp).
 *
 * Xuất 1 module thành .zip (kèm MODULE_SDK_CONTRACT.md) để gửi AI / lập trình viên sửa, rồi tải gói đã sửa lên lại.
 * Module game khai báo "deploy": {"tệp trong module": "đường dẫn chạy thật trong assets/"} — khi cài, các tệp đó được
 * chép vào đúng chỗ game đang chạy, nên không phải đụng tới mã Laravel. Game 5 (Zoo Garden) chép cả thư mục dist/.
 * Module khối lớp được nhập vào CSDL qua ContentImporter (idempotent, không ghi đè bản Admin đã sửa).
 */
class ModuleRegistry
{
    /** Thư mục đích mà module game được phép ghi (chống ghi đè mã lõi). */
    public const DEPLOY_ALLOWED = ['assets/js/games/', 'assets/js/games3d/', 'assets/zoo-garden/'];
    public const BLOCKED_EXT = ['php', 'phtml', 'phar', 'htaccess', 'sh', 'exe', 'bat', 'cmd', 'cgi', 'pl', 'py'];

    public static function gamesPath(string $sub = ''): string
    {
        return base_path('modules/games' . ($sub ? '/' . ltrim($sub, '/') : ''));
    }

    public static function gradesPath(string $sub = ''): string
    {
        return base_path('modules/grades' . ($sub ? '/' . ltrim($sub, '/') : ''));
    }

    public static function allGames(): array
    {
        $out = [];
        foreach (glob(static::gamesPath('*/module.json')) ?: [] as $file) {
            $m = json_decode((string) file_get_contents($file), true);
            if (!is_array($m) || empty($m['code'])) continue;
            $m['folder'] = basename(dirname($file));
            $m['updated_at'] = date('Y-m-d H:i', (int) filemtime($file));
            $m['size_kb'] = (int) round(static::dirSize(dirname($file)) / 1024);
            $out[$m['code']] = $m;
        }
        uasort($out, fn ($a, $b) => ($a['slot'] ?? 99) <=> ($b['slot'] ?? 99));
        return $out;
    }

    public static function allGrades(): array
    {
        $out = [];
        foreach (glob(static::gradesPath('grade-*/module.json')) ?: [] as $file) {
            $m = json_decode((string) file_get_contents($file), true);
            if (!is_array($m) || empty($m['grade_id'])) continue;
            $m['folder'] = basename(dirname($file));
            $m['updated_at'] = date('Y-m-d H:i', (int) filemtime($file));
            $m['size_kb'] = (int) round(static::dirSize(dirname($file)) / 1024);
            $out[(int) $m['grade_id']] = $m;
        }
        ksort($out);
        return $out;
    }

    protected static function dirSize(string $dir): int
    {
        $n = 0;
        if (!is_dir($dir)) return 0;
        foreach (new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator($dir, \FilesystemIterator::SKIP_DOTS)) as $f) {
            if ($f->isFile()) $n += $f->getSize();
        }
        return $n;
    }

    /** Nhập lại học liệu của 1 khối lớp vào CSDL. */
    public static function syncGradeModule(int $gradeId, ?int $userId = null): array
    {
        $folder = sprintf('grade-%02d', $gradeId);
        $path = static::gradesPath($folder);
        if (!is_file($path . '/module.json')) throw new DomainError("Không tìm thấy modules/grades/{$folder}.");
        $manifest = json_decode((string) file_get_contents($path . '/module.json'), true) ?: [];
        $files = $manifest['files'] ?? ['curriculum.json', 'lexicon.json', 'questions.json', 'exam_blueprints.json'];
        $pack = ['format' => 'chie-content', 'version' => 1, 'title' => $manifest['name'] ?? "Lớp {$gradeId}", 'generated_from' => "modules/grades/{$folder}",
            'units' => [], 'lessons' => [], 'passages' => [], 'lexicon' => [], 'questions' => [], 'exam_blueprints' => []];
        foreach ($files as $fn) {
            $fn = basename((string) $fn);
            if (!is_file("$path/$fn")) continue;
            $part = json_decode((string) file_get_contents("$path/$fn"), true);
            if (!is_array($part)) throw new DomainError("Tệp {$folder}/{$fn} không phải JSON hợp lệ.");
            foreach (['units', 'lessons', 'passages', 'lexicon', 'questions', 'exam_blueprints'] as $k) {
                if (!empty($part[$k]) && is_array($part[$k])) $pack[$k] = array_merge($pack[$k], $part[$k]);
            }
        }
        $tmp = storage_path('app/module-' . $folder . '-' . bin2hex(random_bytes(4)) . '.json');
        File::ensureDirectoryExists(dirname($tmp));
        file_put_contents($tmp, json_encode($pack, JSON_UNESCAPED_UNICODE));
        try {
            $run = (new ContentImporter())->run($tmp, false, $userId);
        } finally {
            @unlink($tmp);
        }
        return ['run_id' => $run->id, 'stats' => $run->stats];
    }

    /** Đóng gói 1 module thành .zip (đường dẫn tệp tạm). */
    public static function exportModuleZip(string $type, string $folder): string
    {
        $folder = preg_replace('/[^A-Za-z0-9_\-]/', '', $folder);
        $baseDir = $type === 'game' ? static::gamesPath($folder) : static::gradesPath($folder);
        if ($folder === '' || !is_dir($baseDir)) throw new DomainError("Không có module [{$type}/{$folder}].");
        if (!class_exists(ZipArchive::class)) throw new DomainError('Máy chủ chưa bật PHP zip (ZipArchive).');
        $tmp = storage_path('app/export-' . $folder . '-' . date('Ymd-His') . '.zip');
        File::ensureDirectoryExists(dirname($tmp));
        $zip = new ZipArchive();
        if ($zip->open($tmp, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) throw new DomainError('Không tạo được tệp ZIP.');
        $contract = base_path('modules/MODULE_SDK_CONTRACT.md');
        if (is_file($contract)) $zip->addFile($contract, $folder . '/MODULE_SDK_CONTRACT.md');
        foreach (new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator($baseDir, \FilesystemIterator::SKIP_DOTS)) as $f) {
            if (!$f->isFile()) continue;
            $rel = str_replace('\\', '/', substr($f->getPathname(), strlen($baseDir) + 1));
            $zip->addFile($f->getPathname(), $folder . '/' . $rel);
        }
        $zip->close();
        return $tmp;
    }

    /** Cài / cập nhật 1 module từ .zip tải lên. */
    public static function installModuleZip(UploadedFile $zipFile, ?int $userId = null): array
    {
        return static::installModuleZipPath($zipFile->getRealPath(), $userId);
    }

    /** Gói .zip có phải gói module (có module.json, không có chie-release.json)? */
    public static function isModuleZip(string $path): bool
    {
        if (!class_exists(ZipArchive::class)) return false;
        $z = new ZipArchive();
        if ($z->open($path) !== true) return false;
        try {
            if ($z->locateName('chie-release.json') !== false) return false;
            for ($i = 0; $i < $z->numFiles; $i++) {
                $n = (string) $z->getNameIndex($i);
                if ($n === 'module.json' || preg_match('#^[^/]+/module\.json$#', $n)) return true;
            }
            return false;
        } finally { $z->close(); }
    }

    /** Phiên bản module đang cài theo đường dẫn tương đối modules/games/<folder> hoặc modules/grades/<folder>. */
    public static function localVersion(string $relDir): ?string
    {
        $f = base_path($relDir . '/module.json');
        if (!is_file($f)) return null;
        $m = json_decode((string) file_get_contents($f), true);
        return is_array($m) ? (string) ($m['version'] ?? '') : null;
    }

    /** Chép lại các tệp "deploy" của một module game đang cài (dùng sau khi cập nhật lõi). */
    public static function redeploy(string $folder): array
    {
        $dir = static::gamesPath(preg_replace('/[^A-Za-z0-9_\-]/', '', $folder));
        $m = is_file("$dir/module.json") ? json_decode((string) file_get_contents("$dir/module.json"), true) : null;
        $done = [];
        foreach ((array) ($m['deploy'] ?? []) as $from => $to) {
            $from = ltrim((string) $from, '/'); $to = ltrim((string) $to, '/');
            if (str_contains($from, '..') || str_contains($to, '..')) continue;
            $ok = false;
            foreach (self::DEPLOY_ALLOWED as $prefix) if (str_starts_with($to, $prefix)) $ok = true;
            if (!$ok) continue;
            if (is_file("$dir/$from")) { File::ensureDirectoryExists(dirname(base_path($to))); File::copy("$dir/$from", base_path($to)); $done[] = $to; }
            elseif (is_dir("$dir/$from")) { File::copyDirectory("$dir/$from", base_path($to)); $done[] = $to; }
        }
        return $done;
    }

    public static function installModuleZipPath(string $zipPath, ?int $userId = null): array
    {
        if (defined('CHIE_SHARED_ROOT')) throw new DomainError('Để giữ nguyên lượt chơi, hãy gộp module vào gói cập nhật nóng đầy đủ. Không chép đè module của bản đang hoạt động.');
        if (!class_exists(ZipArchive::class)) throw new DomainError('Máy chủ chưa bật PHP zip (ZipArchive).');
        $tmpDir = storage_path('app/module-install-' . bin2hex(random_bytes(5)));
        File::ensureDirectoryExists($tmpDir);
        try {
            $zip = new ZipArchive();
            if ($zip->open($zipPath) !== true) throw new DomainError('Không mở được tệp ZIP module.');
            for ($i = 0; $i < $zip->numFiles; $i++) {
                $name = (string) $zip->getNameIndex($i);
                if (str_contains($name, '..') || str_starts_with($name, '/') || str_contains($name, '\\')) {
                    $zip->close();
                    throw new DomainError('Gói ZIP chứa đường dẫn không an toàn: ' . $name);
                }
                if (in_array(strtolower(pathinfo($name, PATHINFO_EXTENSION)), self::BLOCKED_EXT, true) || str_ends_with(strtolower($name), '.htaccess')) {
                    $zip->close();
                    throw new DomainError('Vì an toàn, gói module không được chứa tệp thực thi (.php, .htaccess, .sh…): ' . $name);
                }
            }
            $zip->extractTo($tmpDir);
            $zip->close();

            $manifestPath = is_file("$tmpDir/module.json") ? "$tmpDir/module.json" : (glob("$tmpDir/*/module.json")[0] ?? null);
            if (!$manifestPath) throw new DomainError('Gói ZIP không có module.json.');
            $src = dirname($manifestPath);
            $m = json_decode((string) file_get_contents($manifestPath), true);
            if (!is_array($m) || ($m['app'] ?? '') !== 'chie-next-module') throw new DomainError('module.json không đúng định dạng chie-next-module.');
            $type = $m['type'] ?? '';
            $folder = preg_replace('/[^A-Za-z0-9_\-]/', '', (string) ($m['folder'] ?? ''));
            if (!in_array($type, ['game', 'grade'], true) || $folder === '') throw new DomainError('Loại module hoặc tên thư mục không hợp lệ.');
            if ($type === 'grade' && !preg_match('/^grade-(0[1-9]|1[0-2])$/', $folder)) throw new DomainError('Thư mục khối lớp phải là grade-01 … grade-12.');

            @unlink($src . '/MODULE_SDK_CONTRACT.md');   // bản hợp đồng do hệ thống quản lý
            $target = $type === 'game' ? static::gamesPath($folder) : static::gradesPath($folder);
            File::ensureDirectoryExists($target);
            File::copyDirectory($src, $target);

            $deployed = [];
            if ($type === 'game') {
                foreach ((array) ($m['deploy'] ?? []) as $from => $to) {
                    $from = ltrim(str_replace('\\', '/', (string) $from), '/');
                    $to = ltrim(str_replace('\\', '/', (string) $to), '/');
                    if (str_contains($from, '..') || str_contains($to, '..')) continue;
                    $ok = false;
                    foreach (self::DEPLOY_ALLOWED as $prefix) if (str_starts_with($to, $prefix)) $ok = true;
                    if (!$ok) throw new DomainError("Đích triển khai không được phép: {$to}");
                    if (is_dir("$target/$from")) {
                        File::ensureDirectoryExists(base_path($to));
                        File::copyDirectory("$target/$from", base_path($to));
                        $deployed[] = $to;
                    } elseif (is_file("$target/$from")) {
                        File::ensureDirectoryExists(dirname(base_path($to)));
                        File::copy("$target/$from", base_path($to));
                        $deployed[] = $to;
                    }
                }
            }
            $import = null;
            if ($type === 'grade' && !empty($m['grade_id'])) $import = static::syncGradeModule((int) $m['grade_id'], $userId);
            if ($type === 'game' && ($m['code'] ?? '') === 'zoo_garden') ZooGardenService::flushCatalog();
            Cache::forget('chie.modules.games');
            Cache::forget('chie.modules.grades');
            Audit::log('module.installed', ['Module', null], null, ['type' => $type, 'folder' => $folder, 'version' => $m['version'] ?? '?', 'deployed' => $deployed]);
            return ['type' => $type, 'folder' => $folder, 'name' => $m['name'] ?? $folder, 'version' => $m['version'] ?? '?', 'deployed' => $deployed, 'import' => $import];
        } finally {
            File::deleteDirectory($tmpDir);
        }
    }
}
