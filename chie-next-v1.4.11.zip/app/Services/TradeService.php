<?php

namespace App\Services;

use App\Models\InventoryItem;
use App\Models\TradeOffer;
use App\Models\User;
use App\Support\Settings;
use Illuminate\Support\Facades\DB;

/**
 * Cửa đổi đồ 1–1 (KHÔNG mua bán, không kèm Xu, không đặt giá):
 * - Ngoài gia đình: chỉ bạn cùng lớp (lớp giáo viên); đồ trang trí ↔ đồ trang trí CÙNG BẬC; tối đa 3 lần/tuần/cặp;
 *   tài khoản < 7 ngày chỉ đổi bậc Thường; đồ Tuyển chọn khóa 30 ngày và chỉ đổi 1 lần.
 * - Trong gia đình (anh chị em có chung phụ huynh): được đổi nông sản 1–1 hoặc đồ trang trí cùng bậc.
 */
class TradeService
{
    public static function partners(User $u)
    {
        $family = array_diff(RaidService::familyIds($u->id), [$u->id]);
        $classIds = DB::table('classroom_members')->where('student_id', $u->id)->where('status', 'active')->pluck('classroom_id');
        $mates = DB::table('classroom_members')->whereIn('classroom_id', $classIds)->where('status', 'active')->where('student_id', '<>', $u->id)->pluck('student_id')->all();
        $ids = array_unique(array_merge($family, $mates));
        return User::whereIn('id', $ids)->where('role', 'student')->where('status', 'active')->orderBy('name')->get()
            ->map(fn ($p) => ['user' => $p, 'family' => in_array($p->id, $family)]);
    }

    public static function isFamily(int $a, int $b): bool
    {
        return in_array($b, RaidService::familyIds($a), true) && $a !== $b;
    }

    public static function tradeable(User $u)
    {
        return InventoryItem::with('item')->where('user_id', $u->id)->where('placed', false)
            ->whereHas('item', fn ($q) => $q->whereIn('category', ['decor', 'gacha_only']))
            ->where(fn ($q) => $q->whereNull('trade_locked_until')->orWhere('trade_locked_until', '<', now()))->get()
            ->filter(fn ($i) => !($i->item->rarity === 'curated' && $i->trades_count >= 1));
    }

    protected static function weekCount(int $a, int $b): int
    {
        return TradeOffer::where('status', 'accepted')->where('resolved_at', '>=', now()->subDays(7))
            ->where(fn ($q) => $q->where(fn ($w) => $w->where('sender_id', $a)->where('receiver_id', $b))->orWhere(fn ($w) => $w->where('sender_id', $b)->where('receiver_id', $a)))->count();
    }

    protected static function checkItem(User $owner, InventoryItem $i): void
    {
        if ($i->user_id !== $owner->id) throw new DomainError('Vật phẩm không thuộc người đổi.');
        if ($i->placed) throw new DomainError('Hãy gỡ vật phẩm khỏi phòng trước khi đổi.');
        if (!in_array($i->item->category, ['decor', 'gacha_only'])) throw new DomainError('Chỉ đổi được đồ trang trí.');
        if ($i->trade_locked_until && $i->trade_locked_until->isFuture()) throw new DomainError('Vật phẩm Tuyển chọn còn khóa đổi đến ' . $i->trade_locked_until->format('d/m/Y') . '.');
        if ($i->item->rarity === 'curated' && $i->trades_count >= 1) throw new DomainError('Vật phẩm Tuyển chọn chỉ được đổi 1 lần.');
        $days = (int) Settings::get('trade.new_account_days', 7);
        if ($owner->created_at->gt(now()->subDays($days)) && $i->item->rarity !== 'common') throw new DomainError("Tài khoản mới dưới {$days} ngày chỉ đổi đồ bậc Thường.");
    }

    public static function create(User $u, int $partnerId, string $kind, ?int $myItem, ?int $theirItem, ?string $myProduce, ?string $theirProduce): TradeOffer
    {
        $partner = User::where('role', 'student')->where('status', 'active')->findOrFail($partnerId);
        if (!static::partners($u)->pluck('user.id')->contains($partner->id)) throw new DomainError('Chỉ đổi đồ với bạn cùng lớp hoặc người trong gia đình.');
        $family = static::isFamily($u->id, $partner->id);
        if (static::weekCount($u->id, $partner->id) >= (int) Settings::get('trade.weekly_per_pair', 3)) throw new DomainError('Hai bạn đã đổi đủ số lần trong tuần.');
        if (TradeOffer::where('status', 'pending')->where('sender_id', $u->id)->where('receiver_id', $partner->id)->exists()) throw new DomainError('Bạn đang có một lời mời chờ bạn ấy trả lời.');
        if ($kind === 'produce') {
            if (!$family) throw new DomainError('Chỉ người trong gia đình mới đổi nông sản cho nhau.');
            if (!$myProduce || !$theirProduce) throw new DomainError('Chọn nông sản hai bên.');
            if (FarmService::qty($u->id, 'outer', $myProduce) + FarmService::qty($u->id, 'inner', $myProduce) < 1) throw new DomainError('Bạn không có nông sản này.');
            return TradeOffer::create(['sender_id' => $u->id, 'receiver_id' => $partner->id, 'is_family' => true, 'kind' => 'produce',
                'sender_produce' => $myProduce, 'receiver_produce' => $theirProduce, 'status' => 'pending']);
        }
        $a = InventoryItem::with('item')->findOrFail($myItem);
        $b = InventoryItem::with('item')->findOrFail($theirItem);
        static::checkItem($u, $a);
        static::checkItem($partner, $b);
        if ($a->item->rarity !== $b->item->rarity) throw new DomainError('Chỉ đổi đồ cùng bậc hiếm (' . rarity_label($a->item->rarity) . ' ↔ ' . rarity_label($b->item->rarity) . ').');
        return TradeOffer::create(['sender_id' => $u->id, 'receiver_id' => $partner->id, 'is_family' => $family, 'kind' => 'decor',
            'sender_inventory_id' => $a->id, 'receiver_inventory_id' => $b->id, 'rarity' => $a->item->rarity, 'status' => 'pending']);
    }

    public static function respond(User $u, TradeOffer $o, string $action): string
    {
        return DB::transaction(function () use ($u, $o, $action) {
            $o = TradeOffer::whereKey($o->id)->lockForUpdate()->first();
            if ($o->status !== 'pending') throw new DomainError('Lời mời này đã được xử lý.');
            if ($action === 'cancel') { abort_unless($o->sender_id === $u->id, 404); $o->update(['status' => 'cancelled', 'resolved_at' => now()]); return 'Đã hủy lời mời.'; }
            abort_unless($o->receiver_id === $u->id, 404);
            if ($action === 'decline') { $o->update(['status' => 'declined', 'resolved_at' => now()]); return 'Đã từ chối.'; }
            $sender = User::find($o->sender_id);
            if ($o->created_at->lt(now()->subDays(3))) { $o->update(['status' => 'expired', 'resolved_at' => now()]); throw new DomainError('Lời mời đã quá hạn 3 ngày.'); }
            if (static::weekCount($o->sender_id, $o->receiver_id) >= (int) Settings::get('trade.weekly_per_pair', 3)) throw new DomainError('Hai bạn đã đổi đủ số lần trong tuần.');
            if ($o->kind === 'produce') {
                FarmService::lockFarm(min($o->sender_id, $o->receiver_id));
                FarmService::lockFarm(max($o->sender_id, $o->receiver_id));
                foreach ([[$o->sender_id, $o->sender_produce], [$o->receiver_id, $o->receiver_produce]] as [$uid, $code]) {
                    $loc = FarmService::qty($uid, 'outer', $code, true) > 0 ? 'outer' : (FarmService::qty($uid, 'inner', $code, true) > 0 ? 'inner' : null);
                    if (!$loc) throw new DomainError('Một bên không còn nông sản để đổi.');
                    FarmService::addStorage($uid, $loc, $code, -1);
                }
                FarmService::addStorage($o->sender_id, 'outer', $o->receiver_produce, 1);
                FarmService::addStorage($o->receiver_id, 'outer', $o->sender_produce, 1);
            } else {
                $a = InventoryItem::with('item')->lockForUpdate()->findOrFail($o->sender_inventory_id);
                $b = InventoryItem::with('item')->lockForUpdate()->findOrFail($o->receiver_inventory_id);
                static::checkItem($sender, $a);
                static::checkItem($u, $b);
                $a->update(['user_id' => $o->receiver_id, 'source' => 'trade', 'trades_count' => $a->trades_count + 1]);
                $b->update(['user_id' => $o->sender_id, 'source' => 'trade', 'trades_count' => $b->trades_count + 1]);
            }
            $o->update(['status' => 'accepted', 'resolved_at' => now()]);
            Notifier::send($o->sender_id, 'trade', $u->name . ' đã đồng ý đổi đồ với bạn', null, route('trade.index'));
            return 'Đổi đồ thành công!';
        });
    }
}
