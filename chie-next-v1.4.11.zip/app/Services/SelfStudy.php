<?php

namespace App\Services;

use App\Models\GrammarTopic;
use App\Models\User;
use Illuminate\Support\Facades\DB;

/**
 * Tự học theo lộ trình: ghép bài học (lộ trình), chủ điểm ngữ pháp và chủ đề từ vựng của lớp thành MỘT danh sách
 * theo thứ tự (2 bài học → 1 ngữ pháp → 1 từ vựng, lặp lại; ngữ pháp đi theo học kì).
 * Nhiệm vụ hôm nay = ôn tập đến hạn (nếu có) + 3 bước chưa xong đầu tiên → học sinh không phải đoán "học gì trước".
 */
class SelfStudy
{
    public const TODAY_STEPS = 3;

    public static function build(?User $u, int $g): array
    {
        $path = Curriculum::path($g, $u);
        $lessons = [];
        foreach ($path['units'] as $block) {
            foreach ($block['lessons'] as $row) {
                $l = $row['lesson'];
                $lessons[] = ['key' => 'l:' . $l->id, 'type' => 'lesson', 'icon' => 'book-open', 'tone' => 'green', 'title' => $l->title_vi,
                    'sub' => 'Bài học · ' . $block['unit']->title_vi, 'url' => route('learn.lesson', $l), 'start' => null,
                    'done' => in_array($row['state'], ['done', 'mastered'], true), 'locked' => $row['state'] === 'locked', 'sem' => (int) ($block['unit']->semester ?? 1)];
            }
        }

        $marked = $u ? (array) $u->setting('selfstudy_done', []) : [];
        $gStats = $u ? DB::table('skill_stats')->where('user_id', $u->id)->where('tag', 'like', 'gp:%')->groupBy('tag')
            ->selectRaw('tag, SUM(correct) c, SUM(total) t')->get()->keyBy('tag') : collect();
        $published = DB::table('questions')->where('status', 'published')->whereJsonDoesntContain('tags', 'gp-level:nang-cao')->where('tags', 'like', '%"gp:%')->pluck('tags')
            ->flatMap(fn ($j) => array_filter(json_decode($j, true) ?: [], fn ($t) => str_starts_with($t, 'gp:')))->countBy();
        $grammarReady = \Illuminate\Support\Facades\Schema::hasTable('grammar_topics');
        $grammar = ($grammarReady ? GrammarTopic::where('grade_id', $g)->where('track', 'core')->where('status', 'published')->orderBy('semester')->orderBy('sort')->get() : collect())
            ->map(function ($t) use ($gStats, $published, $marked) {
                $s = $gStats[$t->tag()] ?? null;
                $practised = $s && $s->t >= 5 && $s->c / $s->t >= 0.6;
                $canPractise = ($published[$t->tag()] ?? 0) >= 3;
                $key = 'g:' . $t->code;
                return ['key' => $key, 'type' => 'grammar', 'icon' => 'puzzle', 'tone' => 'violet', 'title' => $t->title_vi,
                    'sub' => 'Ngữ pháp · ' . ($canPractise ? 'đọc lý thuyết rồi luyện câu cơ bản' : 'đọc lý thuyết'), 'url' => route('grammar.show', $t->code),
                    'start' => $canPractise ? ['url' => 'api/grammar/start', 'body' => ['topic' => $t->code, 'level' => 'co-ban', 'from' => 'tu-hoc']] : null,
                    'done' => $practised || in_array($key, $marked, true), 'markable' => !$canPractise, 'locked' => false, 'sem' => (int) $t->semester];
            })->all();

        $learned = $u ? DB::table('srs_cards')->join('lexicon_items', 'lexicon_items.id', '=', 'srs_cards.item_id')
            ->where('srs_cards.user_id', $u->id)->where('srs_cards.item_type', 'word')->groupBy('lexicon_items.topic')
            ->selectRaw("COALESCE(lexicon_items.topic, '') t, COUNT(*) c")->pluck('c', 't') : collect();
        $vocab = DB::table('lexicon_items')->where('status', 'published')->where('grade_id', '<=', max($g, 3))->whereNotNull('topic')
            ->groupBy('topic')->selectRaw('topic, COUNT(*) c')->orderByDesc('c')->get()
            ->map(fn ($t) => ['key' => 'v:' . $t->topic, 'type' => 'vocab', 'icon' => 'languages', 'tone' => 'sky', 'title' => 'Từ vựng: ' . $t->topic,
                'sub' => 'Từ vựng · luyện 10 câu', 'url' => route('learn.words', ['chu-de' => $t->topic]),
                'start' => ['url' => 'api/words/start', 'body' => ['topic' => $t->topic, 'from' => 'tu-hoc']],
                'done' => (int) ($learned[$t->topic] ?? 0) >= min(10, (int) $t->c), 'locked' => false, 'sem' => 0])->all();

        // ghép: 2 bài học → 1 ngữ pháp → 1 từ vựng
        $steps = [];
        [$li, $gi, $vi] = [0, 0, 0];
        while ($li < count($lessons) || $gi < count($grammar) || $vi < count($vocab)) {
            for ($k = 0; $k < 2 && $li < count($lessons); $k++) $steps[] = $lessons[$li++];
            if ($gi < count($grammar)) $steps[] = $grammar[$gi++];
            if ($vi < count($vocab)) $steps[] = $vocab[$vi++];
        }
        foreach ($steps as $i => &$s) $s['n'] = $i + 1;
        unset($s);

        $today = array_slice(array_values(array_filter($steps, fn ($s) => !$s['done'] && !$s['locked'])), 0, self::TODAY_STEPS);
        $due = $u ? Curriculum::dueCount($u->id, $g) : ['questions' => 0, 'words' => 0];
        $dueN = $due['questions'] + $due['words'];
        if ($dueN > 0) {
            array_unshift($today, ['key' => 'review', 'type' => 'review', 'icon' => 'rotate-ccw', 'tone' => 'coral', 'title' => "Ôn tập {$dueN} câu & từ đến hạn",
                'sub' => 'Ôn trước để nhớ lâu (lịch 1 – 3 – 7 ngày)', 'url' => route('learn.review'), 'start' => ['url' => 'api/review/start', 'body' => (object) []],
                'done' => false, 'locked' => false, 'n' => 0]);
        }
        $doneToday = $u ? (int) DB::table('attempts')->where('user_id', $u->id)->where('grade_level', $g)->where('status', 'submitted')->where('submitted_at', '>=', today())->count() : 0;

        return ['steps' => $steps, 'today' => $today, 'done' => count(array_filter($steps, fn ($s) => $s['done'])), 'total' => count($steps), 'done_today' => $doneToday, 'grammarReady' => $grammarReady];
    }
}
