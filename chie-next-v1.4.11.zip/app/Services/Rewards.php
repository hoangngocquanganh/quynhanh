<?php

namespace App\Services;

use App\Models\Attempt;
use App\Models\User;
use App\Support\Settings;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;

/**
 * Thưởng XP/Xu — TÁCH KHỎI điểm thang 100.
 * XP = số câu đúng × XP/câu × hệ số độ khó (0,9–1,1) × hệ số tốc độ (1,0–1,2) × hệ số chuỗi đúng (1,0–1,3)
 * Xu = floor(XP × 0,5). Cày lại cùng bài trong ngày: lần 2 = 50%, từ lần 3 = 10%. Ôn đúng lịch SRS = 100%.
 * Không có hệ số theo lớp: lớp 1 và lớp 12 làm đúng như nhau nhận như nhau.
 */
class Rewards
{
    public static function eligible(User $u): bool
    {
        return \App\Support\Permissions::allows($u, 'rewards') && $u->status === 'active';   // v1.4: theo ma trận phân quyền (mặc định: học sinh, phụ huynh, admin)
    }

    /**
     * Khóa "cùng một bài" để giảm thưởng khi làm lại trong ngày. Lượt không có mã bài (luyện kỹ năng, chủ điểm ngữ pháp,
     * chủ đề từ vựng, đề ôn học kì) phân biệt bằng chủ điểm/mức/đề trong meta, nếu không thì bằng tiêu đề.
     * Ôn tập theo lịch SRS không bị giảm (đến hạn mới được ôn).
     */
    public static function repeatKey(Attempt $a): ?string
    {
        if (!$a->ref_type || ($a->kind === 'review' && $a->ref_type === 'srs')) return null;
        $m = $a->meta ?? [];
        $detail = $a->ref_id ? '' : implode('|', [$m['topic'] ?? '', $m['level'] ?? '', $m['test'] ?? '', $m['track'] ?? '', $m['game'] ?? '']);
        if ($detail === '' || $detail === '||||') $detail = $a->ref_id ? '' : (string) $a->title;
        return implode('#', [$a->kind, $a->ref_type, (string) $a->ref_id, $detail]);
    }

    public static function forAttempt(Attempt $a, Collection $items, User $user): void
    {
        if ($a->rewarded || in_array($a->kind, ['demo', 'raid'], true) || !static::eligible($user)) return;
        // đã làm bài (dù sai hết) vẫn tính là một ngày học → giữ chuỗi
        if ($items->whereNotNull('answered_at')->isNotEmpty()) Economy::touchStreak($user->id);
        $graded = $items->filter(fn ($i) => in_array($i->snapshot['type'], \App\Models\Question::AUTO_GRADED, true));
        $correct = $graded->where('is_correct', true);
        if ($correct->isEmpty()) {
            $a->rewarded = true; $a->save();
            return;
        }
        $perCorrect = (int) Settings::get('reward.xp_per_correct', 5);
        $avgDiff = max(1, min(5, (float) $graded->avg(fn ($i) => $i->snapshot['difficulty'] ?? 2)));
        $diff = 0.9 + ($avgDiff - 1) * 0.05;                             // 0,9 → 1,1
        $score = (int) $a->score_100;
        $times = $correct->whereNotNull('time_ms')->pluck('time_ms');
        $speed = 1.0;
        if ($score >= 60 && $times->count() >= 3) {
            $avg = $times->avg();
            $speed = $avg <= 6000 ? 1.2 : ($avg <= 10000 ? 1.1 : 1.0);
        }
        $streak = (int) $a->best_streak;
        $combo = $streak >= 20 ? 1.3 : ($streak >= 10 ? 1.2 : ($streak >= 5 ? 1.1 : 1.0));
        $xp = (int) round($correct->count() * $perCorrect * $diff * $speed * $combo);

        $note = [];
        $percent = 100;
        if ($key = static::repeatKey($a)) {
            $before = Attempt::where('user_id', $a->user_id)->where('kind', $a->kind)->where('ref_type', $a->ref_type)
                ->where('ref_id', $a->ref_id)->where('rewarded', true)->where('id', '<>', $a->id)
                ->where('submitted_at', '>=', today())->get(['id', 'kind', 'ref_type', 'ref_id', 'meta', 'title'])
                ->filter(fn ($x) => static::repeatKey($x) === $key)->count();
            if ($before === 1) { $percent = (int) Settings::get('reward.repeat_2_percent', 50); $note[] = "Làm lại lần 2 trong ngày: nhận {$percent}% thưởng."; }
            if ($before >= 2) { $percent = (int) Settings::get('reward.repeat_3_percent', 10); $note[] = "Làm lại từ lần 3 trong ngày: nhận {$percent}% thưởng. Hãy thử bài mới nhé!"; }
        }
        $xp = (int) floor($xp * $percent / 100);
        $xu = (int) floor($xp * (float) Settings::get('reward.xu_per_xp', 0.5));
        [$xp, $xu, $capped] = Economy::applyDailyCap($user->id, $xp, $xu);
        if ($capped) $note[] = 'Bạn đã chạm mức thưởng tối đa hôm nay. Điểm học vẫn được ghi đầy đủ.';

        if ($xp > 0 || $xu > 0) {
            Economy::grant($user->id, $xp, $xu, $a->kind === 'game' ? 'game_reward' : 'learn_reward', 'attempt:' . $a->id . ':reward',
                $a->kind . ':' . ($a->ref_type ?? '') . ':' . ($a->ref_id ?? ''), ['score_100' => $score, 'diff' => round($diff, 2), 'speed' => $speed, 'combo' => $combo, 'percent' => $percent]);
            Economy::bump($user->id, 'xp_earned', $xp);
            Economy::bump($user->id, 'xu_earned', $xu);
        }
        if ($bonus = DailyQuests::claimIfComplete($user)) $note[] = "Xong cả 3 nhiệm vụ hằng ngày: thưởng thêm +{$bonus['xp']} XP, +{$bonus['xu']} Xu!";
        $meta = $a->meta ?? [];
        if ($note) $meta['reward_note'] = implode(' ', $note);
        $a->meta = $meta;
        $a->xp_awarded = $xp;
        $a->xu_awarded = $xu;
        $a->rewarded = true;
        $a->save();
    }
}
