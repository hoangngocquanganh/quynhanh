<?php

namespace App\Services;

use App\Models\Assignment;
use App\Models\LexiconItem;
use App\Models\Question;
use App\Models\User;
use App\Models\ZooCatalogOverride;
use App\Support\Settings;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\DB;

/**
 * Zoo Garden 3D (game 5) trong Nông trại CHIE — v1.3.0.
 *
 * - Bản lưu game (JSON SaveState) nằm ở farms.zoo_save, mỗi học sinh một bản, có revision.
 * - Cách 2.1: đổi Xu (ví CHIE, sổ cái xu_ledger) → Năng lượng ϟ (tiền trong game). ϟ được giữ ở farms.zoo_pending_energy
 *   cho tới khi game xác nhận đã nhận (claimed_energy) nên không mất khi rớt mạng / chưa bấm Chơi.
 * - Playtime Gate: phút chơi miễn phí/ngày + phút thưởng (học bài, giải đố), có trần tối đa/ngày.
 * - Đố Tiếng Anh: ưu tiên Sổ lỗi (srs_cards) → từ vựng gắn với vật phẩm → ngân hàng câu hỏi đúng lớp → kho từ.
 * Bộ đếm theo ngày dùng daily_counters (Economy::counter/bump).
 */
class ZooGardenService
{
    /** key => [nhãn, kiểu, mặc định, tab] */
    public const SETTINGS_SCHEMA = [
        'zoo.enabled' => ['Bật thế giới 3D Zoo Garden tại /nong-trai (tắt = dùng nông trại cổ điển)', 'bool', true, 'general'],
        'zoo.default_language' => ['Ngôn ngữ mặc định trong game (vi | en)', 'string', 'vi', 'general'],
        'zoo.bilingual_labels' => ['Từ điển song ngữ Anh – Việt + nút loa TTS (🔊) khi chạm vật phẩm', 'bool', true, 'general'],
        'zoo.online_enabled' => ['Bật chơi Online nhiều người (cần máy chủ Node.js riêng — mặc định TẮT)', 'bool', false, 'general'],
        'zoo.online_server_url' => ['URL máy chủ WebSocket khi bật Online', 'string', '', 'general'],
        'zoo.online_shared_secret' => ['Khóa bí mật chung với máy chủ Online (ký vé đăng nhập; tối thiểu 32 ký tự, để trống = chưa dùng)', 'string', '', 'general'],
        'zoo.ai_neighbours_enabled' => ['Cho phép NPC AI hàng xóm trong làng (chơi đơn)', 'bool', true, 'general'],
        'zoo.xu_to_energy_rate' => ['Tỉ lệ đổi: 1 Xu CHIE = bao nhiêu Năng lượng ϟ', 'int', 10, 'general'],
        'zoo.daily_exchange_xu_cap' => ['Hạn mức đổi Xu → ϟ tối đa mỗi ngày (Xu)', 'int', 200, 'general'],
        'zoo.starting_energy' => ['Năng lượng ϟ tặng khi tạo nông trại mới', 'int', 100, 'general'],
        'zoo.playtime_gate_enabled' => ['Bật giới hạn phút chơi & học bài để nạp giờ (Playtime Gate)', 'bool', true, 'playtime'],
        'zoo.daily_free_minutes' => ['Số phút chơi miễn phí mỗi ngày', 'int', 30, 'playtime'],
        'zoo.quiz_unlock_questions' => ['Số câu Tiếng Anh mỗi lượt nạp giờ (cần đúng ≥ 80%)', 'int', 5, 'playtime'],
        'zoo.quiz_unlock_minutes' => ['Số phút cộng thêm mỗi lượt nạp giờ đạt', 'int', 15, 'playtime'],
        'zoo.lesson_unlock_minutes' => ['Số phút tự động thưởng khi hoàn thành 1 bài học / đề / bài giao đạt điểm', 'int', 20, 'playtime'],
        'zoo.daily_max_total_minutes' => ['Tổng phút chơi tối đa trong 1 ngày (bảo vệ mắt)', 'int', 90, 'playtime'],
        'zoo.srs_priority_enabled' => ['Ưu tiên rút câu hỏi từ Sổ lỗi (srs_cards) của học sinh', 'bool', true, 'playtime'],
        'zoo.care_quiz_speedup_percent' => ['Giảm thời gian chờ cây/thú khi giải đố chăm vườn (%)', 'int', 50, 'playtime'],
        'zoo.care_quiz_reward_energy' => ['Thưởng ϟ khi giải đố chăm vườn đúng', 'int', 25, 'playtime'],
        'zoo.care_quiz_reward_xp' => ['Thưởng XP CHIE khi giải đố chăm vườn đúng', 'int', 5, 'playtime'],
        'zoo.care_quiz_reward_xu' => ['Thưởng Xu CHIE khi giải đố chăm vườn đúng', 'int', 2, 'playtime'],
        'zoo.boost_quiz_reward_energy' => ['Thưởng ϟ khi giải đố Trạm Tri Thức đúng', 'int', 60, 'playtime'],
        'zoo.cook_quiz_reward_energy' => ['Thưởng ϟ khi giải đố Đầu bếp Tiếng Anh (Bếp) đúng', 'int', 40, 'playtime'],
        'zoo.dungeon_quiz_reward_energy' => ['Thưởng ϟ khi giải đố của Người gác hầm ngục đúng', 'int', 60, 'playtime'],
        'zoo.boost_quiz_reward_xp' => ['Thưởng XP CHIE khi giải đố 3 câu (Trạm Tri Thức / Bếp / Hầm ngục) đúng', 'int', 15, 'playtime'],
        'zoo.boost_quiz_reward_xu' => ['Thưởng Xu CHIE khi giải đố 3 câu (Trạm Tri Thức / Bếp / Hầm ngục) đúng', 'int', 8, 'playtime'],
        'zoo.daily_quiz_reward_limit' => ['Số lượt đố được thưởng tối đa mỗi ngày (chống cày)', 'int', 20, 'playtime'],
    ];

    public const CATEGORIES = ['crop', 'animal', 'fish', 'item', 'planet', 'service'];
    public const MAX_SAVE_BYTES = 3_000_000;

    public static function cfg(string $key)
    {
        $def = self::SETTINGS_SCHEMA[$key][2] ?? null;
        $type = self::SETTINGS_SCHEMA[$key][1] ?? 'string';
        $v = Settings::get($key, $def);
        return match ($type) { 'bool' => (bool) $v, 'int' => (int) $v, default => (string) $v };
    }

    public static function allSettings(bool $includeSecrets = false): array
    {
        $out = [];
        foreach (array_keys(self::SETTINGS_SCHEMA) as $k) {
            if (!$includeSecrets && str_ends_with($k, '_secret')) continue;   // không gửi khóa bí mật xuống trình duyệt
            $out[$k] = static::cfg($k);
        }
        return $out;
    }

    /** Thông số gốc của game (modules/games/game-5-zoo-garden/catalog.default.json). */
    public static function defaultCatalog(): array
    {
        static $cat = null;
        if ($cat !== null) return $cat;
        $file = base_path('modules/games/game-5-zoo-garden/catalog.default.json');
        $cat = is_file($file) ? (json_decode((string) file_get_contents($file), true) ?: []) : [];
        foreach (self::CATEGORIES as $c) $cat[$c] = $cat[$c] ?? [];
        return $cat;
    }

    public static function catalogOverrides(): array
    {
        return Cache::remember('chie.zoo.catalog_overrides', 3600, function () {
            try {
                $orig = [];
                foreach (static::defaultCatalog() as $cat => $list) {
                    if (is_array($list)) foreach ($list as $it) if (is_array($it) && isset($it['code'])) $orig[$cat][$it['code']] = $it['name_en'] ?? null;
                }
                return ZooCatalogOverride::all()->groupBy('category')->map(fn ($rows) => $rows->keyBy('item_code')->map(fn ($r) => array_filter([
                    'orig_en' => $orig[$r->category][$r->item_code] ?? null,
                    'name_vi' => $r->name_vi, 'name_en' => $r->name_en, 'desc_vi' => $r->desc_vi,
                    'price' => $r->price_energy, 'sell' => $r->sell_energy, 'level' => $r->min_level, 'grow_seconds' => $r->grow_seconds,
                    'enabled' => (bool) $r->is_enabled, 'extra' => $r->extra_json ?: null,
                ], fn ($v) => $v !== null))->all())->all();
            } catch (\Throwable $e) {
                return [];
            }
        });
    }

    public static function flushCatalog(): void
    {
        Cache::forget('chie.zoo.catalog_overrides');
    }

    /** Tệp JS/CSS của bản build (đọc manifest Vite). */
    public static function bundle(): array
    {
        $base = base_path('assets/zoo-garden');
        foreach (['chie-manifest.json', '.vite/manifest.json'] as $m) {
            if (!is_file("$base/$m")) continue;
            $man = json_decode((string) file_get_contents("$base/$m"), true) ?: [];
            foreach ($man as $entry) {
                if (!empty($entry['isEntry']) && !empty($entry['file'])) {
                    return ['js' => 'assets/zoo-garden/' . $entry['file'], 'css' => array_map(fn ($c) => 'assets/zoo-garden/' . $c, $entry['css'] ?? [])];
                }
            }
        }
        return ['js' => null, 'css' => []];
    }

    public static function playtimeState(User $u): array
    {
        $gateOn = (bool) static::cfg('zoo.playtime_gate_enabled');
        $freeMin = max(0, (int) static::cfg('zoo.daily_free_minutes'));
        $maxTotalMin = max($freeMin, (int) static::cfg('zoo.daily_max_total_minutes'));
        $bonusMin = Economy::counter($u->id, 'zoo_bonus_minutes');
        $allowedMin = min($maxTotalMin, $freeMin + $bonusMin);
        $allowedSec = $allowedMin * 60;
        $playedSec = Economy::counter($u->id, 'zoo_play_seconds');
        $remainingSec = max(0, $allowedSec - $playedSec);

        return [
            'gate_enabled' => $gateOn,
            'played_seconds' => $playedSec,
            'allowed_seconds' => $allowedSec,
            'remaining_seconds' => $gateOn ? $remainingSec : 86400,
            'is_locked' => $gateOn && $remainingSec <= 0,
            'can_unlock_more' => $allowedMin < $maxTotalMin,
            'unlock_questions_needed' => max(1, (int) static::cfg('zoo.quiz_unlock_questions')),
            'unlock_minutes_reward' => (int) static::cfg('zoo.quiz_unlock_minutes'),
            'lesson_unlock_minutes' => (int) static::cfg('zoo.lesson_unlock_minutes'),
            'max_total_minutes' => $maxTotalMin,
        ];
    }

    /** Gọi khi học sinh hoàn thành bài học / đề / bài giao đạt điểm (AttemptService::submit). */
    public static function rewardLessonMinutes(int $userId): void
    {
        $min = (int) static::cfg('zoo.lesson_unlock_minutes');
        if ($min > 0) Economy::bump($userId, 'zoo_bonus_minutes', $min);
    }

    public static function guestPayload(): array
    {
        return [
            'guest'=>true,'release'=>defined('CHIE_RELEASE_ID') ? CHIE_RELEASE_ID : 'root','assetBase'=>rtrim(asset('assets/zoo-garden'),'/').'/', 'csrfToken'=>'',
            'endpoints'=>['boot'=>'','save'=>'','exchange'=>'','quizStart'=>'','quizSubmit'=>'','back'=>route('game.home'),'learn'=>route('learn.home')],
            'student'=>['id'=>0,'name'=>'Khách','grade_level'=>current_grade()??3,'xu'=>0,'xp'=>0,'level'=>1,'streak_days'=>0],
            'exchange'=>['rate'=>1,'daily_cap_xu'=>0,'exchanged_today_xu'=>0],
            'playtime'=>['gate_enabled'=>false,'played_seconds'=>0,'allowed_seconds'=>86400,'remaining_seconds'=>86400,'is_locked'=>false,'can_unlock_more'=>false,'unlock_questions_needed'=>0,'unlock_minutes_reward'=>0,'lesson_unlock_minutes'=>0,'max_total_minutes'=>1440],
            'learning'=>['due_srs_count'=>0,'pending_assignments'=>0,'quiz_correct_today'=>0,'srs_cleared_today'=>0,'tts_default_rate'=>0.75,'tts_slow_rate'=>0.65],
            'settings'=>array_merge(static::allSettings(),['zoo.online_enabled'=>false]),
            'catalogOverrides'=>(object)static::catalogOverrides(),'save'=>null,'revision'=>0,'pending_energy'=>0,
            'online'=>['enabled'=>false,'server_url'=>'','ticket_endpoint'=>''],
        ];
    }

    public static function bootPayload(User $u): array
    {
        $farm = FarmService::farm($u->id);
        $wallet = Economy::walletFor($u->id);
        $save = $farm->zoo_save ? json_decode($farm->zoo_save, true) : null;
        $g = (int) ($u->grade_level ?: 3);
        $due = Curriculum::dueCount($u->id, $g);
        $pending = 0;
        try {
            $classIds = DB::table('classroom_members')->where('student_id', $u->id)->where('status', 'active')->pluck('classroom_id');
            $pending = Assignment::whereIn('classroom_id', $classIds)->where('status', 'published')
                ->where(fn ($q) => $q->where('target', 'class')->orWhereExists(fn ($e) => $e->from('assignment_targets')->whereColumn('assignment_targets.assignment_id', 'assignments.id')->where('student_id', $u->id)))
                ->whereDoesntHave('submissions', fn ($q) => $q->where('student_id', $u->id)->whereIn('status', ['submitted', 'graded', 'returned']))
                ->count();
        } catch (\Throwable $e) {
            $pending = 0;
        }

        return [
            'assetBase' => rtrim(asset('assets/zoo-garden'), '/') . '/',
            'release' => defined('CHIE_RELEASE_ID') ? CHIE_RELEASE_ID : 'root',
            'csrfToken' => csrf_token(),
            'endpoints' => [
                'boot' => route('api.farm.zoo.boot'), 'save' => route('api.farm.zoo.save'), 'exchange' => route('api.farm.zoo.exchange'),
                'quizStart' => route('api.farm.zoo.quiz.start'), 'quizSubmit' => route('api.farm.zoo.quiz.submit'),
                'back' => route('game.home'), 'learn' => route('learn.home'),
            ],
            'student' => [
                'id' => $u->id, 'name' => mb_substr((string) $u->name, 0, 20), 'grade_level' => $g,
                'xu' => (int) $wallet->xu, 'xp' => (int) $wallet->xp, 'level' => (int) $wallet->level, 'streak_days' => (int) $wallet->streak_days,
            ],
            'exchange' => [
                'rate' => max(1, (int) static::cfg('zoo.xu_to_energy_rate')),
                'daily_cap_xu' => (int) static::cfg('zoo.daily_exchange_xu_cap'),
                'exchanged_today_xu' => Economy::counter($u->id, 'zoo_exchanged_xu'),
            ],
            'playtime' => static::playtimeState($u),
            'learning' => [
                'due_srs_count' => (int) (($due['questions'] ?? 0) + ($due['words'] ?? 0)),
                'pending_assignments' => $pending,
                'quiz_correct_today' => Economy::counter($u->id, 'zoo_quiz_correct'),
                'srs_cleared_today' => Economy::counter($u->id, 'zoo_srs_cleared'),
                'tts_default_rate' => (float) ($u->setting('tts_rate') ?? Settings::get('tts.default_rate', 0.75)),
                'tts_slow_rate' => (float) Settings::get('tts.slow_rate', 0.65),
            ],
            'settings' => static::allSettings(),
            'catalogOverrides' => (object) static::catalogOverrides(),
            'save' => is_array($save) ? $save : null,
            'revision' => (int) ($farm->zoo_revision ?? 0),
            'pending_energy' => (int) ($farm->zoo_pending_energy ?? 0),
            'online' => [
                'enabled' => (bool) static::cfg('zoo.online_enabled') && strlen((string) static::cfg('zoo.online_shared_secret')) >= 32 && static::cfg('zoo.online_server_url') !== '',
                'server_url' => (string) static::cfg('zoo.online_server_url'),
                'ticket_endpoint' => route('api.farm.zoo.ticket'),
            ],
        ];
    }

    /**
     * Lưu bản game. $saveJson null = chỉ báo phút chơi / xác nhận ϟ đã nhận.
     * Game là chơi đơn (client giữ luật), máy chủ chỉ kiểm tra định dạng & kích thước.
     */
    public static function saveState(User $u, ?string $saveJson, int $clientRevision, int $activeSecondsDelta, int $claimedEnergy = 0): array
    {
        $delta = max(0, min(120, $activeSecondsDelta));
        // chống gửi trùng: không cộng quá thời gian thực kể từ lần báo trước (+5 giây dung sai)
        $lastKey = 'chie.zoo.last_tick.' . $u->id;
        $last = (int) Cache::get($lastKey, 0);
        if ($last > 0) $delta = min($delta, max(0, time() - $last + 5));
        Cache::put($lastKey, time(), 600);
        if ($delta > 0) Economy::bump($u->id, 'zoo_play_seconds', $delta);
        LiveStatus::touch($u->id, 'farm', 'Zoo Garden 3D');

        $save = null;
        if ($saveJson !== null && $saveJson !== '') {
            if (strlen($saveJson) > self::MAX_SAVE_BYTES) throw new DomainError('Bản lưu quá lớn.');
            $save = json_decode($saveJson, true);
            if (!is_array($save) || !isset($save['version']) || !isset($save['plots'])) throw new DomainError('Bản lưu không đúng định dạng Zoo Garden.');
            $save['name'] = mb_substr((string) $u->name, 0, 20);
        }

        return DB::transaction(function () use ($u, $save, $clientRevision, $claimedEnergy) {
            $f = FarmService::lockFarm($u->id);
            if ($claimedEnergy > 0) $f->zoo_pending_energy = max(0, (int) $f->zoo_pending_energy - $claimedEnergy);
            if ($save !== null) {
                $f->zoo_save = json_encode($save, JSON_UNESCAPED_UNICODE);
                $f->zoo_revision = max((int) $f->zoo_revision, $clientRevision) + 1;
                $f->zoo_updated_at = now();
            }
            $f->save();
            return [
                'ok' => true,
                'revision' => (int) $f->zoo_revision,
                'pending_energy' => (int) $f->zoo_pending_energy,
                'playtime' => static::playtimeState($u),
                'wallet' => Economy::walletFor($u->id)->only(['xu', 'xp', 'level']),
            ];
        });
    }

    public static function exchangeXuToEnergy(User $u, int $xuAmount): array
    {
        if ($xuAmount < 1) throw new DomainError('Số Xu cần đổi phải từ 1 trở lên.');
        $rate = max(1, (int) static::cfg('zoo.xu_to_energy_rate'));
        $cap = max(0, (int) static::cfg('zoo.daily_exchange_xu_cap'));

        return DB::transaction(function () use ($u, $xuAmount, $rate, $cap) {
            Economy::lock($u->id); // tuần tự hoá các lượt đổi của cùng học sinh
            $used = Economy::counter($u->id, 'zoo_exchanged_xu');
            if ($used + $xuAmount > $cap) {
                $left = max(0, $cap - $used);
                throw new DomainError("Hôm nay bạn chỉ còn đổi được tối đa {$left} Xu (hạn mức {$cap} Xu/ngày).");
            }
            $f = FarmService::lockFarm($u->id);
            $energy = $xuAmount * $rate;
            $key = 'zooex:' . $u->id . ':' . bin2hex(random_bytes(8));
            Economy::spend($u->id, $xuAmount, 'zoo_exchange', $key, 'zoo', ['xu' => $xuAmount, 'energy' => $energy]);
            Economy::bump($u->id, 'zoo_exchanged_xu', $xuAmount);
            $f->zoo_pending_energy = (int) $f->zoo_pending_energy + $energy;
            $f->save();
            $w = Economy::walletFor($u->id);
            return [
                'ok' => true, 'xu_spent' => $xuAmount, 'energy_added' => $energy, 'xu_balance' => (int) $w->xu,
                'exchanged_today_xu' => $used + $xuAmount, 'daily_cap_xu' => $cap,
                'message' => "Đã đổi {$xuAmount} Xu thành +" . number_format($energy, 0, ',', '.') . ' ϟ Năng lượng!',
            ];
        });
    }

    // ------------------------------------------------------------------ đố Tiếng Anh

    protected static function questionItem(Question $q, bool $fromSrs): array
    {
        $snap = Grader::build($q, 4);
        $pub = Grader::publicView($snap, false);
        $pub['from_srs'] = $fromSrs;
        return ['public' => $pub, 'key' => $snap['key'], 'st' => 'question', 'si' => $q->id, 'e' => $snap['explanation_vi'] ?? ''];
    }

    protected static function wordItem(LexiconItem $w, $pool, bool $fromSrs): array
    {
        $snap = Grader::buildWord($w, $pool, (bool) random_int(0, 1));
        $pub = Grader::publicView($snap, false);
        $pub['from_srs'] = $fromSrs;
        return ['public' => $pub, 'key' => $snap['key'], 'st' => 'word', 'si' => $w->id, 'e' => $snap['explanation_vi'] ?? ''];
    }

    /** Từ vựng Admin gắn với mã vật phẩm (zoo_catalog_overrides.extra_json.words). */
    protected static function targetWords(?string $code): array
    {
        if (!$code) return [];
        foreach (static::catalogOverrides() as $rows) {
            $w = $rows[$code]['extra']['words'] ?? null;
            if (is_array($w) && count($w) >= 2) return $w;
        }
        return [];
    }

    public static function startQuiz(User $u, string $context, ?string $targetCode = null): array
    {
        $g = (int) ($u->grade_level ?: 3);
        $count = match ($context) {
            'playtime_unlock' => max(1, min(15, (int) static::cfg('zoo.quiz_unlock_questions'))),
            'space', 'dungeon', 'cook' => 3,
            default => 1,
        };
        if ($context === 'playtime_unlock' && !static::playtimeState($u)['can_unlock_more']) {
            throw new DomainError('Hôm nay đã đạt số phút chơi tối đa. Hẹn gặp lại ngày mai nhé!');
        }
        $items = [];
        $usedQ = [];
        $usedW = [];

        // 1. Sổ lỗi đến hạn (câu hỏi + từ vựng)
        if ((bool) static::cfg('zoo.srs_priority_enabled')) {
            $cards = DB::table('srs_cards')->where('user_id', $u->id)->where('due_at', '<=', now())->where('stage', '<', 3)
                ->inRandomOrder()->limit($count * 3)->get(['item_type', 'item_id']);
            $qIds = $cards->where('item_type', 'question')->pluck('item_id')->all();
            $wIds = $cards->where('item_type', 'word')->pluck('item_id')->all();
            if ($qIds) {
                foreach (Question::published()->whereIn('id', $qIds)->whereIn('type', ['mcq', 'listen_mcq'])->get() as $q) {
                    if (count($items) >= $count) break;
                    if (count($q->options ?? []) < 2) continue;
                    $items[] = static::questionItem($q, true);
                    $usedQ[] = $q->id;
                }
            }
            if (count($items) < $count && $wIds) {
                $pool = LexiconItem::where('status', 'published')->where('grade_id', '<=', max(3, $g))->inRandomOrder()->limit(30)->get();
                foreach (LexiconItem::whereIn('id', $wIds)->where('status', 'published')->get() as $w) {
                    if (count($items) >= $count || $pool->count() < 4) break;
                    $items[] = static::wordItem($w, $pool, true);
                    $usedW[] = $w->id;
                }
            }
        }

        // 2. Từ vựng gắn với vật phẩm đang tương tác (Admin nhập)
        $words = static::targetWords($targetCode);
        if (count($items) < $count && $words) {
            $pick = $words[array_rand($words)];
            $opts = collect($words)->pluck(1)->unique()->shuffle()->take(4)->values()->all();
            if (!in_array($pick[1], $opts, true)) $opts[0] = $pick[1];
            $opts = Grader::shuffle($opts);
            $items[] = [
                'public' => ['type' => 'mcq', 'skill' => 'vocabulary', 'from_srs' => false, 'prompt' => ['text' => "“{$pick[0]}” nghĩa là gì?", 'speak_word' => $pick[0]], 'display' => ['options' => $opts]],
                'key' => ['correct_index' => array_search($pick[1], $opts, true), 'correct_text' => $pick[1]],
                'st' => null, 'si' => null, 'e' => "{$pick[0]} = {$pick[1]}.",
            ];
        }

        // 3. Ngân hàng câu hỏi trắc nghiệm đã duyệt của lớp
        $need = $count - count($items);
        if ($need > 0) {
            $rows = Question::published()->where('grade_id', $g)->whereIn('type', ['mcq', 'listen_mcq'])
                ->whereNotIn('id', $usedQ ?: [0])->inRandomOrder()->limit($need * 2)->get();
            foreach ($rows as $q) {
                if (count($items) >= $count) break;
                if (count($q->options ?? []) < 2) continue;
                $items[] = static::questionItem($q, false);
            }
        }

        // 4. Kho từ vựng (dự phòng khi lớp chưa đủ câu hỏi)
        if (count($items) < $count) {
            $pool = LexiconItem::where('status', 'published')->where('grade_id', '<=', max(3, $g))->inRandomOrder()->limit(40)->get();
            foreach ($pool as $w) {
                if (count($items) >= $count || $pool->count() < 4) break;
                if (in_array($w->id, $usedW, true)) continue;
                $items[] = static::wordItem($w, $pool, false);
            }
        }

        if (!$items) throw new DomainError('Lớp của bạn chưa có câu hỏi đã duyệt. Hãy nhờ thầy cô / Admin nhập học liệu.');

        $token = Crypt::encryptString(json_encode([
            'u' => $u->id, 'ctx' => $context, 'target' => $targetCode,
            'items' => array_map(fn ($it) => ['k' => $it['key'], 'st' => $it['st'], 'si' => $it['si'], 'e' => $it['e']], $items),
            'exp' => now()->addMinutes(20)->timestamp, 'n' => bin2hex(random_bytes(6)),
        ]));

        return ['token' => $token, 'context' => $context, 'target_code' => $targetCode, 'questions' => array_column($items, 'public')];
    }

    public static function submitQuiz(User $u, string $token, array $answers): array
    {
        try {
            $data = json_decode(Crypt::decryptString($token), true);
        } catch (\Throwable $e) {
            throw new DomainError('Phiên câu đố không hợp lệ, vui lòng thử lại.');
        }
        if (!is_array($data) || ($data['u'] ?? 0) !== $u->id || ($data['exp'] ?? 0) < time()) {
            throw new DomainError('Câu đố đã hết hạn, vui lòng mở lượt mới.');
        }
        if (!DB::table('daily_counters')->insertOrIgnore(['user_id' => $u->id, 'day' => today()->toDateString(), 'key' => 'zooquiz:' . $data['n'], 'value' => 1])) {
            throw new DomainError('Lượt câu đố này đã được chấm.');
        }

        $iv = Learning::intervals();
        $items = $data['items'] ?? [];
        $total = count($items);
        $correct = 0;
        $srsCleared = 0;
        $feedback = [];
        $now = now();

        foreach ($items as $idx => $it) {
            $choice = $answers[$idx] ?? -1;
            $ok = is_numeric($choice) && ($it['k']['correct_index'] ?? null) !== null && (int) $choice === (int) $it['k']['correct_index'];
            if ($ok) $correct++;
            if (!empty($it['st']) && !empty($it['si'])) {
                $card = DB::table('srs_cards')->where('user_id', $u->id)->where('item_type', $it['st'])->where('item_id', $it['si'])->first();
                if ($ok && $card) {
                    $stage = min(3, (int) $card->stage + 1);
                    DB::table('srs_cards')->where('id', $card->id)->update([
                        'stage' => $stage,
                        'due_at' => $stage >= 3 ? $now->copy()->addDays(30) : $now->copy()->addDays($iv[$stage] ?? 7),
                        'last_reviewed_at' => $now, 'last_correct' => true, 'updated_at' => $now,
                    ]);
                    $srsCleared++;
                } elseif (!$ok) {
                    DB::table('srs_cards')->updateOrInsert(
                        ['user_id' => $u->id, 'item_type' => $it['st'], 'item_id' => $it['si']],
                        ['grade_level' => $u->grade_level ?: 3, 'stage' => 0, 'lapses' => ($card->lapses ?? 0) + ($card ? 1 : 0),
                            'due_at' => $now->copy()->addDays($iv[0] ?? 1), 'last_reviewed_at' => $now, 'last_correct' => false,
                            'updated_at' => $now, 'created_at' => $card->created_at ?? $now]
                    );
                }
            }
            $feedback[] = ['is_correct' => $ok, 'correct_index' => $it['k']['correct_index'] ?? null, 'correct_text' => $it['k']['correct_text'] ?? null, 'explanation_vi' => $it['e'] ?? ''];
        }

        Economy::bump($u->id, 'zoo_quiz_total', $total);
        if ($correct > 0) Economy::bump($u->id, 'zoo_quiz_correct', $correct);
        if ($srsCleared > 0) Economy::bump($u->id, 'zoo_srs_cleared', $srsCleared);

        $ctx = $data['ctx'] ?? 'care';
        $passed = $ctx === 'playtime_unlock' ? $correct >= max(1, (int) ceil($total * 0.8)) : $correct === $total;
        $xp = $xu = $energy = $minutes = 0;

        if ($passed) {
            if ($ctx === 'playtime_unlock') {
                $before = static::playtimeState($u);
                if ($before['can_unlock_more']) {
                    $minutes = (int) static::cfg('zoo.quiz_unlock_minutes');
                    Economy::bump($u->id, 'zoo_bonus_minutes', $minutes);
                }
            } elseif (Economy::counter($u->id, 'zoo_quiz_rewards') < (int) static::cfg('zoo.daily_quiz_reward_limit')) {
                Economy::bump($u->id, 'zoo_quiz_rewards', 1);
                $care = $ctx === 'care';
                $rawXp = (int) static::cfg($care ? 'zoo.care_quiz_reward_xp' : 'zoo.boost_quiz_reward_xp');
                $rawXu = (int) static::cfg($care ? 'zoo.care_quiz_reward_xu' : 'zoo.boost_quiz_reward_xu');
                $energy = max(0, (int) static::cfg(match ($ctx) {
                    'care' => 'zoo.care_quiz_reward_energy', 'cook' => 'zoo.cook_quiz_reward_energy',
                    'dungeon' => 'zoo.dungeon_quiz_reward_energy', default => 'zoo.boost_quiz_reward_energy',
                }));
                [$xp, $xu] = Economy::applyDailyCap($u->id, $rawXp, $rawXu);
                DB::transaction(function () use ($u, $xp, $xu, $ctx, $data, $energy) {
                    if ($xp > 0 || $xu > 0) {
                        Economy::grant($u->id, $xp, $xu, 'zoo_quiz', 'zooquiz:' . $u->id . ':' . $data['n'], 'zoo:' . $ctx);
                        if ($xp > 0) Economy::bump($u->id, 'xp_earned', $xp);
                        if ($xu > 0) Economy::bump($u->id, 'xu_earned', $xu);
                    }
                    if ($energy > 0) {
                        $f = FarmService::lockFarm($u->id);
                        $f->zoo_pending_energy = (int) $f->zoo_pending_energy + $energy;
                        $f->save();
                    }
                });
            }
        }

        return [
            'passed' => $passed, 'correct_count' => $correct, 'total' => $total, 'srs_cleared' => $srsCleared,
            'xp_awarded' => $xp, 'xu_awarded' => $xu, 'energy_bonus' => $energy,
            'speedup_percent' => $passed && $ctx === 'care' ? (int) static::cfg('zoo.care_quiz_speedup_percent') : 0,
            'minutes_added' => $minutes, 'feedback' => $feedback,
            'playtime' => static::playtimeState($u),
            'wallet' => Economy::walletFor($u->id)->only(['xu', 'xp', 'level']),
        ];
    }

    /**
     * Vé đăng nhập 1 lần cho máy chủ Online (Node.js) — chuẩn bị sẵn cho bản online sau này.
     * Định dạng: base64url(JSON payload) + "." + base64url(HMAC-SHA256(payload, zoo.online_shared_secret)).
     * Payload: {v:1, uid, name, grade, role:"student", iat, exp (60 giây), nonce}. Máy chủ Node kiểm chữ ký + hạn + nonce dùng 1 lần.
     */
    public static function onlineTicket(User $u): array
    {
        if (!static::cfg('zoo.online_enabled')) throw new DomainError('Chế độ Online đang tắt.');
        $secret = (string) static::cfg('zoo.online_shared_secret');
        if (strlen($secret) < 32) throw new DomainError('Admin chưa đặt khóa bí mật Online (tối thiểu 32 ký tự).');
        $b64 = fn (string $s) => rtrim(strtr(base64_encode($s), '+/', '-_'), '=');
        $now = time();
        $payload = $b64(json_encode(['v' => 1, 'uid' => $u->id, 'name' => mb_substr((string) $u->name, 0, 20), 'grade' => (int) ($u->grade_level ?: 0),
            'role' => 'student', 'iat' => $now, 'exp' => $now + 60, 'nonce' => bin2hex(random_bytes(12))], JSON_UNESCAPED_UNICODE));
        return ['ticket' => $payload . '.' . $b64(hash_hmac('sha256', $payload, $secret, true)), 'server_url' => (string) static::cfg('zoo.online_server_url'), 'expires_in' => 60];
    }

    /** Thống kê 7 ngày cho Phụ huynh / Giáo viên (StudentReport). */
    public static function weeklyStats(int $userId): array
    {
        $since = now()->subDays(6)->toDateString();
        $today = today()->toDateString();
        $rows = DB::table('daily_counters')->where('user_id', $userId)->where('day', '>=', $since)
            ->whereIn('key', ['zoo_play_seconds', 'zoo_quiz_correct', 'zoo_quiz_total', 'zoo_srs_cleared', 'zoo_exchanged_xu'])
            ->get(['key', 'day', 'value']);
        $sum = fn (string $k) => (int) $rows->where('key', $k)->sum('value');
        $todayVal = fn (string $k) => (int) $rows->where('key', $k)->filter(fn ($r) => (string) $r->day === $today || str_starts_with((string) $r->day, $today))->sum('value');
        $qTotal = $sum('zoo_quiz_total');
        $qCorrect = $sum('zoo_quiz_correct');
        return [
            'today_play_minutes' => (int) round($todayVal('zoo_play_seconds') / 60),
            'week_play_minutes' => (int) round($sum('zoo_play_seconds') / 60),
            'daily_free_minutes' => (int) static::cfg('zoo.daily_free_minutes'),
            'week_quiz_correct' => $qCorrect,
            'week_quiz_total' => $qTotal,
            'week_quiz_accuracy' => $qTotal > 0 ? (int) round($qCorrect / $qTotal * 100) : null,
            'week_srs_cleared' => $sum('zoo_srs_cleared'),
            'week_exchanged_xu' => $sum('zoo_exchanged_xu'),
            'has_activity' => $rows->isNotEmpty(),
        ];
    }
}
