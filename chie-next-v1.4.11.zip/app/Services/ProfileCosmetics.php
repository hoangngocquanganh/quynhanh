<?php

namespace App\Services;

use App\Models\User;
use Illuminate\Support\Facades\DB;

class ProfileCosmetics
{
    public const AVATARS = [
        'initials' => ['Chữ tên', ''], 'sprout' => ['Mầm xanh', '🌱'], 'fox' => ['Cáo nhỏ', '🦊'], 'cat' => ['Mèo con', '🐱'],
        'dog' => ['Cún vui', '🐶'], 'panda' => ['Gấu trúc', '🐼'], 'bear' => ['Gấu nâu', '🐻'], 'rabbit' => ['Thỏ trắng', '🐰'],
        'tiger' => ['Hổ con', '🐯'], 'lion' => ['Sư tử', '🦁'], 'owl' => ['Cú thông thái', '🦉'], 'penguin' => ['Chim cánh cụt', '🐧'],
        'frog' => ['Ếch xanh', '🐸'], 'koala' => ['Gấu túi', '🐨'], 'unicorn' => ['Kỳ lân', '🦄'], 'dragon' => ['Rồng nhỏ', '🐲'],
        'astronaut' => ['Phi hành gia', '🧑‍🚀'], 'robot' => ['Robot', '🤖'], 'ninja' => ['Ninja', '🥷'], 'wizard' => ['Phù thủy', '🧙'],
        'whale' => ['Cá voi', '🐳'], 'dolphin' => ['Cá heo', '🐬'], 'turtle' => ['Rùa xanh', '🐢'], 'butterfly' => ['Bươm bướm', '🦋'],
        'bee' => ['Ong chăm học', '🐝'], 'otter' => ['Rái cá tinh anh', '🦦'], 'peacock' => ['Khổng tước', '🦚'],
        'eagle' => ['Đại bàng', '🦅'], 'snowleopard' => ['Báo tuyết', '🐆'], 'moon' => ['Sứ giả mặt trăng', '🌙'],
        'comet' => ['Sao băng', '☄️'], 'phoenix' => ['Phượng hoàng', '🐦‍🔥'], 'crystal' => ['Tinh linh pha lê', '💎'],
        'sun' => ['Thần mặt trời', '🌞'],
    ];
    /** Avatar cũ giữ nguyên; nhân vật thưởng tự mở theo cấp, không cần mua hay quay thưởng. */
    public const AVATAR_LEVELS = ['bee'=>3, 'otter'=>6, 'peacock'=>10, 'eagle'=>15, 'snowleopard'=>20,
        'moon'=>30, 'comet'=>45, 'phoenix'=>60, 'crystal'=>80, 'sun'=>100];
    public const RARITIES = ['common'=>'Phổ thông', 'uncommon'=>'Đặc biệt', 'rare'=>'Hiếm',
        'epic'=>'Sử thi', 'legendary'=>'Huyền thoại', 'mythic'=>'Thần thoại'];

    public static function rarityFor(int $level): string
    {
        return match (true) { $level >= 60 => 'mythic', $level >= 30 => 'legendary', $level >= 15 => 'epic',
            $level >= 6 => 'rare', $level >= 3 => 'uncommon', default => 'common' };
    }
    public const COLORS = ['mint' => 'Xanh mầm', 'sky' => 'Xanh trời', 'blush' => 'Hồng đào', 'lilac' => 'Tím nhạt', 'sand' => 'Vàng kem', 'night' => 'Đêm xanh'];
    /** mã => [tên, kiểu hiển thị, cấp, số huy hiệu, điều kiện] */
    public const FRAMES = [
        'auto' => ['Theo rank hiện tại', 'leaf', 1, 0, 'Tự đổi khi lên rank'],
        'none' => ['Không khung', 'none', 1, 0, 'Có sẵn'], 'leaf' => ['Sắt', 'leaf', 1, 0, 'Có sẵn'],
        'sky' => ['Đồng', 'sky', 3, 0, 'Đạt cấp 3'], 'coral' => ['Bạc', 'coral', 5, 0, 'Đạt cấp 5'],
        'violet' => ['Vàng', 'violet', 8, 0, 'Đạt cấp 8'], 'gold' => ['Bạch Kim', 'gold', 10, 0, 'Đạt cấp 10'],
        'aurora' => ['Lục Bảo', 'aurora', 15, 0, 'Đạt cấp 15'], 'crown' => ['Kim Cương', 'crown', 20, 0, 'Đạt cấp 20'],
        'galaxy' => ['Cao Thủ', 'galaxy', 30, 0, 'Đạt cấp 30'], 'scholar' => ['Học giả', 'scholar', 1, 5, 'Có 5 huy hiệu'],
        'collector' => ['Nhà sưu tập', 'collector', 1, 12, 'Có 12 huy hiệu'], 'legend' => ['Huyền thoại', 'legend', 1, 25, 'Có 25 huy hiệu'],
        'royal' => ['Đại Cao Thủ', 'royal', 45, 0, 'Đạt cấp 45'],
        'celestial' => ['Thách Đấu', 'celestial', 60, 0, 'Đạt cấp 60'],
        'phoenix' => ['Cánh phượng hoàng', 'phoenix', 80, 0, 'Đạt cấp 80'],
        'eternal' => ['Thiên Long', 'eternal', 100, 0, 'Đạt cấp 100'],
    ];

    public static function options(User $u): array
    {
        $level = (int) (DB::table('wallets')->where('user_id', $u->id)->value('level') ?? 1);
        $earned = Badges::earned($u); $frames = []; $avatarRules = []; $rewards = [];
        foreach (self::AVATARS as $id => [$name, $symbol]) {
            $min = self::AVATAR_LEVELS[$id] ?? 1;
            $rarity = self::rarityFor($min);
            $avatarRules[$id] = ['level'=>$min, 'unlocked'=>$u->isAdmin() || $level >= $min,
                'rarity'=>$rarity, 'rarity_label'=>self::RARITIES[$rarity], 'condition'=>$min > 1 ? 'Đạt cấp '.$min : 'Có sẵn'];
            if ($min > 1) $rewards[$min]['avatars'][] = $name;
        }
        foreach (self::FRAMES as $id => [$name, $style, $min, $badges, $how]) {
            if ($id === 'auto') {
                foreach (self::FRAMES as $rankId => $rank) if ($rankId !== 'auto' && $rankId !== 'none' && !$rank[3] && $level >= $rank[2]) $style = $rank[1];
            }
            $rarity = self::rarityFor($id === 'auto' ? $level : max($min, $badges >= 25 ? 60 : ($badges >= 12 ? 30 : ($badges >= 5 ? 6 : 1))));
            $frames[$id] = ['name' => $name, 'style' => $style, 'unlocked' => $u->isAdmin() || ($level >= $min && count($earned) >= $badges), 'condition' => $how,
                'rarity'=>$rarity, 'rarity_label'=>self::RARITIES[$rarity]];
            if ($min > 1 && !$badges) $rewards[$min]['frames'][] = $name;
        }
        // Khung mua/nhận trong kho dùng được; kiểm tra lại quyền sở hữu khi hiển thị và lưu.
        $owned = DB::table('inventory_items')->join('shop_items', 'shop_items.id', '=', 'inventory_items.shop_item_id')
            ->where('inventory_items.user_id', $u->id)->where('shop_items.category', 'avatar_frame')
            ->get(['shop_items.id', 'shop_items.name_vi', 'shop_items.rarity'])->unique('id');
        foreach ($owned as $item) $frames['shop-' . $item->id] = ['name' => $item->name_vi, 'style' => match ($item->rarity) {
            'rare' => 'sky', 'epic' => 'violet', 'curated' => 'legend', default => 'leaf',
        }, 'unlocked' => true, 'condition' => 'Khung trong kho của bạn', 'rarity'=>$item->rarity,
            'rarity_label'=>self::RARITIES[$item->rarity] ?? ($item->rarity === 'curated' ? 'Huyền thoại' : 'Phổ thông')];
        ksort($rewards); $next = null;
        $xp = (int) (DB::table('wallets')->where('user_id',$u->id)->value('xp') ?? 0);
        foreach ($rewards as $min => &$reward) {
            $reward += ['avatars'=>[], 'frames'=>[]];
            $reward['level']=$min; $reward['unlocked']=$level >= $min;
            $reward['rarity']=self::rarityFor($min); $reward['rarity_label']=self::RARITIES[$reward['rarity']];
            if ($min > $level && !$next) $next=$reward + ['xp_left'=>max(0,Economy::xpForLevel($min)-$xp)];
        }
        unset($reward);
        return ['avatars' => self::AVATARS, 'avatar_rules'=>$avatarRules, 'colors' => self::COLORS, 'frames' => $frames, 'earned' => $earned,
            'level'=>$level, 'rank'=>ProfileStats::rankFor($level), 'rewards'=>$rewards, 'next_reward'=>$next];
    }

    public static function appearance(User $u, ?array $options = null): array
    {
        $options ??= static::options($u);
        $s = (array) $u->setting('appearance', []);
        $avatar = !empty($options['avatar_rules'][$s['avatar'] ?? '']['unlocked']) ? $s['avatar'] : 'initials';
        $color = array_key_exists($s['color'] ?? '', self::COLORS) ? $s['color'] : 'mint';
        $selectedFrame = $s['frame'] ?? 'auto';
        $frame = isset($options['frames'][$selectedFrame]) && $options['frames'][$selectedFrame]['unlocked'] ? $selectedFrame : 'none';
        $badge = isset(Badges::CATALOG[$s['badge'] ?? ''], $options['earned'][$s['badge'] ?? '']) ? $s['badge'] : null;
        return ['avatar' => $avatar, 'symbol' => self::AVATARS[$avatar][1] ?: $u->initials(), 'color' => $color, 'frame' => $frame,
            'style' => $options['frames'][$frame]['style'], 'badge' => $badge, 'badge_icon' => $badge ? Badges::CATALOG[$badge][0] : null,
            'label' => self::AVATARS[$avatar][0]];
    }
}
