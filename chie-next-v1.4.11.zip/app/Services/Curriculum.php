<?php

namespace App\Services;

use App\Models\Attempt;
use App\Models\Lesson;
use App\Models\LessonProgress;
use App\Models\Question;
use App\Models\Unit;
use App\Models\User;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;

/**
 * Lộ trình học: Unit → Bài, trạng thái thống nhất (đã hoàn thành / đang học / có thể học / chưa mở),
 * dựa trên MỘT nguồn tiến độ duy nhất (lesson_progress theo từng lớp).
 */
class Curriculum
{
    /** Mức sẵn sàng học liệu của từng lớp (dựa trên dữ liệu đã duyệt thực tế). */
    public static function readinessAll(): array
    {
        return Cache::remember('chie.readiness', 300, function () {
            $out = [];
            for ($g = 1; $g <= 12; $g++) $out[$g] = static::readiness($g);
            return $out;
        });
    }

    public static function readiness(int $g): array
    {
        $lessons = Lesson::where('status', 'published')->whereHas('unit', fn ($q) => $q->where('status', 'published')->forGrade($g))->count();
        $questions = Question::published()->where('grade_id', $g)->whereIn('type', Question::AUTO_GRADED)->count();
        $words = DB::table('lexicon_items')->where('status', 'published')->where('grade_id', '<=', $g)->count();
        $draftUnits = Unit::forGrade($g)->whereIn('status', ['draft', 'review'])->count();
        $status = $lessons > 0 && $questions >= 20 ? 'ready' : ($questions >= 10 ? 'partial' : 'empty');
        return compact('lessons', 'questions', 'words', 'draftUnits', 'status');
    }

    public static function flush(): void
    {
        Cache::forget('chie.readiness');
    }

    /** Các unit đã xuất bản của lớp, kèm bài đã xuất bản (eager load, tránh N+1). */
    public static function units(int $g)
    {
        return Unit::forGrade($g)->where('status', 'published')
            ->with(['publishedLessons' => fn ($q) => $q->withCount(['questions' => fn ($w) => $w->where('status', 'published')])])
            ->orderByRaw("kind = 'focus'")->orderBy('semester')->orderBy('sort')->get()
            ->filter(fn ($u) => $u->publishedLessons->count() > 0)->values();
    }

    /**
     * Dựng lộ trình có trạng thái cho người học (hoặc khách khi $user = null).
     * @return array{units: array, current: ?Lesson, stats: array}
     */
    public static function path(int $g, ?User $user): array
    {
        $units = static::units($g);
        $progress = $user ? LessonProgress::where('user_id', $user->id)->where('grade_level', $g)->get()->keyBy('lesson_id') : collect();
        $due = $user ? static::dueByLesson($user->id, $g) : [];
        $current = null;
        $out = [];
        $done = $total = 0;
        $chainOpen = true;
        foreach ($units as $unit) {
            $rows = [];
            foreach ($unit->publishedLessons as $lesson) {
                $total++;
                $p = $progress->get($lesson->id);
                $st = $p?->status;
                if (!$user) {
                    $state = $lesson->is_public ? 'available' : 'locked';
                } elseif (in_array($st, ['completed', 'mastered'], true)) {
                    $state = $st === 'mastered' ? 'mastered' : 'done';
                    $done++;
                } elseif ($unit->kind === 'focus') {
                    $state = 'available';
                } elseif ($chainOpen) {
                    $state = 'current';
                    $current ??= $lesson;
                    $chainOpen = false;
                } else {
                    $state = 'locked';
                }
                $rows[] = ['lesson' => $lesson, 'state' => $state, 'best' => $p?->best_score, 'in_progress' => $st === 'in_progress',
                    'due' => $due[$lesson->id] ?? 0, 'questions' => $lesson->questions_count];
            }
            $out[] = ['unit' => $unit, 'lessons' => $rows,
                'done' => collect($rows)->whereIn('state', ['done', 'mastered'])->count(), 'count' => count($rows)];
        }
        if ($user && !$current) {
            // mọi bài chính đã xong: gợi ý bài đầu tiên cần ôn
            foreach ($out as $u) foreach ($u['lessons'] as $row) if (!$current && $row['due'] > 0) $current = $row['lesson'];
        }
        return ['units' => $out, 'current' => $current, 'stats' => ['done' => $done, 'total' => $total, 'percent' => $total ? (int) round($done / $total * 100) : 0]];
    }

    /** Số câu đến hạn ôn theo bài (cần ôn). */
    public static function dueByLesson(int $userId, int $g): array
    {
        return DB::table('srs_cards')->join('lesson_question', 'lesson_question.question_id', '=', 'srs_cards.item_id')
            ->where('srs_cards.user_id', $userId)->where('srs_cards.item_type', 'question')->where('srs_cards.grade_level', $g)
            ->where('srs_cards.due_at', '<=', now())->where('srs_cards.stage', '<', 3)
            ->groupBy('lesson_question.lesson_id')->selectRaw('lesson_question.lesson_id, COUNT(*) c')->pluck('c', 'lesson_id')->all();
    }

    public static function dueCount(int $userId, int $g): array
    {
        $q = DB::table('srs_cards')->where('user_id', $userId)->where('grade_level', $g)->where('due_at', '<=', now())->where('stage', '<', 3);
        return ['questions' => (clone $q)->where('item_type', 'question')->count(), 'words' => (clone $q)->where('item_type', 'word')->count()];
    }

    /** Lượt học bài đang dở (để "Học tiếp"). */
    public static function openLessonAttempt(User $u, int $g): ?Attempt
    {
        return Attempt::where('user_id', $u->id)->where('kind', 'lesson')->where('grade_level', $g)->where('status', 'in_progress')
            ->where('started_at', '>=', now()->subDays(3))->latest('id')->first();
    }

    /** Bài có được phép xem bởi người dùng/khách? Bài chưa xuất bản không xem được dù đoán URL. */
    public static function canViewLesson(Lesson $lesson, ?User $u, ?int $grade): bool
    {
        $lesson->loadMissing('unit');
        $isStaff = $u && ($u->isAdmin() || $u->isApprovedTeacher());
        if (!$lesson->isAvailable()) return $u && $u->isAdmin();
        if ($isStaff) return true;
        $unit = $lesson->unit;
        $inGrade = $grade && ($unit->grade_id === $grade || ($unit->grade_to && $unit->grade_id <= $grade && $unit->grade_to >= $grade));
        if (!$u) return $inGrade && $lesson->is_public;
        return $inGrade;
    }
}
