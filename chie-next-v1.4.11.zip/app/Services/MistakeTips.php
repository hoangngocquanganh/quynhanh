<?php

namespace App\Services;

/**
 * Mẹo sửa lỗi người Việt hay mắc — hiển thị khi trả lời sai câu có gắn nhãn tương ứng.
 * Viết mới bằng tiếng Việt dễ hiểu; không dùng phiên âm kiểu tiếng Việt làm chuẩn.
 */
class MistakeTips
{
    public const TAGS = [
        'final_consonant' => ['Âm cuối', 'Tiếng Việt thường "nuốt" âm cuối. Trong tiếng Anh, âm cuối như /t/, /d/, /s/, /z/, /k/ phải bật ra rõ, vì nó thay đổi nghĩa: "ca(t)" và "ca(p)" là hai từ khác nhau.'],
        'consonant_cluster' => ['Cụm phụ âm', 'Tiếng Anh có cụm phụ âm như /st/, /kr/, /sks/. Đừng chèn thêm nguyên âm vào giữa (nói "s-ơ-tốp"): hãy nối liền hai phụ âm, ví dụ "stop" /stɒp/.'],
        'word_stress' => ['Trọng âm từ', 'Mỗi từ nhiều âm tiết có một âm tiết được nhấn mạnh (dấu ˈ trong phiên âm). Nhấn sai có thể khiến người nghe không hiểu, ví dụ ˈpresent (món quà) và preˈsent (trình bày).'],
        'sentence_stress' => ['Trọng âm câu', 'Trong câu, từ mang nghĩa chính (danh từ, động từ, tính từ) được đọc to, rõ; từ chức năng (a, the, to, of) đọc nhẹ và nhanh.'],
        'minimal_pair' => ['Âm dễ nhầm', 'Hai từ chỉ khác một âm (ship /ʃɪp/ – sheep /ʃiːp/). Hãy nghe kỹ độ dài nguyên âm và khẩu hình: /iː/ kéo dài, môi căng; /ɪ/ ngắn, môi thả lỏng.'],
        'plural_s' => ['Đuôi số nhiều', 'Danh từ đếm được số nhiều cần đuôi -s/-es: one book → two books. Tiếng Việt không đổi hình thức từ ("hai quyển sách") nên rất dễ quên.'],
        'third_person_s' => ['Ngôi thứ ba số ít', 'Ở thì hiện tại đơn, chủ ngữ he/she/it hoặc một người/vật số ít → động từ thêm -s/-es: She goes, He has, It works.'],
        'past_ed' => ['Đuôi quá khứ -ed', 'Động từ có quy tắc ở quá khứ thêm -ed và phải đọc đuôi: /t/ (worked), /d/ (played), /ɪd/ (wanted). Động từ bất quy tắc cần học thuộc: go → went.'],
        'articles' => ['Mạo từ a/an/the', '"a/an" cho vật số ít lần đầu nhắc tới (an trước nguyên âm: an apple); "the" cho vật đã xác định, cả hai người nói đều biết là cái nào.'],
        'prepositions' => ['Giới từ', 'Giới từ không dịch từng chữ từ tiếng Việt: "ở trường" là at school, "vào thứ Hai" là on Monday, "vào tháng Năm" là in May.'],
        'word_order' => ['Trật tự từ', 'Tính từ đứng TRƯỚC danh từ (a red bag, không phải a bag red). Câu khẳng định: Chủ ngữ + Động từ + Tân ngữ + Nơi chốn + Thời gian.'],
        'tenses' => ['Thì của động từ', 'Tiếng Việt dùng "đã/đang/sẽ", tiếng Anh đổi hình thức động từ. Hãy tìm dấu hiệu thời gian (yesterday, now, tomorrow, already...) để chọn thì.'],
        'sv_agreement' => ['Hòa hợp chủ ngữ – động từ', 'Động từ phải hợp với chủ ngữ: The students ARE..., Each student IS..., Everyone HAS... Chủ ngữ dài thì tìm danh từ chính.'],
        'literal_translation' => ['Dịch từng từ', 'Đừng dịch từng chữ từ tiếng Việt. Hãy học cả cụm: "Tôi 10 tuổi" là I am 10 years old (không phải I have 10 years).'],
        'to_be' => ['Động từ to be', 'I am, you/we/they are, he/she/it is. Câu có tính từ hoặc danh từ sau chủ ngữ cần "to be": She is happy (không phải She happy).'],
        'conditional' => ['Câu điều kiện', 'Loại 1: If + hiện tại đơn, will + V (có thể xảy ra). Loại 2: If + quá khứ đơn, would + V (khó/không có thật ở hiện tại).'],
        'passive' => ['Câu bị động', 'Bị động = be (chia theo thì) + V3/ed. Dùng khi muốn nhấn mạnh đối tượng chịu tác động: The bridge was built in 1990.'],
        'comparison' => ['So sánh', 'Tính từ ngắn: -er/-est (taller, the tallest). Tính từ dài: more/most (more beautiful). Bất quy tắc: good → better → best.'],
        'present_perfect' => ['Hiện tại hoàn thành', 'have/has + V3: kinh nghiệm hoặc việc kéo dài đến nay (I have lived here for 3 years). Đi với since/for/already/yet/ever/never.'],
        'relative_clause' => ['Mệnh đề quan hệ', 'who cho người, which cho vật, that cho cả hai (mệnh đề xác định); whose chỉ sở hữu.'],
        'reported_speech' => ['Câu gián tiếp', 'Lùi thì khi tường thuật: "I am tired" → She said (that) she was tired. Đổi đại từ và trạng từ thời gian (now → then).'],
        'can_ability' => ['Can (khả năng)', 'can + động từ nguyên mẫu, không thêm -s, không thêm "to": She can swim (không phải She cans swim / can to swim).'],
        'thinking_in_english' => ['Tư duy bằng tiếng Anh', 'Thử nhìn hình và gọi tên bằng tiếng Anh ngay, không dịch qua tiếng Việt. Lặp lại nhiều lần để phản xạ nhanh hơn.'],
    ];

    /** Suy ra nhãn lỗi thường gặp từ nội dung giải thích (dùng khi nhập dữ liệu cũ). */
    public static function inferTags(string $text, string $skill): array
    {
        $t = mb_strtolower($text);
        $rules = [
            'third_person_s' => ['ngôi thứ 3', 'ngôi thứ ba', 'số ít (he', 'she/he/it', 'he/she/it'],
            'past_ed' => ['quá khứ đơn', 'quá khứ', 'v-ed', 'v2'],
            'present_perfect' => ['hiện tại hoàn thành'],
            'passive' => ['bị động'],
            'conditional' => ['câu điều kiện', 'if + '],
            'articles' => ['mạo từ', ' a/an', 'an + nguyên âm'],
            'prepositions' => ['giới từ'],
            'comparison' => ['so sánh'],
            'relative_clause' => ['mệnh đề quan hệ', 'who/which', 'which/that'],
            'reported_speech' => ['gián tiếp', 'tường thuật'],
            'to_be' => ['to be', 'am/is/are'],
            'can_ability' => ['can +', 'động từ khuyết thiếu can'],
            'plural_s' => ['số nhiều'],
            'word_stress' => ['trọng âm'],
        ];
        $tags = [];
        foreach ($rules as $tag => $needles) {
            foreach ($needles as $n) {
                if (str_contains($t, $n)) { $tags[] = $tag; break; }
            }
        }
        if ($skill === 'pronunciation' && !in_array('word_stress', $tags)) $tags[] = 'minimal_pair';
        return array_values(array_unique($tags));
    }

    public static function forTags(array $tags): array
    {
        $out = [];
        foreach ($tags as $tag) {
            if (isset(self::TAGS[$tag])) $out[] = ['tag' => $tag, 'title' => self::TAGS[$tag][0], 'tip' => self::TAGS[$tag][1]];
        }
        return $out;
    }

    public static function label(string $tag): string
    {
        if (str_starts_with($tag, 'gp:')) {   // v1.4: chủ điểm ngữ pháp
            static $titles = null;
            $titles ??= \App\Models\GrammarTopic::pluck('title_vi', 'code')->all();
            return 'Ngữ pháp: ' . ($titles[substr($tag, 3)] ?? substr($tag, 3));
        }
        return self::TAGS[$tag][0] ?? $tag;
    }
}
