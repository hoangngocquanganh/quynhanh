<?php

namespace App\Services;

use App\Models\Farm;
use App\Models\FarmCrop;
use App\Models\FarmPlot;
use App\Models\FarmRecipe;
use App\Models\Question;
use App\Models\User;
use App\Support\Settings;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\DB;

/**
 * CHIE Farm — học trong nông trại. Không chạy nền: cây chín / khiên / kho lạnh tính bằng mốc giờ (NOW() >= matures_at).
 * Gieo, tưới, bắt sâu và cho ăn không bắt buộc câu hỏi; chỉ lượt ôn có token hợp lệ mới nhận XP. Mọi thay đổi Xu/kho trong transaction.
 * Kho Ngoài (bị cướp được) / Kho Trong (an toàn, có sức chứa) / Kho Lạnh (thuê theo giờ, an toàn).
 */
class FarmService
{
    public static function farm(int $userId): Farm
    {
        $f = Farm::find($userId);
        if (!$f) {
            DB::table('farms')->insertOrIgnore(['user_id' => $userId, 'plots_unlocked' => (int) Settings::get('farm.start_plots', 6),
                'inner_capacity' => (int) Settings::get('farm.inner_start_capacity', 20), 'created_at' => now(), 'updated_at' => now()]);
            $f = Farm::find($userId);
        }
        return $f;
    }

    public static function lockFarm(int $userId): Farm
    {
        static::farm($userId);
        return Farm::where('user_id', $userId)->lockForUpdate()->first();
    }

    public static function storage(int $userId): array
    {
        $rows = DB::table('farm_storage')->where('user_id', $userId)->where('qty', '>', 0)->get();
        $out = ['outer' => [], 'inner' => [], 'cold' => []];
        foreach ($rows as $r) $out[$r->location][$r->item_code] = (int) $r->qty;
        return $out;
    }

    public static function addStorage(int $userId, string $loc, string $code, int $delta): void
    {
        if ($delta === 0) return;
        DB::statement('INSERT INTO farm_storage (user_id, location, item_code, qty, created_at, updated_at) VALUES (?,?,?,?,?,?)
            ON DUPLICATE KEY UPDATE qty = GREATEST(0, CAST(qty AS SIGNED) + ?), updated_at = VALUES(updated_at)', [$userId, $loc, $code, max(0, $delta), now(), now(), $delta]);
    }

    public static function qty(int $userId, string $loc, string $code, bool $lock = false): int
    {
        $q = DB::table('farm_storage')->where('user_id', $userId)->where('location', $loc)->where('item_code', $code);
        if ($lock) $q->lockForUpdate();
        return (int) $q->value('qty');
    }

    public static function catalog(): array
    {
        return [
            'crops' => FarmCrop::where('is_active', true)->orderBy('sort')->get()->keyBy('code'),
            'recipes' => FarmRecipe::where('is_active', true)->get()->keyBy('code'),
            'animals' => \App\Models\FarmAnimalKind::where('is_active', true)->orderBy('sort')->get()->keyBy('code'),
        ];
    }

    /** Tên hiển thị của một mã nông sản / món ăn. */
    public static function itemInfo(string $code): array
    {
        static $cat = null;
        $cat ??= static::catalog();
        if (isset($cat['crops'][$code])) { $c = $cat['crops'][$code]; return ['vi' => $c->name_vi, 'en' => $c->name_en, 'icon' => $c->icon, 'sell' => $c->sell_price]; }
        if (isset($cat['recipes'][$code])) { $c = $cat['recipes'][$code]; return ['vi' => $c->name_vi, 'en' => $c->name_en, 'icon' => $c->icon, 'sell' => $c->sell_price]; }
        foreach ($cat['animals'] as $a) if ($a->product_code === $code) return ['vi' => $a->product_vi, 'en' => $a->product_en, 'icon' => $a->product_icon, 'sell' => $a->product_sell];
        return ['vi' => $code, 'en' => $code, 'icon' => '📦', 'sell' => 1];
    }

    public static function state(User $u): array
    {
        $f = static::farm($u->id);
        $plots = FarmPlot::where('user_id', $u->id)->get()->keyBy('slot');
        $cat = static::catalog();
        $max = (int) Settings::get('farm.max_plots', 48);
        $list = [];
        for ($i = 0; $i < min($max, $f->plots_unlocked + 1); $i++) {
            $p = $plots[$i] ?? null;
            $locked = $i >= $f->plots_unlocked;
            $row = ['slot' => $i, 'locked' => $locked];
            if ($p && $p->crop_code) {
                $crop = $cat['crops'][$p->crop_code] ?? null;
                $total = max(1, $p->planted_at->diffInSeconds($p->matures_at));
                $left = max(0, now()->diffInSeconds($p->matures_at, false));
                $row += ['crop' => $p->crop_code, 'icon' => $crop->icon ?? '🌱', 'name' => $crop->name_vi ?? $p->crop_code, 'name_en' => $crop->name_en ?? '',
                    'seconds_left' => (int) $left, 'progress' => (int) round(100 - $left / $total * 100), 'ready' => $left <= 0, 'pest' => (bool) $p->has_pest, 'boosts' => $p->boosts];
            }
            $list[] = $row;
        }
        $animals = [];
        foreach (\App\Models\FarmAnimal::where('user_id', $u->id)->orderBy('id')->get() as $a) {
            $k = $cat['animals'][$a->kind] ?? null;
            if (!$k) continue;
            $left = $a->ready_at ? max(0, now()->diffInSeconds($a->ready_at, false)) : null;
            $animals[] = ['id' => $a->id, 'kind' => $a->kind, 'icon' => $k->icon, 'name' => $a->name ?: $k->name_vi, 'name_en' => $k->name_en,
                'product_icon' => $k->product_icon, 'product' => $k->product_vi, 'hungry' => $a->ready_at === null,
                'seconds_left' => $left === null ? null : (int) $left, 'ready' => $a->ready_at !== null && $left <= 0];
        }
        $storage = static::storage($u->id);
        $named = [];
        foreach ($storage as $loc => $items) foreach ($items as $code => $qty) $named[$loc][] = ['code' => $code, 'qty' => $qty] + static::itemInfo($code);
        return [
            'plots' => $list, 'storage' => $named, 'inner_used' => array_sum($storage['inner']), 'inner_capacity' => $f->inner_capacity,
            'cold_used' => array_sum($storage['cold']), 'cold_capacity' => (int) Settings::get('farm.cold_capacity', 30),
            'cold_until' => $f->cold_until && $f->cold_until->isFuture() ? $f->cold_until->toIso8601String() : null,
            'shield_until' => $f->hasShield() ? $f->shield_until->toIso8601String() : null, 'wall_level' => $f->wall_level,
            'next_plot_price' => static::plotPrice($f->plots_unlocked), 'max_plots' => $max, 'name' => $f->name,
            'animals' => $animals, 'animal_slots' => (int) Settings::get('farm.animal_slots', 6),
            'wallet' => Economy::walletFor($u->id)->only(['xu', 'xp', 'level']), 'server_now' => now()->toIso8601String(),
        ];
    }

    public static function plotPrice(int $unlocked): int
    {
        $start = (int) Settings::get('farm.start_plots', 6);
        return (int) Settings::get('farm.plot_price_base', 200) + max(0, $unlocked - $start) * (int) Settings::get('farm.plot_price_step', 100);
    }

    // ------------------------------------------------------------------ thử thách học (token ký mã hóa, không lộ đáp án)

    /** Tạo câu đố: purpose = plant (học từ của cây) | water | pest (câu ôn từ ngân hàng đúng lớp). */
    public static function quiz(User $u, string $purpose, array $ctx): array
    {
        $g = (int) ($u->grade_level ?: 3);
        if ($purpose === 'feed') {
            $a = \App\Models\FarmAnimal::where('user_id', $u->id)->findOrFail((int) ($ctx['animal'] ?? 0));
            $kind = \App\Models\FarmAnimalKind::where('code', $a->kind)->firstOrFail();
            $words = $kind->words ?? [];
            $pick = $words[random_int(0, count($words) - 1)];
            $reverse = (bool) random_int(0, 1);   // lúc hỏi nghĩa, lúc hỏi từ tiếng Anh
            $pool = collect($words)->where(0, '<>', $pick[0]);
            $opts = $reverse ? array_merge([$pick[0]], $pool->pluck(0)->shuffle()->take(3)->all()) : array_merge([$pick[1]], $pool->pluck(1)->shuffle()->take(3)->all());
            $opts = Grader::shuffle(array_values(array_unique($opts)));
            $correct = $reverse ? $pick[0] : $pick[1];
            $snap = ['type' => 'mcq', 'skill' => 'vocabulary', 'prompt' => $reverse ? ['text' => 'Cho ' . $kind->name_vi . ' ăn: từ tiếng Anh nào nghĩa là “' . $pick[1] . '”?'] : ['text' => 'Cho ' . $kind->name_vi . ' ăn: “' . $pick[0] . '” nghĩa là gì?', 'speak_word' => $pick[0]],
                'display' => ['options' => $opts], 'key' => ['correct_index' => array_search($correct, $opts, true), 'correct_text' => $correct],
                'explanation_vi' => $pick[0] . ' = ' . $pick[1] . '.', 'tags' => []];
            $learn = collect($words)->map(fn ($w) => ['en' => $w[0], 'vi' => $w[1]])->all();
            $ctx = ['animal' => $a->id];
        } elseif ($purpose === 'plant') {
            $crop = FarmCrop::where('is_active', true)->where('code', $ctx['crop'] ?? '')->firstOrFail();
            $words = $crop->words ?? [];
            if (count($words) < 2) throw new DomainError('Cây này chưa có bộ từ vựng.');
            $pick = $words[random_int(0, count($words) - 1)];
            $others = collect($words)->where(0, '<>', $pick[0])->pluck(1)->shuffle()->take(2)->all();
            $extra = DB::table('lexicon_items')->where('status', 'published')->where('grade_id', '<=', max(3, $g))->inRandomOrder()->limit(3)->pluck('meaning_vi')->all();
            $opts = array_values(array_unique(array_merge([$pick[1]], $others, $extra)));
            $opts = Grader::shuffle(array_slice($opts, 0, 4));
            if (!in_array($pick[1], $opts, true)) $opts[0] = $pick[1];
            $opts = Grader::shuffle($opts);
            $snap = ['type' => 'mcq', 'skill' => 'vocabulary', 'prompt' => ['text' => 'Gieo ' . $crop->name_vi . ': từ “' . $pick[0] . '” nghĩa là gì?', 'speak_word' => $pick[0]],
                'display' => ['options' => $opts], 'key' => ['correct_index' => array_search($pick[1], $opts, true), 'correct_text' => $pick[1]],
                'explanation_vi' => $pick[0] . ' = ' . $pick[1] . '. Các từ của cây ' . $crop->name_en . ': ' . collect($words)->map(fn ($w) => $w[0])->implode(', ') . '.', 'tags' => []];
            $learn = collect($words)->map(fn ($w) => ['en' => $w[0], 'vi' => $w[1]])->all();
        } else {
            // ưu tiên câu trong Sổ lỗi đến hạn
            $dueIds = DB::table('srs_cards')->where('user_id', $u->id)->where('item_type', 'question')->where('due_at', '<=', now())->where('stage', '<', 3)->pluck('item_id');
            $q = Question::published()->whereIn('type', ['mcq', 'listen_mcq'])->where('grade_id', $g)->whereIn('id', $dueIds)->inRandomOrder()->first()
                ?? Question::published()->whereIn('type', ['mcq', 'listen_mcq'])->where('grade_id', $g)->inRandomOrder()->first();
            if (!$q) throw new DomainError('Lớp của bạn chưa có câu hỏi đã duyệt để chăm cây. Bạn vẫn có thể thu hoạch bình thường.');
            $snap = Grader::build($q);
            $learn = [];
        }
        $token = Crypt::encryptString(json_encode(['u' => $u->id, 'p' => $purpose, 'ctx' => $ctx, 'k' => $snap['key'], 'q' => $snap['id'] ?? null,
            'e' => $snap['explanation_vi'] ?? null, 'exp' => now()->addMinutes(10)->timestamp, 'n' => bin2hex(random_bytes(6))]));
        return ['token' => $token, 'question' => Grader::publicView($snap, false), 'learn' => $learn];
    }

    /** Kiểm tra câu trả lời của token. Trả về [đúng?, payload]. Token dùng 1 lần. */
    public static function checkQuiz(User $u, string $token, string $purpose, $choice): array
    {
        try {
            $d = json_decode(Crypt::decryptString($token), true);
        } catch (\Throwable $e) {
            throw new DomainError('Câu đố không hợp lệ, hãy thử lại.');
        }
        if (($d['u'] ?? 0) !== $u->id || ($d['p'] ?? '') !== $purpose || ($d['exp'] ?? 0) < time()) throw new DomainError('Câu đố đã hết hạn, hãy thử lại.');
        $nonceKey = 'farmquiz:' . $d['n'];
        if (!DB::table('daily_counters')->insertOrIgnore(['user_id' => $u->id, 'day' => today()->toDateString(), 'key' => $nonceKey, 'value' => 1])) {
            throw new DomainError('Câu đố này đã được trả lời.');
        }
        $ok = is_numeric($choice) && (int) $choice === (int) ($d['k']['correct_index'] ?? -1);
        // câu sai từ ngân hàng → vào Sổ lỗi như khi học
        if (!$ok && !empty($d['q'])) {
            $card = DB::table('srs_cards')->where('user_id', $u->id)->where('item_type', 'question')->where('item_id', $d['q'])->first();
            DB::table('srs_cards')->updateOrInsert(['user_id' => $u->id, 'item_type' => 'question', 'item_id' => $d['q']],
                ['grade_level' => $u->grade_level ?: 3, 'stage' => 0, 'lapses' => ($card->lapses ?? 0) + ($card ? 1 : 0), 'due_at' => now()->addDay(), 'last_correct' => false, 'updated_at' => now(), 'created_at' => $card->created_at ?? now()]);
        }
        return [$ok, $d];
    }

    // ------------------------------------------------------------------ hành động

    public static function plant(User $u, int $slot, string $cropCode, ?string $token = null, $choice = null): array
    {
        $fb = [];
        if ($token !== null) {
            [$ok, $d] = static::checkQuiz($u, $token, 'plant', $choice);
            if (($d['ctx']['crop'] ?? '') !== $cropCode) throw new DomainError('Câu đố không khớp loại cây.');
            $fb = ['is_correct' => $ok, 'correct_text' => $d['k']['correct_text'] ?? null, 'explanation_vi' => $d['e']];
            if (!$ok) return $fb + ['planted' => false, 'message' => 'Chưa đúng — hãy xem lại các từ của cây rồi thử lại nhé!'];
        }
        return DB::transaction(function () use ($u, $slot, $cropCode, $fb) {
            $f = static::lockFarm($u->id);
            if ($slot < 0 || $slot >= $f->plots_unlocked) throw new DomainError('Ô đất này chưa mở.');
            $crop = FarmCrop::where('is_active', true)->where('code', $cropCode)->firstOrFail();
            $w = Economy::walletFor($u->id);
            if ($w->level < $crop->min_level) throw new DomainError("Cần cấp {$crop->min_level} để trồng {$crop->name_vi}.");
            $plot = FarmPlot::where('user_id', $u->id)->where('slot', $slot)->lockForUpdate()->first();
            if ($plot && $plot->crop_code) throw new DomainError('Ô đất đang có cây.');
            Economy::spend($u->id, (int) $crop->seed_price, 'farm_seed', 'seed:' . $u->id . ':' . $slot . ':' . bin2hex(random_bytes(6)), 'crop:' . $crop->code);
            $pest = random_int(1, 100) <= (int) Settings::get('farm.pest_chance_percent', 8);
            FarmPlot::updateOrCreate(['user_id' => $u->id, 'slot' => $slot], ['crop_code' => $crop->code, 'planted_at' => now(),
                'matures_at' => now()->addMinutes($crop->grow_minutes), 'boosts' => 0, 'has_pest' => $pest]);
            return $fb + ['planted' => true, 'message' => 'Đã gieo ' . $crop->name_vi . '! Chín sau ' . static::fmtMinutes($crop->grow_minutes) . '.'];
        });
    }

    /** Tưới (tối đa 3 lần/cây) hoặc bắt sâu trực tiếp; lượt ôn có token mới được XP. */
    public static function care(User $u, int $slot, string $purpose, ?string $token = null, $choice = null): array
    {
        $fb = [];
        if ($token !== null) {
            [$ok, $d] = static::checkQuiz($u, $token, $purpose, $choice);
            if ((int) ($d['ctx']['slot'] ?? -1) !== $slot) throw new DomainError('Câu đố không khớp ô đất.');
            $fb = ['is_correct' => $ok, 'correct_text' => $d['k']['correct_text'] ?? null, 'explanation_vi' => $d['e']];
            if (!$ok) return $fb + ['message' => 'Chưa đúng. Câu này đã vào Sổ lỗi để ôn lại — cây vẫn lớn bình thường.'];
        }
        return DB::transaction(function () use ($u, $slot, $purpose, $fb) {
            $p = FarmPlot::where('user_id', $u->id)->where('slot', $slot)->lockForUpdate()->first();
            if (!$p || !$p->crop_code) throw new DomainError('Ô đất trống.');
            if (!in_array($purpose, ['water', 'pest'], true)) throw new DomainError('Thao tác không hợp lệ.');
            if ($purpose === 'pest') {
                if (!$p->has_pest) throw new DomainError('Cây không có sâu.');
                $p->has_pest = false;
                $msg = 'Đã bắt sâu! Cây khỏe mạnh trở lại.';
            } else {
                if ($p->matures_at->isPast()) throw new DomainError('Cây đã chín, hãy thu hoạch.');
                if ($p->boosts >= 3) throw new DomainError('Cây đã được chăm đủ 3 lần.');
                $left = now()->diffInSeconds($p->matures_at);
                $p->matures_at = now()->addSeconds((int) floor($left * (100 - (int) Settings::get('farm.water_speedup_percent', 20)) / 100));
                $p->boosts += 1;
                $msg = 'Tưới xong! Cây lớn nhanh hơn ' . Settings::get('farm.water_speedup_percent', 20) . '%.';
            }
            $p->save();
            $key = 'farmcare:' . $u->id . ':' . $slot . ':' . bin2hex(random_bytes(6));
            [$xp, $xu] = !empty($fb['is_correct']) ? Economy::applyDailyCap($u->id, 2, 1) : [0, 0];
            if ($xp || $xu) { Economy::grant($u->id, $xp, $xu, 'farm_water', $key, 'slot:' . $slot); Economy::bump($u->id, 'xp_earned', $xp); Economy::bump($u->id, 'xu_earned', $xu); }
            return $fb + ['message' => $msg . ($xp ? " +{$xp} XP" : '')];
        });
    }

    public static function harvest(User $u, int $slot): array
    {
        return DB::transaction(function () use ($u, $slot) {
            $p = FarmPlot::where('user_id', $u->id)->where('slot', $slot)->lockForUpdate()->first();
            if (!$p || !$p->crop_code) throw new DomainError('Ô đất trống.');
            if ($p->matures_at->isFuture()) throw new DomainError('Cây chưa chín (còn ' . static::fmtMinutes((int) ceil(now()->diffInSeconds($p->matures_at) / 60)) . ').');
            $crop = FarmCrop::where('code', $p->crop_code)->first();
            $qty = (int) ($crop->yield ?? 2);
            if ($p->has_pest) $qty = max(1, (int) floor($qty * (100 - (int) Settings::get('farm.pest_yield_penalty_percent', 30)) / 100));
            static::addStorage($u->id, 'outer', $p->crop_code, $qty);
            $name = $crop->name_vi ?? $p->crop_code;
            $p->update(['crop_code' => null, 'planted_at' => null, 'matures_at' => null, 'boosts' => 0, 'has_pest' => false]);
            return ['message' => "Thu hoạch {$qty} {$name}! Nông sản nằm ở Kho Ngoài (có thể bị cướp) — chuyển vào Kho Trong để an toàn."];
        });
    }

    public static function move(User $u, string $code, string $from, string $to, int $qty): array
    {
        if ($qty < 1 || $from === $to || !in_array($from, ['outer', 'inner', 'cold']) || !in_array($to, ['outer', 'inner', 'cold'])) throw new DomainError('Thao tác không hợp lệ.');
        return DB::transaction(function () use ($u, $code, $from, $to, $qty) {
            $f = static::lockFarm($u->id);
            $have = static::qty($u->id, $from, $code, true);
            if ($have < $qty) throw new DomainError('Không đủ số lượng trong kho.');
            if ($to === 'inner' && static::usedLocked($u->id, 'inner') + $qty > $f->inner_capacity) throw new DomainError("Kho Trong đầy (sức chứa {$f->inner_capacity}). Hãy mở rộng hoặc thuê Kho Lạnh.");
            if ($to === 'cold') {
                if (!$f->cold_until || $f->cold_until->isPast()) throw new DomainError('Bạn chưa thuê Kho Lạnh (hoặc đã hết giờ).');
                if (static::usedLocked($u->id, 'cold') + $qty > (int) Settings::get('farm.cold_capacity', 30)) throw new DomainError('Kho Lạnh đã đầy.');
            }
            static::addStorage($u->id, $from, $code, -$qty);
            static::addStorage($u->id, $to, $code, $qty);
            return ['message' => 'Đã chuyển ' . $qty . ' ' . static::itemInfo($code)['vi'] . '.'];
        });
    }

    protected static function usedLocked(int $userId, string $loc): int
    {
        return (int) DB::table('farm_storage')->where('user_id', $userId)->where('location', $loc)->lockForUpdate()->sum('qty');
    }

    /** Kho Lạnh hết giờ: hàng tự trở về Kho Ngoài (tính khi mở trang, không chạy nền). */
    public static function expireCold(int $userId): void
    {
        $f = static::farm($userId);
        if ($f->cold_until && $f->cold_until->isPast()) {
            DB::transaction(function () use ($userId) {
                foreach (DB::table('farm_storage')->where('user_id', $userId)->where('location', 'cold')->where('qty', '>', 0)->lockForUpdate()->get() as $r) {
                    static::addStorage($userId, 'cold', $r->item_code, -$r->qty);
                    static::addStorage($userId, 'outer', $r->item_code, $r->qty);
                }
                Farm::where('user_id', $userId)->update(['cold_until' => null]);
            });
        }
    }

    public static function sell(User $u, string $code, string $from, int $qty): array
    {
        if ($qty < 1 || !in_array($from, ['outer', 'inner', 'cold'])) throw new DomainError('Thao tác không hợp lệ.');
        return DB::transaction(function () use ($u, $code, $from, $qty) {
            static::lockFarm($u->id);
            if (static::qty($u->id, $from, $code, true) < $qty) throw new DomainError('Không đủ số lượng.');
            $price = static::itemInfo($code)['sell'] * $qty;
            static::addStorage($u->id, $from, $code, -$qty);
            Economy::grant($u->id, 0, $price, 'farm_sell', 'farmsell:' . $u->id . ':' . bin2hex(random_bytes(8)), $code . 'x' . $qty);
            return ['message' => "Đã bán cho CHIE, nhận {$price} Xu."];
        });
    }

    // ------------------------------------------------------------------ vật nuôi

    public static function buyAnimal(User $u, string $kindCode): array
    {
        return DB::transaction(function () use ($u, $kindCode) {
            static::lockFarm($u->id);
            $k = \App\Models\FarmAnimalKind::where('is_active', true)->where('code', $kindCode)->firstOrFail();
            $w = Economy::walletFor($u->id);
            if ($w->level < $k->min_level) throw new DomainError("Cần cấp {$k->min_level} để nuôi {$k->name_vi}.");
            $slots = (int) Settings::get('farm.animal_slots', 6);
            if (\App\Models\FarmAnimal::where('user_id', $u->id)->count() >= $slots) throw new DomainError("Chuồng đã đủ {$slots} con.");
            Economy::spend($u->id, (int) $k->price_xu, 'farm_animal', 'animal:' . $u->id . ':' . bin2hex(random_bytes(6)), 'animal:' . $k->code);
            \App\Models\FarmAnimal::create(['user_id' => $u->id, 'kind' => $k->code]);
            return ['message' => 'Chào mừng ' . $k->name_vi . ' (' . $k->name_en . ') về nông trại! Chạm vào con vật để cho ăn.'];
        });
    }

    /** Cho ăn trực tiếp và bắt đầu thời gian tạo sản phẩm. Giữ tương thích lượt ôn có token. */
    public static function feed(User $u, int $animalId, ?string $token = null, $choice = null): array
    {
        $fb = [];
        if ($token !== null) {
            [$ok, $d] = static::checkQuiz($u, $token, 'feed', $choice);
            if ((int) ($d['ctx']['animal'] ?? 0) !== $animalId) throw new DomainError('Câu đố không khớp con vật.');
            $fb = ['is_correct' => $ok, 'correct_text' => $d['k']['correct_text'] ?? null, 'explanation_vi' => $d['e']];
            if (!$ok) return $fb + ['message' => 'Chưa đúng — xem lại các từ rồi thử lại nhé!'];
        }
        return DB::transaction(function () use ($u, $animalId, $fb) {
            $a = \App\Models\FarmAnimal::where('user_id', $u->id)->lockForUpdate()->findOrFail($animalId);
            if ($a->ready_at) throw new DomainError('Con vật đã được cho ăn rồi. Chờ sản phẩm nhé!');
            $k = \App\Models\FarmAnimalKind::where('code', $a->kind)->firstOrFail();
            $a->update(['fed_at' => now(), 'ready_at' => now()->addMinutes($k->produce_minutes)]);
            [$xp, $xu] = !empty($fb['is_correct']) ? Economy::applyDailyCap($u->id, 2, 1) : [0, 0];
            if ($xp || $xu) { Economy::grant($u->id, $xp, $xu, 'farm_feed', 'farmfeed:' . $u->id . ':' . $animalId . ':' . bin2hex(random_bytes(6)), 'animal:' . $a->id); Economy::bump($u->id, 'xp_earned', $xp); Economy::bump($u->id, 'xu_earned', $xu); }
            return $fb + ['message' => 'Đã cho ' . $k->name_vi . ' ăn! Có ' . $k->product_vi . ' sau ' . static::fmtMinutes($k->produce_minutes) . '.' . ($xp ? " +{$xp} XP" : '')];
        });
    }

    public static function collect(User $u, int $animalId): array
    {
        return DB::transaction(function () use ($u, $animalId) {
            static::lockFarm($u->id);
            $a = \App\Models\FarmAnimal::where('user_id', $u->id)->lockForUpdate()->findOrFail($animalId);
            if (!$a->ready_at) throw new DomainError('Con vật đang đói — hãy cho ăn trước.');
            if ($a->ready_at->isFuture()) throw new DomainError('Chưa có sản phẩm (còn ' . static::fmtMinutes((int) ceil(now()->diffInSeconds($a->ready_at) / 60)) . ').');
            $k = \App\Models\FarmAnimalKind::where('code', $a->kind)->firstOrFail();
            $qty = $a->kind === 'chicken' ? 2 : 1;
            static::addStorage($u->id, 'outer', $k->product_code, $qty);
            $a->update(['fed_at' => null, 'ready_at' => null, 'collected' => $a->collected + $qty]);
            return ['message' => "Thu được {$qty} {$k->product_vi} ({$k->product_en})! Sản phẩm nằm ở Kho Ngoài."];
        });
    }

    /** Nấu ăn: chọn đúng nguyên liệu theo TÊN TIẾNG ANH trong công thức; sai thì không mất nguyên liệu, được giải thích. */
    public static function cook(User $u, string $recipeCode, array $chosen): array
    {
        $r = FarmRecipe::where('is_active', true)->where('code', $recipeCode)->firstOrFail();
        $need = $r->inputs;
        $chosen = array_values(array_unique(array_map('strval', $chosen)));
        sort($chosen);
        $want = array_keys($need);
        sort($want);
        if ($chosen !== $want) {
            $names = collect($need)->map(fn ($n, $c) => $n . ' ' . static::itemInfo($c)['en'])->implode(', ');
            return ['cooked' => false, 'message' => 'Chưa đúng nguyên liệu. Công thức “' . $r->name_en . '” cần: ' . $names . '. Đọc lại câu: “' . $r->recipe_en . '”'];
        }
        return DB::transaction(function () use ($u, $r, $need) {
            static::lockFarm($u->id);
            foreach ($need as $code => $n) {
                $total = static::qty($u->id, 'outer', $code, true) + static::qty($u->id, 'inner', $code, true) + static::qty($u->id, 'cold', $code, true);
                if ($total < $n) throw new DomainError('Thiếu ' . static::itemInfo($code)['vi'] . ' (cần ' . $n . ').');
            }
            foreach ($need as $code => $n) {
                foreach (['outer', 'inner', 'cold'] as $loc) {
                    if ($n <= 0) break;
                    $take = min($n, static::qty($u->id, $loc, $code, true));
                    if ($take) { static::addStorage($u->id, $loc, $code, -$take); $n -= $take; }
                }
            }
            Economy::spend($u->id, (int) $r->fee_xu, 'farm_cook', 'cook:' . $u->id . ':' . bin2hex(random_bytes(8)), 'recipe:' . $r->code);
            static::addStorage($u->id, 'outer', $r->code, 1);
            return ['cooked' => true, 'message' => 'Nấu xong ' . $r->name_vi . ' (' . $r->name_en . ')! Món ăn nằm ở Kho Ngoài, bán được ' . $r->sell_price . ' Xu.'];
        });
    }

    /** Mua: mở ô đất / nâng tường / khiên / thuê kho lạnh / mở rộng kho trong — đều là kênh đốt Xu. */
    public static function buy(User $u, string $what, ?int $hours = null): array
    {
        return DB::transaction(function () use ($u, $what, $hours) {
            $f = static::lockFarm($u->id);
            $key = 'farmbuy:' . $u->id . ':' . bin2hex(random_bytes(8));
            switch ($what) {
                case 'plot':
                    if ($f->plots_unlocked >= (int) Settings::get('farm.max_plots', 48)) throw new DomainError('Đã mở tối đa ô đất.');
                    $price = static::plotPrice($f->plots_unlocked);
                    Economy::spend($u->id, $price, 'farm_plot', $key, 'plot:' . ($f->plots_unlocked + 1));
                    $f->plots_unlocked += 1;
                    $msg = 'Đã mở thêm 1 ô đất.';
                    break;
                case 'wall':
                    $prices = Settings::get('farm.wall_prices', []);
                    $next = $f->wall_level + 1;
                    if (!isset($prices[(string) $next])) throw new DomainError('Tường đã đạt cấp cao nhất.');
                    Economy::spend($u->id, (int) $prices[(string) $next], 'farm_wall', $key, 'wall:' . $next);
                    $f->wall_level = $next;
                    $msg = 'Tường thành lên cấp ' . $next . ' — kẻ cướp phải vượt nhiều câu đố hơn.';
                    break;
                case 'shield':
                    $prices = Settings::get('farm.shield_prices', []);
                    if (!isset($prices[(string) $hours])) throw new DomainError('Gói khiên không hợp lệ.');
                    Economy::spend($u->id, (int) $prices[(string) $hours], 'farm_shield', $key, 'shield:' . $hours . 'h');
                    $f->shield_until = ($f->hasShield() ? $f->shield_until : now())->copy()->addHours($hours);
                    $msg = 'Khiên bảo vệ đến ' . $f->shield_until->format('H:i d/m') . '.';
                    break;
                case 'cold':
                    $hours = max(1, min(72, (int) $hours));
                    Economy::spend($u->id, $hours * (int) Settings::get('farm.cold_price_per_hour', 6), 'farm_cold', $key, 'cold:' . $hours . 'h');
                    $f->cold_until = ($f->cold_until && $f->cold_until->isFuture() ? $f->cold_until : now())->copy()->addHours($hours);
                    $msg = 'Đã thuê Kho Lạnh đến ' . $f->cold_until->format('H:i d/m') . '. Hết giờ, hàng tự về Kho Ngoài.';
                    break;
                case 'inner':
                    Economy::spend($u->id, (int) Settings::get('farm.inner_expand_price', 150), 'farm_inner', $key, 'inner');
                    $f->inner_capacity += (int) Settings::get('farm.inner_expand_step', 10);
                    $msg = 'Kho Trong chứa được ' . $f->inner_capacity . ' món.';
                    break;
                default:
                    throw new DomainError('Không rõ thao tác.');
            }
            $f->save();
            return ['message' => $msg];
        });
    }

    public static function fmtMinutes(int $m): string
    {
        if ($m < 60) return $m . ' phút';
        $h = intdiv($m, 60); $r = $m % 60;
        return $h . ' giờ' . ($r ? ' ' . $r . ' phút' : '');
    }
}
