<?php

namespace App\Services;

use App\Models\Attempt;
use App\Models\AttemptItem;
use App\Models\CheatFlag;
use App\Models\User;
use App\Support\Settings;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

/**
 * Vòng đời một lượt làm bài: tạo (snapshot + xáo trộn trên máy chủ) → trả lời từng câu (chấm trên máy chủ)
 * → nộp (một lần duy nhất, khóa dòng) → điểm thang 100 + tiến độ + SRS + thưởng.
 */
class AttemptService
{
    /**
     * @param Collection $questions Question models theo thứ tự mong muốn (đã xáo nếu cần)
     * @param array $opts title, feedback (immediate|after_submit), duration_min, guided_count, assignment_id, meta
     */
    public static function create(User $user, string $kind, ?string $refType, ?int $refId, int $grade, Collection $questions, array $opts = []): Attempt
    {
        if ($questions->isEmpty()) {
            throw new DomainError('Chưa có đủ câu hỏi đã duyệt cho lớp này. Nội dung đang được biên soạn.');
        }
        return DB::transaction(function () use ($user, $kind, $refType, $refId, $grade, $questions, $opts) {
            $now = now();
            $attempt = Attempt::create([
                'user_id' => $user->id, 'kind' => $kind, 'ref_type' => $refType, 'ref_id' => $refId,
                'assignment_id' => $opts['assignment_id'] ?? null, 'grade_level' => $grade, 'status' => 'in_progress',
                'seed' => random_int(1, PHP_INT_MAX), 'total' => $questions->count(), 'title' => $opts['title'] ?? null,
                'meta' => array_merge(['feedback' => $opts['feedback'] ?? 'immediate'], $opts['meta'] ?? []),
                'started_at' => $now, 'last_activity_at' => $now,
                'expires_at' => !empty($opts['duration_min']) ? $now->copy()->addMinutes((int) $opts['duration_min'])->addSeconds(20) : null,
            ]);
            $guided = (int) ($opts['guided_count'] ?? 0);
            $rows = [];
            foreach ($questions->values() as $i => $q) {
                $isQ = $q instanceof \App\Models\Question;
                $rows[] = [
                    'attempt_id' => $attempt->id, 'position' => $i,
                    // ảnh chụp dựng sẵn (đấu 1–1, thử thách gia đình) vẫn giữ mã câu để ghi Sổ lỗi
                    'question_id' => $isQ ? $q->id : (is_array($q) && !empty($q['id']) && empty($q['word_id']) ? (int) $q['id'] : null),
                    'question_version' => $isQ ? $q->version : (is_array($q) ? (int) ($q['version'] ?? 1) : 1),
                    'phase' => $i < $guided ? 'guided' : 'independent',
                    'snapshot' => json_encode($isQ ? Grader::build($q, $opts['max_options'] ?? null) : $q, JSON_UNESCAPED_UNICODE),
                ];
            }
            AttemptItem::insert($rows);
            return $attempt;
        });
    }

    public static function feedbackImmediate(Attempt $a): bool
    {
        return ($a->meta['feedback'] ?? 'immediate') === 'immediate';
    }

    /** Tự nộp nếu đã hết giờ (đồng hồ máy chủ). */
    public static function expireIfNeeded(Attempt $a): Attempt
    {
        if ($a->status === 'in_progress' && $a->expires_at && $a->expires_at->isPast()) {
            return static::submit($a, true);
        }
        return $a;
    }

    /** Dữ liệu cho trình duyệt (không chứa đáp án của câu chưa trả lời / bài thi chưa nộp). */
    public static function view(Attempt $a): array
    {
        $a = static::expireIfNeeded($a);
        $immediate = static::feedbackImmediate($a);
        $done = $a->status !== 'in_progress';
        $items = $a->items()->get()->map(function (AttemptItem $it) use ($immediate, $done) {
            $answered = $it->answered_at !== null;
            $reveal = $done || ($immediate && $answered);
            $v = Grader::publicView($it->snapshot, $reveal);
            $v['position'] = $it->position;
            $v['phase'] = $it->phase;
            $v['answered'] = $answered;
            $v['response'] = $it->response;
            if ($reveal) {
                $v['is_correct'] = $it->is_correct;
                $v['tips'] = $it->is_correct === false ? MistakeTips::forTags($it->snapshot['tags'] ?? []) : [];
            }
            if ($it->phase === 'guided' && !$reveal) {
                $v['hint_vi'] = static::hintFor($it->snapshot);
            }
            $v['question_id'] = $it->question_id;
            return $v;
        });
        return [
            'id' => $a->id, 'kind' => $a->kind, 'title' => $a->title, 'status' => $a->status, 'grade' => $a->grade_level,
            'total' => $a->total, 'answered' => $a->answered, 'correct' => $done || $immediate ? $a->correct : null,
            'score_100' => $a->score_100, 'feedback' => $a->meta['feedback'] ?? 'immediate',
            'expires_at' => $a->expires_at?->toIso8601String(), 'server_now' => now()->toIso8601String(),
            'seconds_left' => $a->expires_at ? max(0, now()->diffInSeconds($a->expires_at, false)) : null,
            'items' => $items->values(), 'meta' => array_intersect_key($a->meta ?? [], array_flip(['feedback', 'lesson_id', 'mode'])),
            'result' => $done ? static::resultSummary($a) : null,
        ];
    }

    /** Gợi ý cho phần luyện có hướng dẫn (không lộ đáp án). */
    public static function hintFor(array $snap): ?string
    {
        if (!empty($snap['prompt']['hint_vi'])) return $snap['prompt']['hint_vi'];
        $tips = MistakeTips::forTags($snap['tags'] ?? []);
        if ($tips) return $tips[0]['title'] . ': ' . $tips[0]['tip'];
        return match ($snap['type']) {
            'word_order' => 'Tìm chủ ngữ (I, She, My mother...) đặt đầu câu, rồi tới động từ, cuối cùng là phần còn lại.',
            'matching' => 'Ghép những cặp bạn chắc chắn trước, cặp khó để sau cùng.',
            'listen_mcq' => 'Bấm "Nghe chậm" và chú ý âm cuối của từ.',
            'fill_blank' => 'Xem chủ ngữ và dấu hiệu thời gian để chọn đúng dạng từ.',
            default => match ($snap['skill']) {
                'grammar' => 'Tìm dấu hiệu trong câu: chủ ngữ số ít/số nhiều, từ chỉ thời gian (yesterday, now, every day...).',
                'communication' => 'Đọc kỹ câu A hỏi gì, rồi chọn câu trả lời hợp ngữ cảnh nhất.',
                'reading' => 'Tìm từ khóa của câu hỏi trong đoạn văn, đáp án thường nằm ngay gần đó.',
                'pronunciation' => 'Đọc to từng phương án và so sánh âm được hỏi.',
                default => 'Loại trừ những phương án chắc chắn sai trước.',
            },
        };
    }

    public static function answer(Attempt $a, int $position, array $response, ?int $timeMs = null, bool $hintUsed = false): array
    {
        $a = static::expireIfNeeded($a->fresh());
        if ($a->status !== 'in_progress') {
            throw new DomainError(!empty($a->meta['auto_submitted']) ? 'Đã hết giờ làm bài. Bài của bạn đã được nộp tự động.' : 'Bài này đã nộp, không thể trả lời thêm.');
        }
        return DB::transaction(function () use ($a, $position, $response, $timeMs, $hintUsed) {
            $a = Attempt::whereKey($a->id)->lockForUpdate()->first();
            if ($a->status !== 'in_progress') throw new DomainError('Bài này đã nộp, không thể trả lời thêm.');
            $item = AttemptItem::where('attempt_id', $a->id)->where('position', $position)->lockForUpdate()->first();
            if (!$item) throw new DomainError('Không tìm thấy câu hỏi này trong bài.');
            $immediate = static::feedbackImmediate($a);
            // Bài có phản hồi ngay: chỉ chấm lần đầu (chống thử nhiều lần). Bài thi: cho đổi đáp án tới khi nộp.
            if ($item->answered_at && $immediate) {
                return static::itemFeedback($a, $item, true);
            }
            [$ok, $clean] = Grader::grade($item->snapshot, $response);
            $first = $item->answered_at === null;
            $item->response = $clean;
            $item->is_correct = $ok;
            $item->time_ms = $timeMs !== null ? max(0, min($timeMs, 3600000)) : null;
            $item->hint_used = $item->hint_used || ($hintUsed && $item->phase === 'guided');
            $item->answered_at = now();
            $item->save();
            $agg = AttemptItem::where('attempt_id', $a->id)->selectRaw('SUM(answered_at IS NOT NULL) answered, SUM(is_correct = 1) correct')->first();
            $a->answered = (int) $agg->answered;
            $a->correct = (int) $agg->correct;
            if ($first && $immediate) {
                $streak = ($a->meta['streak'] ?? 0);
                $streak = $ok ? $streak + 1 : 0;
                $meta = $a->meta; $meta['streak'] = $streak; $a->meta = $meta;
                $a->best_streak = max($a->best_streak, $streak);
            }
            $a->last_activity_at = now();
            $a->save();
            LiveStatus::touchAttempt($a);
            return static::itemFeedback($a, $item, $immediate);
        });
    }

    protected static function itemFeedback(Attempt $a, AttemptItem $item, bool $reveal): array
    {
        $out = ['position' => $item->position, 'answered' => true, 'answered_count' => $a->answered, 'total' => $a->total];
        if ($reveal) {
            $snap = $item->snapshot;
            $out += [
                'is_correct' => $item->is_correct,
                'correct_text' => $snap['key']['correct_text'] ?? null,
                'correct_index' => $snap['key']['correct_index'] ?? null,
                'explanation_vi' => $snap['explanation_vi'] ?? null,
                'example_after' => $snap['prompt']['example_after'] ?? null,
                'tips' => $item->is_correct === false ? MistakeTips::forTags($snap['tags'] ?? []) : [],
                'streak' => $a->meta['streak'] ?? 0,
            ];
        } else {
            $out['saved'] = true;
        }
        return $out;
    }

    /** Nộp bài: idempotent (khóa dòng; nộp lại trả kết quả cũ). */
    public static function submit(Attempt $a, bool $auto = false): Attempt
    {
        $a = DB::transaction(function () use ($a, $auto) {
            $a = Attempt::whereKey($a->id)->lockForUpdate()->first();
            if ($a->status !== 'in_progress') return $a;
            $items = AttemptItem::where('attempt_id', $a->id)->get();
            $gradable = $items->filter(fn ($i) => in_array($i->snapshot['type'], \App\Models\Question::AUTO_GRADED, true));
            $total = $gradable->count();
            $correct = $gradable->where('is_correct', true)->count();
            $a->correct = $correct;
            $a->answered = $items->whereNotNull('answered_at')->count();
            $a->score_100 = $total > 0 ? (int) round($correct / $total * 100) : null;
            $a->status = 'submitted';
            $a->submitted_at = now();
            $meta = $a->meta ?? [];
            if ($auto) $meta['auto_submitted'] = true;
            $indep = $gradable->where('phase', 'independent');
            $meta['independent_score'] = $indep->count() ? (int) round($indep->where('is_correct', true)->count() / $indep->count() * 100) : $a->score_100;
            $a->meta = $meta;
            if (in_array($a->kind, ['exam', 'assignment'], true) || ($meta['shareable'] ?? false)) {
                $a->share_token = $a->share_token ?: Str::random(32);
            }
            $a->save();

            $user = User::find($a->user_id);
            Learning::afterSubmit($a, $items, $user);
            Rewards::forAttempt($a, $items, $user);
            // Ghi nhận mốc đã đạt ngay khi nộp, kể cả chưa mở trang Hồ sơ.
            ProfileStats::build($user);
            // v1.3: hoàn thành bài học / ôn tập / đề / bài giao đạt điểm chuẩn → +phút chơi Nông trại 3D (Playtime Gate)
            if ($user && in_array($a->kind, ['lesson', 'review', 'exam', 'assignment'], true)
                && $a->score_100 !== null && $a->score_100 >= (int) Settings::get('learn.pass_score', 60)) {
                ZooGardenService::rewardLessonMinutes($user->id);
            }
            static::detectFastAnswers($a, $items);
            return $a->fresh();
        });
        LiveStatus::touch($a->user_id, null, null);
        return $a;
    }

    protected static function detectFastAnswers(Attempt $a, Collection $items): void
    {
        $limit = (int) Settings::get('reward.fast_answer_ms', 800);
        $timed = $items->whereNotNull('time_ms');
        if ($timed->count() < 8) return;
        $fast = $timed->filter(fn ($i) => $i->time_ms < $limit);
        // Chỉ gắn cờ khi vừa quá nhanh vừa có mẫu bất thường (gần như tuyệt đối đúng). Không tự trừ điểm.
        if ($fast->count() >= (int) ceil($timed->count() * 0.8) && $fast->where('is_correct', true)->count() >= (int) ceil($fast->count() * 0.9)) {
            CheatFlag::create(['user_id' => $a->user_id, 'attempt_id' => $a->id, 'reason' => 'Trả lời nhanh bất thường (< ' . $limit . 'ms/câu) với tỉ lệ đúng rất cao',
                'details' => ['fast' => $fast->count(), 'timed' => $timed->count()]]);
        }
    }

    public static function resultSummary(Attempt $a): array
    {
        $items = $a->items()->get();
        $wrong = $items->filter(fn ($i) => $i->is_correct === false || ($i->answered_at === null && in_array($i->snapshot['type'], \App\Models\Question::AUTO_GRADED, true)));
        $tags = [];
        foreach ($wrong as $w) foreach ($w->snapshot['tags'] ?? [] as $t) $tags[$t] = ($tags[$t] ?? 0) + 1;
        arsort($tags);
        $bySkill = [];
        foreach ($items as $i) {
            if (!in_array($i->snapshot['type'], \App\Models\Question::AUTO_GRADED, true)) continue;
            $s = $i->snapshot['skill'];
            $bySkill[$s]['total'] = ($bySkill[$s]['total'] ?? 0) + 1;
            $bySkill[$s]['correct'] = ($bySkill[$s]['correct'] ?? 0) + ($i->is_correct ? 1 : 0);
        }
        return [
            'score_100' => $a->score_100, 'correct' => $a->correct, 'total' => $a->total, 'answered' => $a->answered,
            'xp' => $a->xp_awarded, 'xu' => $a->xu_awarded, 'reward_note' => $a->meta['reward_note'] ?? null,
            'auto_submitted' => (bool) ($a->meta['auto_submitted'] ?? false),
            'weak_tags' => collect($tags)->take(4)->map(fn ($n, $t) => ['tag' => $t, 'label' => MistakeTips::label($t), 'count' => $n])->values(),
            'by_skill' => collect($bySkill)->map(fn ($v, $k) => $v + ['label' => \App\Models\Question::SKILLS[$k] ?? $k])->values(),
            'share_url' => $a->share_token && !$a->share_revoked_at ? route('share.show', $a->share_token) : null,
            'duration_sec' => $a->submitted_at ? $a->started_at->diffInSeconds($a->submitted_at) : null,
        ];
    }
}
