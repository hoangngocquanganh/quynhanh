<?php

namespace App\Services;

use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

/**
 * Bộ lọc tên hiển thị / tên nông trại nhiều lớp (máy chủ quyết định):
 * chuẩn hóa Unicode, bỏ dấu, map leetspeak, gộp ký tự lặp, chặn mạo danh, URL/SĐT/email, từ cấm (Admin quản lý).
 * Thông báo thân thiện, KHÔNG in lại từ bị chặn.
 */
class NameFilter
{
    // Danh sách tối thiểu tích hợp sẵn; Admin bổ sung trong "Bộ lọc từ".
    protected const BUILTIN = ['admin', 'quantri', 'quan tri', 'chie official', 'chieofficial', 'support', 'moderator', 'giaovien chie',
        'fuck', 'shit', 'bitch', 'dick', 'porn', 'sex', 'dm', 'dmm', 'dcm', 'vcl', 'vkl', 'clgt', 'dit', 'lon', 'buoi', 'cac', 'ditme', 'dkm', 'occho', 'oc cho'];

    public static function normalize(string $s): string
    {
        $s = \Normalizer::normalize($s, \Normalizer::FORM_KC) ?: $s;
        $s = mb_strtolower($s);
        $s = Str::ascii($s);                                     // bỏ dấu tiếng Việt
        $s = strtr($s, ['0' => 'o', '1' => 'i', '3' => 'e', '4' => 'a', '5' => 's', '7' => 't', '@' => 'a', '$' => 's', '!' => 'i']);
        $s = preg_replace('/(.)\1{2,}/', '$1', $s);              // gộp ký tự lặp
        return $s;
    }

    /** null nếu hợp lệ; ngược lại là thông báo lỗi tiếng Việt. */
    public static function check(string $name, int $min = 2, int $max = 30): ?string
    {
        $raw = trim($name);
        $len = mb_strlen($raw);
        if ($len < $min || $len > $max) return "Tên cần dài từ {$min} đến {$max} ký tự.";
        if (!preg_match('/^[\p{L}\p{N} _.\-]+$/u', $raw)) return 'Tên chỉ gồm chữ cái, số, khoảng trắng và dấu _ . -';
        if (preg_match('/(https?:|www\.|\.com|\.vn|@|\d{8,})/i', $raw)) return 'Tên không được chứa đường dẫn, email hay số điện thoại.';
        $n = static::normalize($raw);
        $compact = preg_replace('/[^a-z0-9]/', '', $n);
        $words = preg_split('/[^a-z0-9]+/', $n, -1, PREG_SPLIT_NO_EMPTY);
        [$block, $allow] = static::lists();
        foreach ($allow as $a) {
            if ($a !== '' && str_contains($compact, preg_replace('/[^a-z0-9]/', '', static::normalize($a)))) return null;
        }
        foreach ($block as [$term, $mode]) {
            $t = preg_replace('/[^a-z0-9 ]/', '', static::normalize($term));
            if ($t === '') continue;
            if ($mode === 'word' || mb_strlen(str_replace(' ', '', $t)) <= 4) {
                // từ ngắn: chỉ khớp nguyên từ để tránh chặn nhầm tên thật
                if (str_contains(' ' . implode(' ', $words) . ' ', ' ' . $t . ' ')) return 'Tên này chưa phù hợp. Hãy thử một tên khác nhé!';
            } elseif (str_contains($compact, str_replace(' ', '', $t))) {
                return 'Tên này chưa phù hợp. Hãy thử một tên khác nhé!';
            }
        }
        return null;
    }

    protected static function lists(): array
    {
        return Cache::remember('chie.wordfilters', 300, function () {
            $rows = DB::table('word_filters')->get();
            $block = array_map(fn ($t) => [$t, 'word'], self::BUILTIN);
            foreach ($rows->where('list', 'block') as $r) $block[] = [$r->term, $r->match];
            $allow = $rows->where('list', 'allow')->pluck('term')->all();
            return [$block, $allow];
        });
    }

    public static function suggestions(): array
    {
        $a = ['Cú Mèo', 'Mầm Xanh', 'Cá Heo', 'Sao Nhỏ', 'Gấu Trúc', 'Chim Sẻ', 'Thỏ Ngọc', 'Rùa Nhanh'];
        $b = ['Xanh', 'Vui', 'Chăm', 'Nhanh', 'Hiền'];
        return [$a[array_rand($a)] . ' ' . $b[array_rand($b)] . ' ' . random_int(10, 99), $a[array_rand($a)] . ' ' . random_int(100, 999), $a[array_rand($a)] . ' ' . $b[array_rand($b)]];
    }

    /** Gmail: bỏ dấu chấm và +tag để chống tạo nhiều tài khoản ảo. */
    public static function canonicalEmail(string $email): string
    {
        $email = mb_strtolower(trim($email));
        if (!str_contains($email, '@')) return $email;
        [$local, $domain] = explode('@', $email, 2);
        if (in_array($domain, ['gmail.com', 'googlemail.com'], true)) {
            $local = str_replace('.', '', explode('+', $local)[0]);
            $domain = 'gmail.com';
        }
        return $local . '@' . $domain;
    }

    public static function disposableDomain(string $email): bool
    {
        $domain = mb_strtolower(substr(strrchr($email, '@') ?: '', 1));
        return in_array($domain, ['mailinator.com', '10minutemail.com', 'tempmail.com', 'guerrillamail.com', 'yopmail.com', 'trashmail.com', 'temp-mail.org', 'sharklasers.com', 'getnada.com', 'dispostable.com'], true);
    }
}
