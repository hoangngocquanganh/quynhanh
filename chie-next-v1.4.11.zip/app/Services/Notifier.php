<?php

namespace App\Services;

use App\Models\InboxNotification;

class Notifier
{
    public static function send(int $userId, string $type, string $title, ?string $body = null, ?string $url = null): void
    {
        InboxNotification::create(['user_id' => $userId, 'type' => $type, 'title' => mb_substr($title, 0, 190),
            'body' => $body ? mb_substr($body, 0, 500) : null, 'url' => $url, 'created_at' => now()]);
    }

    public static function many(iterable $userIds, string $type, string $title, ?string $body = null, ?string $url = null): void
    {
        $rows = [];
        foreach ($userIds as $id) $rows[] = ['user_id' => $id, 'type' => $type, 'title' => mb_substr($title, 0, 190), 'body' => $body ? mb_substr($body, 0, 500) : null, 'url' => $url, 'created_at' => now()];
        foreach (array_chunk($rows, 200) as $chunk) InboxNotification::insert($chunk);
    }
}
