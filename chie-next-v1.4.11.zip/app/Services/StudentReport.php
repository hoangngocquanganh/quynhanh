<?php

namespace App\Services;

use App\Models\Assignment;
use App\Models\AssignmentSubmission;
use App\Models\Attempt;
use App\Models\LessonProgress;
use App\Models\SkillStat;
use App\Models\User;
use Illuminate\Support\Facades\DB;

/**
 * Báo cáo học tập của MỘT học sinh (dùng cho phụ huynh đã liên kết & giáo viên phụ trách).
 * Chỉ dữ liệu học tập; không gồm Xu/túi đồ cho giáo viên.
 */
class StudentReport
{
    public static function build(User $s, bool $includeWallet = false): array
    {
        $g = (int) ($s->grade_level ?: 0);
        $path = $g ? Curriculum::path($g, $s) : ['units' => [], 'stats' => ['done' => 0, 'total' => 0, 'percent' => 0], 'current' => null];
        $attempts = Attempt::where('user_id', $s->id)->where('status', 'submitted')->whereIn('kind', ['lesson', 'exam', 'review', 'assignment', 'game'])
            ->latest('submitted_at')->limit(15)->get();
        $weekAvg = Attempt::where('user_id', $s->id)->where('status', 'submitted')->whereNotNull('score_100')->where('submitted_at', '>=', now()->startOfWeek())->avg('score_100');
        $weak = SkillStat::where('user_id', $s->id)->where('tag', '<>', '')->where('total', '>=', 2)->whereColumn('correct', '<', DB::raw('total * 0.7'))
            ->orderByRaw('correct / total')->limit(5)->get()->map(fn ($w) => ['label' => MistakeTips::label($w->tag), 'correct' => $w->correct, 'total' => $w->total]);
        $skills = SkillStat::where('user_id', $s->id)->where('grade_level', $g)->where('tag', '')->get()
            ->map(fn ($w) => ['label' => \App\Models\Question::SKILLS[$w->skill] ?? $w->skill, 'pct' => $w->total ? (int) round($w->correct / $w->total * 100) : 0, 'total' => $w->total]);
        // thời gian học 7 ngày (ước tính từ các lượt làm, mỗi lượt tối đa 60 phút)
        $days = [];
        for ($i = 6; $i >= 0; $i--) $days[now()->subDays($i)->toDateString()] = 0;
        $rows = Attempt::where('user_id', $s->id)->where('started_at', '>=', now()->subDays(6)->startOfDay())->get(['started_at', 'submitted_at', 'last_activity_at']);
        foreach ($rows as $r) {
            $end = $r->submitted_at ?? $r->last_activity_at ?? $r->started_at;
            $min = min(60, max(1, (int) round($r->started_at->diffInSeconds($end) / 60)));
            $d = $r->started_at->toDateString();
            if (isset($days[$d])) $days[$d] += $min;
        }
        $live = LiveStatus::describe(DB::table('user_live_status')->where('user_id', $s->id)->first());
        $due = $g ? Curriculum::dueCount($s->id, $g) : ['questions' => 0, 'words' => 0];
        $classIds = DB::table('classroom_members')->where('student_id', $s->id)->where('status', 'active')->pluck('classroom_id');
        $assignments = Assignment::with('classroom')->whereIn('classroom_id', $classIds)
            ->where(fn ($q) => $q->where('target', 'class')->orWhereExists(fn ($e) => $e->from('assignment_targets')->whereColumn('assignment_targets.assignment_id', 'assignments.id')->where('student_id', $s->id)))
            ->latest('id')->limit(10)->get();
        $subs = AssignmentSubmission::where('student_id', $s->id)->whereIn('assignment_id', $assignments->pluck('id'))->get()->keyBy('assignment_id');
        $out = compact('path', 'attempts', 'weak', 'skills', 'days', 'live', 'due', 'assignments', 'subs') + [
            'weekAvg' => $weekAvg !== null ? (int) round($weekAvg) : null,
            'completedLessons' => LessonProgress::where('user_id', $s->id)->whereIn('status', ['completed', 'mastered'])->count(),
            'classes' => $s->activeClassrooms()->get(),
        ];
        try {
            $out['zoo_stats'] = ZooGardenService::weeklyStats($s->id);   // v1.3: học Tiếng Anh & giờ chơi Nông trại 3D
        } catch (\Throwable $e) {
            $out['zoo_stats'] = null;
        }
        if ($includeWallet) $out['wallet'] = Economy::walletFor($s->id);
        return $out;
    }
}
