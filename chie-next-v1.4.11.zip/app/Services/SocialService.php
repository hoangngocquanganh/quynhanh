<?php

namespace App\Services;

use App\Models\Attempt;
use App\Models\ClassroomMember;
use App\Models\FamilyChallenge;
use App\Models\Team;
use App\Models\TeamMember;
use App\Models\User;
use App\Support\Settings;
use Illuminate\Support\Facades\DB;

/**
 * Đội trong lớp (mục tiêu học chung mỗi tuần, không có trò chuyện) và Thử thách gia đình (phụ huynh – con làm cùng một bộ câu).
 */
class SocialService
{
    // ------------------------------------------------------------------ đội

    public static function weekStart() { return now()->startOfWeek(); }

    /** Điểm tuần của đội = tổng XP học tập/game các thành viên nhận được từ thứ Hai. */
    public static function teamPoints(array $memberIds): int
    {
        if (!$memberIds) return 0;
        return (int) DB::table('xu_ledger')->whereIn('user_id', $memberIds)->where('created_at', '>=', static::weekStart())->where('delta_xp', '>', 0)->sum('delta_xp');
    }

    /** Danh sách đội của lớp kèm thành viên và điểm tuần (sắp xếp giảm dần). */
    public static function classTeams(int $classroomId)
    {
        return Team::with(['members.student'])->where('classroom_id', $classroomId)->orderBy('id')->get()->map(function ($t) {
            $ids = $t->members->pluck('student_id')->all();
            $pts = static::teamPoints($ids);
            return ['team' => $t, 'points' => $pts, 'percent' => $t->weekly_goal ? min(100, (int) round($pts / $t->weekly_goal * 100)) : 0,
                'members' => $t->members->map(fn ($m) => ['id' => $m->student_id, 'name' => $m->student->name, 'points' => static::teamPoints([$m->student_id])])->sortByDesc('points')->values()];
        })->sortByDesc('points')->values();
    }

    public static function createTeam(int $classroomId, string $name, string $emoji, int $goal, int $actorId): Team
    {
        if ($msg = NameFilter::check($name, 2, 40)) throw new DomainError($msg);
        if (Team::where('classroom_id', $classroomId)->count() >= (int) Settings::get('teams.max_per_class', 8)) throw new DomainError('Lớp đã có đủ số đội tối đa.');
        return Team::create(['classroom_id' => $classroomId, 'name' => trim($name), 'emoji' => mb_substr($emoji ?: '⭐', 0, 4), 'weekly_goal' => max(50, min(100000, $goal)), 'created_by' => $actorId]);
    }

    public static function setMember(Team $team, int $studentId, ?int $actorId = null): void
    {
        $inClass = ClassroomMember::where('classroom_id', $team->classroom_id)->where('student_id', $studentId)->where('status', 'active')->exists();
        if (!$inClass) throw new DomainError('Học sinh không ở trong lớp này.');
        TeamMember::updateOrCreate(['classroom_id' => $team->classroom_id, 'student_id' => $studentId], ['team_id' => $team->id]);
    }

    public static function leave(int $classroomId, int $studentId): void
    {
        TeamMember::where('classroom_id', $classroomId)->where('student_id', $studentId)->delete();
    }

    // ------------------------------------------------------------------ thử thách gia đình

    public static function createChallenge(User $parent, int $studentId, ?string $skill, int $count, ?string $message): FamilyChallenge
    {
        if (!$parent->isParentOf($studentId)) abort(404);
        $child = User::findOrFail($studentId);
        if (FamilyChallenge::where('parent_id', $parent->id)->where('student_id', $child->id)->where('status', 'open')->count() >= 3) throw new DomainError('Đang có 3 thử thách chưa xong. Hãy cùng con hoàn thành trước nhé.');
        $g = (int) $child->grade_level;
        $qs = QuestionPicker::pick($g, max(5, min(15, $count)), $child->id, [], array_filter(['skills' => $skill ? [$skill] : null, 'types' => ['mcq', 'listen_mcq', 'word_order', 'matching']]));
        if ($qs->count() < 5) throw new DomainError('Chưa đủ câu đã duyệt cho ' . grade_name($g) . ' để tạo thử thách.');
        $c = FamilyChallenge::create(['parent_id' => $parent->id, 'student_id' => $child->id, 'grade_level' => $g,
            'title' => 'Thử thách ' . ($skill ? mb_strtolower(\App\Models\Question::SKILLS[$skill] ?? $skill) : 'tổng hợp') . ' · ' . $qs->count() . ' câu',
            'snapshots' => $qs->map(fn ($q) => Grader::build($q, 4))->values()->all(), 'status' => 'open', 'message' => $message ? mb_substr(strip_tags($message), 0, 200) : null,
            'expires_at' => now()->addDays(3)]);
        Notifier::send($child->id, 'family', $parent->name . ' gửi bạn một thử thách gia đình!', $c->message ?: 'Làm cùng bộ câu với bố mẹ rồi so điểm nhé.', route('family.show', $c));
        return $c;
    }

    public static function canSee(User $u, FamilyChallenge $c): bool { return $u->id === $c->parent_id || $u->id === $c->student_id; }

    public static function start(User $u, FamilyChallenge $c): Attempt
    {
        if (!static::canSee($u, $c)) abort(404);
        $c = static::refresh($c);
        if ($c->status !== 'open') throw new DomainError('Thử thách đã kết thúc.');
        $field = $u->id === $c->parent_id ? 'parent_attempt_id' : 'child_attempt_id';
        if ($c->$field) {
            $a = Attempt::find($c->$field);
            if ($a && $a->status === 'in_progress') return $a;
            throw new DomainError('Bạn đã làm thử thách này rồi.');
        }
        return DB::transaction(function () use ($u, $c, $field) {
            $c = FamilyChallenge::whereKey($c->id)->lockForUpdate()->first();
            if ($c->$field) return Attempt::findOrFail($c->$field);
            $a = AttemptService::create($u, 'family', 'family', $c->id, $c->grade_level, collect($c->snapshots), ['title' => $c->title, 'feedback' => 'immediate', 'meta' => ['mode' => 'family']]);
            $c->$field = $a->id; $c->save();
            return $a;
        });
    }

    /** Cập nhật trạng thái: cả hai đã nộp → xong (con nhận thưởng nhỏ 1 lần); quá hạn → hết hạn. */
    public static function refresh(FamilyChallenge $c): FamilyChallenge
    {
        if ($c->status !== 'open') return $c;
        $pa = $c->parent_attempt_id ? Attempt::find($c->parent_attempt_id) : null;
        $ca = $c->child_attempt_id ? Attempt::find($c->child_attempt_id) : null;
        if ($pa && $ca && $pa->status !== 'in_progress' && $ca->status !== 'in_progress') {
            $c->update(['status' => 'done']);
            [$xp, $xu] = Economy::applyDailyCap($c->student_id, 5, (int) Settings::get('family.bonus_xu', 15));
            if ($xp || $xu) Economy::grant($c->student_id, $xp, $xu, 'family_bonus', 'family:' . $c->id . ':bonus', 'family:' . $c->id);
            Notifier::send($c->parent_id, 'family', 'Thử thách gia đình đã xong — xem kết quả!', null, route('family.show', $c));
        } elseif ($c->expires_at->isPast()) {
            $c->update(['status' => 'expired']);
        }
        return $c->fresh();
    }
}
