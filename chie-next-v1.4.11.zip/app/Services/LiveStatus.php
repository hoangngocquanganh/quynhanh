<?php

namespace App\Services;

use App\Models\Attempt;
use Illuminate\Support\Facades\DB;

/** Bảng nhịp trực tuyến siêu nhẹ: 1 dòng / người dùng (INSERT ... ON DUPLICATE KEY UPDATE). */
class LiveStatus
{
    public const MODULES = ['learn' => 'Đang học', 'exam' => 'Đang làm đề', 'game' => 'Đang chơi game', 'farm' => 'Đang ở nông trại',
        'review' => 'Đang ôn tập', 'browse' => 'Đang xem trang'];

    public static function touch(int $userId, ?string $module, ?string $label): void
    {
        DB::statement('INSERT INTO user_live_status (user_id, module, label, last_seen_at) VALUES (?, ?, ?, ?)
            ON DUPLICATE KEY UPDATE module = VALUES(module), label = VALUES(label), last_seen_at = VALUES(last_seen_at)',
            [$userId, $module, $label ? mb_substr($label, 0, 190) : null, now()]);
    }

    public static function touchAttempt(Attempt $a): void
    {
        $module = ['lesson' => 'learn', 'exam' => 'exam', 'review' => 'review', 'game' => 'game', 'raid' => 'farm', 'assignment' => 'learn'][$a->kind] ?? 'learn';
        // Phụ huynh chỉ thấy vị trí câu, không thấy đáp án đang chọn.
        $label = ($a->title ?: 'Bài học') . ' — Câu ' . min($a->total, $a->answered + 1) . '/' . $a->total;
        if ($a->expires_at) {
            $left = max(0, now()->diffInSeconds($a->expires_at, false));
            $label .= ' — Còn ' . sprintf('%02d:%02d', intdiv((int) $left, 60), (int) $left % 60);
        }
        static::touch($a->user_id, $module, $label);
    }

    public static function describe(?object $row): array
    {
        if (!$row || !$row->last_seen_at) return ['online' => false, 'text' => 'Chưa hoạt động'];
        $seen = \Illuminate\Support\Carbon::parse($row->last_seen_at);
        $online = $seen->gt(now()->subSeconds(150));
        return [
            'online' => $online,
            'module' => $row->module,
            'text' => $online ? (static::MODULES[$row->module] ?? 'Đang trực tuyến') . ($row->label ? ': ' . $row->label : '') : 'Hoạt động ' . $seen->diffForHumans(),
        ];
    }
}
