<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Subject extends Model
{
    use \App\Models\Concerns\NativeTypes;
    protected $table = 'subjects';
    protected $guarded = ['id'];

    protected function casts(): array
    {
        return ['manifest'=>'array','is_published'=>'boolean'];
    }

}
