<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class GameConfig extends Model
{
    use \App\Models\Concerns\NativeTypes;
    use UnescapedJson;
    protected $table = 'game_configs';
    protected $guarded = ['id'];

    protected function casts(): array
    {
        return ['config'=>'array','enabled'=>'boolean'];
    }

}
