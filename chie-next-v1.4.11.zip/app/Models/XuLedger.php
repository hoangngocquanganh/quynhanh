<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class XuLedger extends Model
{
    use \App\Models\Concerns\NativeTypes;
    protected $guarded = ['id'];

    protected function casts(): array
    {
        return ['meta'=>'array','created_at'=>'datetime'];
    }

    protected $table = 'xu_ledger';
    public $timestamps = false;
}
