<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class GuardianLinkCode extends Model
{
    use \App\Models\Concerns\NativeTypes;
    protected $table = 'guardian_link_codes';
    protected $guarded = ['id'];

    protected function casts(): array
    {
        return ['expires_at'=>'datetime','used_at'=>'datetime','revoked_at'=>'datetime'];
    }

}
