<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class EmailVerification extends Model
{
    use \App\Models\Concerns\NativeTypes;
    protected $table = 'email_verifications';
    protected $guarded = ['id'];

    protected function casts(): array
    {
        return ['expires_at'=>'datetime','used_at'=>'datetime'];
    }

}
