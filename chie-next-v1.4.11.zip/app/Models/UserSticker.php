<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class UserSticker extends Model
{
    use \App\Models\Concerns\NativeTypes;
    protected $table = 'user_stickers';
    protected $guarded = ['id'];

    protected function casts(): array
    {
        return ['due_at' => 'datetime', 'collected_at' => 'datetime', 'last_correct_on' => 'date'];
    }
}
