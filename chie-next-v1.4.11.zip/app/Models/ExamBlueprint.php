<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ExamBlueprint extends Model
{
    use \App\Models\Concerns\NativeTypes;
    protected $table = 'exam_blueprints';
    protected $guarded = ['id'];

    protected function casts(): array
    {
        return ['skill_mix'=>'array','is_active'=>'boolean'];
    }

    public function scopeForGrade($q, int $g) { return $q->where('grade_from', '<=', $g)->where('grade_to', '>=', $g); }
}
