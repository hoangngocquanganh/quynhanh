<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Attempt extends Model
{
    use \App\Models\Concerns\NativeTypes;
    use UnescapedJson;
    protected $table = 'attempts';
    protected $guarded = ['id'];

    protected function casts(): array
    {
        return ['meta'=>'array','rewarded'=>'boolean','started_at'=>'datetime','expires_at'=>'datetime','submitted_at'=>'datetime','last_activity_at'=>'datetime','share_revoked_at'=>'datetime'];
    }

    public function user() { return $this->belongsTo(User::class); }
    public function items() { return $this->hasMany(AttemptItem::class)->orderBy('position'); }
    public function assignment() { return $this->belongsTo(Assignment::class); }
    public function isOpen(): bool { return $this->status === 'in_progress' && (!$this->expires_at || $this->expires_at->isFuture()); }
}
