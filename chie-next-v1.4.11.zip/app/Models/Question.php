<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Question extends Model
{
    use \App\Models\Concerns\NativeTypes;
    use UnescapedJson;
    protected $guarded = ['id'];

    public const SKILLS = [
        'vocabulary' => 'Từ vựng', 'grammar' => 'Ngữ pháp', 'listening' => 'Nghe', 'speaking' => 'Nói',
        'reading' => 'Đọc', 'writing' => 'Viết', 'pronunciation' => 'Phát âm', 'communication' => 'Giao tiếp',
    ];

    public const TYPES = [
        'mcq' => 'Trắc nghiệm', 'listen_mcq' => 'Nghe và chọn', 'word_order' => 'Sắp xếp từ thành câu',
        'matching' => 'Ghép cặp', 'fill_blank' => 'Điền từ', 'writing' => 'Viết tự do (giáo viên chấm)',
        'speaking' => 'Luyện nói (tự đánh giá)',
    ];

    /** Loại câu chấm tự động được. */
    public const AUTO_GRADED = ['mcq', 'listen_mcq', 'word_order', 'matching', 'fill_blank'];

    protected function casts(): array
    {
        return [
            'prompt' => 'array', 'options' => 'array', 'answer' => 'array', 'tags' => 'array', 'flags' => 'array',
            'reviewed_at' => 'datetime',
        ];
    }

    public function unit() { return $this->belongsTo(Unit::class); }
    public function versions() { return $this->hasMany(QuestionVersion::class); }
    public function lessons() { return $this->belongsToMany(Lesson::class, 'lesson_question'); }

    public function scopePublished($q) { return $q->where('status', 'published'); }

    public function skillLabel(): string { return self::SKILLS[$this->skill] ?? $this->skill; }
    public function typeLabel(): string { return self::TYPES[$this->type] ?? $this->type; }

    /** Ảnh chụp nội dung để lưu vào lượt làm (lịch sử không đổi khi học liệu sửa sau này). */
    public function snapshot(): array
    {
        return [
            'id' => $this->id, 'version' => $this->version, 'skill' => $this->skill, 'type' => $this->type, 'difficulty' => $this->difficulty,
            'prompt' => $this->prompt, 'options' => $this->options, 'answer' => $this->answer,
            'explanation_vi' => $this->explanation_vi, 'tags' => $this->tags ?? [],
        ];
    }

    public static function hashContent(string $text, $options, $answer): string
    {
        $norm = function ($s) {
            $s = \Normalizer::normalize((string) $s, \Normalizer::FORM_C) ?: (string) $s;
            $s = mb_strtolower(trim($s));
            $s = str_replace(["\u{2019}", "\u{2018}", "\u{201C}", "\u{201D}"], ["'", "'", '"', '"'], $s);
            $s = preg_replace("/[^\\p{L}\\p{N}\\s'\\/-]/u", ' ', $s);
            return trim(preg_replace('/\s+/u', ' ', $s));
        };
        $opts = is_array($options) ? array_map($norm, array_map(fn ($o) => is_array($o) ? json_encode($o, JSON_UNESCAPED_UNICODE) : $o, $options)) : [];
        sort($opts);
        return sha1($norm($text) . '|' . implode('|', $opts) . '|' . $norm(json_encode($answer, JSON_UNESCAPED_UNICODE)));
    }
}
