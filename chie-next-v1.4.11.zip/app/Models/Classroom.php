<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Classroom extends Model
{
    use \App\Models\Concerns\NativeTypes;
    protected $table = 'classrooms';
    protected $guarded = ['id'];

    protected function casts(): array
    {
        return [];
    }

    public function teacherLinks() { return $this->hasMany(ClassroomTeacher::class); }
    public function activeTeacherLinks() { return $this->hasMany(ClassroomTeacher::class)->whereNull('revoked_at'); }
    public function teachers() { return $this->belongsToMany(User::class, 'classroom_teachers', 'classroom_id', 'teacher_id')->wherePivotNull('revoked_at')->withPivot('role'); }
    public function members() { return $this->hasMany(ClassroomMember::class); }
    public function activeMembers() { return $this->hasMany(ClassroomMember::class)->where('status', 'active'); }
    public function students() { return $this->belongsToMany(User::class, 'classroom_members', 'classroom_id', 'student_id')->wherePivot('status', 'active'); }
    public function invites() { return $this->hasMany(ClassInvite::class); }
    public function assignments() { return $this->hasMany(Assignment::class); }
}
