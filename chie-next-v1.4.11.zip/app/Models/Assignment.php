<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Assignment extends Model
{
    use \App\Models\Concerns\NativeTypes;
    protected $table = 'assignments';
    protected $guarded = ['id'];

    protected function casts(): array
    {
        return ['question_ids'=>'array','available_from'=>'datetime','due_at'=>'datetime'];
    }

    public function classroom() { return $this->belongsTo(Classroom::class); }
    public function teacher() { return $this->belongsTo(User::class, 'teacher_id'); }
    public function lesson() { return $this->belongsTo(Lesson::class); }
    public function blueprint() { return $this->belongsTo(ExamBlueprint::class, 'blueprint_id'); }
    public function targets() { return $this->hasMany(AssignmentTarget::class); }
    public function submissions() { return $this->hasMany(AssignmentSubmission::class); }
    public function typeLabel(): string { return ['lesson'=>'Học bài','practice'=>'Luyện tập','exam'=>'Làm đề','writing'=>'Bài viết','speaking'=>'Bài nói'][$this->type] ?? $this->type; }
}
