<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class GuardianLink extends Model
{
    use \App\Models\Concerns\NativeTypes;
    protected $table = 'guardian_links';
    protected $guarded = ['id'];

    protected function casts(): array
    {
        return ['verified_at'=>'datetime','revoked_at'=>'datetime'];
    }

    public function parent() { return $this->belongsTo(User::class, 'parent_id'); }
    public function student() { return $this->belongsTo(User::class, 'student_id'); }
}
