<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class WorldLevel extends Model
{
    use \App\Models\Concerns\NativeTypes;
    protected $table = 'world_levels';
    protected $guarded = ['id'];

    protected function casts(): array
    {
        return ['is_active'=>'boolean'];
    }

    public function world() { return $this->belongsTo(World::class); }
}
