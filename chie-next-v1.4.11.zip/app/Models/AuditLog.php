<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class AuditLog extends Model
{
    use \App\Models\Concerns\NativeTypes;
    use UnescapedJson;
    protected $table = 'audit_logs';
    protected $guarded = ['id'];

    protected function casts(): array
    {
        return ['old_values'=>'array','new_values'=>'array','created_at'=>'datetime'];
    }

    public $timestamps = false;
    public function actor() { return $this->belongsTo(User::class, 'actor_user_id'); }
}
