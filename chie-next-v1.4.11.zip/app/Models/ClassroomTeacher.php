<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ClassroomTeacher extends Model
{
    use \App\Models\Concerns\NativeTypes;
    protected $table = 'classroom_teachers';
    protected $guarded = ['id'];

    protected function casts(): array
    {
        return ['assigned_at'=>'datetime','revoked_at'=>'datetime'];
    }

    public $timestamps = false;
    public function classroom() { return $this->belongsTo(Classroom::class); }
    public function teacher() { return $this->belongsTo(User::class, 'teacher_id'); }
}
