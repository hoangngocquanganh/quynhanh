<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TeamMember extends Model
{
    use \App\Models\Concerns\NativeTypes;
    protected $table = 'team_members';
    protected $guarded = ['id'];

    protected function casts(): array
    {
        return [];
    }
    public function student() { return $this->belongsTo(User::class, 'student_id'); }
    public function team() { return $this->belongsTo(Team::class); }
}
