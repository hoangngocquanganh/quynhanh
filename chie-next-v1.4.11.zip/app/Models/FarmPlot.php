<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class FarmPlot extends Model
{
    use \App\Models\Concerns\NativeTypes;
    protected $table = 'farm_plots';
    protected $guarded = ['id'];

    protected function casts(): array
    {
        return ['planted_at'=>'datetime','matures_at'=>'datetime','has_pest'=>'boolean'];
    }

}
