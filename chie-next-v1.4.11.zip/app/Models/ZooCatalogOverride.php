<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/** Ghi đè danh mục Zoo Garden do Admin chỉnh (tên, giá ϟ, thời gian lớn, cấp mở, bật/tắt, từ vựng). */
class ZooCatalogOverride extends Model
{
    use \App\Models\Concerns\NativeTypes;
    use UnescapedJson;
    protected $table = 'zoo_catalog_overrides';
    protected $guarded = ['id'];

    protected function casts(): array
    {
        return ['extra_json' => 'array', 'is_enabled' => 'boolean'];
    }
}
