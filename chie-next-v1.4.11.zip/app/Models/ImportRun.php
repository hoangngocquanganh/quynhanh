<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ImportRun extends Model
{
    use \App\Models\Concerns\NativeTypes;
    protected $table = 'import_runs';
    protected $guarded = ['id'];

    protected function casts(): array
    {
        return ['stats'=>'array','dry_run'=>'boolean','started_at'=>'datetime','finished_at'=>'datetime'];
    }
    public $timestamps = false;
}
