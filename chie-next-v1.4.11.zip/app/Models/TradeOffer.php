<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TradeOffer extends Model
{
    use \App\Models\Concerns\NativeTypes;
    protected $table = 'trade_offers';
    protected $guarded = ['id'];

    protected function casts(): array
    {
        return ['is_family'=>'boolean','resolved_at'=>'datetime'];
    }

    public function sender() { return $this->belongsTo(User::class, 'sender_id'); }
    public function receiver() { return $this->belongsTo(User::class, 'receiver_id'); }
    public function senderItem() { return $this->belongsTo(InventoryItem::class, 'sender_inventory_id'); }
    public function receiverItem() { return $this->belongsTo(InventoryItem::class, 'receiver_inventory_id'); }
}
