<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class FarmCrop extends Model
{
    use \App\Models\Concerns\NativeTypes;
    protected $table = 'farm_crops';
    protected $guarded = ['id'];

    protected function casts(): array
    {
        return ['words'=>'array','is_active'=>'boolean'];
    }

}
