<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class FarmAnimalKind extends Model
{
    use \App\Models\Concerns\NativeTypes;
    protected $table = 'farm_animal_kinds';
    protected $guarded = ['id'];

    protected function casts(): array
    {
        return ['words' => 'array', 'is_active' => 'boolean'];
    }

}
