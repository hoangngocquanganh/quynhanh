<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ReadingPassage extends Model
{
    use \App\Models\Concerns\NativeTypes;
    protected $table = 'reading_passages';
    protected $guarded = ['id'];

    protected function casts(): array
    {
        return ['glossary'=>'array','flags'=>'array'];
    }

}
