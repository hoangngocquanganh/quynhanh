<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class AttemptItem extends Model
{
    use \App\Models\Concerns\NativeTypes;
    use UnescapedJson;
    protected $table = 'attempt_items';
    protected $guarded = ['id'];

    protected function casts(): array
    {
        return ['snapshot'=>'array','response'=>'array','is_correct'=>'boolean','hint_used'=>'boolean','answered_at'=>'datetime'];
    }

    public $timestamps = false;
    public function attempt() { return $this->belongsTo(Attempt::class); }
    public function question() { return $this->belongsTo(Question::class); }
}
