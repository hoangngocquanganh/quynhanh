<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ClassInvite extends Model
{
    use \App\Models\Concerns\NativeTypes;
    protected $table = 'class_invites';
    protected $guarded = ['id'];

    protected function casts(): array
    {
        return ['expires_at'=>'datetime','revoked_at'=>'datetime'];
    }

    public function classroom() { return $this->belongsTo(Classroom::class); }
    public function isUsable(): bool { return !$this->revoked_at && $this->expires_at->isFuture() && $this->uses < $this->max_uses; }
}
