<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class WorldProgress extends Model
{
    use \App\Models\Concerns\NativeTypes;
    protected $guarded = ['id'];

    protected function casts(): array
    {
        return ['passed'=>'boolean'];
    }
    protected $table = 'world_progress';
}
