<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Unit extends Model
{
    use \App\Models\Concerns\NativeTypes;
    use UnescapedJson;
    protected $table = 'units';
    protected $guarded = ['id'];

    protected function casts(): array
    {
        return ['flags'=>'array'];
    }

    public function grade() { return $this->belongsTo(Grade::class); }
    public function lessons() { return $this->hasMany(Lesson::class)->orderBy('sort'); }
    public function publishedLessons() { return $this->hasMany(Lesson::class)->where('status', 'published')->orderBy('sort'); }
    /** Unit hiển thị cho lớp $g (unit thường của lớp đó hoặc unit chuyên đề dùng chung cho dải lớp). */
    public function scopeForGrade($q, int $g) { return $q->where(function ($w) use ($g) { $w->where('grade_id', $g)->orWhere(function ($b) use ($g) { $b->where('grade_id', '<=', $g)->where('grade_to', '>=', $g); }); }); }
}
