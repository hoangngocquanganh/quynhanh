<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ClassroomMember extends Model
{
    use \App\Models\Concerns\NativeTypes;
    protected $table = 'classroom_members';
    protected $guarded = ['id'];

    protected function casts(): array
    {
        return ['joined_at'=>'datetime','left_at'=>'datetime'];
    }

    public function classroom() { return $this->belongsTo(Classroom::class); }
    public function student() { return $this->belongsTo(User::class, 'student_id'); }
}
