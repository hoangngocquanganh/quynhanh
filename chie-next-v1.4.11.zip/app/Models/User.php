<?php

namespace App\Models;

use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Support\Facades\DB;

class User extends Authenticatable
{
    use \App\Models\Concerns\NativeTypes;
    protected $fillable = [
        'name', 'full_name', 'username', 'email', 'canonical_email', 'password', 'role', 'status', 'teacher_status',
        'grade_level', 'birth_year', 'created_by_parent_id', 'email_verified_at', 'settings', 'last_login_at', 'grade_changed_at',
    ];

    protected $hidden = ['password', 'remember_token'];

    public const ROLES = ['admin' => 'Quản trị viên', 'teacher' => 'Giáo viên', 'parent' => 'Phụ huynh', 'student' => 'Học sinh'];

    protected function casts(): array
    {
        return [
            'email_verified_at' => 'datetime', 'last_login_at' => 'datetime', 'grade_changed_at' => 'datetime',
            'password' => 'hashed', 'settings' => 'array',
        ];
    }

    public function isAdmin(): bool { return $this->role === 'admin'; }
    public function isTeacher(): bool { return $this->role === 'teacher'; }
    public function isApprovedTeacher(): bool { return $this->role === 'teacher' && $this->teacher_status === 'approved'; }
    public function isParent(): bool { return $this->role === 'parent'; }
    public function isStudent(): bool { return $this->role === 'student'; }
    public function roleLabel(): string { return self::ROLES[$this->role] ?? $this->role; }

    public function setting(string $key, $default = null) { return data_get($this->settings ?? [], $key, $default); }

    public function wallet() { return $this->hasOne(Wallet::class); }
    public function farm() { return $this->hasOne(Farm::class); }

    // ---- quan hệ phụ huynh
    public function childLinks() { return $this->hasMany(GuardianLink::class, 'parent_id')->where('status', 'active'); }
    public function children() { return $this->belongsToMany(User::class, 'guardian_links', 'parent_id', 'student_id')->wherePivot('status', 'active'); }
    public function guardians() { return $this->belongsToMany(User::class, 'guardian_links', 'student_id', 'parent_id')->wherePivot('status', 'active'); }

    // ---- quan hệ lớp học
    public function memberships() { return $this->hasMany(ClassroomMember::class, 'student_id'); }
    public function activeClassrooms() { return $this->belongsToMany(Classroom::class, 'classroom_members', 'student_id', 'classroom_id')->wherePivot('status', 'active'); }
    public function teachingClassrooms() { return $this->belongsToMany(Classroom::class, 'classroom_teachers', 'teacher_id', 'classroom_id')->wherePivotNull('revoked_at'); }

    /** ID các lớp giáo viên đang được phân công (hiệu lực ngay khi thu hồi). */
    public function teachingClassroomIds(): array
    {
        if ($this->isAdmin()) {   // v1.3.1: Admin xem được mọi lớp trong khu giáo viên
            return DB::table('classrooms')->where('status', 'active')->pluck('id')->map(fn ($v) => (int) $v)->all();
        }
        if (!$this->isApprovedTeacher()) return [];
        return DB::table('classroom_teachers')->join('classrooms', 'classrooms.id', '=', 'classroom_teachers.classroom_id')
            ->where('teacher_id', $this->id)->whereNull('revoked_at')->where('classrooms.status', 'active')
            ->pluck('classroom_id')->map(fn ($v) => (int) $v)->all();   // v1.3.1: hosting trả chuỗi → ép số
    }

    public function isParentOf(int $studentId): bool
    {
        return $this->isParent() && DB::table('guardian_links')->where('parent_id', $this->id)
            ->where('student_id', $studentId)->where('status', 'active')->exists();
    }

    public function teachesStudent(int $studentId): bool
    {
        $ids = $this->teachingClassroomIds();
        if (!$ids) return false;
        return DB::table('classroom_members')->whereIn('classroom_id', $ids)->where('student_id', $studentId)
            ->where('status', 'active')->exists();
    }

    /** Ai được xem dữ liệu học tập của học sinh $studentId? */
    public function canViewStudent(int $studentId): bool
    {
        return $this->isAdmin() || $this->id === $studentId || $this->isParentOf($studentId) || $this->teachesStudent($studentId);
    }

    public function initials(): string
    {
        $parts = preg_split('/\s+/u', trim($this->name));
        $s = mb_substr($parts[0] ?? '?', 0, 1) . (count($parts) > 1 ? mb_substr(end($parts), 0, 1) : '');
        return mb_strtoupper($s);
    }
}
