<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CheatFlag extends Model
{
    use \App\Models\Concerns\NativeTypes;
    protected $table = 'cheat_flags';
    protected $guarded = ['id'];

    protected function casts(): array
    {
        return ['details'=>'array'];
    }

    public function user() { return $this->belongsTo(User::class); }
}
