<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Farm extends Model
{
    use \App\Models\Concerns\NativeTypes;
    protected $table = 'farms';
    protected $guarded = ['id'];
    /** Bản lưu Zoo Garden có thể lớn — không đưa vào toArray()/JSON mặc định. */
    protected $hidden = ['zoo_save'];

    protected function casts(): array
    {
        return ['shield_until'=>'datetime','cold_until'=>'datetime','zoo_updated_at'=>'datetime','zoo_revision'=>'integer','zoo_pending_energy'=>'integer'];
    }

    protected $primaryKey = 'user_id';
    public $incrementing = false;
    public function hasShield(): bool { return $this->shield_until && $this->shield_until->isFuture(); }
}
