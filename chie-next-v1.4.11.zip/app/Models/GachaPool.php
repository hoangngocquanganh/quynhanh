<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class GachaPool extends Model
{
    use \App\Models\Concerns\NativeTypes;
    protected $table = 'gacha_pools';
    protected $guarded = ['id'];

    protected function casts(): array
    {
        return ['rates'=>'array','is_active'=>'boolean'];
    }

    public function items() { return $this->belongsToMany(ShopItem::class, 'gacha_pool_items'); }
}
