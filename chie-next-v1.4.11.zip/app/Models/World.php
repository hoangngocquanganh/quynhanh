<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class World extends Model
{
    use \App\Models\Concerns\NativeTypes;
    protected $table = 'worlds';
    protected $guarded = ['id'];

    protected function casts(): array
    {
        return ['is_active'=>'boolean'];
    }

    public function levels() { return $this->hasMany(WorldLevel::class)->orderBy('sort'); }
}
