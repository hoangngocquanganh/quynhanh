<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class WordFilter extends Model
{
    use \App\Models\Concerns\NativeTypes;
    protected $table = 'word_filters';
    protected $guarded = ['id'];

    protected function casts(): array
    {
        return [];
    }

}
