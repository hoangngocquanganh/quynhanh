<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Lesson extends Model
{
    use \App\Models\Concerns\NativeTypes;
    use UnescapedJson;
    protected $table = 'lessons';
    protected $guarded = ['id'];

    protected function casts(): array
    {
        return ['objectives'=>'array','content'=>'array','is_public'=>'boolean','reviewed_at'=>'datetime'];
    }

    public function unit() { return $this->belongsTo(Unit::class); }
    public function questions() { return $this->belongsToMany(Question::class, 'lesson_question')->withPivot('sort')->orderBy('lesson_question.sort'); }
    public function isAvailable(): bool { return $this->status === 'published' && $this->unit && $this->unit->status === 'published'; }
}
