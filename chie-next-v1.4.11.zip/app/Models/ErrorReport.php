<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ErrorReport extends Model
{
    use \App\Models\Concerns\NativeTypes;
    protected $table = 'error_reports';
    protected $guarded = ['id'];

    protected function casts(): array
    {
        return [];
    }

    public function user() { return $this->belongsTo(User::class); }
}
