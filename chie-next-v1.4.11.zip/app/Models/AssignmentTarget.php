<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class AssignmentTarget extends Model
{
    use \App\Models\Concerns\NativeTypes;
    protected $table = 'assignment_targets';
    protected $guarded = ['id'];

    protected function casts(): array
    {
        return [];
    }
    public $timestamps = false;
}
