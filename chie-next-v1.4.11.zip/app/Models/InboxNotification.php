<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class InboxNotification extends Model
{
    use \App\Models\Concerns\NativeTypes;
    protected $table = 'notifications_inbox';
    protected $guarded = ['id'];

    protected function casts(): array
    {
        return ['read_at'=>'datetime','created_at'=>'datetime'];
    }
    public $timestamps = false;
}
