<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class FamilyChallenge extends Model
{
    use \App\Models\Concerns\NativeTypes;
    protected $table = 'family_challenges';
    protected $guarded = ['id'];

    protected function casts(): array
    {
        return ['snapshots' => 'array', 'expires_at' => 'datetime'];
    }
    public function parent() { return $this->belongsTo(User::class, 'parent_id'); }
    public function student() { return $this->belongsTo(User::class, 'student_id'); }
    public function parentAttempt() { return $this->belongsTo(Attempt::class, 'parent_attempt_id'); }
    public function childAttempt() { return $this->belongsTo(Attempt::class, 'child_attempt_id'); }
}
