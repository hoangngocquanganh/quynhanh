<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class GachaLog extends Model
{
    use \App\Models\Concerns\NativeTypes;
    protected $table = 'gacha_logs';
    protected $guarded = ['id'];

    protected function casts(): array
    {
        return ['was_pity'=>'boolean','created_at'=>'datetime'];
    }

    public $timestamps = false;
    public function item() { return $this->belongsTo(ShopItem::class, 'shop_item_id'); }
}
