<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/** Chủ điểm ngữ pháp (chương trình GDPT 2018). Câu hỏi gắn nhãn "gp:<code>" trong bảng questions. */
class GrammarTopic extends Model
{
    use \App\Models\Concerns\NativeTypes;
    protected $guarded = ['id'];

    public const TRACKS = ['core' => 'Theo chương trình', 'exam10' => 'Ôn thi vào lớp 10', 'examgrad' => 'Ôn thi tốt nghiệp THPT'];

    protected function casts(): array
    {
        return ['theory' => 'array'];
    }

    public function tag(): string
    {
        return 'gp:' . $this->code;
    }

    /** Câu hỏi của chủ điểm; $statuses mặc định chỉ câu đã duyệt. */
    public function questionsQuery(array $statuses = ['published'])
    {
        return Question::whereIn('status', $statuses)->whereJsonContains('tags', $this->tag());
    }

    public static function stageOf(int $grade): string
    {
        return $grade <= 5 ? 'tieu_hoc' : ($grade <= 9 ? 'thcs' : 'thpt');
    }
}
