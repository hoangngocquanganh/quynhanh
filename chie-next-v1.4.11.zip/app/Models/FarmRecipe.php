<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class FarmRecipe extends Model
{
    use \App\Models\Concerns\NativeTypes;
    protected $table = 'farm_recipes';
    protected $guarded = ['id'];

    protected function casts(): array
    {
        return ['inputs'=>'array','is_active'=>'boolean'];
    }

}
