<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class LessonProgress extends Model
{
    use \App\Models\Concerns\NativeTypes;
    protected $table = 'lesson_progress';
    protected $guarded = ['id'];

    protected function casts(): array
    {
        return ['completed_at'=>'datetime','last_attempt_at'=>'datetime'];
    }

    public function lesson() { return $this->belongsTo(Lesson::class); }
}
