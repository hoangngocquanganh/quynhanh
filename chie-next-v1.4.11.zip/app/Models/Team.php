<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Team extends Model
{
    use \App\Models\Concerns\NativeTypes;
    protected $table = 'teams';
    protected $guarded = ['id'];

    protected function casts(): array
    {
        return ['weekly_goal' => 'integer'];
    }
    public function members() { return $this->hasMany(TeamMember::class); }
    public function classroom() { return $this->belongsTo(Classroom::class); }
}
