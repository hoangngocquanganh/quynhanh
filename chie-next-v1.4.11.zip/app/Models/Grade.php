<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Grade extends Model
{
    use \App\Models\Concerns\NativeTypes;
    protected $table = 'grades';
    protected $guarded = ['id'];

    protected function casts(): array
    {
        return ['is_visible'=>'boolean'];
    }

    public $incrementing = false;
    public function units() { return $this->hasMany(Unit::class); }
}
