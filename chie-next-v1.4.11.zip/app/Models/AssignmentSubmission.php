<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class AssignmentSubmission extends Model
{
    use \App\Models\Concerns\NativeTypes;
    protected $table = 'assignment_submissions';
    protected $guarded = ['id'];

    protected function casts(): array
    {
        return ['graded_at'=>'datetime','submitted_at'=>'datetime','share_feedback_with_parent'=>'boolean','is_late'=>'boolean'];
    }

    public function assignment() { return $this->belongsTo(Assignment::class); }
    public function student() { return $this->belongsTo(User::class, 'student_id'); }
    public function attempt() { return $this->belongsTo(Attempt::class); }
    public function finalScore(): ?int { return $this->teacher_score ?? $this->auto_score; }
}
