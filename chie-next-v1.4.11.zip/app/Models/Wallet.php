<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Wallet extends Model
{
    use \App\Models\Concerns\NativeTypes;
    protected $table = 'wallets';
    protected $guarded = ['id'];

    protected function casts(): array
    {
        return ['last_active_date'=>'date'];
    }

    protected $primaryKey = 'user_id';
    public $incrementing = false;
}
