<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class MediaFile extends Model
{
    use \App\Models\Concerns\NativeTypes;
    protected $table = 'media_files';
    protected $guarded = ['id'];

    protected function casts(): array
    {
        return [];
    }

}
