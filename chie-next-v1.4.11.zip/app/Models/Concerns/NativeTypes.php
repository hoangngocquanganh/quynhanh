<?php

namespace App\Models\Concerns;

use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Schema;

/**
 * v1.3.1 — Một số hosting (PHP dùng libmysqlclient hoặc bật ATTR_STRINGIFY_FETCHES) trả MỌI cột từ MySQL dưới dạng chuỗi
 * ("3" thay vì 3). Mã so sánh chặt (===) khi đó sai: bài học báo 404, lượt làm bài "không tìm thấy", game báo lỗi liên tục.
 * Trait này tự ép kiểu số nguyên / boolean cho mọi cột số của bảng (đọc cấu trúc bảng một lần, lưu bộ đệm),
 * trừ cột đã khai báo cast riêng trong model.
 */
trait NativeTypes
{
    /** @var array<string, array<string,string>> */
    protected static array $nativeTypeMap = [];

    public function getCasts()
    {
        $casts = parent::getCasts();
        foreach (static::nativeTypesFor($this->getTable()) as $col => $type) {
            if (!array_key_exists($col, $casts)) $casts[$col] = $type;
        }
        return $casts;
    }

    public static function nativeTypesFor(string $table): array
    {
        if (isset(static::$nativeTypeMap[$table])) return static::$nativeTypeMap[$table];
        $key = 'chie.coltypes.' . $table . '.' . config('chie.version');
        try {
            $map = Cache::rememberForever($key, function () use ($table) {
                $out = [];
                foreach (Schema::getColumns($table) as $c) {
                    $tn = strtolower((string) ($c['type_name'] ?? ''));
                    $full = strtolower((string) ($c['type'] ?? ''));
                    if ($tn === 'tinyint' && str_starts_with($full, 'tinyint(1)')) $out[$c['name']] = 'boolean';
                    elseif (in_array($tn, ['tinyint', 'smallint', 'mediumint', 'int', 'integer', 'bigint'], true)) $out[$c['name']] = 'integer';
                    elseif (in_array($tn, ['float', 'double', 'real'], true)) $out[$c['name']] = 'float';
                }
                return $out;
            });
        } catch (\Throwable $e) {
            $map = [];
        }
        return static::$nativeTypeMap[$table] = is_array($map) ? $map : [];
    }
}
