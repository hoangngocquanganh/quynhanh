<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class StickerPack extends Model
{
    use \App\Models\Concerns\NativeTypes;
    protected $table = 'sticker_packs';
    protected $guarded = ['id'];

    public function stickers()
    {
        return $this->hasMany(Sticker::class, 'pack_id')->orderBy('sort')->orderBy('id');
    }

    public function fitsGrade(?int $g): bool
    {
        return $g !== null && $g >= (int) $this->grade_from && $g <= (int) $this->grade_to;
    }

    public function gradeLabel(): string
    {
        return $this->grade_from === $this->grade_to ? 'Lớp ' . $this->grade_from : 'Lớp ' . $this->grade_from . '–' . $this->grade_to;
    }
}
