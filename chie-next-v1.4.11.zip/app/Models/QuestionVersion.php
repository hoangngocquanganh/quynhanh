<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class QuestionVersion extends Model
{
    use \App\Models\Concerns\NativeTypes;
    use UnescapedJson;
    protected $table = 'question_versions';
    protected $guarded = ['id'];

    protected function casts(): array
    {
        return ['snapshot'=>'array','created_at'=>'datetime'];
    }
    public $timestamps = false;
}
