<?php

namespace App\Models;

/** Lưu JSON giữ nguyên tiếng Việt (dễ tìm kiếm, dễ đọc trong CSDL). */
trait UnescapedJson
{
    protected function asJson($value, $flags = 0)
    {
        return json_encode($value, $flags | JSON_UNESCAPED_UNICODE);
    }
}
