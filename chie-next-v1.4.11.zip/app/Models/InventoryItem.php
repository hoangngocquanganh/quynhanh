<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class InventoryItem extends Model
{
    use \App\Models\Concerns\NativeTypes;
    protected $table = 'inventory_items';
    protected $guarded = ['id'];

    protected function casts(): array
    {
        return ['trade_locked_until'=>'datetime','placed'=>'boolean'];
    }

    public function item() { return $this->belongsTo(ShopItem::class, 'shop_item_id'); }
    public function owner() { return $this->belongsTo(User::class, 'user_id'); }
}
