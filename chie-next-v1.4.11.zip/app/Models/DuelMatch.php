<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class DuelMatch extends Model
{
    use \App\Models\Concerns\NativeTypes;
    protected $table = 'duel_matches';
    protected $guarded = ['id'];

    protected function casts(): array
    {
        return ['snapshots' => 'array', 'started_at' => 'datetime', 'ends_at' => 'datetime', 'finished_at' => 'datetime'];
    }
    public function a() { return $this->belongsTo(User::class, 'player_a'); }
    public function b() { return $this->belongsTo(User::class, 'player_b'); }
}
