<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class LexiconItem extends Model
{
    use \App\Models\Concerns\NativeTypes;
    use UnescapedJson;
    protected $table = 'lexicon_items';
    protected $guarded = ['id'];

    protected function casts(): array
    {
        return ['flags'=>'array'];
    }

}
