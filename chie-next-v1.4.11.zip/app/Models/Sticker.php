<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Sticker extends Model
{
    use \App\Models\Concerns\NativeTypes;
    protected $table = 'stickers';
    protected $guarded = ['id'];

    protected function casts(): array
    {
        return ['is_active' => 'boolean'];
    }

    public function pack()
    {
        return $this->belongsTo(StickerPack::class, 'pack_id');
    }

    /** Dữ liệu gửi xuống trình duyệt (không có thông tin người dùng). */
    public function card(): array
    {
        return ['id' => $this->id, 'emoji' => $this->emoji, 'word' => $this->word, 'ipa' => $this->ipa, 'vi' => $this->meaning_vi,
            'ex_en' => $this->example_en, 'ex_vi' => $this->example_vi, 'note' => $this->note_vi];
    }
}
