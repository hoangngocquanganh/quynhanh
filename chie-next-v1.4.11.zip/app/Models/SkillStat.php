<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SkillStat extends Model
{
    use \App\Models\Concerns\NativeTypes;
    protected $table = 'skill_stats';
    protected $guarded = ['id'];

    protected function casts(): array
    {
        return [];
    }

}
