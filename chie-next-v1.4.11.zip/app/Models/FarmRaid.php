<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class FarmRaid extends Model
{
    use \App\Models\Concerns\NativeTypes;
    protected $table = 'farm_raids';
    protected $guarded = ['id'];

    protected function casts(): array
    {
        return ['loot_taken'=>'array','loot_received'=>'array','loot_destroyed'=>'array','expires_at'=>'datetime','finished_at'=>'datetime'];
    }

    public function attacker() { return $this->belongsTo(User::class, 'attacker_id'); }
    public function defender() { return $this->belongsTo(User::class, 'defender_id'); }
}
