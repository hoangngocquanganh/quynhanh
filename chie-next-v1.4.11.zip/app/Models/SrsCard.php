<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SrsCard extends Model
{
    use \App\Models\Concerns\NativeTypes;
    protected $table = 'srs_cards';
    protected $guarded = ['id'];

    protected function casts(): array
    {
        return ['due_at'=>'datetime','last_reviewed_at'=>'datetime','last_correct'=>'boolean'];
    }

}
