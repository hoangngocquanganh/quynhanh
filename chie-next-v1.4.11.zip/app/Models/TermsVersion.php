<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TermsVersion extends Model
{
    use \App\Models\Concerns\NativeTypes;
    protected $table = 'terms_versions';
    protected $guarded = ['id'];

    protected function casts(): array
    {
        return ['is_active'=>'boolean','published_at'=>'datetime'];
    }

}
