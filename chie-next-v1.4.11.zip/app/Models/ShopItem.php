<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ShopItem extends Model
{
    use \App\Models\Concerns\NativeTypes;
    protected $table = 'shop_items';
    protected $guarded = ['id'];

    protected function casts(): array
    {
        return ['is_active'=>'boolean','season_ends_at'=>'datetime'];
    }

    public function isSeasonExpired(): bool { return $this->season_ends_at !== null && $this->season_ends_at->isPast(); }
}
