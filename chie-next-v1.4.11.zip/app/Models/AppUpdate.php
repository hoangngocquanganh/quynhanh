<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class AppUpdate extends Model
{
    use \App\Models\Concerns\NativeTypes;
    protected $table = 'app_updates';
    protected $guarded = ['id'];

    protected function casts(): array
    {
        return ['log' => 'array'];
    }

}
