<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class FarmAnimal extends Model
{
    use \App\Models\Concerns\NativeTypes;
    protected $table = 'farm_animals';
    protected $guarded = ['id'];

    protected function casts(): array
    {
        return ['fed_at' => 'datetime', 'ready_at' => 'datetime'];
    }

}
