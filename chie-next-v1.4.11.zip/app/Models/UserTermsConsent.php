<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class UserTermsConsent extends Model
{
    use \App\Models\Concerns\NativeTypes;
    protected $table = 'user_terms_consents';
    protected $guarded = ['id'];

    protected function casts(): array
    {
        return ['accepted_at'=>'datetime'];
    }
    public $timestamps = false;
}
