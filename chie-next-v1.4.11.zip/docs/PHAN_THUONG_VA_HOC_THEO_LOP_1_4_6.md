# Phần thưởng cấp và học vừa sức · 1.4.6

## Đã cập nhật

- 34 avatar: giữ 24 avatar có sẵn, thêm 10 nhân vật thưởng theo cấp 3, 6, 10, 15, 20, 30, 45, 60, 80, 100.
- 16 lựa chọn khung trong danh mục, gồm lựa chọn không khung; khung trong kho vẫn dùng được. Thêm Hoàng gia (45), Thiên giới (60), Cánh phượng hoàng (80), Vương miện vĩnh cửu (100).
- Sáu độ hiếm có tên và màu rõ ràng: Phổ thông, Đặc biệt, Hiếm, Sử thi, Huyền thoại, Thần thoại.
- Phần thưởng tự mở khi đạt cấp; không trừ Xu và không tự thay trang bị đang chọn. Máy chủ kiểm tra cấp khi lưu và khi hiển thị. Admin được mở toàn bộ danh mục để thử.
- Trang ngoại hình có hành trình phần thưởng, mốc tiếp theo và XP còn thiếu. Danh hiệu thêm Tinh tú (80), Thần thoại (100).
- Khung cao cấp có viền nhiều lớp, trang trí và ánh sáng; hiệu ứng nhẹ ở bản xem trước lớn, tôn trọng cài đặt giảm chuyển động.
- Tự học chỉ đưa câu ngữ pháp cơ bản đã xuất bản vào nút luyện; câu nâng cao vẫn chọn trong Ngữ pháp. Lượt học trong ngày chỉ tính trong lớp đang chọn.
- Hướng dẫn ngắn theo lớp 1–2, 3–5, 6–9, 10–12 trên trang Ngữ pháp.

Không có migration mới. Gói đầy đủ chứa cả các bản sửa trước.

## Việc nên ưu tiên tiếp để khớp học trên lớp

1. Giáo viên rà và duyệt câu hỏi ngữ pháp còn chờ: độ đúng, lời giải, mức khó và lớp. Không tự xuất bản câu chưa duyệt.
2. Đối chiếu từng chủ điểm với Unit của bộ sách thực tế, cho chọn bộ sách ở hồ sơ lớp. Chưa gắn nhãn khớp hoàn toàn một bộ sách khi chưa có bảng đối chiếu.
3. Bổ sung kiểm tra đầu vào và gợi ý ôn phần yếu dựa trên kết quả nhiều lượt học, có giáo viên kiểm chứng trước khi dùng để phân trình độ.

Chương trình theo lớp/học kỳ và việc khớp thứ tự một bộ sách là hai công việc cần đối chiếu riêng. Trang [Đề án Ngoại ngữ Quốc gia – thông tin chương trình](https://ngoainguquocgia.moet.gov.vn/hoc-chuong-trinh-tieng-anh-moi-hoc-sinh-se-dat-theo-trinh-do-6-bac-1706505.html) mô tả định hướng giao tiếp và tính liên thông giữa lớp/cấp. Đây là căn cứ định hướng, không thay cho thẩm định từng câu hỏi hoặc tài liệu chương trình hiện hành.

Cấp XP và độ hiếm là phần thưởng trong app; không quy đổi thành chứng chỉ hay bậc năng lực tiếng Anh.

## Kiểm tra

21 trường hợp tại và sát mốc cấp; quyền lưu avatar/khung; hình thức dự phòng khi lựa chọn chưa mở; admin thử; Tự học lớp 1–12; hồi quy huy hiệu, avatar, nộp bài và thưởng. Xem thử giao diện 1366px và 390px không tràn ngang.
