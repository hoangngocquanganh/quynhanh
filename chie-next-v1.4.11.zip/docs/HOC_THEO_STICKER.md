# Học theo sticker (CHIE NEXT 1.3.3)

## Học sinh

- Menu **Sticker** (hoặc ô **Album sticker** ở trang Học tập) mở trang album.
  - Gói **hợp lớp đang học** hiện trước, gói của lớp khác ở mục "Khám phá".
  - Đầu trang có **Sticker của ngày**: mọi bạn cùng lớp thấy cùng một sticker trong ngày.
- Trong một gói:
  - **Bóc sticker mới**: thẻ học hiện trước (hình, từ, phiên âm, nghĩa, câu ví dụ, ghi chú văn hoá, nút Nghe / Nghe chậm), sau đó là câu hỏi 4 lựa chọn. Trả lời đúng thì sticker được dán vào album.
  - **Nghe & chọn hình**: chỉ nghe, chọn hình đúng (luyện nghe).
  - **Ôn sticker**: các sticker từng trả lời sai, đánh dấu bằng chấm đỏ "!".
  - Chạm vào ô sticker để xem lại thẻ, kể cả sticker chưa bóc (xem trước để học).
- Kiểu câu hỏi: nhìn hình chọn từ · nhìn từ chọn nghĩa · nhìn nghĩa chọn từ · nghe chọn hình. Gói thành ngữ chỉ hỏi nghĩa. Bàn phím: phím 1–4 để chọn.
- **Hạng sticker**: đúng lần đầu được hạng đồng. Đúng vào **ngày khác** lên bạc, rồi vàng (ôn cách quãng). Đúng nhiều lần trong một ngày không lên hạng.
- **Thưởng** (chỉ học sinh/phụ huynh, tính vào trần thưởng ngày):
  - +2 XP khi bóc sticker mới.
  - +3 XP khi sticker lên vàng.
  - +20 XP và 10 Xu khi sưu tầm đủ một gói. Mỗi phần thưởng chỉ nhận **1 lần** (có khóa chống trùng trong sổ cái Xu, loại `sticker_reward`).

## Admin → 2 · Học liệu & đề → Sticker học tập

- Danh sách gói. Mỗi gói sửa được: tên, emoji, màu, **khoảng lớp**, trạng thái (Đang mở / Nháp / Lưu trữ), thứ tự.
- Sửa từng sticker: emoji, từ, IPA, nghĩa, câu ví dụ, ghi chú văn hoá, bật/tắt.
- **Nhập gói .json**: định dạng như `database/content/chie_stickers_v1_3_3.json` (`"format": "chie-stickers"`). Chỉ thêm gói hoặc sticker có mã mới, không ghi đè bản đã sửa.
- **Admin → Hệ thống → Cấu hình** chỉnh được: `sticker.session_size` (số câu mỗi lượt, mặc định 6), `sticker.xp_new`, `sticker.xp_gold`, `sticker.xp_pack`, `sticker.xu_pack`.

## Nội dung

| Gói | Lớp | Số sticker |
|---|---|---|
| Chào hỏi lễ phép · Màu sắc & con số | 1–2 | 12 · 13 |
| Gia đình em · Con vật quanh nhà | 1–3 | 13 · 13 |
| Trường em | 1–5 | 13 |
| Tết Nguyên Đán · Tết Trung thu | 3–6 | 13 · 12 |
| Món ngon Việt Nam · Giao thông an toàn | 3–7 | 14 · 13 |
| Đi chợ & mua sắm | 4–7 | 13 |
| Việc nhà & nếp sinh hoạt | 5–8 | 13 |
| Quê hương & thiên nhiên · Lễ hội & truyền thống | 6–9 | 14 · 13 |
| Môi trường & sống xanh | 8–12 | 14 |
| Nghề nghiệp & tương lai · Thành ngữ Anh – Việt | 9–12 | 13 · 14 |
| Văn hoá & hội nhập | 10–12 | 13 |

Nguồn sinh nội dung: `tools/build_stickers_v1_3_3.py`. Sửa tệp này rồi chạy lại để tạo JSON mới; với site đang chạy thì sửa trong Admin.

**Lưu ý:**
- Hình sticker là emoji, nên hiển thị hơi khác nhau giữa Windows, Android và iPhone.
- Một vài khái niệm Việt Nam không có emoji riêng, nên dùng hình gần nghĩa: 🟩 cho bánh chưng, 👒 cho nón lá. Admin đổi được emoji của từng sticker.
- Nội dung do CHIE NEXT biên soạn, giáo viên nên rà lại trước khi giới thiệu cho cả lớp.
