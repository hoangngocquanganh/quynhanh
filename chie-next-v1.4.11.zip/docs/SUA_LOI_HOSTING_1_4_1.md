# Sửa lỗi hosting và cập nhật 1.4.1

Đã tái hiện trên hosting: trang Tự học và Ngữ pháp trả HTTP 500 sau khi chọn lớp; Học tập và Từ vựng vẫn trả HTTP 200. Chưa có log hosting nên chưa khẳng định nguyên nhân lỗi 500. Thiếu bảng Ngữ pháp là trường hợp bản vá đã kiểm thử.

## Khi chức năng cập nhật đang lỗi

1. Trong cPanel File Manager, vào thư mục cài CHIE (thường là `public_html/chie`, nơi có `index.php`, `artisan`, `app/`).
2. Tải `chie-updater-repair-1.4.1.zip` vào đó và giải nén, cho phép ghi đè 3 tệp. Đây là gói sửa qua File Manager, không tải gói này vào trang Cập nhật phiên bản.
3. Tải lại trang quản trị Cập nhật phiên bản. Tải gói `chie-next-v1.4.1.zip`, bấm Kiểm tra gói, sau đó Áp dụng cập nhật. Nếu tệp lớn quá giới hạn, đặt gói đầy đủ trong `storage/app/updates/` rồi chọn gói trong trang quản trị.
4. Bấm Cập nhật CSDL ngay nếu còn bước chờ. Nếu không còn bước chờ mà giao diện vẫn cũ, bấm Kiểm tra CSDL và xóa bộ đệm.
5. Mở lại `/chie/tu-hoc` và `/chie/ngu-phap`.

Gói vá không chứa `.env`, dữ liệu ví, tài khoản hoặc nội dung thư mục `storage/`. Bản 1.4.1 bổ sung bước kiểm tra/sửa cài đặt Ngữ pháp và nhập lại các nội dung còn thiếu; không ghi đè câu hỏi/chủ điểm đã có.

Nếu còn lỗi, lấy thông báo trong trang Cập nhật và log mới nhất trong `storage/logs/`. Không bật APP_DEBUG công khai và không gửi mật khẩu hoặc nội dung `.env`.
