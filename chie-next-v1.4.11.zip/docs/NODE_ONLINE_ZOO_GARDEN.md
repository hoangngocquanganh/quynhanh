# Việc cần Node.js — để dành cập nhật sau (CHIE NEXT 1.3.0 · Zoo Garden)

Mọi phần **không cần Node.js** đã làm xong trong 1.3.0. Tệp này gom những việc **bắt buộc có Node.js**, để sau này bạn (hoặc AI/lập trình viên) làm tiếp mà không phải tìm hiểu lại từ đầu.

Có 2 nhóm việc:

| # | Việc | Node chạy ở đâu | Bắt buộc? |
|---|---|---|---|
| A | **Build lại game** sau khi sửa mã TypeScript | Máy tính của bạn (một lần mỗi lần sửa) | Chỉ khi sửa game |
| B | **Chơi Online nhiều người** (gặp bạn, đi thăm vườn, đánh boss chung, xếp hạng, chat) | Một máy chủ chạy liên tục (VPS) | Tùy chọn |

Hosting cPanel của CHIE **không cần** Node cho cả hai việc. A chạy trên máy cá nhân rồi tải bản build lên. B chạy trên một máy chủ riêng, còn CHIE vẫn ở cPanel.

---

## A. Build lại game (khi sửa mã Zoo Garden)

Mã nguồn đã tích hợp CHIE nằm ở `modules/games/game-5-zoo-garden/source/`.

1. Cài **Node.js 22.12+** (khuyên dùng 24 LTS) trên máy tính.
2. Mở terminal trong `source/`, chạy `npm ci`.
3. Chép mô hình, icon, nhạc từ CHIE vào thư mục `source/public/assets/`:
   - `assets/zoo-garden/assets/models/` → `source/public/assets/models/`
   - `assets/zoo-garden/assets/icons/` → `source/public/assets/icons/`
   - `assets/zoo-garden/assets/audio/` → `source/public/assets/audio/`
4. Sửa mã trong `source/src/`.
5. Chạy `npm run build:chie`. Lệnh này kiểm tra kiểu TypeScript, build với `--base ./`, rồi tạo `dist/chie-manifest.json`.
6. Xóa `dist/index.html`. Nếu để lại, học sinh mở trực tiếp được game mà không cần đăng nhập, vượt qua giới hạn giờ chơi.
7. Đưa bản build lên, chọn một cách:
   - Chép `dist/*` đè vào `assets/zoo-garden/` qua File Manager.
   - Hoặc: đặt `dist/` cạnh `module.json` (đổi tên `source/dist` → `dist`), tăng `version` trong `module.json`, nén cả thư mục `game-5-zoo-garden`, rồi tải lên **Admin → Quản lý Zoo Garden 3D → tab Module** (hoặc trang Cập nhật phiên bản). Hệ thống tự chép `dist/` vào `assets/zoo-garden/`.

Kiểm thử tự động (tùy chọn): `source/tests/` có sẵn, chạy `npm test` (khoảng 2.200 test, 5–6 phút; một số test cần thêm thư mục `art/`, `promo/` và `public/` đầy đủ của gói `cute_game-main` gốc).

Quy tắc khi sửa (đã ghi trong `README_AI.md` của module):
- Không dùng script nội tuyến, vì CSP của CHIE chặn.
- Không gọi `gameBridge.setPersistence()`.
- Gọi API bằng `getChieBoot().endpoints.*`, không viết cứng đường dẫn.

---

## B. Chơi Online nhiều người

### B1. Hiện trạng trong CHIE 1.3.0 (đã làm sẵn phía PHP)

- **Admin → Quản lý Zoo Garden 3D → Cài đặt chung** có 3 ô:
  - `zoo.online_enabled` — công tắc Online.
  - `zoo.online_server_url` — địa chỉ máy chủ, ví dụ `wss://game.tenmien.vn`.
  - `zoo.online_shared_secret` — khóa bí mật chung, ít nhất 32 ký tự. Khóa này không bao giờ gửi xuống trình duyệt.
- **API vé đăng nhập**: `POST /api/farm/zoo-ticket` (cần đăng nhập học sinh + CSRF) trả về:
  ```json
  {"ticket": "<payload>.<chữ ký>", "server_url": "wss://game.tenmien.vn", "expires_in": 60}
  ```
  - `payload` = base64url của JSON `{"v":1,"uid":123,"name":"Bé Mầm","grade":3,"role":"student","iat":…,"exp":iat+60,"nonce":"…"}`.
  - `chữ ký` = base64url( HMAC-SHA256(payload, zoo.online_shared_secret) ).
  - Mã: `App\Services\ZooGardenService::onlineTicket()`.
- Dữ liệu khởi tạo của game (`getChieBoot().online`) có `{enabled, server_url, ticket_endpoint}`.
  - `enabled` chỉ là `true` khi đủ 3 điều kiện: công tắc bật, có URL, khóa đủ dài.
- Bản build hiện tại vẫn là **chơi đơn** (`VITE_STATIC_HOST=true`). `main.ts` chỉ gọi `initOnline()` khi công tắc bật, nhưng bản tĩnh thì `initOnline()` chỉ chạy chế độ solo.
- **Chưa làm** (cần Node): máy chủ online nhận vé CHIE; bản build client online; đồng bộ bản lưu giữa máy chủ game và CHIE.

### B2. Máy chủ game có sẵn trong `cute_game-main/server/`

- (`modules/games/game-5-zoo-garden/source/server/`) `server.mjs` gồm: HTTP + WebSocket (`ws`), phòng chơi tối đa `MAX_PLAYERS` người, quyền quyết định chiến đấu (`combat-authority.mjs`, `colossus-authority.mjs`), hầm ngục chung (`dungeon-lobby.mjs`), xếp hạng (`ranking.mjs`), tài khoản và phiên đăng nhập (`account-store.mjs`).
- CSDL: PostgreSQL qua `DATABASE_URL` (bảng `zoo_accounts`, `zoo_sessions`, `zoo_action_receipts`… trong `server/schema.sql`). Không có Postgres thì lưu tệp ở `DATA_DIR/accounts.json`.
- Biến môi trường: `HOST`, `PORT` (mặc định 8787), `COOKIE_SECURE`, `DATABASE_URL`, `DATABASE_REQUIRED`, `DATA_DIR`, `ALLOWED_ORIGINS`, `MAX_PLAYERS`, `TRUST_PROXY`.
- Hiện máy chủ có **hệ tài khoản riêng** (đăng ký/đăng nhập bằng tên + mật khẩu). Cần thay bằng vé CHIE.

### B3. Các bước cần làm

**1. Chuẩn bị máy chủ**
- VPS Linux 2 vCPU / 2–4 GB RAM.
- Cài Node 24, PostgreSQL 16 (hoặc Neon/Supabase), Nginx, chứng chỉ HTTPS (Let's Encrypt).
- Tên miền phụ, ví dụ `game.tenmien.vn`.
- Nginx chuyển tiếp `https://game.tenmien.vn` và WebSocket (`Upgrade`/`Connection`) tới `127.0.0.1:8787`.
- Chạy bằng `systemd` hoặc `pm2`.
- Đặt `ALLOWED_ORIGINS=https://tenmien.vn`, `COOKIE_SECURE=1`, `TRUST_PROXY=1`, `DATABASE_REQUIRED=1`.

**2. Máy chủ nhận vé CHIE** — thêm route `POST /api/auth/chie` vào `server/server.mjs`. Mẫu kiểm vé:
```js
import { createHmac, timingSafeEqual } from 'node:crypto';
const used = new Map(); // nonce -> exp (nên lưu Redis/Postgres nếu chạy nhiều tiến trình)
export function verifyChieTicket(ticket, secret, now = Math.floor(Date.now() / 1000)) {
  const [payload, sig] = String(ticket).split('.');
  if (!payload || !sig) return null;
  const expect = createHmac('sha256', secret).update(payload).digest('base64url');
  if (expect.length !== sig.length || !timingSafeEqual(Buffer.from(expect), Buffer.from(sig))) return null;
  const data = JSON.parse(Buffer.from(payload, 'base64url').toString('utf8'));
  if (data.v !== 1 || data.role !== 'student' || data.exp < now || used.has(data.nonce)) return null;
  used.set(data.nonce, data.exp);
  for (const [n, e] of used) if (e < now) used.delete(n);
  return { id: `chie-${data.uid}`, name: data.name, grade: data.grade };
}
```
- Vé hợp lệ → tạo hoặc lấy tài khoản `chie-<uid>` trong `zoo_accounts`. Tên lấy theo CHIE, không cho đổi.
- Tạo phiên như luồng đăng nhập hiện có. Cookie phải đặt `SameSite=None; Secure`, vì game chạy trong iframe trên tên miền CHIE. Hoặc trả token cho client gắn vào URL WebSocket.
- **Tắt** đăng ký/đăng nhập bằng mật khẩu khi chạy cho CHIE (thêm biến `CHIE_ONLY=1`).
- Thêm biến `CHIE_SHARED_SECRET` = đúng giá trị `zoo.online_shared_secret` trong Admin.

**3. Client bản online** (sửa trong `source/src/`)
- `online.ts`, hàm `initOnline()`: khi `getChieBoot()?.online?.enabled`:
  - Gọi `POST boot.online.ticket_endpoint` (kèm `X-CSRF-TOKEN`) để lấy vé.
  - Gửi vé tới `POST {server_url → https}/api/auth/chie` với `credentials: 'include'`.
  - Mở WebSocket tới `server_url`.
  - Thay `serviceBase` (đang là `import.meta.env.BASE_URL`) bằng địa chỉ máy chủ game.
  - Ẩn form đăng nhập/đăng ký trong bảng "Play together".
- Build bản online: `npm run build:chie -- --mode chie-online`, với `.env.chie-online` chứa `VITE_STATIC_HOST=false`.
  - Hoặc làm một bản build có cả hai chế độ, chọn lúc chạy theo `boot.online.enabled`. Cách này tốt hơn: Admin bật/tắt không phải build lại.
- Thêm vào CSP của trang `/nong-trai/zoo` (`FarmController::zooFrame`): `connect-src 'self' https://game.tenmien.vn wss://game.tenmien.vn`. Nên đọc từ `zoo.online_server_url` để không viết cứng.

**4. Bản lưu khi chơi online** — chọn một trong hai cách:
- **Đơn giản:** máy chủ game vẫn để client gửi bản lưu lên CHIE như bây giờ (`/api/farm/zoo-save`). Máy chủ game chỉ lo phòng chơi, vị trí, chiến đấu chung, chat.
- **Chặt chẽ hơn** (chống gian lận): máy chủ game giữ bản lưu và đẩy bản sao về CHIE bằng API máy-chủ-tới-máy-chủ. Cần làm thêm phía CHIE: route `POST /api/zoo/server-save` không qua phiên, xác thực bằng HMAC dùng chung `zoo.online_shared_secret`, body `{uid, save_json, revision, ts, sig}`.
- Đổi Xu → ϟ, đố Tiếng Anh, giới hạn giờ chơi **giữ nguyên ở CHIE**.
- Nếu máy chủ game giữ bản lưu, thêm lệnh "cộng ϟ chờ nhận" (`pending_energy`) vào luồng của máy chủ.

**5. An toàn cho trẻ em và pháp lý**
- Học sinh là trẻ vị thành niên. Trước khi bật chat tự do:
  - Nên chỉ cho dùng **câu chat soạn sẵn**, hoặc lọc từ bằng bộ lọc của CHIE (`NameFilter`, bảng `word_filters`).
  - Thêm nút báo cáo, chặn người chơi, nhật ký kiểm duyệt.
  - Chỉ cho gặp bạn cùng lớp/cùng trường (lấy từ `classroom_members` qua API CHIE).
- Cập nhật Điều khoản / Chính sách riêng tư của CHIE (dữ liệu được gửi sang máy chủ game: id, tên hiển thị, lớp).
- Hỏi ý kiến người có chuyên môn pháp lý về bảo vệ dữ liệu cá nhân và trẻ em trước khi mở cho học sinh.

**6. Kiểm thử trước khi bật**
- 2–4 trình duyệt và 2 điện thoại thật cùng phòng: vào/ra, mất mạng rồi vào lại.
- Hai người thu hoạch cùng một cây, cùng đánh boss → không nhận thưởng trùng.
- Ẩn tab, mở túi đồ giữa trận.
- Vé giả, vé hết hạn, vé dùng lại → bị từ chối.
- Học sinh bị khóa giờ chơi thì không vào được phòng (máy chủ game có thể gọi CHIE kiểm tra, hoặc client không kết nối khi bị khóa).
- Tải thử: `npm run loadtest` có sẵn trong `cute_game-main`.

### B4. Ước lượng công việc
Làm theo cách "Đơn giản" ở bước 4: khoảng **3–6 ngày công** cho lập trình viên quen Node/WebSocket. Chưa tính kiểm duyệt chat và rà soát pháp lý. Cách "Chặt chẽ" thêm khoảng 3–5 ngày.

---

## C. Tệp và vị trí liên quan

| Việc | Tệp |
|---|---|
| Vé đăng nhập Online (PHP) | `app/Services/ZooGardenService.php` → `onlineTicket()`, route `api.farm.zoo.ticket` |
| Cài đặt Online | `ZooGardenService::SETTINGS_SCHEMA` (`zoo.online_*`) |
| CSP khung game | `app/Http/Controllers/FarmController.php` → `zooFrame()` |
| Client online | `modules/games/game-5-zoo-garden/source/src/online.ts`, `main.ts` (chỗ gọi `initOnline`) |
| Máy chủ game gốc | `modules/games/game-5-zoo-garden/source/server/` (bản sao từ `cute_game-main/server/`) |
| Hợp đồng giao tiếp module | `modules/MODULE_SDK_CONTRACT.md` |
