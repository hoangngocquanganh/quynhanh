# Tình trạng các phần còn thiếu — CHIE NEXT 1.3.3

## 0a. Mới trong 1.3.3

| Yêu cầu | Đã làm |
|---|---|
| Học theo sticker | Mục **Sticker** trong menu học sinh và Admin: **17 gói, 223 sticker** theo chủ đề gần gũi với học sinh Việt Nam. Gồm chào hỏi lễ phép, gia đình, con vật làng quê, trường em (khăn quàng đỏ, chào cờ), Tết Nguyên Đán, Trung thu, món ngon Việt, đi chợ, giao thông (mũ bảo hiểm), việc nhà, quê hương (lúa, sen, tre, Hạ Long, Sa Pa), lễ hội (áo dài, múa rối nước, 20/11, Giỗ Tổ), môi trường, nghề nghiệp, văn hoá & hội nhập, thành ngữ Anh – Việt. Mỗi gói gắn một khoảng lớp; gói hợp lớp đang học xếp lên đầu. Xem `docs/HOC_THEO_STICKER.md`. |
| Đổi lớp trong Hồ sơ | **Hồ sơ → Đổi lớp học**: bấm số lớp 1–12; bài học, từ vựng, sticker, đề luyện đổi theo lớp, tiến độ mỗi lớp giữ riêng. Chip "Lớp N" trên thanh trên cùng cũng dẫn tới đây. Admin, giáo viên đổi lớp học thử, không đổi tài khoản. |
| Lỗi giao diện Luyện đề (tiêu đề tràn khung) | Thẻ đề mới: tiêu đề tự xuống dòng, số câu và số phút dạng nhãn, nút "Làm đề" luôn nằm đáy thẻ, màu theo loại đề (hằng ngày, thi thử, theo lớp). |
| "Máy chủ đang gặp sự cố" trên hosting | Chưa tái hiện được: đã thử đúng tình huống trên MariaDB 10.11 và **MySQL 8.0**, cả hai chạy được. Bản 1.3.3 làm lỗi **tự lộ nguyên nhân**: thông báo đỏ có **mã tra cứu**; với tài khoản Admin còn hiện tên lỗi và vị trí tệp. Nếu lỗi không do CHIE trả về (tường lửa ModSecurity của hosting, PHP dừng đột ngột), thông báo cũng ghi rõ. Mã tra cứu nằm trong **Admin → Hệ thống → Theo dõi lỗi**. Bấm nhiều lần không còn xếp chồng thông báo. |
| Làm trên máy rồi đẩy lên host | Lệnh mới `php artisan chie:release 1.3.4 --notes="…"` đóng gói zip có mã băm, rồi tải lên **Admin → Cập nhật phiên bản**. Xem `HUONG_DAN_CAI_LEN_HOSTING.md` mục G. |

## 0. Đã làm trong 1.3.1 – 1.3.2

| Vấn đề | Đã làm |
|---|---|
| Trên hosting thật: bài học 404, Luyện đề "Máy chủ đang gặp sự cố", Word Runner báo "Không tìm thấy dữ liệu" liên tục | Hosting trả số từ MySQL dưới dạng chữ. Mọi model giờ tự ép kiểu theo cấu trúc bảng (trait `NativeTypes`), và các truy vấn thô cũng được ép kiểu. Đã thử lại toàn bộ (215 mục e2e đạt) với Apache và chế độ "số thành chữ" giống hosting. |
| Admin không vào được trang học sinh (403) | **Admin là quyền cao nhất**: vào được mọi trang của học sinh, giáo viên, phụ huynh. Menu Admin có nhóm **"0 · Khu học tập"** (Vào trang học, Luyện đề, Trò chơi). Trong trang học có mục **Quản trị** để quay lại. Lớp Admin chọn để học thử chỉ lưu trên trình duyệt. Giáo viên có mục **Học thử**. |
| Tạm ẩn trò chơi để tập trung học | **Admin → Game Studio → "Hiển thị tính năng trò chơi cho học sinh"**. Mặc định **ẨN**: menu Game đấu trường, Nông trại, cửa hàng, đấu 1-1… biến mất khỏi giao diện học sinh. Ai có link trực tiếp (`/tro-choi`, `/nong-trai`) vẫn vào thử được. Admin luôn thấy mục Game. Bấm **Hiện trò chơi** để mở lại. |
| Giao diện | Giao diện mới **"Mạ non"** theo kiểu Duolingo: màu xanh lá chủ đạo, vàng hoa mai, đỏ hoa đào; font Be Vietnam Pro (dấu Tiếng Việt rõ). Nút bấm nổi 3D, lời chào theo buổi trong ngày. Lộ trình là con đường uốn lượn, mỗi chủ điểm một màu. Có chế độ tối đủ tương phản và bố cục riêng cho điện thoại. |


Cập nhật lần 2: đã làm nốt mọi phần **không cần Node.js**. Phần cần Node.js (chơi Online, build lại game) được ghi riêng trong **`docs/NODE_ONLINE_ZOO_GARDEN.md`**.

## 1. Đã làm thêm trong lần cập nhật này

| Trước đây chưa làm | Bây giờ |
|---|---|
| Giá dịch vụ trang trại (chuồng, robot) | Admin chỉnh được **giá ϟ** của: xây chuồng (kèm cấp mở), mở rộng chuồng bậc 1/2, robot làm vườn, phụ việc chuồng thú. Tên Tiếng Việt vẫn đổi được như trước. Giá robot và phụ việc giờ tách riêng (trước dùng chung 1 giá). |
| Đố Tiếng Anh trong Bếp và Hầm ngục | Hộp thoại **Bếp** có nút "🍳 Đầu bếp Tiếng Anh" (3 câu → hồi đầy máu + hồi máu dần 10 phút, +40 ϟ, XP/Xu). Hộp thoại **Người gác hầm ngục** có nút "📜 Thử thách" (3 câu → +15 phòng thủ, +15% sát thương 15 phút, +60 ϟ, XP/Xu). Mức thưởng chỉnh trong Admin. |
| Đố theo cây vừa chạm (`target_code`) | Học sinh chạm một cây/vật phẩm rồi bấm "🎓 Đố từ vựng" trong vòng 90 giây → câu hỏi ưu tiên từ vựng Admin đã gắn cho cây đó (sau Sổ lỗi). |
| Game 1–4 nạp động từ module | `game/play.blade.php` nạp JS theo `entry_2d` / `entry_3d` trong `module.json` (chỉ cho phép tệp có thật trong `assets/`). **Game Studio** lấy ô cấu hình từ `schema` của module (thêm ô mới không cần sửa PHP) và có nút **"Khôi phục mặc định của module"** dùng `defaults`. |
| Cập nhật một chạm cho gói module | Trang **Cập nhật phiên bản** nhận cả gói module lẻ (có `module.json`, không có `chie-release.json`) và cài ngay. Khi cập nhật **cả web**, module nào đã được cập nhật riêng lên phiên bản mới hơn sẽ **được giữ nguyên**, và tệp chạy thật của nó được triển khai lại. |
| Lớp 2 chưa có học liệu | Gói mới `chie_supplement_v1_3.json`: Lớp 2 gồm 8 chủ đề, 8 bài, 64 từ có IPA, 64 câu (hỏi nghĩa, chọn từ, nghe). |
| Lớp 7, 9, 12 chưa có bài học | Cùng gói: mỗi lớp thêm 24 câu mới (ngữ pháp, từ vựng, giao tiếp, phát âm, nghe, đọc) và 3 bài ôn tập. |
| Chưa có ma trận đề theo lớp | Mỗi module lớp có `exam_blueprints.json` (Kiểm tra 15 phút + Đề ôn học kỳ, tỉ lệ kỹ năng theo ngân hàng câu của lớp), tổng 23 khung đề. Có gói `chie_exam_blueprints_v1_3.json`; `ContentImporter` đã biết nhập khung đề. |
| Tự nhập nội dung mới khi nâng cấp | Migration `2026_10_18_000008` tự nhập 2 gói mới khi nâng cấp từ 1.2 (không nhân đôi, không ghi đè bản Admin đã sửa). |
| Online — phần PHP | Đã làm sẵn: vé đăng nhập ký HMAC `POST /api/farm/zoo-ticket`, ô khóa bí mật trong Admin (không bao giờ gửi xuống trình duyệt), khối `online` trong dữ liệu khởi tạo. |
| Lỗi cài đặt `1067 Invalid default value for 'started_at'` trên MySQL/MariaDB cũ | Mọi cột `timestamp` bắt buộc trong migration đã có giá trị mặc định rõ ràng (`useCurrent`). Đã thử cài mới qua trình cài đặt với `explicit_defaults_for_timestamp=OFF` + strict mode: cài thành công. Nếu đã cài lỗi một lần: làm trống CSDL rồi cài lại (xem `HUONG_DAN_CAI_LEN_HOSTING.md` mục E). |
| Bộ kiểm thử e2e cũ trỏ vào `/nong-trai` | Đã sửa `t4_game.py`, `t7_v2.py`, `t10_upgrade.py`, `int.js` (bản cổ điển ở `/nong-trai/co-dien`, thêm kiểm tra khung Zoo Garden và API). |

**Lưu ý về nội dung mới:** câu, bài và từ mới đều ở trạng thái **Chờ duyệt**, theo đúng quy tắc của gói học liệu biên soạn mới. Giáo viên hoặc Admin rà soát trong **Admin → Học liệu** rồi xuất bản. Trước khi duyệt, học sinh lớp 2 chưa thấy bài, và đề theo lớp sẽ báo "chưa đủ câu".

## 2. Còn lại — cần Node.js (xem `docs/NODE_ONLINE_ZOO_GARDEN.md`)

1. **Máy chủ Online nhiều người** (Node + WebSocket + PostgreSQL, chạy trên VPS): nhận vé CHIE, bỏ hệ tài khoản riêng, kiểm duyệt chat cho trẻ em.
2. **Bản build client online** (`online.ts` lấy vé từ CHIE, kết nối `wss://…`). Bản trong gói vẫn là chơi đơn.
3. **Build lại game** mỗi khi sửa mã TypeScript (chạy trên máy tính, không phải hosting).

## 3. Không làm được ở đây (cần bạn thực hiện)

- Bộ test của game (2.157 test): **đạt hết** sau khi cập nhật stub cho mã tích hợp.
- **Thử trên điện thoại thật** (iPhone Safari, Android Chrome) và **trên cPanel thật**.
  - Đã thử: Chromium 1280×800 và giả lập cảm ứng 390×844, WebGL phần mềm, PHP 8.3 + MariaDB 10.11 với `php -S`.
  - Bộ e2e Python của CHIE: **214 mục đạt**. Mục duy nhất trượt là "chie-release.json không tải được từ ngoài": do `php -S` không đọc `.htaccess`, trên Apache/LiteSpeed tệp này bị chặn đúng.
- **Rà soát nội dung mới** (Lớp 2, ôn tập 7/9/12): do giáo viên làm.
- **Giấy phép `cute_game-main`:** gói gốc không có tệp LICENSE. Bạn cần chắc chắn mình có quyền dùng mã và mô hình 3D.

## 4. Những chỗ làm khác đặc tả (giữ nguyên lý do)

| Đặc tả | Đã làm | Lý do |
|---|---|---|
| Nhúng game thẳng vào layout, `window.CHIE_ZOO_BOOT` nội tuyến | iframe `/nong-trai/zoo` + `<script type="application/json">` | CSP chặn script nội tuyến; CSS của game phá giao diện CHIE |
| `gameBridge.setPersistence()` | Game tự lưu localStorage, tích hợp đẩy lên MySQL | `setPersistence` làm game tưởng online, khóa chế độ chơi đơn |
| Cộng ϟ thẳng vào bản lưu trên máy chủ | `farms.zoo_pending_energy` → game nhận rồi xác nhận | Không mất / không cộng trùng khi rớt mạng |
| Chip 🔊 gắn trong mọi ô vật phẩm | Chip nổi khi chạm | Không vỡ bố cục túi đồ, cửa hàng |
| Giữ `assets/zoo-garden/index.html` | Đã xóa | Tránh chơi không cần đăng nhập, vượt giới hạn giờ chơi |
| JS game 1–4 nằm trong `modules/` | JS chạy vẫn ở `assets/js/games*`; module giữ bản sao và chép sang khi cài (`deploy`) | `modules/` bị chặn truy cập web (bảo mật), và bản 3D import tương đối `./engine.js` |

## 5. Giới hạn cần biết

- Game chơi đơn tin dữ liệu từ máy học sinh: ϟ và đồ trong game có thể bị sửa. Kinh tế Xu của CHIE vẫn an toàn (chỉ có chiều Xu → ϟ, thưởng do máy chủ chấm, có trần ngày).
- Zoo Garden và nông trại cổ điển là hai nông trại riêng; "vượt tường" thuộc bản cổ điển.
- Lần đầu vào tải khoảng 11 MB. Bản lưu tối đa 3 MB mỗi học sinh.
