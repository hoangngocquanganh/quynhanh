# Kiểm tra hosting và bản sửa 1.4.4

Ngày 17/10/2026, kiểm tra trực tiếp hosting bằng chế độ khách, lớp 4:

- `/hoc/sticker`: 500.
- `/ngu-phap`: 503, dữ liệu chưa sẵn sàng.
- `/tu-hoc`, `/hoc/lo-trinh`, `/hoc/tu-vung`, `/hoc/phat-am`, `/luyen-de`, `/tro-choi`, trang chủ, đăng nhập, pháp lý: 200.

Đối chiếu thêm lớp 1, 6, 9, 12: Lộ trình/Tự học 200; Sticker 500; Ngữ pháp 503 ở cả bốn lớp. Rà localhost 1.185 yêu cầu GET qua 5 vai trò không có lỗi 500; bao gồm trang Ngữ pháp, 17 album và bốn game. Các chuyển hướng đăng nhập, giới hạn lớp/quyền và trang học thử thiếu lượt làm có thể trả 302/404 theo thiết kế.

Chưa có nhật ký hoặc phiên đăng nhập quản trị hosting nên chưa kết luận chính xác nguyên nhân lỗi Sticker. Trên localhost, Sticker hoạt động; khả năng hosting chưa hoàn tất CSDL cần được kiểm chứng qua nhật ký và danh sách migration.

Bản sửa:

- Migration bổ sung tự tạo các bảng Sticker còn thiếu và nhập lại nội dung còn thiếu. Giữ nguyên nội dung đã chỉnh và album học sinh; chạy lại không nhân bản.
- Trang Sticker và quản trị Sticker hiển thị thông báo 503 có hướng dẫn cập nhật nếu thiếu bảng, thay vì lỗi SQL 500.
- API không chấm/thưởng Sticker thuộc gói đã ẩn.
- Lỗi HTML bất ngờ có mã CHIE để tra trong `storage/logs`, không công khai chi tiết CSDL. Không cần bật APP_DEBUG trên hosting.

Trên hosting: sao lưu trước khi cập nhật; vào Admin → Cập nhật phiên bản, tải ZIP 1.4.4 và áp dụng. Nếu trang báo CSDL chưa sẵn sàng, bấm Cập nhật CSDL ngay. Kiểm tra lại Sticker và Ngữ pháp. Nếu vẫn lỗi, gửi mã CHIE và đoạn nhật ký tương ứng; không gửi `.env` hoặc mật khẩu.

Phạm vi: rà trang GET trên localhost với khách/học sinh/giáo viên/phụ huynh/admin bằng tài khoản tạm, hoàn tác dữ liệu; kiểm thử thiếu bảng và tính lặp lại của sửa Sticker; hồi quy khách không ghi điểm. Đây không phải kiểm chứng mọi thao tác ghi dữ liệu hoặc các trang cần đăng nhập trên hosting.
