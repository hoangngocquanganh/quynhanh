# Hướng dẫn cài CHIE NEXT 1.3.0 (có Nông trại 3D Zoo Garden) lên hosting cPanel

Hosting **không cần Node.js, npm hay Composer**. Game 3D đã được build sẵn trong gói.

## A. Yêu cầu hosting
- PHP **8.2 trở lên** (nên dùng 8.3). cPanel → **Select PHP Version → Extensions**, bật: `pdo_mysql`, `mbstring`, `openssl`, `fileinfo`, `tokenizer`, `ctype`, `zip`.
  - `zip` cần cho cập nhật một chạm và xuất/nhập module.
- MySQL 5.7+ hoặc MariaDB 10.4+, bảng mã `utf8mb4`.
- Dung lượng trống khoảng **80 MB**.
- Nên bật HTTPS: cPanel → **SSL/TLS Status → AutoSSL**. Toàn màn hình, ghi âm và cài lên màn hình điện thoại cần HTTPS.

## B. Cài mới
1. **Tạo CSDL:** cPanel → **MySQL® Databases**.
   - Tạo database, ví dụ `tenTK_chie`.
   - Tạo user, ví dụ `tenTK_chieuser`, đặt mật khẩu mạnh.
   - **Add User To Database** → chọn **ALL PRIVILEGES**. Database phải trống.
2. **Tải gói lên:** cPanel → **File Manager**.
   - Cài ở tên miền gốc: mở `public_html/`. Cài ở thư mục con: tạo `public_html/chie/`.
   - **Upload** file `chie-next-v1.3.0-zoo-garden.zip`.
3. **Giải nén:** chuột phải file zip → **Extract**.
   - Phải thấy ngay `index.php`, `.htaccess`, `app/`, `assets/`, `modules/`, `vendor/`… Nếu chúng bị lồng trong một thư mục con thì chọn hết và **Move** ra ngoài.
   - Bật **Settings → Show Hidden Files** để thấy `.htaccess`.
   - Xóa file zip sau khi giải nén.
4. **Chạy trình cài đặt:** mở `https://tenmien.vn/` (hoặc `/chie/`), trang sẽ tự chuyển tới `/install`.
   - Mục nào báo đỏ thì sửa trong **Select PHP Version** rồi tải lại trang.
   - Lấy **mã cài đặt** trong File Manager: mở `storage/app/install-token.txt`.
   - Điền mã cài đặt và thông tin CSDL: máy chủ `localhost`, cổng `3306`, tên/user/mật khẩu ở bước 1.
   - Điền tên website, tài khoản **Admin đầu tiên** (mật khẩu ít nhất 10 ký tự).
   - Chọn gói học liệu. Nên chọn **tất cả**: có gói mới "Bổ sung 1.3: Lớp 2 + ôn tập Lớp 7, 9, 12" và "Khung đề theo từng lớp".
   - SMTP có thể bỏ trống.
   - Bấm **Cài đặt** và chờ 10–60 giây. Trình cài đặt tự khóa sau khi xong.

## C. Nâng cấp (từ 1.2.0 hoặc 1.3.x lên 1.3.3)
Đang chạy 1.3.x: chỉ cần **Cách 1** bên dưới (Admin → Cập nhật phiên bản → tải `chie-next-v1.3.3.zip`). Bản 1.3.3 thêm 3 bảng sticker (`sticker_packs`, `stickers`, `user_stickers`) và tự nhập 17 gói sticker; không sửa bảng cũ.

1. **Sao lưu:** cPanel → **Backup**, hoặc phpMyAdmin → Export CSDL. Nén thư mục web thành một bản sao.
2. **Cách 1 — cập nhật một chạm:**
   - Đăng nhập Admin → **Hệ thống → Cập nhật phiên bản**.
   - Chọn file zip → nhập mật khẩu → **Kiểm tra gói** → **Áp dụng cập nhật**.
   - Nếu hosting giới hạn dung lượng tải lên dưới 16 MB: tải zip vào `storage/app/updates/` bằng File Manager, rồi chọn gói đó trong trang Cập nhật.
3. **Cách 2 — chép tay:**
   - Giải nén vào thư mục tạm.
   - Chép đè mọi thứ vào thư mục web, **trừ `.env` và `storage/`**.
   - Vào Admin → Hệ thống → Cập nhật phiên bản → bấm **Cập nhật CSDL ngay** (hoặc chạy `php artisan migrate --force`).
4. Khi cập nhật CSDL, hệ thống **tự nhập** học liệu mới: Lớp 2, ôn tập Lớp 7/9/12, khung đề theo lớp. Các mục này ở trạng thái **Chờ duyệt**: vào **Admin → Học liệu** để rà soát rồi xuất bản.
5. Nếu thấy giao diện cũ: chạy `php artisan optimize:clear`, hoặc xóa các file trong `storage/framework/views/`.

## D. Kiểm tra sau khi cài
1. **Admin → 3 · Game & cơ chế → Quản lý Zoo Garden 3D**.
   - Phải thấy nhãn xanh "Bản build: index-….js".
   - Chỉnh giờ chơi, tỉ lệ đổi Xu, phần thưởng ở tab **Giờ chơi & thưởng Tiếng Anh**.
2. Đăng nhập một tài khoản **học sinh thử** → **Game đấu trường → Nông trại**.
   - Lần đầu game tải khoảng 11 MB.
   - Bấm **Chơi**, rồi thử các nút ⛶ Toàn màn hình, 🔄 Đổi ϟ, 🎓 Đố từ vựng.
3. Nếu có lỗi:
   - Trang trắng hoặc lỗi 500: xem `storage/logs/`.
   - Mô hình 3D không tải: kiểm tra `.htaccess` còn ở thư mục gốc và `assets/zoo-garden/assets/models/` có đủ 56 file `.glb`.
   - Máy yếu: dùng nút **Bản cổ điển** (`/nong-trai/co-dien`), hoặc Admin tắt "Bật thế giới 3D Zoo Garden".

## E. Lỗi thường gặp khi cài

| Lỗi | Cách xử lý |
|---|---|
| `SQLSTATE[42000] … 1067 Invalid default value for 'started_at'` (hoặc `expires_at`, `due_at`…) | Đã sửa trong gói 1.3.0 mới, gặp ở MySQL/MariaDB cũ đặt `explicit_defaults_for_timestamp=OFF`. Cách làm: (1) tải lên gói mới, giải nén đè; (2) **làm trống CSDL**: phpMyAdmin → chọn CSDL → Check all → **Drop**, vì lần cài lỗi đã tạo dở vài bảng; (3) mở lại `/install`. Nếu mất mã cài đặt thì xóa `storage/app/install-token.txt` rồi tải lại trang để tạo mã mới. |
| "CSDL đã có bảng users" | Lần cài trước bị dừng giữa chừng. Làm trống CSDL như trên rồi cài lại. |
| Trang bài học báo 404, Luyện đề báo "Máy chủ đang gặp sự cố", Word Runner báo "Không tìm thấy dữ liệu" liên tục | Đã sửa từ 1.3.1. Nguyên nhân: hosting trả mọi số trong CSDL dưới dạng chữ (`"33"` thay vì `33`), làm các phép so sánh sai. Cập nhật lên bản mới nhất là hết. |
| Admin vào trang học sinh bị 403 | Đã sửa từ 1.3.1: Admin dùng được mọi trang. Lần đầu vào **Học tập**, hệ thống hỏi chọn lớp; lớp này chỉ lưu trên trình duyệt, không đổi tài khoản Admin. |
| Thông báo đỏ "Máy chủ gặp lỗi khi xử lý (mã ABC123)" | Đăng nhập Admin rồi làm lại: thông báo sẽ có thêm "Chi tiết cho Admin". Hoặc vào **Admin → Hệ thống → Theo dõi lỗi**, tìm dòng `[CHIE-ABC123]`. Chụp gửi hỗ trợ. |
| Thông báo "Máy chủ trả lỗi … không phải từ CHIE" | Tường lửa hosting (ModSecurity) chặn yêu cầu, hoặc PHP bị dừng do hết bộ nhớ/thời gian. Nhờ nhà cung cấp hosting xem nhật ký ModSecurity/Apache theo giờ xảy ra lỗi; hoặc trong cPanel → ModSecurity tắt thử cho tên miền. |
| Lỗi 500 hoặc trang trắng | Xem `storage/logs/`. Kiểm tra PHP ≥ 8.2 và thư mục `storage/` ghi được. |

## G. Làm trên máy tính (Laragon) rồi đẩy lên hosting

1. Cài **Laragon Full**, bấm **Start All**. Giải nén CHIE NEXT vào `C:\laragon\www\chie`, tạo CSDL trống trong phpMyAdmin, mở `http://localhost/chie/install` để cài.
2. Sửa và thử trên máy tại `http://localhost/chie`.
3. **Đẩy lên host — cách an toàn (có sao lưu, có Hoàn tác):**
   - Mở Terminal của Laragon trong thư mục `chie`, chạy `php artisan chie:release 1.3.4 --notes="Nội dung thay đổi"`. Số phiên bản phải lớn hơn bản đang chạy trên host.
   - Lệnh tạo `storage/app/releases/chie-next-v1.3.4.zip`.
   - Trên host: **Admin → Hệ thống → Cập nhật phiên bản**, tải zip lên → **Kiểm tra gói** → **Áp dụng**.
4. **Đẩy lên host — cách nhanh (sửa vặt):**
   - Dùng WinSCP **Commands → Synchronize** từ `C:\laragon\www\chie` lên thư mục web trên host.
   - Đặt mặt nạ loại trừ `.env; storage/; bootstrap/cache/; tests/`.
   - Nếu có migration mới: **Admin → Cập nhật phiên bản → Cập nhật CSDL ngay**.
5. Không bao giờ chép `.env` hoặc `storage/` từ máy lên host: hai nơi có CSDL và khóa riêng.

## F. Nginx (không dùng cPanel)
Dùng cấu hình ở `docs/HUONG_DAN_CAI_DAT.md` mục 11, và thêm `modules` vào danh sách thư mục bị chặn:
```
location ~ ^/(app|bootstrap|config|database|lang|modules|resources|routes|storage|tests|tools|vendor|docs)/ { deny all; }
location ~* \.glb$ { types { model/gltf-binary glb; } expires 30d; }
```
