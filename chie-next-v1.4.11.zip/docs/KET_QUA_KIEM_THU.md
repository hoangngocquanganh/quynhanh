# Kết quả kiểm thử — CHIE NEXT 1.1.0

Ngày chạy: 16–17/10/2026 (bản 1.0.0), 17/10/2026 (bản 1.1.0, chạy lại toàn bộ). Kết quả dưới đây là **những gì đã thực sự chạy**; mục chưa chạy được liệt kê riêng ở cuối.

## Môi trường thử

| Thành phần | Phiên bản |
|---|---|
| Hệ điều hành | Linux (container), không phải cPanel |
| Máy chủ web | Apache 2.4.58 + mod_php, `.htaccess` bật |
| PHP | 8.3 |
| CSDL | MariaDB 10.11 |
| Trình duyệt tự động | Chromium (Playwright 1.56), WebGL phần mềm (SwiftShader) — không có GPU thật |
| Vị trí cài | thư mục con `/chie`, `/chie-rel` và tên miền gốc (cổng 8081) |

## Tổng hợp

| Bộ kiểm thử | Nội dung | Kết quả |
|---|---|---|
| `t1_crawl.py` | Khách chọn lớp & ghi nhớ; đăng ký (thiếu lớp, dưới 16 tuổi, thử tự đăng ký Admin); giáo viên chờ duyệt; đăng nhập sai; **crawl mọi liên kết** theo 4 vai trò (≈ 400 trang) tìm lỗi 5xx | **17/17 PASS** |
| `t2_learn.py` | Phân quyền theo lớp, bài nháp trả 404, không lộ đáp án, trộn đáp án khớp khóa, giải thích khi sai, gửi lại câu không đổi kết quả, điểm = đúng/tổng×100, thưởng không cộng 2 lần, sổ cái đúng 1 bút toán, người khác không xem được lượt làm, đề có giờ máy chủ, hết giờ tự nộp & không nhận thêm câu, SRS, đổi lớp tách tiến độ, **chấm đúng mọi dạng câu** (mcq, nghe, sắp xếp, ghép cặp) | **27/27 PASS** |
| `t3_roles.py` | Liên kết phụ huynh bằng mã (đoán sai, dùng lại, phụ huynh khác), phụ huynh tạo tài khoản con, con không tự hủy liên kết; Admin duyệt giáo viên; tạo lớp, mã mời, mã sai, mã thu hồi; giáo viên chỉ xem lớp mình; giao/nộp/chấm bài, phụ huynh thấy nhận xét chia sẻ; không giao bài khác lớp; chặn chéo vai trò; khóa tài khoản đăng xuất ngay; điều chỉnh Xu ghi sổ; nhật ký kiểm toán | **37/37 PASS** |
| `t4_game.py` | 4 game khởi động & không lộ đáp án; thưởng giảm khi chơi lại; mở khóa màn; bảng xếp hạng không lộ email; mua đồ chống trùng, không đủ cấp, đặt phòng, không bán đồ đang đặt, bán lại 50%; hòm quà chống trùng, bảo đảm lượt 200, khóa đổi 30 ngày, giới hạn ngày, không đủ Xu; nông trại: gieo sai/đúng, token dùng 1 lần, chưa chín, thu hoạch, không thu 2 lần, chuyển kho, không bán quá số lượng, mua khiên; cướp trại thắng lấy ≤ 8%, không kết thúc 2 lần, 1 trận/cặp/ngày; đổi đồ cùng lớp, người gửi không tự chấp nhận, chặn người ngoài | **44/44 PASS** |
| `t6_content.py` | Gói chuyên đề chưa duyệt bị ẩn; Admin duyệt hàng loạt; chuyên đề nhiều lớp hiện đúng lớp 3–5, ẩn ở lớp 7; sửa câu tăng phiên bản; xuất CSV; báo lỗi câu hỏi; thông báo lỗi bằng tiếng Việt | **13/13 PASS** |
| `t5_install.py` (trên **gói phát hành sạch**, ở tên miền gốc) | Tự chuyển `/install`; chặn tải 8 loại tệp nội bộ (.env, vendor, storage, mã nguồn, .env.example…); sai mã cài; sai mật khẩu CSDL; cài thành công kèm nhập học liệu; tạo khóa, xóa mã cài; `.env` có APP_DEBUG=false, không ghi tên miền; `/install` 404 sau khi cài; đăng nhập Admin mới; trang 404 không lộ lỗi; API chưa đăng nhập không lộ dữ liệu | **24/24 PASS** |
| `int.js` (trình duyệt thật, khổ 390 px) | Khách học thử trọn bài; học sinh học trọn bài → trang kết quả; làm đề có giờ → nộp; Word Runner chơi được; nông trại mở câu đố gieo hạt; mở hòm quà; đặt đồ vào phòng — không lỗi JavaScript | 1.0: **7/7 PASS**; 1.1: **6/6 PASS** |
| `ui.js` (trình duyệt thật) | 78 trang × 4 khổ màn hình (360, 390, 768, 1366 px) theo 5 vai trò: mã trạng thái, lỗi JavaScript, tràn ngang | Lần chạy đầy đủ: 312 lượt trang, phát hiện 8 vấn đề → **đã sửa** (thanh trên bị tràn ở 360–390 px, thẻ phụ huynh tràn chữ, dòng xem lại kết quả tràn). Xem lần chạy lại ở cuối tệp |
| `t7_v2.py` (tính năng 1.1) | Vật nuôi: mua, chưa đủ cấp, cho ăn sai/đúng, token dùng 1 lần, thu sản phẩm không 2 lần; nấu sai/đúng/thiếu nguyên liệu, bán món, Kho Lạnh, nâng tường; **Đấu 1–1**: ghép trận, cùng bộ câu, không lộ đáp án, người đúng nhiều thắng, thưởng 1 lần, khóa trận đã xong, người ngoài 404, đấu với máy không thưởng, hết giờ tự kết thúc, thách đấu chỉ bạn cùng lớp/người nhà; **Đội**: giáo viên tạo/phân, 1 lớp 1 đội, người ngoài bị chặn; **Thử thách gia đình**: chỉ con đã liên kết, chưa xem bài nhau khi chưa xong, thưởng 1 lần, không làm lại | **47/47 PASS** |
| `t9_misc.py` | Link chia sẻ kết quả (không cần đăng nhập, không lộ email, thu hồi được); điều khoản phiên bản mới bắt đồng ý lại; phụ huynh đặt lại mật khẩu con (chỉ con do mình tạo); hủy liên kết → 404; trần 500 Xu / 1.000 XP mỗi ngày; tải ảnh học liệu, chặn tệp PHP; gói ôn ngoại tuyến chỉ có thẻ từ; `sw.js`, manifest, trang ngoại tuyến phục vụ đúng; chặn tải `chie-release.json` | **18/18 PASS** |
| `t8_update.py` (bản cài sạch) | Cập nhật một chạm: từ chối gói cũ hơn, gói sai mã băm, đường dẫn `../`, tệp ngoài danh sách (`.env`); sai mật khẩu xác nhận; gói rút gọn < 1 MB; áp dụng 1.1.0 → 1.1.1, `.env` không bị đụng, có sao lưu, web vẫn chạy; **hoàn tác**; cập nhật bằng gói đặt sẵn qua File Manager | **16/16 PASS** |
| `t10_upgrade.py` | Cài **bản 1.0.0 thật** (gói đã giao trước), tạo dữ liệu, chép tệp 1.1 (trừ `.env`, `storage/`) → trang Cập nhật báo “CSDL cần cập nhật” → bấm nút → các trang mới chạy, dữ liệu nền vật nuôi có, dữ liệu cũ còn nguyên | **10/10 PASS** (sau khi `t5_install.py` trên gói 1.0.0: 24/24) |
| `g3d.js` (Chromium khổ 390 px, WebGL phần mềm) | 4 game 3D đều dựng khung 3D, trả lời được câu, không lỗi JavaScript; ~61 khung hình/giây trên WebGL phần mềm | **4/4 game chạy** |
| `duelb.js` | Đấu 1–1 trên trình duyệt: vào trận với máy, sân 3D, trả lời hết câu, trang kết quả | PASS (thắng trận) |
| `wmap.js` | Bản đồ thế giới 3D: kéo, chạm đảo mở màn | PASS |
| `pwa.js` | Đăng ký service worker, tải gói ôn ngoại tuyến, **tắt máy chủ web** rồi mở lại trang → hiện trang ngoại tuyến có thẻ từ đã tải | PASS |
| Nhập dữ liệu lặp lại | Nhập lại 2 gói: toàn bộ báo “đã có”, không tạo bản trùng | PASS |
| Cùng một bản cài chạy ở gốc và thư mục con | Gói đã cài truy cập qua `http://host:8081/` và `http://host/chie-rel/`: liên kết, tài nguyên, chuyển hướng đều đúng tiền tố | PASS |
| Nhật ký lỗi máy chủ sau toàn bộ lượt chạy cuối | `storage/logs` | **0 lỗi** |

Tổng bản 1.1: **253 kiểm tra tự động đạt / 253** (t1 17, t2 27, t3 37, t4 44, t5 24, t6 13, t7 47, t8 16, t9 18, t10 10 — chưa tính lần t5 trên gói 1.0), cộng crawl, quét giao diện và các kịch bản trình duyệt.

## Lỗi đã phát hiện và sửa trong quá trình kiểm thử

| Lỗi | Sửa |
|---|---|
| Trang nông trại & phòng lỗi 500 (biểu thức `@json` có dấu phẩy) | Dùng `json_encode` trong thuộc tính |
| Trang hòm quà lỗi 500 (ngày giờ nhật ký chưa ép kiểu) | Thêm ép kiểu `created_at` cho 3 mô hình |
| Trang đổi đồ lỗi 500 (trùng tên biến) | Đổi tên biến |
| Bán được đồ đang đặt trong phòng | Chặn ở máy chủ |
| Cất đồ khỏi phòng lỗi khi thiếu tọa độ | Sửa kiểm tra tham số |
| Liên kết phụ huynh/tạo mã chuyển về trang trước (có thể là trang 404) | Chuyển về trang đúng |
| Thông báo lỗi nhập liệu hiện mã `validation.required` | Thêm bộ thông báo tiếng Việt |
| Lớp phủ “Bắt đầu” của game không ẩn | Quy tắc `[hidden]` toàn cục |
| Word Runner: bấm đáp án phải chờ cổng chạy tới | Bấm đáp án → lao nhanh tới cổng |
| Lỗi nghiệp vụ (hết Xu, hết lượt) bị ghi như lỗi hệ thống | Không ghi nhật ký lỗi cho lỗi nghiệp vụ |
| Thông báo đổi đồ khác bậc hiển thị sai bậc | Sửa |
| Thiếu ô lọc nguồn và duyệt toàn bộ kết quả lọc trong ngân hàng câu hỏi | Bổ sung |
| Cài đặt “nhắc nghỉ mắt” có trong Admin nhưng chưa hoạt động | Bổ sung nhắc nghỉ cho học sinh |
| (1.1) Game 3D lỗi khởi động do biến dùng trước khi khai báo (nông trại, tháp) | Sắp xếp lại thứ tự khởi tạo |
| (1.1) Trình cập nhật từ chối nhầm `.env.example` (so khớp tiền tố) | So khớp chính xác với tệp, tiền tố chỉ với thư mục |
| (1.1) Gói cập nhật đầy đủ vượt giới hạn tải lên 2 MB của hosting | Gói rút gọn + chọn gói đặt sẵn trong `storage/app/updates/` + báo lỗi thân thiện |
| (1.1) Chạy seed khi nâng cấp có thể ghi đè chỉnh sửa của Admin | Bỏ seed khi nâng cấp; dữ liệu nền mới nằm trong migration (chỉ thêm nếu chưa có) |
| (1.1) Camera bản đồ/nông trại 3D quá xa trên điện thoại | Chỉnh góc nhìn riêng cho màn hình hẹp |
| (1.1) Dòng kho nông trại tràn ngang ở 360 px | Cho nút hành động xuống dòng |

## Chưa kiểm thử (trung thực)

- **Chưa chạy trên cPanel/LiteSpeed thật**, chưa thử PHP 8.2 (chỉ 8.3), chưa thử MySQL 8 (chỉ MariaDB 10.11), chưa thử Nginx.
- Âm thanh: máy thử không có giọng đọc nên **không nghe thực tế** tốc độ 0,65/0,75, đọc theo cụm, chặn chồng tiếng; chỉ kiểm tra mã và không có lỗi JavaScript.
- Ghi âm bằng micro thật, quyền micro trên điện thoại.
- Gửi email thật qua SMTP (xác minh email, quên mật khẩu).
- Trình duyệt Safari/iOS, Firefox, máy Android thật (chỉ Chromium giả lập khổ màn hình).
- **Game 3D trên điện thoại thật** (GPU di động, nóng máy, pin): chỉ chạy trên WebGL phần mềm của Chromium giả lập. Con số ~61 khung hình/giây **không** đại diện cho điện thoại đời cũ — vì vậy có mức “3D nhẹ” và “2D”.
- Đấu 1–1 dùng hỏi trạng thái mỗi ~1,5 giây (**không dùng WebSocket**); chưa thử nhiều trận đồng thời hay mạng chập chờn thật.
- Cập nhật một chạm trên cPanel thật (quyền tệp, giới hạn thời gian chạy PHP, tiện ích `zip`).
- “Thêm vào màn hình chính” trên iOS/Android thật.
- Tải lớn/đồng thời nhiều người dùng, sao lưu–khôi phục.
- Trình đọc màn hình (đã gắn nhãn ARIA, chưa thử với NVDA/VoiceOver).

## Chạy lại kiểm thử

Xem `tests/e2e/README.md`. Các kịch bản chỉ dùng CSDL thử, đọc thông tin đăng nhập từ biến môi trường và tự sinh mật khẩu ngẫu nhiên cho tài khoản thử.

## Lần quét giao diện cuối (sau khi sửa)

Bản 1.0: 77 trang × 2 khổ (360 và 1366 px) theo 5 vai trò = 154 lượt, 0 vấn đề.

Bản 1.1: 83 trang × 2 khổ = **166 lượt**, phát hiện 4 vấn đề: 3 lỗi 500 do thư mục bộ nhớ đệm giao diện trên **máy thử** bị sai quyền ghi (không phải lỗi mã; sửa quyền xong trang chạy bình thường) và 1 tràn ngang ở nông trại 360 px (đã sửa). Quét lại các trang đó: **0 vấn đề**.
