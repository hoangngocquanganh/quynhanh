# Phân tích trực tuyến · 1.4.7

## Sử dụng

Tải ZIP đầy đủ vào Admin → Cập nhật phiên bản, kiểm tra và áp dụng. Cần chạy migration `2026_10_20_000015_create_activity_analytics`; nếu được yêu cầu, bấm Cập nhật CSDL ngay. Vào `/chie/admin`.

- Hôm nay: biểu đồ theo giờ; 7 ngày và 1 tháng qua (30 ngày): theo ngày, gồm ngày hiện tại.
- Lọc vai trò, quốc gia, tỉnh/bang, thành phố. Chọn quốc gia mới sẽ bỏ lựa chọn tỉnh/thành trước đó, rồi bấm Lọc báo cáo.
- Bốn chỉ số chính: tài khoản hoạt động, lượt xem trang, đang trực tuyến, tỷ lệ có dữ liệu quốc gia. Có so sánh với khoảng trước cùng độ dài, tới cùng giờ.
- Biểu đồ kỳ này/kỳ trước, bảng dữ liệu có thể mở để đọc số chính xác; bảng tối đa 50 khu vực nổi bật; phân bố theo khu chức năng và vai trò.
- Làm mới tự động mỗi 45 giây khi tab đang hiện. Dừng làm mới khi đang chỉnh bộ lọc để tránh mất lựa chọn. Các thẻ Vận hành hôm nay ở dưới vẫn phản ánh toàn hệ thống, không theo bộ lọc phân tích.

## Định nghĩa số liệu

Chỉ tài khoản đã đăng nhập được thống kê, kể cả admin. Chọn vai trò Học sinh để xem riêng học sinh. Khách không ghi lịch sử và không được tính trong báo cáo này.

Một tài khoản chỉ tính một lần trong tổng khoảng thời gian, kể cả mở nhiều tab. Có thể xuất hiện trong nhiều ngày, khu chức năng hoặc khu vực; không cộng các dòng thành số tài khoản duy nhất.

Lượt xem trang là một GET HTML thành công; không tính API, tài nguyên, chuyển hướng, trang lỗi. Nhịp heartbeat không tăng lượt xem. Trực tuyến là có hoạt động trong 150 giây gần nhất; tab ẩn không gửi heartbeat. Đây là số liệu tài khoản của app, không phải tích hợp Google Analytics hay chỉ số “phiên truy cập” của Google.

Giờ dùng cấu hình `APP_TIMEZONE`, mặc định Asia/Ho_Chi_Minh. Dữ liệu lịch sử chỉ bắt đầu sau khi cài bản này; không dựng lại lịch sử từ bảng trạng thái mới nhất. Khi chưa có migration, báo cáo hướng dẫn cập nhật thay vì gây lỗi 500.

## Khu vực IP

Nguồn hiện hỗ trợ: Cloudflare location headers, chỉ chấp nhận khi kết nối trực tiếp tới máy chủ đến từ dải proxy Cloudflare đã cấu hình. Không tin header do khách tự gửi. Không gọi dịch vụ tra IP bên ngoài và không gửi IP học sinh đi tra cứu.

Để có quốc gia/tỉnh/thành:

1. Tên miền cần đi qua proxy Cloudflare (DNS proxied).
2. Trong Cloudflare, mở Rules → Settings / Managed Transforms, bật **Add visitor location headers**.
3. Truy cập app bằng tài khoản từ mạng Internet rồi kiểm tra lại báo cáo sau khoảng một phút.
4. Nếu hosting dùng LiteSpeed/Apache hoặc một proxy khác để viết lại REMOTE_ADDR thành IP khách trước khi PHP chạy, quản trị hosting cần giữ đúng IP của kết nối proxy Cloudflare cho PHP. Không thêm toàn bộ Internet vào danh sách proxy tin cậy chỉ để có số liệu vị trí.

Tài liệu chính thức: [Managed Transforms – visitor location headers](https://developers.cloudflare.com/rules/transform/managed-transforms/reference/), [dải IPv4](https://www.cloudflare.com/ips-v4), [dải IPv6](https://www.cloudflare.com/ips-v6). Dải mặc định được đối chiếu ngày 17/10/2026 trong config/analytics.php.

Kiểm tra phản hồi công khai hosting ngày 17/10/2026 thấy Server LiteSpeed và không có CF-Ray/CF-Cache-Status; đây chưa đủ để xác nhận cấu hình nội bộ. Chưa có quyền vào tài khoản hosting/Cloudflare để bật trực tiếp.

Nếu chưa có nguồn vị trí, hiển thị Chưa xác định. Định vị IP chỉ ước lượng quốc gia/tỉnh/thành; VPN, mạng di động hoặc dữ liệu nhà cung cấp có thể làm sai vị trí. Không suy đoán địa chỉ nhà, GPS hoặc quận/phường từ dữ liệu không có.

## Dữ liệu và kiểm thử

Bảng activity_analytics lưu theo tài khoản/giờ/khu chức năng/khu vực; không lưu IP thô, GPS, URL, tham số trang hoặc đáp án trong bảng này. Xóa tài khoản sẽ xóa các dòng tương ứng. Dữ liệu không được gửi sang Google. Báo cáo HTML và JSON đều bảo vệ bởi quyền admin hiện có.

Kiểm thử đã chạy: ranh giới ngày/7 ngày/30 ngày; khử trùng tài khoản; heartbeat không cộng lượt xem; lọc quốc gia/tỉnh/thành/vai trò; không ghi cho khách; bỏ header vị trí giả; thiếu migration; chỉ admin xem HTML/JSON. Rà 1.185 lượt GET qua 5 vai trò không gặp 500. Kiểm thử hồi quy khách không ghi dữ liệu vẫn đạt. Kiểm tra trình duyệt 1440px/390px: không tràn ngang, làm mới thành công, giữ bộ lọc đang sửa, không có lỗi JavaScript.

Dữ liệu trong ảnh xem thử là dữ liệu kiểm thử trong giao dịch đã hoàn tác, không phải số liệu hosting.
