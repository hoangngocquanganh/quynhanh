# Cập nhật giữ nguyên phiên và lượt chơi · 1.4.11

## Hoạt động

Mỗi gói cập nhật nóng được kiểm tra mã băm, chuẩn bị trong `storage/app/deploy/releases/<id>`, kiểm tra khởi động bằng PHP CLI, rồi đổi duy nhất con trỏ `storage/app/deploy/active.json`. Không chép đè mã của bản đang dùng.

- Người mở trang mới dùng phiên bản mới.
- Tab học/game đang mở ghim API vào phiên bản đã bắt đầu. Bản cũ và tài nguyên cũ được giữ lại để trả lời/nộp bài/lưu Nông trại.
- `.env`, APP_KEY, cookie/phiên đăng nhập, CSDL, ví, album và bản lưu dùng chung. Không xóa session, không bật maintenance mode và không ép tải lại tab.
- Service worker mới chờ vòng đời bình thường, không ép chiếm tab và không xóa cache cũ khi người khác đang dùng.
- Hoàn tác bản cập nhật nóng đổi lại con trỏ; vẫn giữ bản mới cho các lượt chơi đã bắt đầu bằng bản đó.
- Khóa cập nhật ngăn hai admin triển khai cùng lúc. Gói lỗi, thiếu dung lượng, khởi động thất bại hoặc không tương thích không được chuyển sang hoạt động.

## Điều kiện

Chỉ áp dụng nóng gói được kiểm tra tương thích giao thức API/dữ liệu. Manifest phải có `live_update: {protocol: 1, schema: "unchanged"}`. Lệnh đóng gói dùng `--live` chỉ sau khi người phát triển đã xác nhận điều này.

Gói có migration chưa chạy, thay đổi cấu hình app/xác thực/phiên, hoặc chứa module cũ hơn đang dùng bị chặn. Đây là chủ đích để tránh lỗi giữa lượt chơi; không có bảo đảm an toàn cho mọi thay đổi CSDL tùy ý. Thay đổi CSDL cần kế hoạch triển khai tương thích riêng, hoặc bảo trì được quản trị viên quyết định.

Cầu vào index.php/artisan/release-loader.php, .htaccess và service worker cũng được giữ ổn định. Gói thay các tệp này bị chặn cập nhật nóng; cần triển khai riêng để không âm thầm bỏ qua thay đổi hệ thống.

Module ZIP lẻ không được chép đè khi đã cài cơ chế này. Gộp module vào bản phát hành đầy đủ. Sao lưu theo cơ chế cũ cũng không được tự chép đè qua giao diện cập nhật nóng.

Hosting cần PHP CLI chạy được qua proc_open, quyền ghi thư mục storage/assets, và dung lượng cho bản mới lẫn bản cũ. Không cần bật cửa sổ Terminal cho người dùng; hệ thống tự chạy bước kiểm tra. Nếu hosting chặn kiểm tra, bản hiện tại được giữ lại và admin nhận thông báo.

## Cài lần đầu

Bản 1.4.11 là bước cài cầu chuyển phiên bản. Hosting vẫn đang dùng trình cập nhật cũ cho chính lần cài này, nên nên thực hiện lúc ít người hoạt động. Cơ chế giữ hai phiên bản áp dụng cho các lần triển khai sau khi cài xong. Người đã mở trang từ trước khi có cơ chế ghim API cần mở trang lại một lần sau khi hoàn thành lượt chơi.

Sau đó cập nhật gói tương thích như bình thường trong Admin → Cập nhật phiên bản. Không tự xóa `storage/app/deploy`, `assets/chie-releases`, bản gốc ở thư mục cài, hay cache cũ khi còn lượt chơi có thể sử dụng chúng. Không tự tạo lại APP_KEY hoặc sửa tên/path cookie giữa các phiên bản.

Việc giữ nhiều bản sử dụng thêm dung lượng. Hiện không có tác vụ tự xóa bản cũ để tránh cắt ngang tab mở lâu. Khi cần thu hồi bản có lỗi bảo mật hoặc dọn dung lượng, quản trị cần kế hoạch kết thúc các lượt cũ; không dùng cơ chế này để giữ API cũ mãi khi đã xác định không an toàn.

Kiểm thử: chuyển/hoàn tác con trỏ trong thư mục cách ly; không thay khóa/phiên/tài nguyên cũ; chặn gói không tương thích và bản khởi động thất bại. Thử hai bản Laravel đầy đủ qua HTTP: đăng nhập giữ được qua chuyển bản/hoàn tác, bài đang làm tiếp tục trả lời qua API bản cũ, Nông trại cũ vẫn lưu, tài nguyên theo phiên bản mới tải được. Dữ liệu tài khoản thử được xóa sau kiểm tra.
