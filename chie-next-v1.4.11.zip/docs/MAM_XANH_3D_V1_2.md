# CHIE NEXT 1.2.0 — Thị trấn Mầm Xanh

Bản này thay thế toàn bộ cảnh và cách điều khiển của game nông trại. Đây là thị trấn 3D phong cách low-poly do dự án tự dựng, lấy cảm hứng từ nhịp chơi đời sống/nông trại. Không sử dụng hình ảnh, nhân vật, mã nguồn hay thương hiệu của Avatar.

## Chơi thế nào

Vào **Game đấu trường → Thị trấn Mầm Xanh**.

- Đi bằng WASD, phím mũi tên (bấm vào cảnh trước), cần cảm ứng, hoặc chạm mặt đất để tự tìm đường.
- Chạm ô đất/con vật để nhân vật đi đến rồi mở thao tác. Phím E hoặc nút bàn tay tương tác với vật gần nhất.
- Gieo hạt, tưới cây, bắt sâu, cho ăn trực tiếp. Không cần trả lời câu hỏi.
- Cây vẫn có giá hạt giống, thời gian chín, cấp mở khóa; chỉ tưới tối đa 3 lần. Những giá trị này lấy từ cấu hình/database sẵn có.
- Thu hoạch rồi mở **Kho & chợ** để bán hoặc chuyển hàng sang kho an toàn.
- Các nút phía dưới mở vật nuôi, bếp, thay màu áo và sổ tay trong màn chơi.
- Nút bản đồ có các điểm đến; nút xoay đổi camera; +/- phóng to/thu nhỏ; nút mở rộng phủ màn hình trình duyệt, kể cả thiết bị không hỗ trợ Fullscreen API.
- Bấm ? để xem hướng dẫn hoặc mở giao diện danh sách. Nếu thiết bị không hỗ trợ WebGL hoặc người dùng chọn 2D, danh sách vẫn hoạt động.

## Tiếng Anh nhẹ nhàng

Tên nông sản và vật nuôi có tiếng Anh đi kèm tiếng Việt. Lời nhắn của cô Mây có nút nghe, xem nghĩa và hành động tưới vườn hoa tự chọn. Bếp vẫn là một hoạt động học tự chọn; không phải điều kiện để trồng trọt.

Không tự bật bài trắc nghiệm trong vòng lặp chăm vườn. Thao tác trực tiếp không phát XP học tập hay thưởng Xu cho việc tưới/cho ăn. Người chơi vẫn nhận nông sản, sản phẩm vật nuôi và tiền bán hàng theo luật máy chủ. API lượt ôn có token được giữ tương thích; token giả/hết hạn vẫn bị từ chối.

## Phạm vi và dữ liệu

- Đã làm lại game nông trại; các game khác, tài khoản, vai trò, quản lý lớp và học liệu giữ nguyên.
- Cư dân trong thị trấn là NPC cục bộ, không phải người chơi trực tuyến. Chưa bổ sung phòng nhiều người chơi thời gian thực hay chat trực tuyến.
- Bản đồ, vị trí đứng và hoạt ảnh chỉ ở phía trình duyệt; màu áo được nhớ trên thiết bị. Các thay đổi kinh tế vẫn lưu MySQL/MariaDB qua API có đăng nhập của CHIE.
- Mất mạng: đi dạo trong cảnh đã tải được; không mua, trồng, thu hoạch, bán hay phát thưởng giả ở máy khách. Khi có mạng sẽ lấy lại trạng thái máy chủ.
- Vượt tường giữ luồng cũ trên trang riêng; không dựng lại thành chiến đấu 3D trong bản này.

## Triển khai cPanel

Vẫn dùng Laravel/PHP + MySQL/MariaDB. Three.js và toàn bộ JavaScript/CSS được kèm sẵn, không tải CDN, không cần máy chủ Node.js và không cần npm build trên hosting.

1. Sao lưu tệp website và database theo quy trình hiện có.
2. Thử bản này trên staging trước; dùng cấu hình database staging riêng.
3. Có thể dùng **Cập nhật** trong admin để nạp ZIP: phiên bản đã tăng lên 1.2.0 và chie-release.json đã được tính lại SHA-256. Luồng cập nhật này chưa được chạy thực tế trong môi trường bàn giao.
4. Nếu chép thủ công: giải nén ở gốc ứng dụng theo hướng dẫn cài đặt có sẵn; giữ nguyên .env, storage, uploads và dữ liệu đang chạy. Chạy `php artisan optimize:clear` sau khi thay tệp. Không chạy migrate:fresh hay seed lại trên database thật.
5. Không có migration schema mới trong bản thay đổi này. Cài mới vẫn dùng trình cài đặt và bộ migration có sẵn.
6. Tải lại trang để service worker chuyển phiên bản. Nếu từng chọn đồ họa 2D, chuyển lại Auto trong cài đặt game để mở cảnh 3D.

## Kết quả kiểm tra của bản 1.2.0

Đã chạy trong môi trường chỉnh sửa:

- Node kiểm tra cú pháp các tệp JavaScript thay đổi.
- `node tests/town/navigation.mjs`: tìm đường vòng, đường liên tục, tránh vật cản, giới hạn bản đồ và đích không thể tới.
- `node tests/town/farm-client.cjs`: chạy event handler thật của farm.js trong bộ giả lập DOM/API tối thiểu; xác nhận gieo/tưới/cho ăn không gọi quiz, khóa thao tác đang gửi, chặn ghi ngoại tuyến, xử lý lỗi máy chủ, không tự cộng tiền.
- `node tests/town/models.mjs`: dựng model bằng thư viện Three.js thật, xác nhận biến đổi hữu hạn và tái sử dụng hình học. Đây không phải kiểm tra WebGL hay ảnh render.
- Kiểm tra ZIP và manifest SHA-256 cho toàn bộ tệp.

**Chưa kiểm tra được:** PHP runtime, database thật, đăng nhập và API đầu-cuối, màn hình WebGL, Safari/Android, FPS, cập nhật/hoàn tác trên cPanel. Môi trường chỉnh sửa không cung cấp PHP/MySQL hoặc trình duyệt kiểm thử phù hợp. Không xem báo cáo kiểm thử bản 1.1.0 là bằng chứng cho bản 1.2.0.

### Kiểm tra bắt buộc trên staging trước khi dùng thật

Sau khi cài và nhập dữ liệu, chọn ID một tài khoản học sinh thử nghiệm. Chỉ chạy lệnh sau với môi trường/database thử:

```bash
APP_ENV=testing CHIE_TEST_USER_ID=123 php tests/town/server.php
```

Thay 123 bằng ID thật của tài khoản thử. Script dùng transaction ngoài và rollback; không reset database. Kiểm tra gieo trực tiếp, giá hạt, ô khóa, token giả, tưới quá 3 lần, bắt sâu lặp, thu hoạch sớm/lặp, cho ăn lặp và XP. Script được cung cấp nhưng chưa chạy vì thiếu PHP/MySQL.

Sau đó thử thủ công:

- Mở /nong-trai ở màn hình 390×844 và desktop; kiểm tra cảnh, bảng, chữ tiếng Việt và không tràn ngang.
- Đi quanh nhà/hồ; không xuyên vật cản; tới mọi ô trong vườn 48 ô.
- Gieo, tưới, chờ chín, thu hoạch, chuyển kho, bán, mua vật nuôi, cho ăn và lấy sản phẩm.
- Thử hai lần bấm nhanh; lỗi thiếu tiền; mất mạng, nối lại; quay về tab sau thời gian dài.
- Chọn nguyên liệu trong bếp, đợi ít nhất 15 giây để bảo đảm lượt đồng bộ không xóa lựa chọn.
- Kiểm tra xoay camera/cảm ứng/toàn màn hình/thoát bằng Escape, chế độ giảm chuyển động và fallback 2D.
- Đo FPS trên điện thoại mục tiêu; hạ chất lượng trong cài đặt nếu cần. Chưa có cam kết 60 FPS.
