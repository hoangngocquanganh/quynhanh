# Cập nhật 1.4.5

- Ẩn mục Quản trị trong menu giao diện học. Admin vẫn giữ đầy đủ quyền và truy cập riêng `/admin`.
- Logo trên trang học và khu quản trị đều về trang chủ. Admin đăng nhập mặc định về trang học.
- Luôn hiện form tải ZIP, kể cả khi có gói chờ. Gói mới hợp lệ mới thay trạng thái gói chờ; lỗi kiểm tra không làm mất trạng thái gói trước.
- Tự bỏ trạng thái chờ nếu gói không còn hoặc phiên bản không mới hơn bản đang chạy. Không xóa ZIP đặt sẵn.

Hosting đang 1.4.4: tại trang cập nhật, bấm “Bỏ gói này” dưới gói 1.4.0 để hiện ô tải lên, sau đó tải ZIP 1.4.5, kiểm tra và áp dụng. Hoàn tất các migration còn thiếu theo thông báo; gói giữ cả bản sửa Sticker 1.4.4.

Địa chỉ quản trị: `/chie/admin`; cập nhật: `/chie/admin/he-thong/cap-nhat`.

Kiểm thử: menu và liên kết logo; loại gói chờ cũ; kiểm tra ZIP hợp lệ; form tải lên hiện khi có gói chờ; ZIP hỏng không thay trạng thái gói đã kiểm tra. Dữ liệu tài khoản thử được hoàn tác.
