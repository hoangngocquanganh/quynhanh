# Báo cáo nhập dữ liệu từ bản cũ (CHIE-NEXT-v9.9-FINAL-COMPLETE.zip)

Bản cũ chỉ được dùng làm **nguồn kiểm kê học liệu**. Mã nguồn, giao diện và cấu trúc CSDL của CHIE NEXT được viết mới hoàn toàn; không chép mã cũ.

## 1. Cách làm

1. Chạy các seeder cũ vào một CSDL tách biệt (`oldchie`, chỉ trên máy kiểm thử) để đọc ra đúng dữ liệu mà bản cũ tạo, kể cả dữ liệu sinh bằng vòng lặp.
2. Một công cụ trích xuất đọc CSDL đó cùng tệp từ vựng của bản cũ, **chuẩn hóa**, **lọc nội dung sinh tự động vô nghĩa**, **bỏ trùng**, gắn cờ nội dung nghi ngờ, rồi xuất ra gói `database/content/zip_content_v1.json` (định dạng `chie-content`).
3. Trình nhập (`php artisan chie:import` hoặc **Admin → Nhập dữ liệu**) kiểm tra từng mục rồi mới ghi CSDL; mục có cờ được để **Chờ duyệt**, không xuất bản. Mỗi lần nhập lưu một báo cáo trong bảng `import_runs` (xem được trong Admin).
4. Nhập lại cùng gói: toàn bộ mục báo “đã có”, không tạo bản trùng (đã kiểm chứng, xem `KET_QUA_KIEM_THU.md`).

## 2. Kết quả theo loại

| Loại | Trong bản cũ | Nhập vào CHIE NEXT | Lý do không nhập / ghi chú |
|---|---|---|---|
| Câu hỏi | 2.510 | **1.268** (1.250 xuất bản, 18 chờ duyệt) | 1.000 câu ngữ pháp sinh tự động lặp khuôn vô nghĩa; 241 câu trùng; 1 câu nghe thiếu nội dung phát âm |
| Từ vựng | 18.210 cụm sinh tự động + bộ từ gốc + 621 mục mega_vocab | **785 từ** | Gộp 1.642 bản trùng; bỏ 18.210 cụm ghép tự động không có nghĩa thật |
| Chủ điểm mẫu | 12 | **12** (xuất bản) | — |
| Bài học mẫu | 60 | **60** (xuất bản) | Phần “Làm quen/Nghe mẫu” dựng lại từ chính câu hỏi của bài, không bịa thêm |
| Bài học “khung” | 10.000 | 0 | Vỏ rỗng sinh tự động, không có nội dung |
| Tên chủ điểm theo chương trình | 80 | **80 ở trạng thái Nháp** | Tên gần giống mục lục sách giáo khoa → cần giáo viên đối chiếu bản quyền trước khi dùng |
| Bài đọc | 200 | 0 | Cùng một khuôn câu lặp lại, chỉ thay chủ đề |
| Mẫu đề thi | 550 | 0 (tạo mới 8 cấu trúc đề) | Bản sao gần như giống nhau |
| Mẫu câu hỏi | 5.000 | 0 | Khuôn sinh tự động |
| Màn chơi “Vương Quốc CHIE” | 10 | **10** | — |
| Cây trồng, công thức nấu, vật phẩm, tỉ lệ hòm quà | có | Viết lại trong dữ liệu nền | Lấy làm tham khảo cơ chế; số liệu chỉnh theo đặc tả V9.1 |

## 3. Chuẩn hóa đã áp dụng cho câu hỏi

| Sửa | Số câu |
|---|---|
| Câu ví dụ trong đề làm lộ đáp án → chuyển ra phần hiện **sau** khi trả lời | 621 |
| Đáp án lưu bằng chỉ số (0/1/2) → đổi sang nội dung đáp án (để trộn phương án an toàn) | 135 |
| Bỏ tiền tố nhãn thừa trong đề (ví dụ “[Grammar]”) | 33 |
| Xóa dòng hội thoại “B: ___” bị lặp | 18 |
| Câu “sắp xếp” thực chất là chọn đáp án → đổi thành trắc nghiệm | 1 |

## 4. Mục bị gắn cờ (Chờ duyệt — học sinh chưa thấy)

| Cờ | Số câu | Ý nghĩa |
|---|---|---|
| `co_the_lo_dap_an` | 17 | Đề có thể chứa gợi ý trùng đáp án |
| `lua_chon_trung` | 3 | Hai phương án giống nhau |
| `manh_tu_khong_khop_cau` | 3 | Mảnh từ của câu sắp xếp không khớp câu đúng |

Lọc nhanh: **Admin → Học liệu → Câu hỏi → Trạng thái: Chờ duyệt**.

## 5. Học liệu theo lớp sau khi nhập (gói từ bản cũ)

| Lớp | Câu đã xuất bản | Bài học đã xuất bản | Từ vựng |
|---|---|---|---|
| 1–2 | 0 | 0 | 0 |
| 3 | 550 | 30 | 669 |
| 4 | 201 | 5 | 0 |
| 5 | 204 | 5 | 0 |
| 6 | 66 | 5 | 64 |
| 7 | 16 | 0 | 0 |
| 8 | 56 | 5 | 0 |
| 9 | 16 | 0 | 0 |
| 10 | 67 | 5 | 52 |
| 11 | 57 | 5 | 0 |
| 12 | 17 | 0 | 0 |

Bản cũ **thiếu nghiêm trọng** học liệu cho lớp 1–2, 7, 9, 12. Hệ thống vẫn chạy (luyện theo kỹ năng, game, đề ngắn dùng câu đã có) nhưng sẽ báo rõ “chưa đủ câu” thay vì lấy câu của lớp khác.

## 6. Gói mới biên soạn: `chie_focus_pack_v1.json`

Để lấp chỗ trống và đáp ứng yêu cầu “lỗi người Việt hay gặp”, gói này được **biên soạn mới** (không lấy từ sách giáo khoa):

| Nhóm lớp | Chuyên đề |
|---|---|
| 1–2 | Chào hỏi & màu sắc; Số đếm & đồ dùng học tập |
| 3–5 | Đọc rõ âm cuối; Số nhiều & a/an; am/is/are; Giới từ in/on/at/under |
| 6–9 | Đọc đuôi -s/-es và -ed; Ngôi thứ ba số ít; Chọn thì; Trọng âm; Không dịch từng chữ |
| 10–12 | Hiện tại hoàn thành vs quá khứ đơn; Hòa hợp chủ ngữ–động từ; Câu điều kiện; Bị động & mạo từ |

15 chủ điểm, 15 bài, 120 câu, mỗi bài có phần giới thiệu, câu mẫu (kèm nghĩa), ghi nhớ, “Lỗi người Việt hay gặp” và câu luyện có giải thích. **Toàn bộ ở trạng thái Chờ duyệt** vì chưa qua giáo viên rà soát. Duyệt nhanh (sau khi giáo viên đã đọc lại): **Admin → Học liệu → Câu hỏi** → Nguồn: `chie_focus_pack_v1` → tích “Áp dụng cho toàn bộ … câu theo bộ lọc” → Duyệt & xuất bản; rồi **Admin → Học liệu → Cây chương trình** → ở từng lớp (1, 3, 6, 10) bấm **Xuất bản** trên chủ điểm “Chuyên đề”, tích “Chọn tất cả bài” → Xuất bản.

Học liệu của CHIE NEXT **không được Bộ GD&ĐT thẩm định hay chứng nhận**. Cấu trúc “đề ôn vào lớp 10/tốt nghiệp” chỉ mô phỏng để luyện tập, có ghi chú cần đối chiếu cấu trúc đề công bố của năm thi.

## 7. Cảnh báo bảo mật phát hiện trong bản cũ

Tệp ZIP cũ có chứa tệp `.env` với **thông tin đăng nhập CSDL thật** (tên người dùng CSDL của hosting cũ kèm mật khẩu). Thông tin này **không được sao chép** vào CHIE NEXT, không xuất hiện trong gói phát hành. Khuyến nghị:

1. Vào cPanel → MySQL Databases, **đổi mật khẩu** người dùng CSDL đó ngay (coi như đã lộ).
2. Không chia sẻ lại tệp ZIP cũ; xóa các bản sao còn lưu.
3. Nếu bản cũ đang chạy trên hosting, kiểm tra `.env` có thể tải trực tiếp qua trình duyệt hay không.
