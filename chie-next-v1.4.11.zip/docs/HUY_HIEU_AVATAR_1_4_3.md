# Huy hiệu, avatar và giao diện câu hỏi — 1.4.3

## Hồ sơ và ngoại hình

- Hồ sơ → Đổi avatar & khung (`/ho-so/ngoai-hinh`).
- 24 avatar có sẵn, 6 màu nền, 12 lựa chọn khung theo cấp/số huy hiệu; khung đã sở hữu trong cửa hàng cũng chọn được.
- Chọn một huy hiệu đã đạt để gắn trên avatar. Mỗi lần lưu đều kiểm tra lại cấp, huy hiệu và quyền sở hữu vật phẩm ở máy chủ.
- Avatar hiển thị trên Hồ sơ, thanh điều hướng và bảng tên đấu 1–1. Nhân vật 3D trong sàn đấu vẫn là linh vật của trò chơi.
- Avatar là danh mục có sẵn, chưa có chức năng tải ảnh cá nhân lên.

## Huy hiệu

40 huy hiệu thuộc các nhóm Bài học, Luyện tập, Kiên trì, Từ vựng, Ngữ pháp, Khám phá và Cấp độ. Mỗi huy hiệu có điều kiện, tiến độ và trạng thái đã đạt.

Bảng mới `user_badges` lưu huy hiệu vĩnh viễn theo tài khoản, khóa duy nhất (user_id, code) ngăn nhận trùng. Tự ghi nhận sau khi nộp bài và khi mở Hồ sơ. Không phát thêm XP/Xu khi chỉ mở trang Hồ sơ hoặc đổi avatar. Dữ liệu hiện có được tính để mở khóa khi đọc Hồ sơ; hệ thống không suy đoán những mốc lịch sử không còn dữ liệu.

## Câu hỏi

- Bỏ emoji minh họa đáp án, hình ở các lựa chọn, bong bóng nói và nút nghe của câu hỏi thông thường.
- Không tự phát âm khi chọn đáp án, ghép từ, ghép cặp, kiểm tra hoặc hiện câu hỏi.
- Câu nghe/nói có nút nghe chủ động; trang phát âm và nghe mẫu trong bài học vẫn giữ.
- Làm sạch dữ liệu hiển thị trên máy chủ nên lượt làm đã tạo trước nâng cấp cũng không hiện lại các gợi ý này.

## Các lỗi đã sửa

- Đấu với bạn máy: bạn máy thắng không còn hiện nhầm thành hòa, cả kết quả và lịch sử trận.
- Thống kê câu đã làm chỉ đếm số câu thực sự đã trả lời.
- Khung đã bán/đổi khỏi kho không còn được dùng; giao diện tự về khung mặc định.
- Thanh trên có lối vào Hồ sơ bằng avatar trên điện thoại; hiển thị Xu cho Admin theo quyền nhận thưởng.

## Cập nhật hosting

Dùng `chie-next-v1.4.3.zip` qua cơ chế cập nhật phiên bản. Cần chạy migration `2026_10_20_000013_create_user_badges` (bộ cập nhật chạy tự động; nếu còn bước chờ, bấm Cập nhật CSDL ngay). Gói gồm các bản vá hosting và chế độ khách trước đó.

Kiểm thử: `tests/e2e/profile_cosmetics.php` dùng dữ liệu tạm trong transaction và rollback. Đã kiểm tra mở khóa vĩnh viễn, không trùng huy hiệu, lưu ngoại hình, từ chối khung/huy hiệu chưa đạt, khung cửa hàng, tự nhận sau khi nộp bài, kết quả bạn máy và dữ liệu câu hỏi. Đã xem bản render trang ngoại hình/Hồ sơ ở 1366px và 390px, không tràn ngang; kiểm thử trình duyệt câu trắc nghiệm xác nhận không hình gợi ý/nút nghe/tự đọc.
