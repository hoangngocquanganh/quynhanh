# Hướng dẫn cài đặt CHIE NEXT trên cPanel

> **Bản 1.3.0:** xem hướng dẫn ngắn gọn, cập nhật cho Zoo Garden tại [`HUONG_DAN_CAI_LEN_HOSTING.md`](HUONG_DAN_CAI_LEN_HOSTING.md). Tài liệu dưới đây là hướng dẫn chi tiết gốc (vẫn đúng).

CHIE NEXT là ứng dụng PHP (Laravel 11) dùng MySQL/MariaDB. Gói phát hành đã có sẵn thư viện (`vendor/`) và giao diện dựng sẵn (`assets/`), nên **không cần Composer, Node hay npm trên hosting**.

## 1. Yêu cầu

| Hạng mục | Yêu cầu |
|---|---|
| PHP | 8.2 trở lên (khuyên dùng 8.3). Bật: `pdo_mysql`, `mbstring`, `openssl`, `tokenizer`, `ctype`, `fileinfo`, `json` |
| CSDL | MySQL 5.7+ hoặc MariaDB 10.4+, bảng mã `utf8mb4` |
| Máy chủ web | Apache hoặc LiteSpeed có `mod_rewrite` và cho phép `.htaccess` (mặc định trên cPanel) |
| Dung lượng | Khoảng 45 MB sau khi giải nén |
| Tiện ích PHP thêm | `zip` (để cập nhật một chạm; không bắt buộc khi cài) |
| HTTPS | Nên bật (cPanel → SSL/TLS Status → AutoSSL). Micro ghi âm trên trình duyệt chỉ hoạt động qua HTTPS |

## 2. Chọn nơi cài

Ứng dụng chạy được ở **tên miền gốc** (`https://tenmien.vn/`) hoặc **thư mục con** (`https://tenmien.vn/chie/`). Không cần sửa mã hay ghi tên miền vào đâu cả.

- Cài ở tên miền gốc: giải nén vào `public_html/`.
- Cài ở thư mục con: tạo `public_html/chie/` rồi giải nén vào đó.

> Nếu thư mục đích đã có website khác, hãy sao lưu trước. Không giải nén đè lên một bản CHIE cũ — xem mục 8.

## 3. Tải lên và giải nén

1. cPanel → **File Manager** → mở thư mục đích.
2. **Upload** tệp `chie-next-v1.1.0.zip`.
3. Chuột phải tệp ZIP → **Extract**. Sau khi giải nén phải thấy trực tiếp các mục `index.php`, `.htaccess`, `app/`, `assets/`, `vendor/`… trong thư mục đích (không bị lồng thêm một thư mục con). Nếu bị lồng, chọn tất cả bên trong và **Move** ra ngoài.
4. Bật **Settings → Show Hidden Files** để thấy `.htaccess` và `.env.example`.
5. Xóa tệp ZIP sau khi giải nén.

Quyền thư mục: cPanel thường để đúng sẵn (thư mục 755, tệp 644). Hai thư mục `storage/` và `bootstrap/cache/` cần ghi được; thư mục cài đặt cần ghi được để tạo tệp `.env` lần đầu.

## 4. Tạo cơ sở dữ liệu

cPanel → **MySQL® Databases**:

1. **Create New Database**, ví dụ `tenTK_chie`.
2. **Add New User**, ví dụ `tenTK_chieuser`, đặt mật khẩu mạnh (dùng nút Password Generator) và lưu lại ở nơi an toàn.
3. **Add User To Database** → chọn **ALL PRIVILEGES**.

CSDL phải **trống**. Trình cài đặt từ chối CSDL đã có bảng `users` để tránh ghi đè dữ liệu cũ.

## 5. Chạy trình cài đặt

1. Mở trình duyệt vào địa chỉ website (ví dụ `https://tenmien.vn/chie/`). Lần đầu, hệ thống tự chuyển tới `/install` và tự tạo tệp `.env` với khóa mã hóa ngẫu nhiên.
2. Trang cài đặt kiểm tra phiên bản PHP, tiện ích mở rộng và quyền ghi. Mục nào đỏ thì sửa trong cPanel (**Select PHP Version** / **MultiPHP Manager**) rồi tải lại trang.
3. Lấy **mã cài đặt**: trong File Manager mở tệp `storage/app/install-token.txt` và chép dãy ký tự. Chỉ người có quyền vào hosting mới đọc được tệp này — đó là cách ngăn người lạ cài đè.
4. Điền biểu mẫu:
   - Mã cài đặt.
   - Máy chủ CSDL (thường là `localhost`), cổng `3306`, tên CSDL, người dùng, mật khẩu đã tạo ở bước 4.
   - Tên website.
   - **Tài khoản Admin đầu tiên**: tên, email, mật khẩu (ít nhất 10 ký tự). Hệ thống **không có tài khoản/mật khẩu mặc định**; đây là Admin duy nhất được tạo tự động. Không có cách tự đăng ký làm Admin.
   - Gói học liệu muốn nhập (mặc định chọn cả hai gói, xem `BAO_CAO_NHAP_DU_LIEU.md`).
   - SMTP (không bắt buộc). Nếu điền, hệ thống bật xác minh email khi đăng ký và gửi được thư quên mật khẩu.
5. Bấm **Cài đặt**. Quá trình tạo bảng, dữ liệu nền, nhập học liệu và tạo Admin mất khoảng 10–60 giây.
6. Khi xong, trình cài đặt **tự khóa** (tạo `storage/installed.lock`, xóa `install-token.txt`); mọi truy cập `/install` sau đó trả về 404.

## 6. Việc cần làm ngay sau khi cài

1. Đăng nhập bằng tài khoản Admin vừa tạo.
2. **Admin → Học liệu → Cây chương trình**: các chủ điểm đánh dấu “cần rà soát” (tên giống mục lục sách giáo khoa, gói chuyên đề mới biên soạn) đang ở trạng thái *Nháp/Chờ duyệt* — học sinh chưa thấy. Giáo viên/Admin xem, sửa rồi chọn **Xuất bản**.
3. **Admin → Học liệu → Câu hỏi**: lọc trạng thái *Chờ duyệt* để duyệt các câu bị gắn cờ khi nhập.
4. **Admin → Hệ thống**: xem lại cài đặt (tuổi tối thiểu tự đăng ký, cho phép giáo viên đăng ký, tốc độ đọc mặc định, giới hạn thời gian chơi…).
5. **Admin → Người dùng**: duyệt tài khoản giáo viên đăng ký mới. Giáo viên chưa được duyệt không vào được khu vực lớp học.
6. Sao lưu CSDL định kỳ: cPanel → **Backup** hoặc **phpMyAdmin → Export**.

## 7. Email (SMTP)

Nếu lúc cài chưa điền SMTP, có thể sửa tệp `.env` (File Manager → Edit):

```
MAIL_MAILER=smtp
MAIL_HOST=mail.tenmien.vn
MAIL_PORT=465
MAIL_SCHEME=smtps
MAIL_USERNAME=no-reply@tenmien.vn
MAIL_PASSWORD=(mật khẩu hộp thư)
MAIL_FROM_ADDRESS=no-reply@tenmien.vn
```

Sau đó vào **Admin → Hệ thống** bật “Bắt buộc xác minh email” nếu muốn. Khi chưa có SMTP, thư không được gửi đi (chỉ ghi vào nhật ký), vì vậy quên mật khẩu cần Admin đặt lại thủ công trong trang người dùng.

## 8. Cập nhật lên bản mới

**Từ bản 1.1.0 trở đi — cập nhật một chạm:**

1. Sao lưu CSDL (cPanel → Backup hoặc phpMyAdmin → Export).
2. Admin → Hệ thống → **Cập nhật phiên bản** → chọn gói `.zip` → nhập mật khẩu → **Kiểm tra gói**. Hệ thống kiểm tra mã băm từng tệp và từ chối gói bị sửa, gói cũ hơn, gói chứa đường dẫn nguy hiểm.
3. Bấm **Áp dụng cập nhật** (nhập lại mật khẩu). Tệp cũ được sao lưu vào `storage/app/backups/…`, CSDL được cập nhật tự động. Nếu lỗi giữa chừng, hệ thống tự khôi phục tệp cũ.
4. Có nút **Hoàn tác** cho lần cập nhật gần nhất (chỉ khôi phục tệp, không khôi phục CSDL).

Cần tiện ích PHP **zip** (cPanel → Select PHP Version → Extensions). Hosting thường giới hạn dung lượng tải lên (2–64 MB): dùng **gói cập nhật rút gọn** (chỉ chứa tệp thay đổi), hoặc tải gói đầy đủ vào thư mục `storage/app/updates/` bằng File Manager rồi chọn gói đó trong trang Cập nhật.

**Từ 1.0.0 lên 1.1.0 (một lần, thủ công):** sao lưu, giải nén gói 1.1.0 vào thư mục tạm, chép đè mọi thứ **trừ** `.env` và `storage/`, rồi đăng nhập Admin → Hệ thống → **Cập nhật phiên bản**: trang sẽ báo “CSDL cần cập nhật”, nhập mật khẩu và bấm **Cập nhật CSDL ngay** (không cần Terminal). Nếu có Terminal cũng có thể chạy `php artisan migrate --force`.

## 9. Nhập thêm học liệu

Đặt tệp gói (`.json`, định dạng `chie-content`) vào `database/content/`, rồi vào **Admin → Nhập dữ liệu**. Có chế độ **Chạy thử** để xem báo cáo trước khi ghi. Nhập lại cùng một gói không tạo bản trùng (idempotent). Nội dung bị gắn cờ nghi ngờ được để *Chờ duyệt*, không xuất bản.

Nếu có Terminal: `php artisan chie:import ten_goi.json --dry` rồi `php artisan chie:import ten_goi.json`.

## 10. Khắc phục sự cố

| Hiện tượng | Cách xử lý |
|---|---|
| Trang trắng hoặc lỗi 500 | Xem `storage/logs/chie-YYYY-MM-DD.log`. Kiểm tra phiên bản PHP ≥ 8.2 và quyền ghi `storage/` |
| Lỗi 404 ở mọi trang trừ trang chủ | `mod_rewrite` chưa bật hoặc thiếu `.htaccess` (bật Show Hidden Files, kiểm tra tệp tồn tại) |
| “Không kết nối được CSDL” | Tên CSDL/người dùng trên cPanel luôn có tiền tố tài khoản (`tenTK_...`). Kiểm tra đã **Add User To Database** |
| Mất mã cài đặt | Xóa `storage/app/install-token.txt` rồi tải lại `/install` để tạo mã mới (chỉ khi chưa cài xong) |
| Cần cài lại từ đầu | Xóa `storage/installed.lock`, `.env` và làm trống CSDL. **Toàn bộ dữ liệu sẽ mất** |
| Không nghe được âm thanh | Giọng đọc dùng bộ đọc của trình duyệt/thiết bị. Trên Android cài “Speech Services by Google”, trên Windows thêm giọng English trong Settings → Time & Language → Speech |
| Không ghi âm được | Cần HTTPS và cho phép micro trong trình duyệt |
| Game 3D chậm hoặc nóng máy | Ở màn hình bắt đầu game chọn “3D nhẹ” hoặc “2D (tiết kiệm pin)”; lựa chọn lưu trên máy đó |
| Không “cài lên màn hình chính” / ôn ngoại tuyến được | Cần HTTPS. Trên điện thoại mở menu trình duyệt → “Thêm vào màn hình chính”. Gói ôn ngoại tuyến tải ở Học tập → Ôn tập |

## 11. Nginx (không phải cPanel)

Trỏ `root` vào thư mục cài và thêm:

```
location / { try_files $uri $uri/ /index.php?$query_string; }
location ~ ^/(app|bootstrap|config|database|lang|modules|resources|routes|storage|tests|tools|vendor|docs)/ { deny all; }
location ~ /\. { deny all; }
location ~ \.(md|sql|log|lock|zip)$ { deny all; }
location ~ \.php$ { include fastcgi_params; fastcgi_pass unix:/run/php/php8.3-fpm.sock; fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name; }
```

Cấu hình Nginx này chưa được kiểm thử trên máy chủ thật.
