# Chơi khách Thế giới & Nông trại · 1.4.8

Trang Game mở hai ô Thị trấn Mầm Xanh và Thế giới phiêu lưu cho khách chưa đăng nhập.

- Thế giới: chọn màn đang được bật, làm câu hỏi đã duyệt theo lớp đang chọn. Trình chấm bài khách chấm trên máy chủ bằng gói đề mã hóa; không tạo attempt hoặc world_progress. Kết quả và sao chỉ giữ trong trang bản đồ đang mở. Khách được chọn màn để thử; tài khoản đăng nhập vẫn theo quy tắc mở khóa hiện có.
- Nông trại 3D: cùng game Zoo Garden, bộ nhớ localStorage/sessionStorage trong iframe được thay bằng bộ nhớ RAM riêng trước khi game nạp bản lưu. Không đọc, xóa hoặc ghi bản lưu tài khoản trên máy dùng chung; không đồng bộ MySQL, đổi Xu, vé online hoặc phát thưởng XP/Xu.
- Cấp và tài nguyên trong game có thể thay đổi trong lượt chơi nhưng tải lại/thoát sẽ bắt đầu lại. Không chuyển tiến độ khách sang tài khoản khi đăng nhập.
- Có Nông trại nhẹ: gieo, tưới, thu hoạch cà rốt và cho gà ăn/lấy trứng, cũng chỉ giữ trạng thái trong RAM. Tự dùng bản này nếu Nông trại 3D bị tắt; có liên kết bản cổ điển ở trang 3D.
- Cửa hàng tài khoản, Phòng của tôi, giao dịch, thử thách gia đình và bảng xếp hạng vẫn yêu cầu tài khoản như trước.

Các đường dẫn chơi khách:

- `/chie/choi-thu/the-gioi`
- `/chie/choi-thu/nong-trai`
- `/chie/choi-thu/nong-trai/co-dien`

Admin có tính năng phân quyền riêng “Chơi thử Thế giới & Nông trại”. Các API lưu Nông trại, đổi Xu và ghi tiến độ Thế giới của tài khoản vẫn giữ xác thực; không mở quyền ghi của khách vào các API đó.

Không thêm migration mới. Cập nhật ZIP 1.4.8 tại trang quản trị như thường lệ. Bản đầy đủ chứa cả những sửa đổi trước; hoàn tất migration cũ còn thiếu nếu hosting có thông báo.

Kiểm thử:

- Mở/chấm xong lượt Thế giới, dựng trang 3D/bản nhẹ, không có INSERT/UPDATE/DELETE trong CSDL, không đổi số dòng tài khoản/nông trại/ví/tiến độ/thống kê.
- Trình duyệt thật: vào màn Thế giới, hiển thị kết quả tạm và tải lại mất sao; vào Nông trại 3D, bấm bắt đầu thành công; cấp thử không còn sau tải lại; bản lưu tài khoản mẫu ở trang cha giữ nguyên.
- Không có yêu cầu tới API lưu tài khoản trong lượt chơi, không có lỗi JavaScript; kiểm tra giao diện desktop và điện thoại 390px.
- Kiểm thử bộ nhớ tạm độc lập; TypeScript và dựng bản Zoo Garden đạt. Hồi quy chế độ khách học và 4 game vẫn không ghi dữ liệu.
- Rà 1.205 yêu cầu GET qua 5 vai trò không gặp lỗi 500.
