# CHIE NEXT 1.3.0 — Nông trại 3D Zoo Garden + Module hóa

Bản này ghép game **Zoo Garden** (gói `cute_game-main`, TypeScript + three.js r180) vào mục **Nông trại** của CHIE NEXT, dùng chung tài khoản học sinh, lưu tiến độ vào MySQL, và tách game/học liệu thành module độc lập.

## Học sinh thấy gì

> **Từ 1.3.1, mọi tính năng trò chơi mặc định bị ẩn** để tập trung học. Bật lại: **Admin → Game Studio → Hiện trò chơi**. Link trực tiếp `/nong-trai` vẫn vào được để thử.

- **Game đấu trường → Nông trại** (`/nong-trai`): khung chơi Zoo Garden 3D, nút **⛶ Toàn màn hình** (Android/PC/iPad dùng Fullscreen API; iPhone dùng chế độ phủ kín màn hình bằng CSS).
- **Thanh CHIE** dọc bên trái trong game (trên điện thoại thu gọn thành nút 🎓 ▸):
  - `← CHIE` lưu rồi quay về; số **Xu** và **⏳ phút chơi còn lại**.
  - `🔄 Đổi ϟ`: đổi Xu học tập sang Năng lượng ϟ (mặc định 1 Xu = 10 ϟ, tối đa 200 Xu/ngày).
  - `🎓 Đố từ vựng`: 1 câu Tiếng Anh (ưu tiên **Sổ lỗi**). Đúng → cây đang lớn & vật nuôi rút ngắn 50% thời gian chờ, +25 ϟ, +5 XP, +2 Xu.
  - `⚡ Bùa tri thức`: 3 câu. Đúng hết → +25% sát thương, +20% may mắn trong 15 phút, +60 ϟ, +15 XP, +8 Xu.
  - Trong **Bếp**: nút "🍳 Đầu bếp Tiếng Anh" (3 câu → hồi đầy máu + hồi máu dần, +40 ϟ, XP/Xu). Ở **Người gác hầm ngục**: nút "📜 Thử thách" (3 câu → +15 phòng thủ, +15% sát thương 15 phút, +60 ϟ).
  - Chạm một cây rồi bấm "🎓 Đố từ vựng" trong 90 giây → ưu tiên từ vựng gắn với cây đó.
- **Từ điển song ngữ**: chạm vào cây/cá/vật phẩm có mã trong game → hiện tên Tiếng Anh, tên Việt, nút 🔊 nghe và 🐢 nghe chậm (Web Speech, tốc độ theo cài đặt TTS của CHIE), kèm từ vựng Admin gắn thêm.
- **Playtime Gate**: 30 phút miễn phí/ngày; học xong 1 bài/ôn tập/đề/bài giao đạt điểm chuẩn (`learn.pass_score`) +20 phút; giải 5 câu đạt 80% +15 phút; tối đa 90 phút/ngày. Chỉ tính khi tab đang mở, đã bấm Chơi và có thao tác trong 2 phút. Hết giờ → hộp thoại khóa màn chơi.
- Bảng tin trong game nhắc bài tập giáo viên giao chưa nộp và số mục Sổ lỗi đến hạn.
- Nông trại cũ (bản 1.2) vẫn ở **`/nong-trai/co-dien`** (nút "Bản cổ điển"); Admin tắt Zoo Garden thì `/nong-trai` tự dùng bản cổ điển.

## Phụ huynh / giáo viên

Báo cáo học sinh có thêm thẻ **"Học Tiếng Anh & giải trí ở Nông trại 3D (7 ngày)"**: phút chơi hôm nay/7 ngày, số câu đố đúng/tổng (%), số mục Sổ lỗi đã sửa, Xu đã đổi sang ϟ (chỉ phụ huynh thấy).

## Admin → 3 · Game & cơ chế → Quản lý Zoo Garden 3D

7 tab: Cài đặt chung · Giờ chơi & thưởng Tiếng Anh · Cây trồng (27) · Vật nuôi (7) + dịch vụ (5) + Cá (20) · Vật phẩm (210, có tìm kiếm/lọc nhóm) · Hành tinh (9) · Module.
- Ô để trống = thông số gốc (hiện mờ). Lưu → ghi bảng `zoo_catalog_overrides`, áp dụng khi học sinh mở lại nông trại.
- "Bật" bỏ chọn: cây/thú/hành tinh bị khóa (cấp mở 999), vật phẩm bị gỡ khỏi cửa hàng/xưởng.
- Hỗ trợ: xóa bản lưu Zoo Garden của 1 học sinh khi bị hỏng.
- KPI hôm nay: số em có nông trại, tổng giờ chơi, câu đố đúng, Sổ lỗi đã sửa, Xu đã đổi.
- Sổ cái Xu có 2 loại mới: `zoo_exchange`, `zoo_quiz`.

## Game Studio & Cập nhật (mới)

- **Game Studio** đọc ô cấu hình từ `schema` trong `modules/games/game-X/module.json` và có nút **Khôi phục mặc định của module**. Trang chơi game 1–4 nạp JS theo `entry_2d` / `entry_3d` của module.
- **Cập nhật phiên bản** nhận cả gói module lẻ. Khi cập nhật cả web, module đã cập nhật riêng lên phiên bản mới hơn được giữ nguyên.
- Dịch vụ trang trại: Admin chỉnh được giá ϟ (xây chuồng, mở rộng chuồng, robot, phụ việc chuồng) ở tab Vật nuôi & Cá.

## Học liệu mới

- `database/content/chie_supplement_v1_3.json`: Lớp 2 (8 chủ đề, 64 từ, 64 câu, 8 bài) + ôn tập Lớp 7, 9, 12 (mỗi lớp 24 câu, 3 bài). Mọi mục **Chờ duyệt**.
- `database/content/chie_exam_blueprints_v1_3.json`: 23 khung đề theo từng lớp (cũng nằm trong `modules/grades/grade-XX/exam_blueprints.json`).
- Nâng cấp từ 1.2: migration `2026_10_18_000008` tự nhập 2 gói trên.

## Module (`modules/`)

| Thư mục | Nội dung |
|---|---|
| `modules/games/game-1-word-runner` … `game-4-reading-escape` | Bản sao JS 2D/3D + `module.json` (khóa `deploy` chỉ nơi chạy thật trong `assets/js/games*`) + `README_AI.md` |
| `modules/games/game-5-zoo-garden` | `catalog.default.json`, mã nguồn game đã tích hợp + máy chủ online gốc (`source/`, `source/server/`), `README_AI.md` |
| `modules/grades/grade-01` … `grade-12` | Học liệu tách theo lớp từ `database/content/*.json`: `curriculum.json`, `questions.json`, `lexicon.json`, `exam_blueprints.json` |
| `modules/MODULE_SDK_CONTRACT.md` | Hợp đồng giao tiếp, tự đính kèm khi xuất gói |

Tab **Module**: 📥 tải .zip của riêng 1 module (gửi AI sửa), 📤 tải lên gói đã sửa (chặn `.php/.sh/.py/.htaccess`, đường dẫn `..`), 🔄 đồng bộ học liệu 1 lớp vào CSDL (idempotent). `modules/` bị chặn truy cập web bằng `.htaccess`.

## Kỹ thuật

- Trang `/nong-trai/zoo` là trang độc lập (iframe) để CSS/JS của game không đụng giao diện CHIE. Dữ liệu khởi tạo nằm trong `<script type="application/json" id="chie-zoo-boot">` (CSP của CHIE chặn script nội tuyến). Trang này có CSP riêng cho phép `'wasm-unsafe-eval'` (bộ giải nén mô hình Meshopt) và `worker-src blob:`.
- Bản build ở `assets/zoo-garden/` (56 `.glb`, 330 `.webp`, nhạc nền), tệp entry đọc từ `assets/zoo-garden/chie-manifest.json`. Build với `--base ./` nên chạy được ở tên miền gốc lẫn thư mục con.
- Bản lưu game: `farms.zoo_save` (JSON), `zoo_revision`, `zoo_updated_at`. Game vẫn tự lưu vào localStorage như bản gốc; tích hợp đẩy bản lưu lên máy chủ khi có thay đổi (tối đa 1 lần/15 giây), khi rời trang và khi ẩn tab. Mở trên máy khác → lấy bản MySQL. Máy dùng chung → dữ liệu game của học sinh trước bị xóa khỏi trình duyệt khi học sinh khác mở.
- Năng lượng ϟ mua bằng Xu / được thưởng nằm ở `farms.zoo_pending_energy` cho tới khi game xác nhận đã nhận → không mất khi rớt mạng hoặc chưa bấm Chơi.
- Câu đố: token mã hóa (không lộ đáp án), dùng 1 lần, hết hạn 20 phút; sai → vào Sổ lỗi; đúng mục Sổ lỗi → tăng bậc SRS theo `learn.srs_intervals_days`. Thưởng XP/Xu đi qua trần ngày `reward.daily_*_cap` và giới hạn 20 lượt thưởng/ngày.
- Phút chơi: máy chủ chỉ cộng tối đa 120 giây mỗi lần báo và không vượt thời gian thực giữa hai lần báo.

## Nâng cấp từ 1.2.0

1. Sao lưu tệp + CSDL. Thử trên staging trước.
2. Admin → Cập nhật phiên bản → tải gói ZIP 1.3.0 (đã có `chie-release.json` SHA-256), hoặc chép đè thủ công rồi chạy `php artisan migrate --force` (migration `2026_10_18_000007_add_zoo_garden_tables.php`, chỉ thêm cột/bảng).
3. Hosting cần PHP `zip` (để xuất/nhập module) — đã là yêu cầu của bản trước.
4. Nếu dùng LiteSpeed/Apache: `.htaccess` gốc đã thêm MIME `.glb`, `.webp`, `.mp3`.

Tình trạng các phần còn thiếu: `docs/CHUA_LAM_DUOC_ZOO_GARDEN.md`. Việc cần Node.js (Online, build lại game): `docs/NODE_ONLINE_ZOO_GARDEN.md`. Cài lên hosting: `docs/HUONG_DAN_CAI_LEN_HOSTING.md`.
