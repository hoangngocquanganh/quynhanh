# Bảng trạng thái chức năng — CHIE NEXT 1.1.0

Ký hiệu cột **Kiểm chứng**:
- **E2E** — có kịch bản kiểm thử tự động (HTTP hoặc trình duyệt thật) chạy đạt, xem `KET_QUA_KIEM_THU.md`.
- **Trang** — trang hiển thị không lỗi (crawl + ảnh chụp 3 khổ màn hình), nhưng thao tác chưa có kịch bản riêng.
- **Chưa** — đã viết mã nhưng chưa kiểm chứng tự động.

## 1. Học tập (học sinh và khách)

| Chức năng | Trạng thái | Kiểm chứng |
|---|---|---|
| Khách vào lần đầu được hỏi “Bạn đang học lớp mấy?”, lựa chọn được ghi nhớ | Có | E2E |
| Học thử cho khách (bài công khai, không lưu điểm, không nhận Xu) | Có | E2E (trình duyệt) |
| Đăng ký học sinh bắt buộc chọn lớp; dưới 16 tuổi (chỉnh được) phải do phụ huynh tạo | Có | E2E |
| Tiến độ tách riêng theo từng lớp; đổi lớp ở “Lớp học của tôi” | Có | E2E |
| Lộ trình theo chủ điểm → bài, trạng thái Hoàn thành/Thành thạo/Đang học/Khóa | Có | Trang |
| Chu trình bài: Làm quen → Nghe mẫu → Luyện có hướng dẫn → Tự làm → Ôn lại | Có | E2E (trình duyệt) |
| Chấm trên máy chủ; đáp án không gửi xuống trước khi trả lời; trộn phương án | Có | E2E |
| Giải thích tiếng Việt vì sao sai + mẹo “lỗi người Việt” (âm cuối, cụm phụ âm, trọng âm, -s/-ed, mạo từ, giới từ, trật tự từ, thì, hòa hợp chủ–vị, dịch từng chữ…) | Có | E2E |
| Sổ lỗi + ôn tập theo lịch 1 – 3 – 7 ngày | Có | E2E |
| Luyện theo kỹ năng, theo chủ điểm yếu | Có | E2E |
| Từ vựng: thẻ từ, IPA, ví dụ, nghe thường/chậm | Có | Trang |
| Phát âm: bảng 44 âm IPA kèm hướng dẫn khẩu hình bằng tiếng Việt, trò nghe phân biệt cặp tối thiểu | Có | Trang |
| Tự ghi âm và nghe lại để so với mẫu (ghi âm chỉ ở trên máy, không gửi lên, **không chấm điểm phát âm**) | Có | Chưa (cần micro thật) |
| Giọng đọc: mặc định 0,75×, chậm 0,65×, chọn 0,65/0,75/0,9/1; đọc theo cụm; không chồng tiếng; dừng khi rời trang | Có | Chưa (máy kiểm thử không có giọng đọc) |
| Đề luyện: 8 cấu trúc (Daily 5, 15 phút, 20 câu, giữa kỳ, cuối kỳ, mô phỏng vào 10, tốt nghiệp…); giờ do máy chủ tính; tự nộp khi hết giờ | Có | E2E |
| Không đủ câu đã duyệt → báo rõ, không lấy câu của lớp khác | Có | E2E |
| Trang kết quả 100 điểm, xem lại từng câu | Có | E2E |
| Link chia sẻ kết quả đề + thu hồi | Có | E2E |
| Báo lỗi câu hỏi (học sinh) → hàng chờ của Admin | Có | E2E |
| Bài được giao, nộp bài viết/nói tự đánh giá | Có | E2E |
| Nhắc nghỉ mắt sau 20 phút (tiểu học) / 30 phút (THCS–THPT) dùng liên tục | Có | Chưa |
| **Ôn khi mất mạng**: tải gói thẻ từ về máy; mất mạng thì web tự mở trang ôn thẻ từ (không tính điểm, không cộng Xu); cài lên màn hình chính như ứng dụng | Có (1.1) | E2E (trình duyệt, tắt máy chủ) |
| Cỡ chữ, giao diện tối, giảm chuyển động, tốc độ đọc | Có | Trang |

## 2. Game đấu trường và kinh tế Xu

| Chức năng | Trạng thái | Kiểm chứng |
|---|---|---|
| **4 game 3D**: Word Runner (chạy làn trên đường làng), Grammar Tower (bản đồ thủ thành, tháp mọc lên bắn quái), Voice Island (đảo giữa biển, chạm bong bóng nổi), Reading Escape (thư viện 3 phòng, sách phát sáng, cửa mở) — mỗi câu chấm trên máy chủ | Có (1.1) | E2E (API cả 4; trình duyệt cả 4 bản 3D) |
| Đồ họa 3D tối ưu điện thoại: tự chọn mức cao/vừa/nhẹ theo máy, tự hạ độ phân giải khi chậm, ngừng vẽ khi ẩn tab, hình khối low-poly không tải ảnh ngoài; người chơi chọn được “3D nhẹ” hoặc “2D tiết kiệm pin”; máy không có WebGL tự dùng 2D | Có (1.1) | E2E (trình duyệt, ~60 khung hình/giây trên máy thử) |
| Vương Quốc CHIE: 10 màn mở khóa tuần tự, bản đồ 3D các hòn đảo (vuốt ngang, chạm đảo để vào màn) | Có | E2E |
| Thưởng XP/Xu theo số câu đúng × độ khó × tốc độ × chuỗi; chơi lại trong ngày giảm 100% → 50% → 10%; trần ngày XP 1.000 / Xu 500 | Có | E2E |
| Một ví, sổ cái Xu có khóa chống trùng; bấm 2 lần không trừ/cộng 2 lần | Có | E2E |
| Bảng xếp hạng không lộ thông tin cá nhân | Có | E2E |
| CHIE Farm **3D**: ruộng, chuồng, kho, tường theo cấp, khiên dạng vòm; gieo hạt = học từ của cây, tưới/bắt sâu = trả lời câu ôn, thu hoạch theo giờ máy chủ; vẫn có dạng danh sách cho bàn phím/trình đọc màn hình | Có (1.1) | E2E |
| **Vật nuôi**: gà (trứng), cừu (len), bò (sữa); cho ăn = trả lời đúng câu từ vựng về con vật; sản phẩm sau thời gian chờ để bán hoặc nấu ăn | Có (1.1) | E2E |
| Kho Ngoài / Kho Trong / Kho Lạnh, bán nông sản, mua khiên, nâng tường, mở ô đất | Có | E2E |
| Nhà bếp tiếng Anh (đọc công thức, chọn nguyên liệu theo tên tiếng Anh), 8 món gồm món dùng trứng/sữa | Có | E2E |
| Cướp trại: phí đốt, ≥70% đúng mới thắng, lấy ≤8%/món, trần thiệt hại 20%/ngày, mỗi cặp 1 lần/ngày 3 lần/tuần, không cướp người trong gia đình, khiên chặn | Có | E2E (thắng, lấy ≤8%, giới hạn cặp) |
| Cửa hàng đồ trang trí (chỉ thẩm mỹ), túi đồ, bán lại cho hệ thống 50% | Có | E2E |
| Hòm quà: tỉ lệ công khai 85 / 12 / 2,9 / 0,1%, bảo đảm lượt 200, 10 lượt/ngày, ngôn ngữ dễ hiểu cho tiểu học, ghi rõ “không quy đổi ra tiền” | Có | E2E |
| Phòng của tôi (lưới 8×6), điểm đẹp | Có | E2E (trình duyệt) |
| Đổi đồ: chỉ bạn cùng lớp/gia đình, 1–1 cùng bậc, 3 lần/tuần/cặp, tài khoản < 7 ngày chỉ đổi đồ Thường, đồ Tuyển chọn khóa 30 ngày và chỉ đổi 1 lần | Có | E2E (đổi thành công, chặn người ngoài) |
| **Đấu 1–1** gần thời gian thực: đấu nhanh ghép ngẫu nhiên cùng lớp học liệu, thách bạn cùng lớp/người nhà, hoặc đấu với “Quái Nhỏ” (máy); cùng một bộ câu, máy chủ chấm, thắng nhờ đúng nhiều hơn rồi nhanh hơn; sân đấu 3D; không trò chuyện; thưởng thắng nhỏ chỉ khi đấu người thật | Có (1.1) | E2E (HTTP + trình duyệt) |
| **Đội trong lớp** (thay cho “bang hội”, an toàn cho trẻ): giáo viên chia đội, học sinh tự chọn đội; mục tiêu điểm học mỗi tuần, bảng đội; không trò chuyện | Có (1.1) | E2E |

## 3. Phụ huynh

| Chức năng | Trạng thái | Kiểm chứng |
|---|---|---|
| Liên kết với con **chỉ** qua mã do con tạo (dùng 1 lần, hết hạn 48 giờ), không liên kết bằng email/tên | Có | E2E (đoán mã sai, mã dùng lại bị chặn) |
| Tạo tài khoản cho con dưới 16 tuổi (đăng nhập bằng tên đăng nhập) | Có | E2E |
| Tổng quan, tiến độ từng con, bài tập & nhận xét giáo viên (khi giáo viên cho phép chia sẻ) | Có | E2E |
| Phụ huynh tự học (chọn lớp tự học riêng) | Có | Trang |
| Đặt lại mật khẩu cho tài khoản con do mình tạo; hủy liên kết | Có | E2E |
| **Thử thách gia đình** (chơi chung phụ huynh–con): bố mẹ tạo bộ câu theo lớp của con kèm lời nhắn, cả hai cùng làm, so điểm, xem lại bài của nhau khi cả hai đã xong; con nhận thưởng nhỏ | Có (1.1) | E2E |
| Không xem được học sinh khác, không làm bài thay | Có | E2E |

## 4. Giáo viên

| Chức năng | Trạng thái | Kiểm chứng |
|---|---|---|
| Đăng ký giáo viên ở trạng thái chờ duyệt, không có quyền gì cho tới khi Admin duyệt | Có | E2E |
| Tạo lớp, mã mời có hạn dùng / số lượt / thu hồi, chế độ tự vào hoặc cần duyệt | Có | E2E |
| Chỉ xem học sinh trong lớp mình được phân công | Có | E2E |
| Giao bài: bài học, luyện kỹ năng, đề, bài viết, bài nói; cho cả lớp hoặc từng em; hạn nộp, điểm tối thiểu | Có | E2E (bài viết, bài học, chặn bài sai lớp) |
| Chấm & nhận xét, chọn chia sẻ với phụ huynh | Có | E2E |
| Báo cáo lớp | Có | Trang |
| Soạn câu hỏi (khi Admin bật) → vào hàng chờ duyệt | Có | Trang |

## 5. Quản trị

| Chức năng | Trạng thái | Kiểm chứng |
|---|---|---|
| Tổng quan số liệu thật từ CSDL | Có | Trang |
| Người dùng: tìm, lọc, phân trang, thao tác hàng loạt (duyệt GV, khóa/mở), tạo tài khoản, đặt lại mật khẩu, điều chỉnh Xu có lý do | Có | E2E |
| Khóa tài khoản → bị đăng xuất ngay ở lần truy cập kế tiếp | Có | E2E |
| Lớp học, phân công/thu hồi giáo viên, chuyển lớp; liên kết gia đình | Có | Trang |
| Cây chương trình, bài học, ngân hàng câu hỏi có phiên bản, duyệt hàng loạt theo bộ lọc, nhập/xuất CSV | Có | E2E |
| Kho từ vựng, cấu trúc đề, link chia sẻ | Có | Trang |
| Nhập gói học liệu có chạy thử, báo cáo, idempotent | Có | E2E |
| Báo lỗi câu hỏi, tải lên tệp âm thanh/ảnh (chặn tệp không phải âm thanh/ảnh) | Có | E2E |
| Cài đặt hệ thống, điều khoản có phiên bản (bắt đồng ý lại), bộ lọc tên, cờ gian lận (trả lời quá nhanh) | Có | E2E (điều khoản) |
| Cấu hình game có phiên bản và hoàn tác; kinh tế (giá, tỉ lệ hòm quà phải tổng 100%, nông trại) | Có | Trang |
| Nhật ký kiểm toán (đăng nhập của Admin/giáo viên, đăng nhập sai, thay đổi quyền, Xu, liên kết, chấm bài…) | Có | E2E |

## 6. Cài đặt & vận hành

| Chức năng | Trạng thái | Kiểm chứng |
|---|---|---|
| Chạy ở tên miền gốc hoặc thư mục con, không ghi cứng tên miền | Có | E2E (cả `/chie` và gốc) |
| Trình cài đặt bảo vệ bằng mã trong tệp trên hosting, tạo Admin đầu tiên, tự khóa | Có | E2E |
| Không cần Node/npm/Composer trên hosting | Có | E2E (gói phát hành chạy trực tiếp) |
| Chặn tải tệp nội bộ (.env, vendor, storage, mã nguồn) | Có | E2E (Apache) |
| **Cập nhật một chạm** trong Admin: kiểm tra mã băm từng tệp, chặn đường dẫn nguy hiểm và tệp lạ, không đụng `.env`/`storage`, sao lưu tệp cũ, tự khôi phục khi lỗi, nút Hoàn tác; nhận gói rút gọn (nhỏ, vượt giới hạn tải lên) hoặc gói đặt sẵn qua File Manager | Có (1.1) | E2E (lên 1.1.1 rồi hoàn tác) |

## 7. Giới hạn còn lại (trung thực)

- **Chưa thử trên cPanel/LiteSpeed thật**: mọi kiểm thử chạy trên Apache 2.4 + PHP 8.3 + MariaDB 10.11 cục bộ.
- **Đấu 1–1 dùng hỏi trạng thái mỗi ~1,5 giây**, không dùng WebSocket (hosting chia sẻ thường không hỗ trợ) — điểm đối thủ cập nhật chậm tối đa khoảng 1,5 giây.
- **“Bang hội” làm thành “Đội trong lớp”** do giáo viên quản lý, không có kênh trò chuyện, để an toàn cho học sinh nhỏ.
- **“Phòng chung phụ huynh–con” làm thành “Thử thách gia đình”** (làm cùng bộ câu, so điểm), không phải phòng trò chuyện trực tiếp.
- **Ngoại tuyến** chỉ ôn thẻ từ đã tải; không làm bài có điểm khi mất mạng (điểm và Xu luôn do máy chủ chấm).
- **Cập nhật một chạm** không hoàn tác thay đổi CSDL — cần sao lưu CSDL trước; tính năng này có từ 1.1.0 nên bản 1.0.0 phải cập nhật thủ công một lần.
- Game 3D: đồ họa tự dựng bằng hình khối low-poly (không dùng mô hình/ảnh tải ngoài) để nhẹ; chưa có nhạc nền. Đã đo ~60 khung hình/giây trên máy thử dùng đồ họa phần mềm; **chưa đo trên điện thoại thật**.
- **Không** chấm điểm phát âm bằng máy (theo yêu cầu: không đưa điểm phát âm giả); chỉ tự ghi âm – nghe lại – tự đánh giá.
- Giọng đọc dùng bộ đọc có sẵn của trình duyệt/thiết bị nên chất lượng khác nhau theo máy.
- Email (xác minh, quên mật khẩu) cần cấu hình SMTP.
- Học liệu lớp 1–2, 7, 9, 12 còn ít; gói chuyên đề mới đang chờ giáo viên duyệt (xem `BAO_CAO_NHAP_DU_LIEU.md`).
- Không nhập tài khoản người dùng từ bản cũ.
- Bộ kiểm thử là kịch bản Python + Playwright (cần CSDL thử), chưa có bộ PHPUnit.

## 8. Cách giải quyết các chỗ mâu thuẫn giữa tài liệu

| Mâu thuẫn | Cách xử lý | Lý do |
|---|---|---|
| V9.1 đề xuất 5 tab cho học sinh; yêu cầu mới ghi 4 tab | 4 tab: Học tập · Game đấu trường · Luyện đề · Hồ sơ | Yêu cầu trong tệp đính kèm được ưu tiên |
| Công thức XP: theo lượt hay theo câu | Theo số câu đúng (×5) nhân hệ số độ khó/tốc độ/chuỗi | Gắn thưởng với học thật, khó “cày” |
| Phụ huynh có được tự học không | Có, với lớp tự học riêng, không ảnh hưởng tiến độ của con | Đáp ứng nhu cầu phụ huynh học cùng con |
| Học sinh nhỏ tự đăng ký | Dưới 16 tuổi (chỉnh được) phải do phụ huynh tạo tài khoản | Bảo vệ trẻ em, có người giám hộ đồng ý điều khoản |
| Tên chủ điểm giống mục lục SGK trong bản cũ | Nhập ở trạng thái Nháp, gắn cờ cần rà soát | Tránh rủi ro bản quyền, không tự xưng theo SGK |
| Yêu cầu “bang hội”, “phòng chung”, “PvP” | Đội trong lớp, Thử thách gia đình, Đấu 1–1 không có trò chuyện | Đáp ứng chơi cùng nhau nhưng giữ an toàn cho trẻ em (không nhắn tin với người lạ) |
| Yêu cầu “3D” trên hosting không build | three.js đóng gói sẵn trong `assets/vendor`, ES module, không cần Node | Đúng ràng buộc “không Node trên hosting” |
