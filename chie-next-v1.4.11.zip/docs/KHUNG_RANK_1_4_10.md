# Khung rank · 1.4.10

Thay toàn bộ kiểu viền màu cũ bằng 15 bộ khung vector gốc: cánh giáp đối xứng, viền kim loại nhiều lớp, đá quý và huy hiệu chân khung. Không lấy logo hoặc ảnh nhân vật của trò chơi khác; avatar người dùng vẫn hiện trong phần rỗng ở giữa.

Các mốc rank/cấp:

| Cấp | Rank |
|---|---|
| 1 | Sắt |
| 3 | Đồng |
| 5 | Bạc |
| 8 | Vàng |
| 10 | Bạch Kim |
| 15 | Lục Bảo |
| 20 | Kim Cương |
| 30 | Cao Thủ |
| 45 | Đại Cao Thủ |
| 60 | Thách Đấu |
| 80 | Phượng Hoàng |
| 100 | Thiên Long |

Ba khung huy hiệu Học giả, Nhà sưu tập và Huyền thoại có thiết kế mới riêng. Khung trong kho dùng thiết kế mới theo kiểu tương ứng và vẫn kiểm tra quyền sở hữu.

Lựa chọn “Theo rank hiện tại” tự thay khung khi lên rank. Hồ sơ chưa chọn khung mặc định dùng lựa chọn này; người dùng vẫn có thể chọn không khung hoặc trang bị một khung đã mở. Khóa lưu cũ giữ nguyên để lựa chọn, huy hiệu và khung trong kho không bị mất. Không đổi XP, Xu hoặc điều kiện mở khóa cũ. Admin giữ quyền thử mọi khung.

Giao diện hồ sơ, thanh trên, xem trước, thẻ lựa chọn, đấu 1–1 và trình làm bài dùng chung kiểu khung. Có khoảng trống dành cho cánh khung, huy hiệu gắn kèm và màn hình điện thoại. Khung là SVG nhỏ, tải cùng website; không cần thư viện đồ họa hoặc tài nguyên bên ngoài. Hiệu ứng nhẹ ở phần xem trước Thiên Long tôn trọng cài đặt giảm chuyển động.

Đã kiểm tra: XML của toàn bộ SVG; 21 trường hợp mốc cấp; tự đổi khung ở 5 mốc độc lập; chống chọn avatar/khung chưa mở; bảo toàn quyền sở hữu; hồi quy hồ sơ/huy hiệu/thưởng; biên dịch giao diện; xem thử màn hình 1366 và 390px không tràn ngang.

Cập nhật ZIP 1.4.10 qua trang quản trị. Không có migration mới; gói đầy đủ chứa các sửa đổi trước. Trang ngoại hình: `/chie/ho-so/ngoai-hinh`.
