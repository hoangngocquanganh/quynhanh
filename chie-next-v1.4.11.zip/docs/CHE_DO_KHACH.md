# Chế độ khách (1.4.2)

Không cần tài khoản để học bài công khai đã xuất bản, luyện tập, học từ vựng theo chủ đề, luyện ngữ pháp đã duyệt và chơi 4 game học khi có đủ câu đã duyệt đúng lớp.

Đề được mã hóa và giữ tạm trong bộ nhớ trang. Máy chủ kiểm tra mã và chấm đáp án; không tạo tài khoản, attempts, attempt_items, điểm, XP/Xu, lịch sử, SRS hoặc tiến độ cho khách. Không lưu lượt trong session, localStorage hoặc sessionStorage. Tải lại trang học sẽ bắt đầu lượt mới. Cookie kỹ thuật của website (CSRF, phiên chọn lớp) và các tùy chọn thiết bị có sẵn không phải dữ liệu kết quả học tập.

Khách không xem được nội dung chưa công khai, câu chờ duyệt hoặc bài nháp. Khách chưa có ví, phòng, kho đồ, nông trại lưu tiến độ, thử thách gia đình hoặc đấu với người khác; các tính năng này vẫn dùng tài khoản.

Quản trị → Người dùng → Phân quyền: có quyền Khách luyện không lưu điểm; quyền Game, Ngữ pháp và Từ vựng vẫn kiểm tra ở máy chủ. Các API ghi điểm cho tài khoản vẫn yêu cầu đăng nhập.

1.4.2 bao gồm bản vá cập nhật hosting 1.4.1. Nếu bộ cập nhật trên host chưa chạy được, dùng gói sửa bộ cập nhật 1.4.1 qua File Manager trước, sau đó cập nhật gói đầy đủ 1.4.2.
