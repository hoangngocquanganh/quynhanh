# Ma trận phân quyền — CHIE NEXT

Mọi kiểm tra quyền chạy **trên máy chủ** ở từng route/API (middleware `auth`, `role:…`, `teacher.approved`, `student.grade` và kiểm tra quyền sở hữu trong controller). Giao diện ẩn nút chỉ để gọn, không phải lớp bảo vệ. Truy cập dữ liệu không thuộc quyền trả về **404** (không tiết lộ dữ liệu có tồn tại hay không).

✅ được phép · ⚠️ được phép có điều kiện · ❌ bị chặn

> **v1.4 — Phân quyền chỉnh được:** Quản trị → Người dùng → **Phân quyền** (`/admin/nguoi-dung/phan-quyen`). Mỗi tính năng (học tập, ngữ pháp, game, nông trại, cửa hàng, đấu 1–1, hồ sơ, nhận XP/Xu…) bật/tắt riêng cho Học sinh, Giáo viên, Phụ huynh, Khách; lưu ở cài đặt `permissions.matrix`, ghi nhật ký. Mặc định = bảng dưới đây. **Admin luôn toàn quyền và nhận XP/Xu** (để kiểm thử). Ô khóa: khu Quản trị chỉ Admin; khu Giáo viên/Phụ huynh chỉ đúng vai trò; Khách không làm bài, không có ví. Kiểm tra quyền sở hữu dữ liệu trong controller vẫn giữ nguyên. Mã: `app/Support/Permissions.php`, middleware `CheckFeature` + `RequireRole`.

## 1. Khu vực

| Khu vực / route | Khách | Học sinh | Phụ huynh | Giáo viên chờ duyệt | Giáo viên đã duyệt | Admin |
|---|---|---|---|---|---|---|
| Chọn lớp, trang học, lộ trình, đề (xem) | ✅ | ✅ | ✅ (lớp tự học) | ✅ | ✅ | ✅ |
| Học thử bài công khai | ✅ | — | — | — | — | — |
| Làm bài, lưu điểm, nhận Xu (`/api/lessons`, `/api/attempts`) | ❌ | ✅ lớp của mình | ⚠️ tự học | ⚠️ xem thử | ⚠️ xem thử | ⚠️ xem thử |
| Bài được giao, Lớp học của tôi, Hồ sơ học sinh | ❌ | ✅ | ❌ | ❌ | ❌ | ❌ |
| Game, Nông trại, Cửa hàng, Hòm quà, Phòng, Đổi đồ, Bảng xếp hạng | ❌ (xem giới thiệu) | ✅ | ❌ | ❌ | ❌ | ❌ |
| Đấu 1–1, Đội của lớp (`/tro-choi/dau`, `/doi-cua-toi`, `/api/duel/*`) | ❌ | ✅ (chỉ trận/đội của mình) | ❌ | ❌ | ❌ | ❌ |
| Thử thách gia đình (`/thu-thach-gia-dinh/*`) | ❌ | ✅ thử thách gửi cho mình | ✅ tạo cho con đã liên kết | ❌ | ❌ | ❌ |
| Gói ôn ngoại tuyến (`/api/offline/pack`, chỉ thẻ từ đã duyệt) | ❌ | ✅ | ✅ | ✅ | ✅ | ✅ |
| `/phu-huynh/*` | ❌ | ❌ | ✅ | ❌ | ❌ | ❌ |
| `/giao-vien` (trang chờ duyệt) | ❌ | ❌ | ❌ | ✅ | ✅ | ❌ |
| `/giao-vien/*` (lớp, giao bài, chấm, báo cáo, soạn câu) | ❌ | ❌ | ❌ | ❌ | ✅ | ❌ |
| `/giao-vien/lop/{lớp}/doi` (quản lý đội) | ❌ | ❌ | ❌ | ❌ | ✅ lớp được phân công | ❌ |
| `/admin/*` | ❌ | ❌ | ❌ | ❌ | ❌ | ✅ |
| `/admin/he-thong/cap-nhat` (cập nhật phiên bản) | ❌ | ❌ | ❌ | ❌ | ❌ | ✅ + nhập lại mật khẩu ở mỗi thao tác |
| `/install` | ⚠️ chỉ trước khi cài + có mã trong tệp | ❌ sau khi cài (404) | | | | |

## 2. Dữ liệu theo đối tượng

| Dữ liệu | Học sinh | Phụ huynh | Giáo viên | Admin |
|---|---|---|---|---|
| Lượt làm bài, kết quả | Chỉ của mình | Con đã liên kết (chỉ xem) | Học sinh trong lớp được phân công (chỉ xem) | Tất cả |
| Đáp án câu chưa trả lời / đề chưa nộp | ❌ không gửi xuống trình duyệt | ❌ | ❌ | ✅ trong trang quản trị |
| Tiến độ, Sổ lỗi | Của mình, theo từng lớp | Con đã liên kết | Học sinh trong lớp | Tất cả |
| Bài giao | Của lớp mình / giao riêng cho mình | Của con (xem) | Lớp mình (tạo, đóng, chấm) | Tất cả |
| Nhận xét giáo viên | Của mình | Chỉ khi giáo viên chọn chia sẻ | Lớp mình | Tất cả |
| Ví Xu, sổ cái | Của mình (xem) | ❌ | ❌ | Xem tất cả; điều chỉnh phải ghi lý do, có nhật ký |
| Thông tin cá nhân (email, họ tên đầy đủ) | Của mình | Của mình | Của mình; học sinh trong lớp: tên hiển thị | Tất cả |
| Bảng xếp hạng | Tên hiển thị + điểm, không email/lớp/trường | — | — | — |
| Trận đấu 1–1 | Chỉ 2 người trong trận; đối thủ chỉ thấy tên hiển thị và số câu đúng | ❌ | ❌ | ❌ (không có trang xem trận) |
| Đội trong lớp | Đội của lớp mình: tên đội, tên hiển thị thành viên, điểm tuần | ❌ | Lớp mình (tạo, phân, xóa đội) | — |
| Thử thách gia đình | Của mình; xem bài của bố mẹ chỉ khi cả hai đã làm xong | Thử thách mình tạo; xem bài của con khi cả hai đã xong | ❌ | — |

## 3. Quan hệ và cách xác minh

| Quan hệ | Cách tạo | Cách hủy |
|---|---|---|
| Phụ huynh ↔ con | (a) Con tạo mã 8 ký tự trong Hồ sơ (hết hạn 48 giờ, dùng 1 lần, lưu dạng băm), phụ huynh nhập mã; (b) Phụ huynh tạo tài khoản cho con; (c) Admin tạo trong “Gia đình”. **Không** liên kết bằng email hay tên | Con hủy (trừ tài khoản do phụ huynh tạo), phụ huynh hủy, Admin thu hồi |
| Học sinh ↔ lớp | Mã mời lớp (hạn dùng, số lượt, thu hồi được); lớp chế độ “cần duyệt” thì giáo viên duyệt; hoặc Admin thêm | Học sinh rời lớp, giáo viên xóa khỏi lớp, Admin chuyển lớp |
| Giáo viên ↔ lớp | Giáo viên đã duyệt tự tạo lớp (nếu Admin cho phép), hoặc Admin phân công | Admin thu hồi phân công |
| Vai trò Admin | Chỉ trình cài đặt (Admin đầu tiên), lệnh `php artisan chie:create-admin` trên máy chủ, hoặc Admin khác tạo | Admin khác đổi vai trò/khóa. Admin không tự thao tác hàng loạt lên chính mình |

## 4. Chống lạm dụng

| Biện pháp | Áp dụng |
|---|---|
| Giới hạn tần suất | Đăng nhập 8 lần/phút/tài khoản + 30 lần/phút/IP; nhập mã (lớp, liên kết) 10 lần/phút; đăng ký 20 lần/giờ/IP; API 240 lần/phút |
| CSRF | Mọi form và API ghi dữ liệu |
| Khóa chống trùng | Mua, bán, quay hòm quà, nộp bài, thưởng (bấm 2 lần / mạng chập chờn không nhân đôi) |
| Khóa dòng CSDL | Ví, kho nông trại, trận cướp, lời mời đổi đồ, mã liên kết |
| Câu đố nông trại / cho vật nuôi ăn | Mã hóa, ràng buộc người dùng + mục đích + đối tượng + hạn, dùng một lần |
| Đấu 1–1 | Cùng bộ câu, đáp án không gửi xuống; trận khóa dòng khi kết thúc; thưởng thắng có khóa chống trùng, chỉ khi đấu người thật, qua trần ngày; thách đấu chỉ với bạn cùng lớp/người nhà |
| Cập nhật một chạm | Chỉ Admin, nhập lại mật khẩu; gói phải có danh sách SHA-256 từng tệp; chặn `../`, `.env`, `storage/`, tệp ngoài danh sách; sao lưu + tự khôi phục |
| Cờ gian lận | Trả lời liên tiếp quá nhanh được ghi để Admin xem (không tự phạt) |
| Bộ lọc tên | Chặn tên hiển thị chứa từ không phù hợp, đường dẫn, số điện thoại |
| Nội dung bảo mật | CSP chỉ cho phép tài nguyên cùng nguồn, không script nội tuyến; chặn tải `.env`, `vendor/`, `storage/`, mã nguồn |
| Nhật ký kiểm toán | Đăng ký, đổi quyền, khóa tài khoản, điều chỉnh Xu, liên kết/hủy liên kết, vào/rời lớp, chấm bài, nhập dữ liệu, sửa cài đặt, duyệt nội dung |
