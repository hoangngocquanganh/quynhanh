# HỢP ĐỒNG GIAO TIẾP CHIE NEXT MODULE SDK (v1.3.0)

Chuẩn giao tiếp giữa **CHIE Core (Laravel 11)** và các **module độc lập** trong `modules/`. Khi sửa một module, CHỈ sửa tệp trong thư mục module đó và giữ đúng giao tiếp dưới đây. Tăng `version` trong `module.json` mỗi lần sửa.

## Quy tắc chung
- `module.json` bắt buộc có: `"app": "chie-next-module"`, `"type": "game" | "grade"`, `"folder"`, `"version"`.
- Gói `.zip` có thể chứa thư mục module ở gốc hoặc chính các tệp của module. Không được chứa `.php`, `.phtml`, `.phar`, `.sh`, `.py`, `.htaccess`, đường dẫn `..`.
- Cài đặt: Admin → **Quản lý Zoo Garden 3D** → tab **Module** → "Tải lên gói .zip", hoặc Admin → **Cập nhật phiên bản** (nhận cả gói module). Hoặc chép đè thư mục qua File Manager.
- Khi cập nhật lõi bằng gói đầy đủ: module nào có `version` đang cài **lớn hơn** bản trong gói lõi sẽ được giữ nguyên.

## 1. Module game học (`modules/games/game-1..4`)
- Tệp: `module.json`, `js/game2d.js`, `js/game3d.js`, `README_AI.md`.
- `deploy` trong `module.json` ánh xạ tệp module → nơi chạy thật (chỉ cho phép `assets/js/games/`, `assets/js/games3d/`):
  `{"js/game2d.js": "assets/js/games/<code>.js", "js/game3d.js": "assets/js/games3d/<code>.js"}`.
- Trang chơi `resources/views/game/play.blade.php` nạp `assets/js/games/common.js`, rồi `entry_2d` và (ES module) `entry_3d` khai báo trong `module.json` (tệp phải nằm trong `assets/` và tồn tại; thiếu thì dùng `assets/js/games*/<code>.js`).
- `schema`: `{"khóa": ["Nhãn", "int"|"float"|"bool", min, max]}` — các ô Admin → Game Studio hiển thị và kiểm tra. Giá trị đã lưu được truyền xuống game trong cấu hình như trước.
- `defaults`: `{"khóa": giá trị}` — dùng cho nút "Khôi phục mặc định của module".
- Bản 3D import `./engine.js` (three.js r160, `window.CHIE3D`) và `./models.js` cùng thư mục `assets/js/games3d/`.
- API: `POST /api/games/{code}/start` (lấy câu hỏi đã duyệt đúng lớp), chấm từng câu và cộng XP/Xu ở máy chủ. Thông số cơ chế (số câu, thời gian, tim, tốc độ, thưởng) chỉnh ở **Admin → Game Studio**.

## 2. Module game 5 — Zoo Garden 3D (`modules/games/game-5-zoo-garden`)
- Trang `/nong-trai` nhúng khung `/nong-trai/zoo` (iframe). Khung in dữ liệu khởi tạo trong
  `<script type="application/json" id="chie-zoo-boot">` và nạp bản build theo `assets/zoo-garden/chie-manifest.json` (manifest Vite).
- Dữ liệu khởi tạo (`getChieBoot()`): `assetBase`, `csrfToken`, `endpoints{boot,save,exchange,quizStart,quizSubmit,back,learn}`,
  `student{id,name,grade_level,xu,xp,level,streak_days}`, `exchange{rate,daily_cap_xu,exchanged_today_xu}`,
  `playtime{gate_enabled,played_seconds,allowed_seconds,remaining_seconds,is_locked,can_unlock_more,unlock_questions_needed,unlock_minutes_reward,lesson_unlock_minutes,max_total_minutes}`,
  `learning{due_srs_count,pending_assignments,quiz_correct_today,srs_cleared_today,tts_default_rate,tts_slow_rate}`,
  `settings{zoo.*}`, `catalogOverrides{crop|animal|fish|item|planet|service:{code:{name_vi,name_en,desc_vi,price,sell,level,grow_seconds,enabled,extra}}}`,
  `save` (SaveState hoặc null), `revision`, `pending_energy`, `online{enabled,server_url,ticket_endpoint}`.
- API (JSON, cookie phiên + `X-CSRF-TOKEN`):
  - `GET  /api/farm/zoo-boot` → dữ liệu khởi tạo như trên.
  - `POST /api/farm/zoo-save` `{save_json?: string, revision: int, active_seconds_delta: 0..120, claimed_energy?: int}` → `{revision, pending_energy, playtime, wallet}`.
  - `POST /api/farm/zoo-exchange` `{xu: 1..5000}` → `{xu_spent, energy_added, xu_balance, exchanged_today_xu, daily_cap_xu, message}` (ϟ vào `pending_energy`, game nhận rồi báo `claimed_energy`).
  - `POST /api/farm/zoo-quiz/start` `{context: care|cook|space|dungeon|playtime_unlock, target_code?}` → `{token, questions[]}`.
  - `POST /api/farm/zoo-ticket` → `{ticket, server_url, expires_in}` (vé HMAC cho máy chủ Online — xem `docs/NODE_ONLINE_ZOO_GARDEN.md`).
  - `POST /api/farm/zoo-quiz/submit` `{token, answers: int[]}` → `{passed, correct_count, total, srs_cleared, xp_awarded, xu_awarded, energy_bonus, speedup_percent, minutes_added, feedback[], playtime, wallet}`.
- Build với `--base ./`. Không dùng script nội tuyến. Lỗi trả về dạng `{message}` (HTTP 422).

## 3. Module học liệu khối lớp (`modules/grades/grade-01..12`)
- `module.json`: `"type": "grade"`, `"folder": "grade-XX"`, `"grade_id": XX`, `"files": ["curriculum.json","lexicon.json","questions.json","exam_blueprints.json"]`.
- `exam_blueprints.json`: `exam_blueprints[]` (`code` duy nhất, `title`, `type`, `grade_from`, `grade_to`, `question_count`, `duration_min`, `skill_mix{skill: %}`) — nhập idempotent theo `code`.
- `curriculum.json`: `units[]` (`key, grade, semester, title_vi, title_en, sort, status_hint`), `lessons[]` (`key, unit_key, grade, title_vi, sort, difficulty, question_keys[]`), `passages[]`.
- `questions.json`: `questions[]` (`key, grade, skill, type, difficulty, prompt{text, speak?, emoji?}, options[], answer{correct, accepted?}, explanation_vi, tags[], status_hint`).
- `lexicon.json`: `lexicon[]` (`word, ipa "/…/", meaning_vi, example_en, example_vi, pos, topic, emoji, grade, status_hint`).
- Nhập qua `ContentImporter` (kiểm tra lại từng mục; idempotent theo `key`/`word`; không ghi đè bản Admin đã sửa; mục nghi vấn → "Chờ duyệt").
