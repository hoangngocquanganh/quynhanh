# Zoo Garden 3D — module `game-5-zoo-garden`

Game nông trại 3D (gốc: `cute_game-main`, TypeScript + three.js r180 + Vite 7) chạy trong CHIE NEXT tại `/nong-trai`.
Đọc kèm `MODULE_SDK_CONTRACT.md`.

## Cấu trúc
| Đường dẫn | Nội dung |
|---|---|
| `module.json` | Khai báo module; `deploy: {"dist": "assets/zoo-garden"}` — nếu gói tải lên có `dist/`, hệ thống chép đè vào `assets/zoo-garden/`. |
| `catalog.default.json` | Thông số gốc của 27 cây, 7 thú, 20 cá, 210 vật phẩm, 9 hành tinh (hiển thị trong Admin). Sinh từ `source/src/content.ts`. |
| `source/` | Mã nguồn game ĐÃ tích hợp CHIE (xem dưới). Không có `node_modules` và mô hình 3D. |
| `source/server/` | Máy chủ Online gốc (Node.js + WebSocket) — chưa dùng; kế hoạch tích hợp ở `docs/NODE_ONLINE_ZOO_GARDEN.md` của CHIE. |
| `dist/` (tùy chọn) | Bản build mới để cài — chỉ cần khi bạn sửa game. |

## Tệp tích hợp CHIE trong `source/src/`
- `chie-boot.ts` — chạy đầu tiên: đọc `<script type="application/json" id="chie-zoo-boot">`, đường dẫn tài nguyên động (`getZooAssetBase()`), tách localStorage theo học sinh, nạp bản lưu MySQL, ngôn ngữ mặc định.
- `chie-integration.ts` + `chie-integration.css` — ghi đè danh mục từ Admin (kể cả giá dịch vụ: `PEN_BUILD`, `PEN_EXPANSIONS`, `setHelperCosts`), nút đố trong Bếp/Hầm ngục (`chieQuizButton` trong `chie-boot.ts`), thanh công cụ CHIE, đồng bộ bản lưu, Playtime Gate, đổi Xu → ϟ, đố Tiếng Anh, từ điển song ngữ + loa TTS.
- Sửa nhỏ: `main.ts` (gọi 2 hàm trên, chỉ bật online khi Admin cho phép), `assets.ts`, `asset-url.ts`, `bots.ts` (đường dẫn), `platform.ts` (không đăng ký service worker riêng), `i18n.ts` (`addViOverrides`), `vite.config.ts` (`manifest: true`), `package.json` (`build:chie`).

## Build lại
```
cd source
npm ci
# chép mô hình/icon/nhạc từ CHIE: assets/zoo-garden/assets/{models,icons,audio} → source/public/assets/
npm run build:chie        # = tsc --noEmit && vite build --mode chie --base ./ && node scripts/chie-postbuild.mjs
```
Đổi tên `source/dist` thành `dist/` ở cấp module (cạnh `module.json`), tăng `version`, nén cả thư mục `game-5-zoo-garden` rồi tải lên Admin → tab Module.
(Hoặc chép tay `dist/*` vào `assets/zoo-garden/` qua File Manager.)

## Quy tắc
- Build phải dùng `--base ./` (đường dẫn tương đối) để CHIE chạy được ở tên miền gốc lẫn thư mục con.
- Không dùng script nội tuyến (CSP của CHIE chặn). Dữ liệu khởi tạo đọc qua `getChieBoot()`.
- Không gọi `gameBridge.setPersistence()` (game sẽ tưởng đang online và khóa chế độ chơi đơn).
- Gọi API bằng URL trong `boot.endpoints` (không viết cứng `/api/...`), gửi kèm `X-CSRF-TOKEN: boot.csrfToken`.
- Không đặt `.php`, `.sh`, `.htaccess`, `.py` trong gói — bị từ chối khi tải lên.
