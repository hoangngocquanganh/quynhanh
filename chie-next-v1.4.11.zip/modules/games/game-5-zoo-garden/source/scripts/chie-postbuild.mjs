// CHIE NEXT: sau khi build, chép manifest Vite ra tên không có dấu chấm đầu (dễ upload qua FTP/File Manager).
import { copyFileSync, existsSync } from 'node:fs';
if (existsSync('dist/.vite/manifest.json')) copyFileSync('dist/.vite/manifest.json', 'dist/chie-manifest.json');
console.log('CHIE: dist/ sẵn sàng — chép toàn bộ vào assets/zoo-garden/ của CHIE NEXT.');
