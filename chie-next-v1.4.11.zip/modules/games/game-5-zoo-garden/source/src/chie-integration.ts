/**
 * CHIE NEXT × Zoo Garden — tích hợp vào web học tiếng Anh CHIE (Laravel).
 *
 *  applyChieBootOverrides()  gọi trong main.ts TRƯỚC khi đọc bản lưu: áp dụng mọi chỉnh sửa của Admin
 *                            (tên Việt/Anh, giá mua/bán, thời gian lớn, cấp mở, bật/tắt) vào bảng nội dung game.
 *  initChieIntegration()     gọi ở cuối main.ts: thanh công cụ CHIE, đồng bộ bản lưu lên MySQL, đếm phút chơi
 *                            (Playtime Gate), đổi Xu → ϟ, đố Tiếng Anh ưu tiên Sổ lỗi, từ điển song ngữ + loa TTS.
 *
 * Không dùng gameBridge.setPersistence(): game sẽ tưởng đang "online" và khoá một số chế độ chơi đơn.
 * Thay vào đó game vẫn tự lưu vào localStorage như bản gốc, còn module này đẩy bản lưu đó lên máy chủ.
 */
import './chie-integration.css';
import type { GameBridge } from './game-bridge.ts';
import { CROPS, ITEMS, PLANETS, FISH, RECIPES, DISGUISES, SAVE_KEY, ANIMALS, PEN_BUILD, PEN_EXPANSIONS, maxHp, type AnimalKind, type SaveState } from './model.ts';
import { setHelperCosts } from './helper-state.ts';
import { addViOverrides, getLanguage } from './i18n.ts';
import { getChieBoot, type ChieBootPayload, type ChieCatalogOverride, type ChiePlaytime } from './chie-boot.ts';

export { getChieBoot } from './chie-boot.ts';

/** Tên Tiếng Anh (sau khi áp chỉnh sửa của Admin) theo mã — dùng cho từ điển song ngữ và loa TTS. */
export const ENGLISH_NAMES = new Map<string, string>();
/** Tên Tiếng Việt theo mã (chỉ những mã Admin đã đặt tên). */
const VI_NAMES = new Map<string, string>();
/** Từ vựng gắn kèm do Admin nhập ("word = nghĩa"). */
const EXTRA_WORDS = new Map<string, [string, string][]>();

const num = (v: unknown): number | null => (typeof v === 'number' && Number.isFinite(v) ? v : null);

export function applyChieBootOverrides(): void {
  for (const [id, c] of Object.entries(CROPS)) ENGLISH_NAMES.set(id, c.name);
  for (const [id, a] of Object.entries(ANIMALS)) ENGLISH_NAMES.set(id, a.name);
  for (const [id, it] of Object.entries(ITEMS)) if (!ENGLISH_NAMES.has(id)) ENGLISH_NAMES.set(id, it.name);
  for (const [id, p] of Object.entries(PLANETS)) ENGLISH_NAMES.set(id, p.name);

  const boot = getChieBoot();
  if (!boot) return;
  const vi: Record<string, string> = {};
  const rename = (code: string, ov: ChieCatalogOverride, oldEn: string, apply: (en: string) => void) => {
    if (ov.name_en) { apply(ov.name_en); ENGLISH_NAMES.set(code, ov.name_en); }
    if (ov.name_vi) { vi[oldEn] = ov.name_vi; if (ov.name_en) vi[ov.name_en] = ov.name_vi; VI_NAMES.set(code, ov.name_vi); }
    const words = (ov.extra as { words?: unknown } | undefined)?.words;
    if (Array.isArray(words)) EXTRA_WORDS.set(code, words.filter((w): w is [string, string] => Array.isArray(w) && w.length === 2).map(w => [String(w[0]), String(w[1])]));
  };
  const ov = boot.catalogOverrides || {};

  // 1. Cây trồng (CROPS + ITEMS cùng mã)
  for (const [code, o] of Object.entries(ov.crop || {})) {
    const c = CROPS[code], it = ITEMS[code];
    if (!c || !it) continue;
    rename(code, o, c.name, en => { c.name = en; it.name = en; });
    if (o.desc_vi) vi[it.desc] = o.desc_vi;
    if ((num(o.level) ?? 0) > 0) c.level = o.level!;
    if ((num(o.grow_seconds) ?? 0) > 0) c.duration = o.grow_seconds! * 1000;
    if ((num(o.sell) ?? -1) >= 0) it.sell = o.sell!;
    if (o.enabled === false) c.level = 999; // ẩn khỏi danh sách gieo (không ai đạt cấp 999)
  }

  // 2. Vật nuôi
  for (const [code, o] of Object.entries(ov.animal || {})) {
    const a = ANIMALS[code as AnimalKind];
    if (!a) continue;
    rename(code, o, a.name, en => { a.name = en; });
    if ((num(o.level) ?? 0) > 0) a.level = o.level!;
    if ((num(o.price) ?? -1) >= 0) a.price = o.price!;
    if ((num(o.grow_seconds) ?? 0) > 0) a.growMs = o.grow_seconds! * 1000;
    if (o.enabled === false) a.level = 999;
  }

  // 3. Cá, vật phẩm, trang bị, cải trang, thú cưng, dịch vụ
  for (const cat of ['fish', 'item', 'disguise', 'service'] as const) {
    for (const [code, o] of Object.entries(ov[cat] || {})) {
      const it = ITEMS[code];
      if (it) {
        rename(code, o, it.name, en => { it.name = en; if (FISH[code]) FISH[code].name = en; });
        if (o.desc_vi) vi[it.desc] = o.desc_vi;
        if ((num(o.sell) ?? -1) >= 0) { it.sell = o.sell!; if (FISH[code]) FISH[code].sell = o.sell!; }
        if ((num(o.price) ?? -1) >= 0) { it.price = o.price!; for (const r of RECIPES) if (r.result === code) r.energy = o.price!; }
        if (o.enabled === false) for (let i = RECIPES.length - 1; i >= 0; i--) if (RECIPES[i].result === code) RECIPES.splice(i, 1);
      }
      const dz = DISGUISES[code];
      if (dz && o.name_vi) vi[dz.name] = o.name_vi;
    }
  }

  // 3b. Dịch vụ trang trại (chuồng, robot…): không phải vật phẩm — chỉ đổi được tên Tiếng Việt nơi game dùng đúng chuỗi gốc.
  const price = (o: ChieCatalogOverride) => (typeof o.price === 'number' && Number.isSafeInteger(o.price) && o.price >= 0 ? o.price : null);
  for (const [code, o] of Object.entries(ov.service || {})) {
    if (o.name_vi && o.orig_en) { vi[o.orig_en] = o.name_vi; VI_NAMES.set(code, o.name_vi); }
    const p = price(o);
    const build = PEN_BUILD as { level: number; price: number };
    const steps = PEN_EXPANSIONS as unknown as number[];
    if (code === 'pen_build') { if (p !== null) build.price = p; if ((num(o.level) ?? 0) > 0) build.level = o.level!; }
    if (code === 'pen_expand_1' && p !== null) steps[0] = p;
    if (code === 'pen_expand_2' && p !== null) steps[1] = p;
    if (code === 'garden_helper') setHelperCosts(p, null);
    if (code === 'farm_helper') setHelperCosts(null, p);
  }

  // 4. Hành tinh
  for (const [code, o] of Object.entries(ov.planet || {})) {
    const p = (PLANETS as Record<string, { name: string; level: number }>)[code];
    if (!p) continue;
    rename(code, o, p.name, en => { p.name = en; });
    if ((num(o.level) ?? 0) > 0) p.level = o.level!;
    if (o.enabled === false && code !== 'home') p.level = 999;
  }

  if (Object.keys(vi).length) addViOverrides(vi);
}

// ---------------------------------------------------------------------------------------------- tiện ích

const esc = (s: unknown) => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]!));

let voicesReady = false;
export function speakEnglish(text: string, slow = false): void {
  if (!text || typeof window === 'undefined' || !('speechSynthesis' in window)) return;
  try {
    const synth = window.speechSynthesis;
    synth.cancel();
    const boot = getChieBoot();
    const u = new SpeechSynthesisUtterance(text);
    u.lang = 'en-US';
    u.rate = slow ? (boot?.learning?.tts_slow_rate ?? 0.65) : (boot?.learning?.tts_default_rate ?? 0.75);
    const voices = synth.getVoices();
    if (!voicesReady && !voices.length) { voicesReady = true; synth.onvoiceschanged = () => {}; }
    const en = voices.find(v => v.lang.startsWith('en') && /Google|Natural|Samantha|Microsoft|Daniel|Karen/i.test(v.name)) || voices.find(v => v.lang.startsWith('en'));
    if (en) u.voice = en;
    synth.speak(u);
  } catch { /* trình duyệt không hỗ trợ */ }
}

async function api<T = any>(boot: ChieBootPayload, url: string, body?: unknown, keepalive = false): Promise<T> {
  const res = await fetch(url, {
    method: body === undefined ? 'GET' : 'POST',
    credentials: 'same-origin',
    keepalive,
    headers: { 'Content-Type': 'application/json', Accept: 'application/json', 'X-CSRF-TOKEN': boot.csrfToken, 'X-Requested-With': 'XMLHttpRequest', 'X-Chie-Release': boot.release || 'root' },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  let data: any = null;
  try { data = await res.json(); } catch { data = null; }
  if (res.status === 419) throw new Error('Phiên đăng nhập đã hết hạn. Hãy tải lại trang.');
  if (res.status === 401) throw new Error('Bạn cần đăng nhập lại CHIE.');
  if (!res.ok) throw new Error((data && (data.message || data.error)) || `Lỗi máy chủ (${res.status}).`);
  return data as T;
}

function el<K extends keyof HTMLElementTagNameMap>(tag: K, cls?: string, html?: string): HTMLElementTagNameMap[K] {
  const e = document.createElement(tag);
  if (cls) e.className = cls;
  if (html !== undefined) e.innerHTML = html;
  return e;
}

// ---------------------------------------------------------------------------------------------- khởi tạo

export function initChieIntegration(bridge: GameBridge): void {
  const boot = getChieBoot();
  if (!boot) return;
  if (boot.guest) {
    const bar = el('div', 'chie-bar');
    bar.id = 'chie-guest-bar';
    const back = el('a', 'chie-pill'); back.href = boot.endpoints.back; back.target = '_top'; back.textContent = '← CHIE';
    const note = el('span', 'chie-stat'); note.textContent = 'Chơi khách · không lưu cấp độ';
    bar.append(back, note); document.body.appendChild(bar);
    let given = false;
    window.setInterval(() => {
      const title = document.getElementById('title-screen');
      if (!given && title?.hidden) {
        given = true;
        const s = bridge.getState();
        if (s.level === 1 && s.energy === 0) bridge.grantGift({ count: 0, energy: Math.max(0, Number(boot.settings['zoo.starting_energy'] ?? 100)) });
      }
      const status = document.getElementById('save-status');
      if (status) status.textContent = 'Chơi khách — tiến độ chỉ giữ trong lượt này';
    }, 1000);
    return; // No account endpoints, exchange, online tickets, playtime counters or server saves.
  }

  let revision = boot.revision || 0;
  let pendingSeconds = 0;
  let pendingEnergy = Math.max(0, Number((boot as { pending_energy?: number }).pending_energy ?? 0));
  let claimedEnergy = 0;
  let lastUploadedAt = 0;
  let lastUploadClock = 0;
  let uploading = false;
  let lastInput = Date.now();
  let freshChecked = false;
  let warnedLow = false;
  const lastTapped = { code: '', at: 0 };

  // ---------------------------------------------------------------- giao diện: thanh CHIE + hộp thoại
  const bar = el('div', 'chie-bar');
  bar.id = 'chie-mini-bar';
  bar.setAttribute('role', 'toolbar');
  bar.setAttribute('aria-label', 'Thanh công cụ CHIE');
  bar.innerHTML = `
    <button type="button" class="chie-pill" data-chie="back" title="Lưu và quay về CHIE">← CHIE</button>
    <span class="chie-stat" title="Xu học tập trong ví CHIE">💰 <b id="chie-bar-xu"></b></span>
    <span class="chie-stat" title="Thời gian chơi còn lại hôm nay">⏳ <b id="chie-bar-time"></b></span>
    <button type="button" class="chie-pill" data-chie="exchange" title="Đổi Xu học tập sang Năng lượng ϟ">🔄 Đổi ϟ</button>
    <button type="button" class="chie-pill accent" data-chie="care" title="Giải đố Tiếng Anh: cây & thú lớn nhanh hơn, nhận Xu + ϟ">🎓 Đố từ vựng</button>
    <button type="button" class="chie-pill" data-chie="space" title="Trạm Tri Thức: +25% sát thương & +20% may mắn trong 15 phút">⚡ Bùa tri thức</button>
    <button type="button" class="chie-pill" data-chie="fullscreen" title="Toàn màn hình">⛶ Toàn màn hình</button>
    <button type="button" class="chie-pill chie-fold" data-chie="fold" aria-expanded="true" title="Thu gọn / mở thanh CHIE">◂ Thu gọn</button>`;
  document.body.appendChild(bar);
  // Điện thoại: thu gọn sẵn thành một nút nhỏ ở mép trái (bấm để mở) cho đỡ che màn chơi.
  if (matchMedia('(max-width: 700px), (max-height: 520px)').matches) {
    bar.classList.add('folded');
    const fb = bar.querySelector<HTMLElement>('[data-chie="fold"]');
    if (fb) { fb.textContent = '🎓 ▸'; fb.setAttribute('aria-expanded', 'false'); }
  }

  const dlg = el('dialog', 'chie-modal');
  dlg.id = 'chie-action-modal';
  dlg.innerHTML = `<div class="chie-modal-body" id="chie-action-body"></div><div class="chie-modal-foot"><button type="button" class="chie-btn" data-chie="close">Đóng</button></div>`;
  document.body.appendChild(dlg);

  const gate = el('dialog', 'chie-modal chie-gate');
  gate.id = 'chie-playtime-modal';
  document.body.appendChild(gate);
  gate.addEventListener('cancel', e => { if (boot.playtime.is_locked) e.preventDefault(); });

  const chip = el('div', 'chie-word-chip');
  chip.hidden = true;
  chip.setAttribute('role', 'status');
  document.body.appendChild(chip);

  const toast = (text: string) => { try { bridge.showNotice(text); } catch { /* */ } };

  function renderGate(): void {
    const p = boot!.playtime;
    gate.innerHTML = `
      <h3>⏰ Hết giờ chơi Nông trại hôm nay</h3>
      <p>Bạn đã dùng hết thời gian chơi hiện có. Muốn chơi tiếp <b>Zoo Garden 3D</b>, hãy chọn:</p>
      <div class="chie-col">
        ${p.can_unlock_more ? `<button type="button" class="chie-btn primary" data-chie="unlock">🎓 Trả lời ${p.unlock_questions_needed} câu Tiếng Anh ngay (+${p.unlock_minutes_reward} phút)</button>` : ''}
        ${p.can_unlock_more ? `<button type="button" class="chie-btn" data-chie="learn">📚 Về CHIE học 1 bài (+${p.lesson_unlock_minutes} phút tự động)</button>` : `<p class="chie-note">Hôm nay đã đạt tối đa ${p.max_total_minutes} phút chơi để bảo vệ mắt. Hẹn gặp lại ngày mai nhé!</p>`}
        <button type="button" class="chie-btn" data-chie="back">← Về CHIE</button>
      </div>`;
  }

  function fmtTime(): string {
    const p = boot!.playtime;
    if (!p.gate_enabled) return '∞';
    const s = Math.max(0, Math.floor(p.remaining_seconds));
    return `${Math.floor(s / 60)}p${String(s % 60).padStart(2, '0')}`;
  }
  function updateBar(): void {
    const xu = document.getElementById('chie-bar-xu');
    if (xu) xu.textContent = `${Number(boot!.student.xu || 0).toLocaleString('vi-VN')} Xu`;
    const tm = document.getElementById('chie-bar-time');
    if (tm) { tm.textContent = fmtTime(); tm.parentElement?.classList.toggle('low', boot!.playtime.gate_enabled && boot!.playtime.remaining_seconds < 180); }
    const p = boot!.playtime;
    if (p.gate_enabled && !p.is_locked && p.remaining_seconds > 0 && p.remaining_seconds <= 180 && !warnedLow) {
      warnedLow = true;
      toast(`⏳ Còn ${Math.ceil(p.remaining_seconds / 60)} phút chơi hôm nay. Học thêm 1 bài trên CHIE để được cộng giờ nhé!`);
    }
  }
  function applyPlaytime(p?: ChiePlaytime): void {
    if (p) boot!.playtime = { ...boot!.playtime, ...p };
    updateBar();
    if (boot!.playtime.is_locked) {
      if (!gate.open) { renderGate(); if (dlg.open) dlg.close(); try { gate.showModal(); } catch { gate.setAttribute('open', ''); } }
    } else if (gate.open) gate.close();
  }
  function applyWallet(w?: { xu?: number; xp?: number; level?: number }): void {
    if (!w) return;
    if (typeof w.xu === 'number') boot!.student.xu = w.xu;
    if (typeof w.xp === 'number') boot!.student.xp = w.xp;
    if (typeof w.level === 'number') boot!.student.level = w.level;
    updateBar();
  }
  // Khi bị khoá giờ chơi: chặn phím điều khiển nhân vật (trừ khi đang gõ trong hộp thoại CHIE).
  const blockKeys = (e: KeyboardEvent) => {
    if (!boot.playtime.is_locked) return;
    const t = e.target as Node | null;
    if (t && (gate.contains(t) || dlg.contains(t))) return;
    e.stopImmediatePropagation();
    e.preventDefault();
  };
  window.addEventListener('keydown', blockKeys, true);
  window.addEventListener('keyup', blockKeys, true);
  ['pointerdown', 'keydown', 'touchstart', 'wheel'].forEach(ev => window.addEventListener(ev, () => { lastInput = Date.now(); }, { capture: true, passive: true }));

  // ---------------------------------------------------------------- đồng bộ bản lưu lên MySQL
  const started = () => { const t = document.getElementById('title-screen'); return !!t && t.hidden; };
  let storageOk = true;
  try { localStorage.setItem('chie-zoo-probe', '1'); localStorage.removeItem('chie-zoo-probe'); } catch { storageOk = false; }
  const serverSavedAt = Number((boot.save as { savedAt?: number } | null)?.savedAt) || 0;
  lastUploadedAt = serverSavedAt; // bản trên máy chủ đã có — chỉ đẩy khi game lưu mới hơn
  function readLocalSave(): { raw: string; savedAt: number } | null {
    let raw: string | null = null;
    if (storageOk) { try { raw = localStorage.getItem(SAVE_KEY); } catch { raw = null; } }
    if (!raw) {
      // Trình duyệt chặn bộ nhớ: game không đọc được bản MySQL, nên KHÔNG đè bản trên máy chủ bằng ván mới.
      if (storageOk || boot!.save || !started()) return null;
      try { const s = bridge.getState(); raw = JSON.stringify({ ...s, savedAt: Date.now() }); } catch { return null; }
    }
    try { const savedAt = Number(JSON.parse(raw).savedAt) || 0; return { raw, savedAt }; } catch { return null; }
  }

  async function sync(force = false, unloading = false): Promise<void> {
    if (uploading && !force) return;
    const local = readLocalSave();
    const changed = !!local && local.savedAt > lastUploadedAt;
    if (!changed && pendingSeconds < 1 && claimedEnergy < 1 && !force) return;
    uploading = true;
    const seconds = Math.min(120, pendingSeconds);
    const claim = claimedEnergy;
    pendingSeconds -= seconds;
    claimedEnergy -= claim;
    lastUploadClock = Date.now();
    const body: Record<string, unknown> = { revision, active_seconds_delta: seconds, claimed_energy: claim };
    if (changed && local) body.save_json = local.raw;
    try {
      const keep = unloading && (!body.save_json || (body.save_json as string).length < 60_000);
      const data = await api(boot!, boot!.endpoints.save, body, keep);
      if (typeof data.revision === 'number') revision = data.revision;
      if (changed && local) lastUploadedAt = local.savedAt;
      applyWallet(data.wallet);
      if (data.playtime) applyPlaytime(data.playtime);
      const st = document.querySelector('#save-status');
      if (st && changed) st.textContent = '● Đã lưu vào tài khoản CHIE';
    } catch (err) {
      pendingSeconds += seconds;
      claimedEnergy += claim;
      if (!unloading && force) toast(`⚠️ Chưa lưu được lên CHIE: ${(err as Error).message}`);
    } finally {
      uploading = false;
    }
  }

  // Nhịp 1 giây: đếm thời gian chơi thật (tab đang mở, đã vào game, có thao tác trong 2 phút gần nhất).
  window.setInterval(() => {
    const now = Date.now();
    const active = !document.hidden && started() && !boot.playtime.is_locked && now - lastInput < 120_000;
    if (active) {
      pendingSeconds += 1;
      if (boot.playtime.gate_enabled) {
        boot.playtime.remaining_seconds = Math.max(0, boot.playtime.remaining_seconds - 1);
        if (boot.playtime.remaining_seconds <= 0 && !boot.playtime.is_locked) {
          boot.playtime.is_locked = true;
          applyPlaytime();
          void sync(true);
        }
      }
      updateBar();
    }
    // Năng lượng đang chờ nhận (đổi Xu / thưởng đố) — trao khi game đã bắt đầu.
    if (pendingEnergy > 0 && started()) {
      const amount = pendingEnergy;
      if (bridge.grantGift({ count: 0, energy: amount })) {
        pendingEnergy -= amount;
        claimedEnergy += amount;
        toast(`⚡ +${amount.toLocaleString('vi-VN')} ϟ Năng lượng từ CHIE`);
        void sync(true);
      }
    }
    if (!freshChecked && started()) {
      freshChecked = true;
      const s = bridge.getState();
      const startEnergy = Number(boot.settings?.['zoo.starting_energy'] ?? 0);
      if (!boot.save && s.level === 1 && s.xp === 0 && s.energy === 0 && startEnergy > 0) bridge.grantGift({ count: 0, energy: startEnergy });
    }
    // Đẩy bản lưu khi có thay đổi (tối đa 1 lần / 15 giây) hoặc mỗi 45 giây để báo phút chơi.
    const since = now - lastUploadClock;
    const local = since > 15_000 ? readLocalSave() : null;
    if ((local && local.savedAt > lastUploadedAt) || (since > 45_000 && pendingSeconds > 0)) void sync();
  }, 1000);

  const flush = () => void sync(true, true);
  window.addEventListener('pagehide', flush);
  document.addEventListener('visibilitychange', () => { if (document.hidden) flush(); });

  // ---------------------------------------------------------------- nút trên thanh CHIE
  function goBack(url: string) {
    void sync(true).finally(() => {
      try { (window.top ?? window).location.href = url; } catch { window.location.href = url; }
    });
  }
  function toggleFullscreen() {
    // Trong khung iframe của trang /nong-trai: nhờ trang cha phóng to (hỗ trợ cả iPhone không có Fullscreen API).
    if (window.parent && window.parent !== window) { window.parent.postMessage({ type: 'chie-zoo-fullscreen' }, window.location.origin); return; }
    const d = document as Document & { webkitFullscreenElement?: Element; webkitExitFullscreen?: () => void };
    const root = document.documentElement as HTMLElement & { webkitRequestFullscreen?: () => void };
    if (d.fullscreenElement || d.webkitFullscreenElement) { void (d.exitFullscreen?.() ?? d.webkitExitFullscreen?.()); return; }
    try { if (root.requestFullscreen) void root.requestFullscreen({ navigationUI: 'hide' }).catch(() => {}); else root.webkitRequestFullscreen?.(); } catch { /* */ }
  }
  const onClick = (e: Event) => {
    const btn = (e.target as HTMLElement | null)?.closest<HTMLElement>('[data-chie]');
    if (!btn) return;
    e.preventDefault();
    switch (btn.dataset.chie) {
      case 'back': goBack(boot.endpoints.back); break;
      case 'learn': goBack(boot.endpoints.learn); break;
      case 'exchange': openExchange(); break;
      case 'care': void openQuiz('care'); break;
      case 'space': void openQuiz('space'); break;
      case 'unlock': void openQuiz('playtime_unlock'); break;
      case 'fullscreen': toggleFullscreen(); break;
      case 'close': dlg.close(); break;
      case 'fold': {
        const folded = bar.classList.toggle('folded');
        btn.setAttribute('aria-expanded', String(!folded));
        btn.textContent = folded ? '🎓 ▸' : '◂ Thu gọn';
        break;
      }
    }
  };
  bar.addEventListener('click', onClick);
  dlg.addEventListener('click', onClick);
  gate.addEventListener('click', onClick);
  // Không để thao tác trên thanh CHIE lọt xuống mặt đất 3D (đi bộ nhầm).
  for (const host of [bar, chip]) ['pointerdown', 'pointerup', 'touchstart', 'mousedown', 'wheel'].forEach(ev => host.addEventListener(ev, e => e.stopPropagation(), { passive: true }));

  function showDialog(html: string): HTMLElement {
    const body = document.getElementById('chie-action-body')!;
    body.innerHTML = html;
    if (!dlg.open) { try { dlg.showModal(); } catch { dlg.setAttribute('open', ''); } }
    return body;
  }

  // ---------------------------------------------------------------- đổi Xu → ϟ
  function openExchange(): void {
    const ex = boot!.exchange;
    const left = Math.max(0, ex.daily_cap_xu - ex.exchanged_today_xu);
    const opts = [10, 25, 50, 100].filter(x => x <= Math.max(left, 0));
    const body = showDialog(`
      <h3>🔄 Đổi Xu học tập → Năng lượng ϟ</h3>
      <p>Tỉ lệ: <b>1 Xu = ${ex.rate} ϟ</b>. Ví của bạn: <b>${Number(boot!.student.xu).toLocaleString('vi-VN')} Xu</b>.</p>
      <p class="chie-note">Hạn mức hôm nay còn <b>${left}/${ex.daily_cap_xu} Xu</b>. Học bài trên CHIE để kiếm thêm Xu nhé!</p>
      <div class="chie-row">${opts.map(x => `<button type="button" class="chie-btn" data-ex="${x}">${x} Xu → +${(x * ex.rate).toLocaleString('vi-VN')} ϟ</button>`).join('') || '<p class="chie-note">Đã hết hạn mức đổi hôm nay.</p>'}</div>
      <p id="chie-ex-status" class="chie-note" aria-live="polite"></p>`);
    body.querySelectorAll<HTMLButtonElement>('[data-ex]').forEach(b => {
      b.onclick = async () => {
        const xu = Number(b.dataset.ex || 0);
        const st = document.getElementById('chie-ex-status')!;
        body.querySelectorAll<HTMLButtonElement>('[data-ex]').forEach(x => { x.disabled = true; });
        st.textContent = 'Đang đổi…';
        try {
          const data = await api(boot!, boot!.endpoints.exchange, { xu });
          boot!.student.xu = data.xu_balance;
          boot!.exchange.exchanged_today_xu = data.exchanged_today_xu;
          pendingEnergy += Number(data.energy_added) || 0;
          updateBar();
          dlg.close();
          toast(`🎉 ${data.message}`);
          if (!started()) toast('Năng lượng sẽ được cộng ngay khi bạn bấm Chơi.');
        } catch (err) {
          st.textContent = `⚠️ ${(err as Error).message}`;
          body.querySelectorAll<HTMLButtonElement>('[data-ex]').forEach(x => { x.disabled = false; });
        }
      };
    });
  }

  // ---------------------------------------------------------------- đố Tiếng Anh
  type Ctx = 'care' | 'space' | 'cook' | 'dungeon' | 'playtime_unlock';
  const TITLES: Record<Ctx, string> = {
    care: '🎓 Đố từ vựng chăm vườn',
    space: '⚡ Trạm Tri Thức',
    cook: '🍳 Đầu bếp Tiếng Anh',
    dungeon: '📜 Thử thách của Người gác hầm',
    playtime_unlock: '⏰ Nạp thêm phút chơi',
  };
  const SUB: Record<Ctx, string> = {
    care: 'Đúng hết: cây đang lớn & vật nuôi rút ngắn thời gian chờ, nhận thêm ϟ, XP và Xu CHIE.',
    space: 'Đúng hết: Bùa Tri Thức +25% sát thương, +20% may mắn trong 15 phút, kèm ϟ, XP và Xu CHIE.',
    cook: 'Đúng hết: một "món ngon" hồi đầy máu và hồi máu dần trong 10 phút, kèm ϟ, XP và Xu CHIE.',
    dungeon: 'Đúng hết: +15 phòng thủ và +15% sát thương trong 15 phút để vào hầm, kèm ϟ, XP và Xu CHIE.',
    playtime_unlock: 'Trả lời đúng ít nhất 80% để được cộng thêm phút chơi.',
  };

  async function openQuiz(context: Ctx): Promise<void> {
    if (context !== 'playtime_unlock' && boot!.playtime.is_locked) { applyPlaytime(); return; }
    const render = (html: string) => {
      if (context === 'playtime_unlock') { gate.innerHTML = `<div class="chie-modal-body">${html}</div><div class="chie-modal-foot"><button type="button" class="chie-btn" data-chie="regate">← Quay lại</button></div>`; gate.querySelector('[data-chie="regate"]')?.addEventListener('click', () => renderGate()); return gate.querySelector<HTMLElement>('.chie-modal-body')!; }
      return showDialog(html);
    };
    let body = render('<p>⏳ Đang lấy câu hỏi (ưu tiên từ Sổ lỗi của bạn)…</p>');
    try {
      const target = context === 'care' && Date.now() - lastTapped.at < 90_000 ? lastTapped.code : undefined;
      const payload = await api(boot!, boot!.endpoints.quizStart, target ? { context, target_code: target } : { context });
      const qs: any[] = payload.questions || [];
      const answers: number[] = qs.map(() => -1);
      body = render(`
        <h3>${TITLES[context]}</h3><p class="chie-note">${SUB[context]}</p>
        ${qs.map((q, i) => {
          const p = q.prompt || {};
          const speak = p.speak || p.speak_word || '';
          return `<div class="chie-q" data-q="${i}">
            <div class="chie-q-head"><b>Câu ${i + 1}/${qs.length}</b>${q.from_srs ? '<span class="chie-tag">📌 Sổ lỗi</span>' : ''}</div>
            <p class="chie-q-text">${p.emoji ? esc(p.emoji) + ' ' : ''}${esc(p.text || (q.type === 'listen_mcq' ? 'Nghe và chọn đáp án đúng' : ''))}${p.ipa ? ` <span class="chie-ipa">${esc(p.ipa)}</span>` : ''}</p>
            ${speak ? `<div class="chie-row"><button type="button" class="chie-btn sm" data-say="${esc(speak)}">🔊 Nghe</button><button type="button" class="chie-btn sm" data-say="${esc(speak)}" data-slow="1">🐢 Nghe chậm</button></div>` : ''}
            <div class="chie-opts">${(q.display?.options || []).map((o: string, oi: number) => `<button type="button" class="chie-opt" data-opt="${oi}">${esc(o)}</button>`).join('')}</div>
          </div>`;
        }).join('')}
        <div id="chie-quiz-fb" aria-live="polite"></div>
        <button type="button" class="chie-btn primary wide" id="chie-quiz-submit">Nộp đáp án</button>`);
      body.querySelectorAll<HTMLElement>('[data-say]').forEach(b => { b.onclick = () => speakEnglish(b.dataset.say || '', b.dataset.slow === '1'); });
      body.querySelectorAll<HTMLElement>('[data-q]').forEach(group => {
        const qi = Number(group.dataset.q);
        group.querySelectorAll<HTMLButtonElement>('[data-opt]').forEach(b => {
          b.onclick = () => { answers[qi] = Number(b.dataset.opt); group.querySelectorAll('.chie-opt').forEach(x => x.classList.remove('on')); b.classList.add('on'); };
        });
      });
      const submit = body.querySelector<HTMLButtonElement>('#chie-quiz-submit')!;
      submit.onclick = async () => {
        const fb = body.querySelector<HTMLElement>('#chie-quiz-fb')!;
        if (answers.some(a => a < 0)) { fb.innerHTML = '<p class="chie-err">Hãy chọn đáp án cho tất cả câu hỏi.</p>'; return; }
        submit.disabled = true; submit.textContent = 'Đang chấm…';
        try {
          const r = await api(boot!, boot!.endpoints.quizSubmit, { token: payload.token, answers });
          applyWallet(r.wallet);
          (r.feedback || []).forEach((f: any, i: number) => {
            const g = body.querySelector(`[data-q="${i}"]`);
            g?.querySelectorAll<HTMLButtonElement>('.chie-opt').forEach((b, oi) => { b.disabled = true; if (oi === f.correct_index) b.classList.add('ok'); else if (oi === answers[i] && !f.is_correct) b.classList.add('bad'); });
          });
          if (r.passed) {
            rewardQuiz(context, r);
            if (r.playtime) applyPlaytime(r.playtime);
            if (context !== 'playtime_unlock') dlg.close();
            const parts = [`Đúng ${r.correct_count}/${r.total}`];
            if (r.minutes_added) parts.push(`+${r.minutes_added} phút chơi`);
            if (r.energy_bonus) parts.push(`+${r.energy_bonus} ϟ`);
            if (r.xp_awarded) parts.push(`+${r.xp_awarded} XP`);
            if (r.xu_awarded) parts.push(`+${r.xu_awarded} Xu`);
            if (r.srs_cleared) parts.push(`sửa ${r.srs_cleared} lỗi trong Sổ lỗi`);
            toast(`🎓 ${parts.join(' · ')}!`);
          } else {
            const wrong = (r.feedback || []).map((f: any, i: number) => f.is_correct ? '' : `<li>Câu ${i + 1}: đáp án <b>${esc(f.correct_text)}</b>${f.explanation_vi ? ` — ${esc(f.explanation_vi)}` : ''}</li>`).join('');
            fb.innerHTML = `<div class="chie-fail"><p>Đúng ${r.correct_count}/${r.total}. Chưa đạt lần này.</p><ul>${wrong}</ul><p>Câu sai đã vào <b>Sổ lỗi</b> để ôn lại.</p></div>`;
            submit.disabled = false; submit.textContent = 'Làm bộ câu khác';
            submit.onclick = () => void openQuiz(context);
            if (r.playtime) boot!.playtime = { ...boot!.playtime, ...r.playtime };
          }
        } catch (err) {
          fb.innerHTML = `<p class="chie-err">⚠️ ${esc((err as Error).message)}</p>`;
          submit.disabled = false; submit.textContent = 'Thử nộp lại';
        }
      };
    } catch (err) {
      render(`<h3>${TITLES[context]}</h3><p class="chie-err">⚠️ ${esc((err as Error).message)}</p>`);
    }
  }

  function rewardQuiz(context: Ctx, r: any): void {
    if (r.energy_bonus > 0) pendingEnergy += Number(r.energy_bonus) || 0;
    if (!started()) return;
    let next: SaveState;
    try { next = structuredClone(bridge.getState()); } catch { return; }
    const now = Date.now();
    if (context === 'care' && r.speedup_percent > 0) {
      const share = Math.min(0.9, r.speedup_percent / 100);
      for (const plot of next.plots) {
        if (!plot.crop || !(plot.plantedAt > 0)) continue;
        const dur = plot.growDuration || CROPS[plot.crop]?.duration || 0;
        plot.plantedAt -= Math.round(dur * share);
      }
      for (const a of next.farm?.animals ?? []) {
        const def = ANIMALS[a.kind];
        if (!def) continue;
        if (now - a.bornAt < def.growMs) a.bornAt -= Math.round(def.growMs * share);
        else if (def.productMs > 0) a.cycleAt -= Math.round(def.productMs * share);
      }
    }
    if (context === 'space') {
      const exp = now + 15 * 60 * 1000;
      next.buffs = { ...next.buffs, atk: { value: 0.25, expiresAt: exp, source: 'chie_quiz' }, luck: { value: 0.2, expiresAt: exp, source: 'chie_quiz' } };
    }
    if (context === 'cook') {
      next.hp = Math.max(next.hp, maxHp(next));
      next.buffs = { ...next.buffs, regen: { value: 4, expiresAt: now + 10 * 60 * 1000, source: 'chie_quiz' } };
    }
    if (context === 'dungeon') {
      const exp = now + 15 * 60 * 1000;
      next.buffs = { ...next.buffs, def: { value: 15, expiresAt: exp, source: 'chie_quiz' }, atk: { value: 0.15, expiresAt: exp, source: 'chie_quiz' } };
    }
    if (context !== 'playtime_unlock') {
      try { bridge.applyAuthoritativeState(next); bridge.grantGift({ count: 0, energy: 0 }); } catch { /* */ }
    }
  }

  // ---------------------------------------------------------------- nút đố trong hộp thoại của game (Bếp, Hầm ngục) + nhớ vật vừa chạm
  document.addEventListener('click', e => {
    const t = e.target as HTMLElement | null;
    const q = t?.closest<HTMLElement>('[data-chie-quiz]');
    if (q) { e.preventDefault(); e.stopPropagation(); void openQuiz(q.dataset.chieQuiz === 'dungeon' ? 'dungeon' : 'cook'); return; }
    const holder = t?.closest<HTMLElement>('[data-item],[data-crop],[data-fish]');
    const code = holder?.dataset.item || holder?.dataset.crop || holder?.dataset.fish || '';
    if (code && ENGLISH_NAMES.has(code)) { lastTapped.code = code; lastTapped.at = Date.now(); }
  }, true);

  // ---------------------------------------------------------------- từ điển song ngữ + loa TTS
  if (boot.settings?.['zoo.bilingual_labels'] !== false) {
    let hideTimer: number | undefined;
    document.addEventListener('click', e => {
      const t = e.target as HTMLElement | null;
      const say = t?.closest<HTMLElement>('[data-chie-say]');
      if (say) { e.preventDefault(); e.stopPropagation(); speakEnglish(say.dataset.chieSay || '', say.dataset.slow === '1'); return; }
      const holder = t?.closest<HTMLElement>('[data-item],[data-crop],[data-fish]');
      if (!holder || bar.contains(holder) || dlg.contains(holder) || gate.contains(holder)) return;
      const code = holder.dataset.item || holder.dataset.crop || holder.dataset.fish || '';
      const en = ENGLISH_NAMES.get(code);
      if (!en) return;
      const viName = VI_NAMES.get(code) || '';
      const words = EXTRA_WORDS.get(code) || [];
      chip.innerHTML = `<span class="flag">🇬🇧</span><b lang="en">${esc(en)}</b>${viName && getLanguage() === 'vi' ? `<span class="vi">${esc(viName)}</span>` : ''}
        <button type="button" data-chie-say="${esc(en)}" aria-label="Nghe phát âm">🔊</button><button type="button" data-chie-say="${esc(en)}" data-slow="1" aria-label="Nghe chậm">🐢</button>
        ${words.length ? `<span class="words">${words.slice(0, 4).map(w => `<span data-chie-say="${esc(w[0])}">${esc(w[0])} = ${esc(w[1])}</span>`).join(' · ')}</span>` : ''}`;
      chip.hidden = false;
      window.clearTimeout(hideTimer);
      hideTimer = window.setTimeout(() => { chip.hidden = true; }, 6000);
    }, true);
  }

  // ---------------------------------------------------------------- nhắc việc học trên Bảng tin làng
  try {
    if (boot.learning.pending_assignments > 0) bridge.newsNote?.({ icon: '📋', title: `Bạn có ${boot.learning.pending_assignments} bài tập giáo viên giao chưa nộp`, text: `Hoàn thành bài trên CHIE để được tự động +${boot.playtime.lesson_unlock_minutes} phút chơi Nông trại và thêm Xu học tập.` });
    if (boot.learning.due_srs_count > 0) bridge.newsNote?.({ icon: '🎓', title: `Sổ lỗi có ${boot.learning.due_srs_count} mục cần ôn hôm nay`, text: 'Bấm "🎓 Đố từ vựng" trên thanh CHIE để ôn lỗi sai, cây lớn nhanh hơn và nhận thêm Xu + ϟ.' });
  } catch { /* */ }

  updateBar();
  applyPlaytime();
}
