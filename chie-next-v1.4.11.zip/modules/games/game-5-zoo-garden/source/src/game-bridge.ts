import type { SaveState } from './model.ts';
import type { World } from './world.ts';
import type { CombatHit, CombatEffect } from './combat.ts';
import type {GameIntent,ActionReply} from './actions.ts';
export type EnemyStatus='fear'|'charm'|'slow'|'blind'|'sheep'|'taunt'|'stun';
export interface GamePresence { y:number;x:number;z:number;facing:number;planet:string;name:string;color:string;level:number;hp:number;maxHp:number;gear:SaveState['gear'];moving:boolean;visible:boolean;visual?:{size:number;stealth:boolean;shield:boolean;flight:number;bat:boolean} }
export interface GameAction { kind:'basic'|'skill'|'effect'|'swap'|'scenery';/** 'scenery': a hit on breakable scenery (breakables.ts), for the server to decide. */scenery?:{id:string;source:string};/** 'swap': the hand now out (weapon-pair.ts). */hand?:'main'|'side';targetId?:string;index?:number;special?:string;x:number;z:number;facing:number;effect?:unknown }
export interface NetworkHooks {
  role:'host'|'peer'|null;
  visitCrop?:(index:number)=>void;
  reportDamage?:(enemyId:string,source:string)=>void;
  /** The host saw a creature's blow, shot or area reach a summon (owner null: the host's own); the server settles it. */
  reportDecoy?:(ownerId:string|null,decoyId:number,enemyId:string,source:string)=>void;
  hit?:(enemyId:string,damage:number,stun:number,impact?:CombatHit)=>boolean;
  status?:(enemyId:string,kind:EnemyStatus,duration:number)=>boolean;
  moveTarget?:(enemyId:string,x:number,z:number)=>boolean;
  onHostKill?:(enemyId:string,xp:number,boss:boolean,type:string)=>void;
  onRemoteDamage?:(playerId:string,amount:number)=>void;
}
export interface NetworkDrop {id:string;ownerId:string;item:string;count:number;room:string;planet:string;x:number;z:number;owner:string;releaseAt:number;expiresAt:number;thrown?:boolean}
export interface GameBridge {
  spawnNetworkDrop(drop:NetworkDrop,actor:string):void;removeNetworkDrop(id:string):void;releaseNetworkDrop(id:string):void;clearNetworkDrops():void;
  applyAuthorityHealth(delta:number,died:boolean):void;
  getState():SaveState;applyState(next:SaveState):void;getWorld():World;getPresence():GamePresence;
  getOfflineState():SaveState|null;setPersistence(handler:((state:SaveState)=>void)|null):void;
  setActionHandler(handler:((intent:GameIntent)=>Promise<ActionReply>)|null):void;
  applyAuthoritativeState(next:SaveState):void;
  setNetworkHooks(hooks:NetworkHooks):void;
  applyRemoteHit(enemyId:string,damage:number,stun?:number,impact?:CombatHit):void;
  applyRemoteStatus(enemyId:string,kind:EnemyStatus,duration:number):void;
  applyRemoteMove(enemyId:string,x:number,z:number):void;
  applySharedKill(enemyId:string,xp:number,boss:boolean,type?:string):void;
  applyRemoteDamage(amount:number,source?:string):void;
  /** The server's word that one of this explorer's pets guarded it (pet-guard.ts): drawn, never decided, here. */
  applyGuard?(event:import('./pet-guard.ts').GuardEvent):void;
  /** Bond Surge (pet-surge.ts), decided by the server for this explorer's pets. */
  applySurge?(event:import('./pet-surge.ts').SurgeEvent):void;
  /** The server's health count of one of this explorer's summons (0: it popped). */
  applyDecoyHp(id:number,hp:number,kind:string,x:number,z:number):void;
  applyRemoteEffect(effect:CombatEffect):void;
  setVisiting(owner:string|null,homeState?:Partial<SaveState>):void;
  showNotice(text:string):void;
  /** A quiet note in News (news-inbox.ts) for social news that arrives mid-fight instead of a pop-up over the controls. */
  newsNote?(note:{icon:string;title:string;text:string;params?:Record<string,string|number>}):void;
  /** True while a living creature is chasing the explorer (hud-combat.ts aggro): social pop-ups wait for the end of it. */
  inFight?():boolean;
  /** AI neighbours (bots.ts): does the player already have this item; hand over a gift (items and/or energy; false when it cannot be given now); may a neighbour walk up and talk now. */
  /** A neighbour's blow on an enemy (bots.ts): the enemy takes the damage and falls, but a kill pays the player nothing, wherever it happens, and it never touches the player's target ring, hit-stop or HUD. */
  botHit(enemyId:string,damage:number):void;
  /** The daily Colossus neighbours may help against (solo, at home, awake), and a neighbour's blow on it (never rewarded). */
  colossusRally?():{id:string;x:number;z:number;r:number}|null;colossusStrike?(botId:string,damage:number):void;
  ownsItem(id:string):boolean;grantGift(gift:{item?:string;count:number;energy:number}):boolean;botContext():{active:boolean;ready:boolean};
  /** The Delvers' Vault online (dungeon.ts): a dg* message from the server, and the way to send one (null when offline). */
  dungeonMessage?(message:{type:string;[key:string]:unknown}):void;
  setDungeonSender?(send:((message:Record<string,unknown>)=>boolean)|null):void;
  onFrame(listener:(dt:number)=>void):()=>void;
  onAction(listener:(action:GameAction)=>void):()=>void;
}

