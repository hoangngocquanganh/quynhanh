/**
 * CHIE NEXT bridge — phần chạy SỚM NHẤT (import đầu tiên của main.ts).
 *
 * Trang Laravel `/nong-trai/zoo` in dữ liệu khởi tạo vào <script type="application/json" id="chie-zoo-boot">
 * (CSP của CHIE chặn script nội tuyến, nên không dùng window.X = ... trong HTML). Module này:
 *  1. Đọc dữ liệu đó một lần và gắn vào globalThis.CHIE_ZOO_BOOT.
 *  2. Trả về đường dẫn tài nguyên động (cài CHIE ở tên miền gốc hay thư mục con đều đúng).
 *  3. Trước khi game đọc localStorage: tách dữ liệu theo từng học sinh (máy dùng chung),
 *     ép dùng hồ sơ số 1, nạp bản lưu MySQL nếu mới hơn, đặt ngôn ngữ mặc định.
 * Không import module game nào khác để chắc chắn chạy trước i18n.ts và model.ts.
 */

export interface ChiePlaytime {
  gate_enabled: boolean;
  played_seconds: number;
  allowed_seconds: number;
  remaining_seconds: number;
  is_locked: boolean;
  can_unlock_more: boolean;
  unlock_questions_needed: number;
  unlock_minutes_reward: number;
  lesson_unlock_minutes: number;
  max_total_minutes: number;
}

export interface ChieCatalogOverride {
  orig_en?: string | null;
  name_vi?: string | null;
  name_en?: string | null;
  desc_vi?: string | null;
  price?: number | null;
  sell?: number | null;
  level?: number | null;
  grow_seconds?: number | null;
  enabled?: boolean;
  extra?: Record<string, unknown>;
}

import { createGuestStorage } from './guest-storage.ts';

export interface ChieBootPayload {
  guest?: boolean;
  release?: string;
  assetBase: string;
  csrfToken: string;
  endpoints: { boot: string; save: string; exchange: string; quizStart: string; quizSubmit: string; back: string; learn: string };
  student: { id: number; name: string; grade_level: number; xu: number; xp: number; level: number; streak_days: number };
  exchange: { rate: number; daily_cap_xu: number; exchanged_today_xu: number };
  playtime: ChiePlaytime;
  learning: { due_srs_count: number; pending_assignments: number; quiz_correct_today: number; srs_cleared_today: number; tts_default_rate: number; tts_slow_rate: number };
  settings: Record<string, unknown>;
  catalogOverrides: Record<string, Record<string, ChieCatalogOverride>>;
  save: Record<string, unknown> | null;
  revision: number;
}

const SAVE_KEY = 'cute-game-save-v1'; // = model.ts SAVE_KEY (không import để giữ thứ tự chạy)
const SLOT_KEY = 'cute-game-slot';
const LANGUAGE_KEY = 'cute-game-language';
const OWNER_KEY = 'chie-zoo-owner';

let cached: ChieBootPayload | null | undefined;

export function getChieBoot(): ChieBootPayload | null {
  if (cached !== undefined) return cached;
  cached = null;
  const g = globalThis as { CHIE_ZOO_BOOT?: ChieBootPayload };
  if (g.CHIE_ZOO_BOOT && typeof g.CHIE_ZOO_BOOT === 'object') { cached = g.CHIE_ZOO_BOOT; return cached; }
  try {
    const el = typeof document !== 'undefined' ? document.getElementById('chie-zoo-boot') : null;
    if (el?.textContent) { cached = JSON.parse(el.textContent) as ChieBootPayload; g.CHIE_ZOO_BOOT = cached; }
  } catch { cached = null; }
  return cached;
}

/** Thư mục gốc của bản build (luôn kết thúc bằng '/'), ví dụ https://tenmien.vn/chie/assets/zoo-garden/ */
export function getZooAssetBase(): string {
  const custom = getChieBoot()?.assetBase;
  if (typeof custom === 'string' && custom.length > 0) return custom.endsWith('/') ? custom : `${custom}/`;
  const env = (import.meta as { env?: { BASE_URL?: string } }).env;
  return env?.BASE_URL ?? '/';
}

export const chieSetting = <T = unknown>(key: string, fallback: T): T => {
  const v = getChieBoot()?.settings?.[key];
  return (v === undefined || v === null ? fallback : v) as T;
};

function savedAtOf(raw: unknown): number {
  if (!raw || typeof raw !== 'object') return 0;
  const n = Number((raw as { savedAt?: unknown }).savedAt);
  return Number.isFinite(n) ? n : 0;
}

/** Chuẩn bị localStorage cho học sinh đang đăng nhập — chạy ngay khi module được nạp. */
function prepareStorage(): void {
  const boot = getChieBoot();
  if (!boot) return;
  if (boot.guest) {
    // Only this iframe's globals change. The parent/account's browser storage stays untouched.
    Object.defineProperty(globalThis, 'localStorage', { configurable: true, value: createGuestStorage() });
    Object.defineProperty(globalThis, 'sessionStorage', { configurable: true, value: createGuestStorage() });
  }
  let ls: Storage | null = null;
  try { ls = globalThis.localStorage; } catch { ls = null; }
  if (!ls) return;
  try {
    const owner = String(boot.student?.id ?? '');
    if (ls.getItem(OWNER_KEY) !== owner) {
      // Máy dùng chung: xoá dữ liệu game của học sinh khác (giữ ngôn ngữ), bản chính đã nằm trên MySQL.
      const drop: string[] = [];
      for (let i = 0; i < ls.length; i++) {
        const k = ls.key(i);
        if (k && k !== LANGUAGE_KEY && (k.startsWith('cute-game') || k.startsWith('zoo-') || k.startsWith('zoo_'))) drop.push(k);
      }
      drop.forEach(k => ls!.removeItem(k));
      ls.setItem(OWNER_KEY, owner);
    }
    ls.setItem(SLOT_KEY, '0'); // một tài khoản CHIE = một hồ sơ game
    if (boot.save && typeof boot.save === 'object') {
      let local: unknown = null;
      try { local = JSON.parse(ls.getItem(SAVE_KEY) || 'null'); } catch { local = null; }
      if (!local || savedAtOf(boot.save) >= savedAtOf(local)) {
        const copy = { ...boot.save, name: String(boot.student?.name ?? '').slice(0, 20) || (boot.save as { name?: string }).name };
        ls.setItem(SAVE_KEY, JSON.stringify(copy));
      }
    }
    if (!ls.getItem(LANGUAGE_KEY)) ls.setItem(LANGUAGE_KEY, boot.settings?.['zoo.default_language'] === 'en' ? 'en' : 'vi');
  } catch { /* bộ nhớ trình duyệt bị chặn: game vẫn chơi được, đồng bộ qua máy chủ */ }
}

prepareStorage();

/** Nút đố Tiếng Anh chèn vào hộp thoại của game (Bếp, Người gác hầm ngục). Chuỗi rỗng khi chạy ngoài CHIE. */
export function chieQuizButton(context: 'cook' | 'dungeon'): string {
  const boot = getChieBoot();
  if (!boot || boot.guest) return '';
  const label = context === 'cook'
    ? '🍳 Đầu bếp Tiếng Anh — đố 3 câu: món hồi máu + ϟ + XP/Xu CHIE'
    : '📜 Thử thách của Người gác hầm — đố 3 câu: +phòng thủ, +sát thương 15 phút';
  return `<button type="button" class="soft-button wide chie-inline-quiz" data-chie-quiz="${context}">${label}</button>`;
}
