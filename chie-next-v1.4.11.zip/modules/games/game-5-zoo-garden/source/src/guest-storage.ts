/** Per-frame volatile storage: guest play must never read or overwrite a saved account. */
export function createGuestStorage(): Storage {
  const values = new Map<string, string>();
  return {
    get length() { return values.size; },
    key(index: number) { return Array.from(values.keys())[index] ?? null; },
    getItem(key: string) { return values.get(String(key)) ?? null; },
    setItem(key: string, value: string) { values.set(String(key), String(value)); },
    removeItem(key: string) { values.delete(String(key)); },
    clear() { values.clear(); },
  };
}
