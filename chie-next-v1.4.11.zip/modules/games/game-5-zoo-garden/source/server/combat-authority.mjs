import {randomUUID} from 'node:crypto';
import * as Game from '../src/model.ts';
import {ContextGearSelection} from '../src/context-gear.ts';
import {WeaponPair,sideGun,withHand} from '../src/weapon-pair.ts';
import {CombatSimulation,BASE_SKILLS,SPECIALS,DZ,shareableDecoys,decoyPoint} from '../src/combat.ts';
import {ENEMY_TYPES} from '../src/enemy-types.ts';
import {enemyRoster} from '../src/enemy-roster.ts';
import {zoneAt,createEnvironmentLayout,EnvironmentSimulation} from '../src/environments.ts';
import {sanitizeTitanAttacks,beginTitanAttack,stepTitanAttack,titanTelegraphs,isTitanSkill} from '../src/titan-patterns.ts';
import {BOSS_SKILLS,BOSS_WINDUPS,bossTelegraphs,bossPhase,hitControl,BOSS_RESISTED,RESIST_SLOW,liftHeight} from '../src/boss-patterns.ts';
import {atHome,homeRecoveryBonus} from '../src/home-care.ts';
import {chargeTouches} from '../src/boss-body.ts';
import {newStagger,staggerDamage,staggerHit,staggerView} from '../src/boss-stagger.ts';
import {SPLIT,barrierHit,childSpot,newBarrier,splitChildren,stepBarrier} from '../src/elite-roles.ts';
import {eliteDefeat} from '../src/elite-rewards.ts';
import {trailSpot,dogTossFactor,DOG_TOSS_CD} from '../src/guard-dog.ts';
import {companionId,dogWorn} from '../src/pet-slots.ts';
import {DOG_GUARD,petFighter} from '../src/pet-guard.ts';
import {SURGE} from '../src/pet-surge.ts';
import {commandHash} from './action-service.mjs';
import {gearFactor,skillLevel,skillCooldown} from '../src/upgrades.ts';
import {clearJourney} from './adventure-lifecycle.mjs';
import {inSafeZone} from '../src/safe-zone.ts';
import {noteProgress} from './ranking.mjs';
import {createColossusAuthority} from './colossus-authority.mjs';
import {COLOSSUS_STATS,COLOSSUS_TYPE} from '../src/colossus-content.ts';
import {colossusDamage} from '../src/colossus-patterns.ts';
import {grantColossusReward} from '../src/colossus-rewards.ts';
import {BREAK_PLANET,BreakLedger,breakClass,parsePieceId,inReach,bossHolds,fighting,grantBreakDrop,hitWorth} from '../src/breakables.ts';

const dist=(a,b)=>Math.hypot(a.x-b.x,a.z-b.z);
const finite=(value,fallback=0,min=-160,max=160)=>Number.isFinite(value)?Math.max(min,Math.min(max,value)):fallback;
// A boss's stagger meter (boss-stagger.ts) goes out as its share and the seconds left on its knees, never the server's clock.
const snapshot=enemy=>{const {roster,home,changedAt,deadUntil,generation,pending,contributors,scaled,damageAt,cast,nextCastAt,hostPhase,hostAttackCount,combatAttacks,lastHitAt,stagger,...publicState}=enemy;return {...publicState,...(stagger?{stagger:staggerView(stagger,Date.now()/1000)}:{}),chaseGrace:Math.max(0,Math.min(4,((lastHitAt||0)+4000-Date.now())/1000))};};
const STATUS=['fear','charm','slow','blind','sheep','taunt'];

/** The browser host animates navigation; the server owns HP, skill timing, stats, kills and rewards. */
export function createCombatAuthority({store,peers,rooms,remember,send,broadcast,onDeath=()=>{},onError=()=>{},colossusClock,sceneryRandom=Math.random}){
  const engines=new Map(),queues=new Map();let stopped=false;
  // The daily world boss in home rooms (colossus-authority.mjs); its hits, kill and rewards go through the paths below.
  const colossus=createColossusAuthority({send,broadcast,peers,...(colossusClock?{clock:colossusClock}:{})});colossus.setMaxHp(peer=>Game.maxHp(peer.account.profile));
  function queue(id,task){const next=(queues.get(id)||Promise.resolve()).catch(()=>{}).then(task);queues.set(id,next);return next;}
  async function internal(actorId,type,relatedIds,run,requestId=randomUUID(),outbox=true,retryContext={}){
    return queue(actorId,async()=>{
      for(let retry=0;retry<5;retry++){
        const account=await store.get(actorId);if(!account)return null;
        // Health retains this context with its batch even when commit succeeded but publishing the reply failed.
        retryContext.originalRevision??=account.profileRevision||0;
        try{
          const committed=await store.command({actorId,requestId,hash:commandHash({type,requestId}),expectedRevision:account.profileRevision||0,originalRevision:retryContext.originalRevision,actionType:type,relatedIds,run,outbox});
          // A successful commit may outlive its connection. Receipt replay has no changed
          // records, but connected peers still need the persisted HP and life metadata.
          if(committed.reply.replayed)committed.accounts=(await Promise.all([...new Set([actorId,...relatedIds])].map(id=>store.get(id)))).filter(Boolean);
          committed.accounts.forEach(value=>{const current=remember(value),peer=peers.get(value.id);if(peer)send(peer.socket,{type:'profile',profile:current.profile,revision:current.profileRevision,authorityVersion:1});});
          return committed;
        }catch(error){if(error.status===409&&retry<4)continue;throw error;}
      }
    });
  }
  function state(room){if(!room.combat){const planet=room.id.split(':').at(-1),environment=new EnvironmentSimulation(createEnvironmentLayout(planet));environment.time=Date.now()/1000;environment.weather.time=environment.time;room.combat={planet,roster:new Map(enemyRoster(planet).map(e=>[e.id,e])),enemies:new Map(),environment,id:randomUUID(),at:Date.now(),lastBroadcast:0};}return room.combat;}
  function publish(room){
    const now=Date.now();
    for(const enemy of state(room).enemies.values())if(enemy.combatAttacks){
      enemy.titanAttacks=enemy.combatAttacks.filter(c=>!c.done&&c.attack).map(c=>structuredClone(c.attack));
      const pending=enemy.combatAttacks.find(c=>!c.done&&now<c.startsAt);
      if(pending){enemy.phase='windup';enemy.phaseTime=(pending.startsAt-now)/1000;enemy.skill=pending.skill;enemy.telegraphs=pending.marks.map(mark=>({...mark}));}
    }
    room.enemies=[...state(room).enemies.values()].map(snapshot);
  }
  function health(room,enemy,impact){publish(room);broadcast(room,{...snapshot(enemy),type:'enemyHealth',enemyType:enemy.type,impact,...(impact?{impactId:randomUUID()}:{})});}
  const aliveTargets=room=>[...room.members].map(id=>peers.get(id)).filter(p=>p&&p.active&&!p.visit&&p.account.profile.hp>0&&!inSafeZone(p.pose,p.planet));
  const randomFor=seed=>()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296;};
  function observeCast(room,enemy,raw,now){
    const previousPhase=enemy.hostPhase,previousCount=enemy.hostAttackCount;enemy.hostPhase=raw.phase;enemy.hostAttackCount=raw.attackCount;
    const skill=raw.skill;if(!enemy.boss||raw.phase!=='windup'||!BOSS_SKILLS[enemy.type]?.includes(skill)||enemy.hp<=0||now<(enemy.nextCastAt||0)||previousPhase==='windup'&&previousCount===raw.attackCount)return;
    const targets=aliveTargets(room),target=targets.sort((a,b)=>dist(a.pose,enemy)-dist(b.pose,enemy))[0];if(!target||dist(target.pose,enemy)>35)return;
    const source={x:enemy.x,z:enemy.z,radius:enemy.radius,facing:finite(raw.facing,enemy.facing||0,-100,100)},players=targets.map(p=>({id:p.account.id,x:p.pose.x,z:p.pose.z,airborne:engineFor(p).sim.statuses.flight>0}));
    const telegraphPhase=enemy.type==='dragon'?bossPhase(enemy.hp,enemy.maxHp):enemy.hp<enemy.maxHp*.5?2:1;
    const marks=isTitanSkill(skill)?titanTelegraphs(skill,source,target.pose,players,randomFor((raw.attackCount||1)*91571)):bossTelegraphs(skill,source,target.pose,telegraphPhase,raw.attackCount||1);
    if(skill==='rain')for(const p of players)if(dist(p,target.pose)>.05&&dist(p,enemy)<22)marks.push(...bossTelegraphs(skill,source,p,telegraphPhase,(raw.attackCount||1)+marks.length));
    const phase=enemy.type==='dragon'?bossPhase(enemy.hp,enemy.maxHp):1;
    if(phase>=2&&(skill==='slam'||skill==='rain')){
      const random=randomFor((raw.attackCount||1)*9127),environment=state(room).environment;
      players.filter(p=>dist(p,enemy)<=25).forEach((p,index)=>{for(let i=0;i<(phase>=3?5:3);i++){const angle=random()*Math.PI*2,r=random()*4;environment.addFireRain({x:p.x+Math.cos(angle)*r,z:p.z+Math.sin(angle)*r},`dragon:${enemy.generation}:${raw.attackCount}:${index}:${i}`);}});
    }
    const windup=BOSS_WINDUPS[skill]*(enemy.hp<enemy.maxHp*.3?.8:1),cooldown=ENEMY_TYPES[enemy.type].cooldown*(enemy.hp<enemy.maxHp*.5?.7:1)*(enemy.hp<enemy.maxHp*.3?.6:1)*(phase>=3?.8:1);
    enemy.cast={skill,source,marks,startsAt:now+windup*1000,elapsed:0,fired:[],shots:[],attack:null};
    // A new wind-up must not erase lingering orbs, poison pools or shockwaves.
    (enemy.combatAttacks??=[]).push(enemy.cast);enemy.nextCastAt=now+(windup+cooldown)*1000;
  }
  /** True when a hit would land on `peer` now: nothing hurts an explorer standing in the safe zone round the cottage (safe-zone.ts), whatever the host reports. */
  function vulnerable(peer,source){const e=engineFor(peer);return !(peer.visit||!peer.active||peer.account.profile.hp<=0||inSafeZone(peer.pose,peer.planet)||Date.now()-e.damageAt<550||e.sim.invulnerable||source==='melee'&&e.sim.statuses.flight>0);}
  function hurtPlayer(peer,amount,source='melee'){
    const e=engineFor(peer),now=Date.now();
    if(!vulnerable(peer,source))return;
    // Bloom's ward (pet-surge.ts): hazards pass by for a few seconds.
    if(source==='hazard'&&e.sim.statuses.ward>0)return;
    e.damageAt=now;const defense=Game.defense(combatProfile(peer))+e.sim.defenseBonus+(e.sim.statuses.armor>0?80:0);let loss=Math.max(1,Math.round(amount*60/(defense+60)));
    // Phoenix rebirth (pet-surge.ts): a blow that would knock the explorer out leaves SURGE.revive of full health instead, once in five minutes.
    {const max=Game.maxHp(peer.account.profile);let hpNow=peer.account.profile.hp;for(const event of e.healthEvents)hpNow+=event.amount;if(hpNow-loss<=0&&e.sim.surge.revive()){loss=Math.max(0,hpNow-Math.max(1,Math.round(max*SURGE.revive)));send(peer.socket,{type:'surge',event:{slot:e.sim.surge.slot,phase:'big',sig:'rebirth',x:peer.pose.x,z:peer.pose.z,revived:true}});if(!(loss>0))return;}}
    hp(peer,-loss,source);
  }
  function hurtEnemyTarget(peer,enemy,multiplier,source='melee'){
    // The knight's raised shield, facing the creature, stops the blow; a shot it stops flies back and hits the shooter (combat.reflect).
    const sim=engineFor(peer).sim;if(sim.blocks(enemy)){if(source==='shot'&&!peer.visit&&peer.active)sim.reflect(enemy,dist(peer.pose,enemy)/DZ.block.speed);return;}
    // The explorer's own pets guard it (pet-guard.ts): the server's copy of the rules decides what is left of the hit.
    // Only a hit that would land spends a guard, and only this explorer's pets are asked: nobody else's protect it.
    if(!vulnerable(peer,source))return;const left=sim.guardIncoming(enemy.damage*multiplier,source,enemy);if(!(left>0))return;
    hurtPlayer(peer,left,source);
  }
  /**
   * A creature's blow, shot or area reached one of `peer`'s summons (the room host reports it; combat.ts SUMMON_HP).
   * The server's own copy of the summon decides: the reported id, else the same explorer's live summon nearest the
   * creature; it must be within the creature's reach (a shot: its flight). Its new health goes to its explorer.
   */
  function hurtDecoy(peer,enemy,decoyId,multiplier,source='melee',trusted=false){
    if(peer.visit||!peer.active)return false;const sim=engineFor(peer).sim,list=sim.decoys();if(!list.length)return false;
    const def=ENEMY_TYPES[enemy.type],reach=source==='shot'?20:(def?.reach??1.5)+enemy.radius+3;
    const near=d=>trusted||dist(decoyPoint(d,enemy),enemy)<=reach+d.r;
    const decoy=list.find(d=>d.id===decoyId&&near(d))??list.filter(near).sort((a,b)=>dist(decoyPoint(a,enemy),enemy)-dist(decoyPoint(b,enemy),enemy))[0];
    if(!decoy)return false;sim.hurtAlly(decoy.id,enemy.damage*multiplier);
    const left=sim.allies.find(a=>a.id===decoy.id)?.hp??0;send(peer.socket,{type:'decoyHp',id:decoy.id,kind:decoy.kind,x:decoy.x,z:decoy.z,hp:left});return true;
  }
  /** The summons `peer` shares with the room (server.mjs pose), from the server's own simulation, checked by combat.ts shareableDecoys. */
  function decoys(peer){return peer.visit||!peer.active?[]:shareableDecoys(engineFor(peer).sim.decoys(),peer.pose);}
  /** A Colossus blow: the same gates as hurtPlayer, through only a quarter of the defence (colossusDamage). */
  function hurtColossus(peer,multiplier,factor,roll){
    const e=engineFor(peer),now=Date.now();if(peer.visit||!peer.active||peer.account.profile.hp<=0||inSafeZone(peer.pose,peer.planet)||now-e.damageAt<550||e.sim.invulnerable)return false;
    e.damageAt=now;const defense=Game.defense(combatProfile(peer))+e.sim.defenseBonus+(e.sim.statuses.armor>0?80:0);hp(peer,-colossusDamage(COLOSSUS_STATS.atk,multiplier,defense,factor,roll),'melee');return true;
  }
  function updateCast(room,enemy,dt,now){
    if(enemy.hp<=0||enemy.pending)return;
    for(const cast of enemy.combatAttacks??[])updateAttack(room,enemy,cast,dt,now);
    enemy.combatAttacks=(enemy.combatAttacks??[]).filter(c=>!c.done);enemy.cast=enemy.combatAttacks.at(-1)??null;
  }
  function updateAttack(room,enemy,c,dt,now){
    if(now<c.startsAt)return;
    const targets=aliveTargets(room),points=targets.map(p=>({id:p.account.id,x:p.pose.x,z:p.pose.z,airborne:engineFor(p).sim.statuses.flight>0}));c.elapsed+=dt;
    const once=(id,time,fn)=>{if(c.elapsed>=time&&!c.fired.includes(id)){c.fired.push(id);fn();}};
    const area=(p,r,multiplier,source='melee',inner=-1)=>{for(const peer of targets){const d=dist(peer.pose,p);if(d<r&&d>inner)hurtEnemyTarget(peer,enemy,multiplier,source);for(const decoy of engineFor(peer).sim.decoys()){const q=dist(decoyPoint(decoy,p),p);if(q<r&&q>inner)hurtDecoy(peer,enemy,decoy.id,multiplier,source,true);}}};
    if(isTitanSkill(c.skill)){
      c.attack??=beginTitanAttack(c.skill,c.source,c.marks,points);const result=stepTitanAttack(c.attack,dt,enemy,points);
      for(const hit of result.hits){const target=peers.get(hit.id);if(target?.room===room.id)hurtEnemyTarget(target,enemy,hit.multiplier,hit.source);}
      if(result.move){enemy.x=result.move.x;enemy.z=result.move.z;enemy.titanLift=result.move.y;}
      if(result.summon)[...state(room).enemies.values()].filter(e=>e!==enemy&&e.hp>0&&!e.pending&&!e.roster.dormant&&!e.boss&&ENEMY_TYPES[e.type].speed>0&&dist(e,enemy)<60).slice(0,4).forEach((e,i)=>{const angle=c.source.facing+(i+.5)*Math.PI/2;e.x=enemy.x+Math.sin(angle)*(enemy.radius+2);e.z=enemy.z+Math.cos(angle)*(enemy.radius+2);e.hp=e.maxHp;e.damage*=1.3;e.phase='chase';e.lastHitAt=now;health(room,e);});
      if(result.done){c.done=true;if(c.skill==='leap')enemy.titanLift=0;}return;
    }
    if(c.skill==='slam')once(0,0,()=>area(enemy,4.8,1.6));
    if(c.skill==='rain')once(0,0,()=>{for(const mark of c.marks)area(mark,mark.r,1.3,'shot');});
    if(c.skill==='quake')for(let i=0;i<3;i++)once(i,.12+i*.32,()=>area(c.source,3+i*3+.4,1.1,'melee',3+i*3-2.4));
    if(c.skill==='eclipse')once(0,0,()=>{area(enemy,7,.9,'shot');state(room).environment.eclipseUntil=state(room).environment.time+6;});
    if(c.skill==='charge'&&c.elapsed<.8)for(const peer of targets)if(chargeTouches(enemy.type,enemy.radius,enemy.x,enemy.z,enemy.facing||0,peer.pose.x,peer.pose.z)&&!c.fired.includes(peer.account.id)){c.fired.push(peer.account.id);hurtEnemyTarget(peer,enemy,1.3);}
    if(c.skill==='spin'&&c.elapsed<2.4)once(Math.floor(c.elapsed/.35),0,()=>area(enemy,3.4,.5));
    if(c.skill==='barrage'){
      once(0,0,()=>{const count=enemy.hp<enemy.maxHp*.5?20:14;for(let i=0;i<count;i++){const a=i/count*Math.PI*2+c.source.facing;c.shots.push({x:c.source.x,z:c.source.z,vx:Math.sin(a)*13,vz:Math.cos(a)*13,life:1.4});}});
      for(const shot of c.shots){const from={x:shot.x,z:shot.z};shot.x+=shot.vx*dt;shot.z+=shot.vz*dt;shot.life-=dt;for(const peer of targets)if(shot.life>0&&segmentDistance(peer.pose,from,shot)<.65){hurtEnemyTarget(peer,enemy,1,'shot');shot.life=0;}}
    }
    if(c.elapsed>3)c.done=true;
  }
  function segmentDistance(p,a,b){const x=b.x-a.x,z=b.z-a.z,l=x*x+z*z,f=l?Math.max(0,Math.min(1,((p.x-a.x)*x+(p.z-a.z)*z)/l)):0;return Math.hypot(p.x-a.x-x*f,p.z-a.z-z*f);}
  /** The spawn point a creature returns to (rescue checks, respawns): the host's reported homeX/homeZ, taken once, only
   * when it lies within the creature's leash of where it is now, inside the world and in its own zone; else where it was
   * first seen. A peer reconnecting mid-chase thus still gets the true spawn instead of a point along the chase. */
  function spawnHome(roster,raw,planet){
    const home={x:raw.homeX,z:raw.homeZ},leash=roster.type==='dragon'?75:30;
    if(!Number.isFinite(home.x)||!Number.isFinite(home.z)||Math.hypot(home.x,home.z)>155||dist(home,raw)>leash+2)return {x:raw.x,z:raw.z};
    if(!roster.dormant&&(Math.hypot(home.x,home.z)<22||planet==='home'&&zoneAt(home)!==roster.zone))return {x:raw.x,z:raw.z};
    return home;
  }
  /** Hard difficulty follows the room host (difficulty.ts hardScale): when the host or the host's setting changes, the
   * live creatures are rescaled by the ratio, keeping each one's share of health. */
  function rescale(room,s){
    const next=Game.hardScale(peers.get(room.host)?.account.profile),old=s.scale??next;s.scale=next;
    if(old.hp===next.hp&&old.damage===next.damage)return;
    const hp=next.hp/old.hp,damage=next.damage/old.damage;
    for(const enemy of s.enemies.values()){enemy.baseMaxHp=Math.round(enemy.baseMaxHp*hp);enemy.maxHp=Math.round(enemy.maxHp*hp);enemy.hp=Math.min(enemy.maxHp,Math.round(enemy.hp*hp));enemy.baseDamage*=damage;enemy.damage*=damage;if(enemy.hp>0)health(room,enemy);}
  }
  function acceptSnapshots(room,incoming){
    const s=state(room),now=Date.now();rescale(room,s);
    for(const raw of incoming.slice(0,300)){
      const roster=s.roster.get(raw?.id);if(!roster||raw.type!==roster.type||!Number.isFinite(raw.x)||!Number.isFinite(raw.z)||Math.hypot(raw.x,raw.z)>155)continue;
      let enemy=s.enemies.get(roster.id);
      if(!enemy){
        if(!roster.dormant&&(Math.hypot(raw.x,raw.z)<22||s.planet==='home'&&zoneAt(raw)!==roster.zone))continue;
        // Hard difficulty: the room host's save (whose browser spawns the creatures) sets health and damage (difficulty.ts).
        const scale=s.scale,baseMaxHp=Math.round(roster.baseMaxHp*scale.hp),baseDamage=roster.baseDamage*scale.damage;
        enemy={...roster,roster,baseMaxHp,baseDamage,home:spawnHome(roster,raw,s.planet),x:raw.x,z:raw.z,hp:roster.dormant?0:baseMaxHp,maxHp:baseMaxHp,damage:baseDamage,respawn:roster.dormant?999999:0,deadUntil:roster.dormant?Infinity:0,generation:0,contributors:new Map(),changedAt:now,statuses:{},shots:[]};s.enemies.set(roster.id,enemy);
      }
      const elapsed=Math.max(.1,(now-enemy.changedAt)/1000),maximum=(ENEMY_TYPES[roster.type].speed+16)*elapsed+2;
      if(dist(enemy,raw)<=maximum){enemy.x=raw.x;enemy.z=raw.z;}
      enemy.changedAt=now;observeCast(room,enemy,raw,now);
      // Only visual/AI state comes from the elected browser. Combat quantities are canonical.
      Object.assign(enemy,{y:finite(raw.y,0,-30,50),facing:finite(raw.facing,0,-100,100),phase:typeof raw.phase==='string'?raw.phase.slice(0,24):'idle',phaseTime:finite(raw.phaseTime,0,0,60),lift:finite(raw.lift,0,0,20),liftVelocity:finite(raw.liftVelocity,0,-30,30),cooldown:finite(raw.cooldown,0,0,60),targetX:finite(raw.targetX,enemy.x),targetZ:finite(raw.targetZ,enemy.z),skill:typeof raw.skill==='string'?raw.skill.slice(0,40):'',bossStage:finite(raw.bossStage,0,0,4),attackCount:finite(raw.attackCount,0,0,1e9),skillCount:finite(raw.skillCount,0,0,1e9),spinTick:finite(raw.spinTick,0,0,10),titanAttacks:sanitizeTitanAttacks(raw.titanAttacks),titanLift:finite(raw.titanLift,0,0,20)});
      for(const key of ['telegraphs','skillEffects'])enemy[key]=(Array.isArray(raw[key])?raw[key]:[]).slice(0,64).map(v=>({x:finite(v?.x),z:finite(v?.z),r:finite(v?.r,1,0,80),delay:finite(v?.delay,0,0,60),inner:finite(v?.inner,0,0,80),remaining:finite(v?.remaining,0,0,60),multiplier:finite(v?.multiplier,1,0,6)}));
      enemy.shots=(Array.isArray(raw.shots)?raw.shots:[]).slice(0,30).filter(v=>typeof v?.id==='string').map(v=>({id:v.id.slice(0,100),x:finite(v.x),y:finite(v.y,1,-30,50),z:finite(v.z),vx:finite(v.vx,0,-100,100),vz:finite(v.vz,0,-100,100),life:finite(v.life,0,0,60),damage:enemy.damage,targetEnemyId:typeof v.targetEnemyId==='string'?v.targetEnemyId.slice(0,100):undefined}));
      // The same marks drive damage and the warning shown to every browser, including
      // the host. Preserve Titan safe rings, sequence indices and sweep angles.
      if(enemy.cast&&now<enemy.cast.startsAt){enemy.phase='windup';enemy.phaseTime=(enemy.cast.startsAt-now)/1000;enemy.skill=enemy.cast.skill;enemy.telegraphs=enemy.cast.marks.map(mark=>({...mark}));}
    }
    publish(room);return room.enemies;
  }
  function kill(room,enemy,killer,execute=false){
    if(enemy.pending)return;enemy.pending=true;const now=Date.now(),requestId=randomUUID(),killPoint={x:enemy.x,z:enemy.z},killerEpoch=epoch(killer.account),contributorEpochs=new Map([...room.members].map(id=>[id,peers.get(id)?.account.adventureEpoch||0]));
    const contributors=[...enemy.contributors].filter(([id,at])=>now-at<(enemy.type===COLOSSUS_TYPE?3600000:30000)&&room.members.has(id)&&peers.get(id)?.planet===state(room).planet).map(([id])=>id);
    if(!contributors.includes(killer.account.id))contributors.push(killer.account.id);
    internal(killer.account.id,'combatKill',contributors,records=>{
      // The Hard bonus follows the room's creatures (the host's scale), not each contributor's own setting.
      let loot=[];const bonus=Game.scaleReward(state(room).scale);
      for(const id of contributors){const account=records.get(id);if(!account||(account.adventureEpoch||0)!==contributorEpochs.get(id))continue;const before=account.profile,profile=Game.parseSave(JSON.stringify(account.profile));if(!profile)continue;
        const rolled=enemy.type===COLOSSUS_TYPE?grantColossusReward(profile,id===killer.account.id,Math.random,false,bonus):enemy.elite?eliteDefeat(profile,enemy.type,enemy.roster.xp,enemy.elite,Math.random,false,bonus):Game.grantDefeat(profile,enemy.type,enemy.roster.xp,enemy.boss,Math.random,false,bonus);if(id===killer.account.id)loot=rolled;
        if(execute&&id===killer.account.id&&(account.lifeEpoch||0)===killerEpoch.life)profile.hp=Math.min(Game.maxHp(profile),profile.hp+Game.maxHp(profile)*.25);
        account.profile=profile;noteProgress(account,before,profile,now); // weekly leaderboard counters (ranking.mjs)
      }
      const owner=records.get(killer.account.id);if(!owner||(owner.adventureEpoch||0)!==killerEpoch.adventure)return {enemyId:enemy.id,drops:[],execute:false};owner.drops=(owner.drops||[]).filter(d=>d.expiresAt>now);
      const drops=loot.map(item=>({id:randomUUID(),ownerId:owner.id,item:item.id,count:item.count,room:room.id,planet:state(room).planet,x:killPoint.x,z:killPoint.z,owner:owner.id,releaseAt:now+10000,expiresAt:now+30000}));owner.drops.push(...drops);
      return {enemyId:enemy.id,drops,execute};
    },requestId).then(committed=>{
      if(!committed)throw new Error('Missing killer');enemy.pending=false;enemy.hp=0;enemy.stagger=undefined;enemy.deadUntil=Date.now()+enemy.roster.respawn*1000;enemy.respawn=enemy.roster.respawn;enemy.titanAttacks=[];enemy.shots=[];enemy.skillEffects=[];enemy.telegraphs=[];enemy.combatAttacks=[];enemy.cast=null;
      room.killed.add(enemy.id);health(room,enemy);broadcast(room,{type:'defeat',id:enemy.id,by:contributors,eventId:requestId});colossus.killed(room,enemy,killer.account.id);
      for(const drop of committed.reply.result.drops)broadcast(room,{type:'dropSpawn',drop});
      if(execute&&committed.reply.result.execute)send((peers.get(killer.account.id)||killer).socket,{type:'executeResult',id:enemy.id,requestId,ok:true,profile:committed.reply.profile,revision:committed.reply.revision});
      if(enemy.type==='magmaslime')for(const [i,minion] of [...state(room).enemies.values()].filter(e=>e.type==='minislime'&&e.hp<=0&&!e.pending).slice(0,3).entries()){minion.x=enemy.x+Math.cos(i*Math.PI*2/3)*.9;minion.z=enemy.z+Math.sin(i*Math.PI*2/3)*.9;minion.hp=minion.maxHp;minion.deadUntil=0;minion.respawn=0;minion.generation++;health(room,minion);}
      // An elite splitter (elite-roles.ts): the server wakes its children, as for the magma slime; none at the live cap.
      if(enemy.elite){const kids=splitChildren(enemy,[...state(room).enemies.values()]),depth=(enemy.elite==='mini'?enemy.depth??1:0)+1;kids.forEach((m,i)=>{const at=childSpot(enemy.x,enemy.z,i,kids.length);m.x=at.x;m.z=at.z;m.parentId=enemy.elite==='mini'?enemy.parentId:enemy.id;m.depth=depth;m.maxHp=Math.max(1,Math.round(m.baseMaxHp*(depth>=2?SPLIT.tiny.hp:1)));m.hp=m.maxHp;m.deadUntil=0;m.respawn=0;m.generation++;m.contributors.clear();health(room,m);});}
    }).catch(()=>{enemy.pending=false;enemy.hp=Math.max(1,enemy.hp);health(room,enemy);send(killer.socket,{type:'error',message:'The reward could not be saved. Please try again.'});});
  }
  function hit(peer,enemy,impact,execute=false,hazard=false){
    const room=rooms.get(peer.room);if(!room||peer.visit||enemy.hp<=0||enemy.pending)return 0;
    if(!enemy.scaled&&enemy.boss){const players=[...room.members].map(id=>peers.get(id)).filter(p=>p&&!p.visit&&dist(p.pose,enemy)<28),level=Math.max(...players.map(p=>p.account.profile.level),1),difference=Math.max(0,level-enemy.roster.level);enemy.maxHp=Math.round(enemy.baseMaxHp*(1+.6*Math.max(0,players.length-1))*(enemy.type==='dragon'?1:1+difference*.12));enemy.hp=enemy.maxHp;enemy.damage=enemy.baseDamage*(enemy.type==='dragon'?1:(1+difference*.07)*(1+.1*Math.max(0,players.length-1)));enemy.scaled=true;}
    // An elite's crystal barrier (elite-roles.ts SHIELD): shots are deflected, close hits crack it, a heavy hit breaks it (and stuns).
    if(!hazard&&!execute&&enemy.elite==='shielded'){const r=barrierHit(enemy.barrier??=newBarrier(),impact.amount,impact.source);impact={...impact,amount:r.event==='deflect'?Math.max(1,Math.round(r.amount)):r.amount,stun:Math.max(impact.stun||0,r.stun),barrier:r.event};}
    const control=hitControl(enemy.boss,impact.stun||0);
    if(!hazard&&!execute&&enemy.type==='magmaturtle')impact={...impact,amount:impact.amount*(enemy.phase==='recover'?2:.12)};
    if(enemy.type===COLOSSUS_TYPE&&!hazard)impact={...impact,amount:colossus.incoming(room,enemy,peer,impact.amount)};
    // The stagger meter (boss-stagger.ts, the same rule as solo): a kneeling boss takes more, heavy blows and criticals fill it.
    let broke=false;if(enemy.boss&&enemy.type!==COLOSSUS_TYPE&&!hazard&&!execute){const st=enemy.stagger??=newStagger(),sec=Date.now()/1000;impact={...impact,amount:staggerDamage(st,sec,impact.amount)};broke=staggerHit(st,impact,sec,!!enemy.titan)==='break';}
    const dealt=Math.min(enemy.hp,Math.max(0,impact.amount));enemy.contributors.set(peer.account.id,Date.now());enemy.lastHitAt=Date.now();enemy.hp-=dealt;enemy.stun=Math.max(enemy.stun||0,control.stun);
    if(control.slow)enemy.statuses.slow=Math.max(enemy.statuses.slow||0,control.slow);
    if(impact.lift>0){enemy.liftVelocity=Math.max(enemy.liftVelocity||0,Math.sqrt(liftHeight(enemy.boss,impact.lift)*24));enemy.stun=Math.max(enemy.stun||0,.8);enemy.phase='chase';enemy.telegraphs=[];enemy.combatAttacks=(enemy.combatAttacks??[]).filter(c=>c.attack||c.elapsed>0);enemy.cast=enemy.combatAttacks.at(-1)??null;}
    // A break kneels the boss: a stun the host's creature AI obeys, and the wind-up and skill it was on are cancelled, as for a launch.
    if(broke&&enemy.hp>0){enemy.stun=Math.max(enemy.stun||0,enemy.stagger.until-Date.now()/1000);enemy.phase='chase';enemy.telegraphs=[];enemy.combatAttacks=(enemy.combatAttacks??[]).filter(c=>c.attack||c.elapsed>0);enemy.cast=enemy.combatAttacks.at(-1)??null;impact={...impact,brk:true};}
    if(enemy.hp<=0){enemy.hp=1;kill(room,enemy,peer,execute);}health(room,enemy,impact);return dealt;
  }
  const epoch=account=>({adventure:account.adventureEpoch||0,life:account.lifeEpoch||0});
  function hp(peer,amount,source){
    if(!Number.isFinite(amount)||!amount||peer.visit)return;const engine=engineFor(peer),now=Date.now(),context=epoch(peer.account);
    const last=engine.healthEvents.at(-1);
    if(last&&last.adventure===context.adventure&&last.life===context.life&&last.planet===peer.planet&&Math.sign(last.amount)===Math.sign(amount)&&now-last.at<100)last.amount+=amount;
    else engine.healthEvents.push({...context,amount,source,at:now,planet:peer.planet,x:peer.pose.x,z:peer.pose.z});
  }
  function flushHealth(engine){
    if(engine.pendingHealth?.flushing)return engine.pendingHealth.promise;
    if(!engine.pendingHealth&&!engine.healthEvents.length)return Promise.resolve(true);
    const batch=engine.pendingHealth??={events:engine.healthEvents.splice(0),requestId:randomUUID(),context:epoch(engine.peer.account),flushing:false},events=batch.events,actorId=engine.peer.account.id;batch.flushing=true;engine.hpAt=Date.now();
    return batch.promise=internal(actorId,'health',[],records=>{
      const account=records.get(actorId),profile=account.profile;let delta=0,died=false;
      for(const event of events){
        if(event.adventure!==(account.adventureEpoch||0)||event.life!==(account.lifeEpoch||0)||event.at<(account.healthBoundaryAt||0))continue;
        const before=profile.hp;profile.hp=Math.max(0,Math.min(Game.maxHp(profile),profile.hp+event.amount));delta+=profile.hp-before;
        if(profile.hp<=0){profile.planet=event.planet;Game.die(profile,event.x,event.z);clearJourney(account);account.lifeEpoch=(account.lifeEpoch||0)+1;died=true;}
      }
      return {delta,died,lifeEpoch:account.lifeEpoch||0};
    },batch.requestId,false,batch) /* bookkeeping: no event-outbox entry twice a second while hurt */.then(result=>{engine.pendingHealth=null;if(!result)return true;const live=peers.get(actorId);if(!live)return true;
      if(result.reply.result.died){resetPeer(live,{newLife:true});onDeath(live);}
      send(live.socket,{type:'healthResult',...result.reply.result});return true;
    }).catch(async error=>{
      if(error.status===410){
        // The receipt was evicted: its outcome is ambiguous, so reload instead of applying old damage a second time.
        try{const account=await store.get(actorId),live=peers.get(actorId);
          if(account){const current=remember(account);if(live){send(live.socket,{type:'profile',profile:current.profile,revision:current.profileRevision,authorityVersion:1});if((account.adventureEpoch||0)===batch.context.adventure&&engine.reconciledLife.adventure===batch.context.adventure&&(account.lifeEpoch||0)>engine.reconciledLife.life){resetPeer(live,{newLife:true});onDeath(live);}}}
          engine.pendingHealth=null;return true;
        }catch{/* Keep the same batch identity until the authoritative state can be loaded. */}
      }
      batch.flushing=false;return false;
    });
  }
  /** Settle already observed damage before an inventory action calculates healing. */
  async function flushPeerHealth(peer){
    const engine=engines.get(peer.account.id);if(!engine)return;
    const pending=!!engine.pendingHealth,buffered=engine.healthEvents.length>0;
    if(pending&&!await flushHealth(engine))throw new Error('Pending health could not be saved. Please try again.');
    if(buffered&&!await flushHealth(engine))throw new Error('Pending health could not be saved. Please try again.');
  }
  function combatProfile(peer){
    const engine=engineFor(peer),profile=peer.account.profile;engine.gear??=new ContextGearSelection();
    const weapon=engine.gear.forCombat(profile);return withHand({...profile,gear:{...profile.gear,...(weapon?{weapon}:{weapon:undefined})}},engine.pair.hand);
  }
  function engineFor(peer){
    let engine=engines.get(peer.account.id);
    if(engine){
      engine.peer=peer;engine.lastSeen=Date.now();
      if(engine.room!==peer.room){flushHealth(engine);engine.sim.reset();engine.room=peer.room;}
      if(engine.planet!==peer.planet){engine.planet=peer.planet;engine.environment=new EnvironmentSimulation(createEnvironmentLayout(peer.planet));}
      return engine;
    }
    engine={peer,room:peer.room,planet:peer.planet,reconciledLife:epoch(peer.account),lastSeen:Date.now(),nextBasic:0,nextSkill:[0,0,0,0],healthEvents:[],hpAt:0,damageAt:0,lastSkill:new Map(),pair:new WeaponPair(),environment:new EnvironmentSimulation(createEnvironmentLayout(peer.planet))};
    const current=()=>engine.peer,room=()=>rooms.get(current().room);
    const targets=()=>room()?[...state(room()).enemies.values()]:[];
    // A pet's shot and its guard come from the one table (pet-guard.ts), scaled by its level; it stands with its explorer.
    const petShooter=(p,index)=>{const id=companionId(p.account.profile.gear,index),pet=id?Game.ITEMS[id]?.pet:undefined,fighter=pet&&!p.visit&&!atHome(p.planet,p.pose)?petFighter(id,gearFactor(p.account.profile,id),pet.shot):null;return fighter?{...fighter,x:p.pose.x,z:p.pose.z}:null;};
    engine.sim=new CombatSimulation({position:()=>current().pose,facing:()=>current().pose.facing,face:a=>{current().pose.facing=a;},targets,
      weapon:()=>{const weapon=Game.weaponStats(combatProfile(current()));return weapon.kind==='rod'?{kind:'fist',range:1.6,cd:.5,special:'fist'}:weapon;},
      stats:()=>Game.activeStats(combatProfile(current())),moving:()=>current().pose.moving,
      move:(x,z)=>{current().pose.x+=x;current().pose.z+=z;},hit:(target,impact)=>{/* the first own hit after a swap does +20% (weapon-pair.ts) */const m=impact.helper?1:engine.pair.takeBonus();return hit(current(),target,m===1?impact:{...impact,amount:impact.amount*m});},
      heal:fraction=>hp(current(),Game.maxHp(current().account.profile)*fraction,'heal'),
      execute:target=>{const p=current();if(!target.boss&&target.hp/target.maxHp<.4&&dist(p.pose,target)<=3.2+target.radius)hit(p,target,{amount:target.hp,critical:true,stun:0,lift:0,knock:0,direction:{x:0,z:0}},true);},
      effect:effect=>{if(room())broadcast(room(),{type:'effect',by:current().account.id,visual:effect},current().account.id);},
      // The pet waits by the pen at home (pet-pen.ts petMayFight): it shoots only while its explorer is away from the safe village.
      // Two pet slots (pet-slots.ts): each worn companion shoots on its own cooldown; the dog pet tosses through `dog` below.
      pet:()=>petShooter(current(),0),pet2:()=>petShooter(current(),1),
      // The guard dog throws only while the server says it follows (pose.dog is null at home and on visits); it stands at the trailing spot.
      dog:()=>{const p=current();if(p.visit||typeof p.pose?.dog!=='number'||!dogWorn(p.account.profile.gear)||atHome(p.planet,p.pose))return null;const at=trailSpot(p.pose,p.pose.facing||0);return {x:at.x,z:at.z,dmg:dogTossFactor(p.account.profile.level),cd:DOG_TOSS_CD,guard:DOG_GUARD,target:p.target??null};},
      // Pets shoot only what fights their explorer and guard only their own explorer (pet-guard.ts): the chosen creature, the health
      // as the server has it (with the blows not yet saved), and the word to that explorer alone when a guard fired.
      focus:()=>current().target??null,
      health:()=>{const p=current(),profile=p.account.profile;let hp=profile.hp;for(const event of engine.healthEvents)hp+=event.amount;return Math.max(0,hp)/Math.max(1,Game.maxHp(profile));},
      guarded:event=>send(current().socket,{type:'guard',event}),
      // Bond Surge (pet-surge.ts): the server's copy decides the surge, its doubled shots, the signature and the boss's weakness; the explorer is told.
      surged:event=>send(current().socket,{type:'surge',event}),
      skillLevel:index=>skillLevel(combatProfile(current()),index),
      status:(target,kind,duration)=>{if(kind==='stun'){/* a freeze or a root holds bosses too */target.stun=Math.max(target.stun||0,duration);if(room())broadcast(room(),{type:'status',id:target.id,kind,duration});return;}if(target.boss&&BOSS_RESISTED.includes(kind)){kind='slow';duration*=RESIST_SLOW;}target.statuses[kind]=Math.max(target.statuses[kind]||0,duration);if(room())broadcast(room(),{type:'status',id:target.id,kind,duration});},
      moveTarget:(target,x,z)=>{if(dist(target,{x,z})>12)return;target.x=x;target.z=z;if(room())broadcast(room(),{type:'moveEnemy',id:target.id,x,z});}});
    engines.set(peer.account.id,engine);return engine;
  }
  function resetPeer(peer,{newLife=false,reason}={}){
    const engine=engineFor(peer);engine.sim.reset();
    if(newLife||reason==='rest')engine.healthEvents=[];
    if(newLife){engine.reconciledLife=epoch(peer.account);engine.environment=new EnvironmentSimulation(createEnvironmentLayout(peer.planet));engine.damageAt=0;}
    if(reason==='reset'){engine.nextBasic=0;engine.nextSkill=[0,0,0,0];}
  }
  function basic(peer,targetId){if(peer.visit||!peer.active||peer.account.profile.hp<=0)return;if(typeof targetId==='string')peer.target=targetId;const e=engineFor(peer),now=Date.now();if(now<e.nextBasic||!e.pair.ready(now/1000))return;const target=state(rooms.get(peer.room)).enemies.get(targetId);if(e.sim.basic(target)){const weapon=Game.weaponStats(combatProfile(peer));e.nextBasic=now+Math.max(.12,(weapon.cd||.5)/Math.max(.2,1+Game.activeStats(peer.account.profile).haste))*1000;}}
  /** Weapon pair: the explorer changed hands (Tab, the swap button or the auto swap). The server keeps the gap and the draw itself. */
  function swap(peer,hand){if(peer.visit||!peer.active||(hand!=='main'&&hand!=='side'))return false;const e=engineFor(peer),profile=peer.account.profile;e.pair.settle(!!sideGun(profile));if(!e.pair.swap(hand,Date.now()/1000,!!sideGun(profile)))return false;e.sim.swapped();return true;}
  function skill(peer,index){if(peer.visit||!peer.active||peer.account.profile.hp<=0||!Number.isInteger(index)||index<0||index>3)return;const e=engineFor(peer),now=Date.now();if(now<e.nextSkill[index])return;const profile=combatProfile(peer),dz=profile.gear.disguise,weapon=Game.weaponStats(profile),list=Game.DISGUISES[dz]?.skills||[...BASE_SKILLS,SPECIALS[weapon.special||'fist']||SPECIALS.fist];if(dz?e.sim.disguise(dz,index):e.sim.skill(index,weapon.special||'fist')){e.nextSkill[index]=now+skillCooldown(profile,index,list[index].cd,!!dz)/Math.max(.2,1+Game.activeStats(profile).haste)*1000;internal(peer.account.id,'skill',[],records=>{const s=records.get(peer.account.id).profile;Game.recordEvent(s,'skill');return {index};}).catch(()=>{});}}
  function damage(peer,enemyId,source='melee',decoyId){
    if(peer.visit)return;const room=rooms.get(peer.room),enemy=room&&state(room).enemies.get(enemyId),e=engineFor(peer),now=Date.now();
    if(!enemy||enemy.hp<=0)return;
    if(enemy.boss&&BOSS_SKILLS[enemy.type]?.includes(enemy.skill))return;
    const def=ENEMY_TYPES[enemy.type];if(!def)return;const reach=source==='shot'?45:def.reach+enemy.radius+2;
    if(dist(peer.pose,enemy)>reach)return;
    // Aimed at a summon: it takes the blow, never the explorer (a summon already gone means the blow missed).
    if(decoyId!==undefined){hurtDecoy(peer,enemy,decoyId,enemy.phase==='charge'?1.3:1,source);return;}
    hurtEnemyTarget(peer,enemy,enemy.phase==='charge'?1.3:1,source);
  }
  function environmentSnapshot(env){return {time:env.time,lamps:[...env.lamps],eclipseUntil:env.eclipseUntil,nestLevel:env.nestLevel,fireRain:env.fireRain,lightning:env.lightning,weather:env.weather.snapshot()};}
  function tick(dt=.05){
    const now=Date.now();
    for(const room of rooms.values()){
      const s=state(room),active=[...room.members].map(id=>peers.get(id)).filter(p=>p&&p.active&&!p.visit),actors=[...s.enemies.values()].map(e=>({id:e.id,x:e.x,z:e.z,hp:e.hp,maxHp:e.maxHp,boss:e.boss,flying:ENEMY_TYPES[e.type]?.flying,lavaImmune:e.type==='lavaworm'}));
      const liveDragon=[...s.enemies.values()].find(e=>e.type==='dragon'&&e.hp>0);s.environment.dragonPhase=liveDragon?bossPhase(liveDragon.hp,liveDragon.maxHp):0;
      s.environment.nearbyPlayers=active.length;
      const before=environmentSnapshot(s.environment),weatherBefore=structuredClone(before.weather),rainBefore=structuredClone(before.fireRain),lightningBefore=structuredClone(before.lightning);
      const focus=active.length?active[(s.focusCursor=(s.focusCursor||0)+1)%active.length].pose:{x:0,z:0};
      const step=s.environment.step(dt,focus,{x:0,z:0},{speed:6,maxHp:100,flying:true},actors);
      for(const strike of step.enemyHits){const enemy=s.enemies.get(strike.id);if(!enemy||enemy.pending||enemy.hp<=0)continue;
        const contributor=[...enemy.contributors].filter(([,at])=>now-at<30000).map(([id])=>peers.get(id)).find(p=>p?.room===room.id&&!p.visit);
        if(contributor)hit(contributor,enemy,{amount:strike.amount,critical:false,stun:0,lift:0,knock:0,direction:{x:0,z:0}},false,true);
        else{enemy.hp=Math.max(0,enemy.hp-strike.amount);if(enemy.hp===0){enemy.deadUntil=now+enemy.roster.respawn*1000;enemy.respawn=enemy.roster.respawn;enemy.shots=[];enemy.titanAttacks=[];enemy.combatAttacks=[];enemy.cast=null;}health(room,enemy);}
      }
      const dragon=[...s.enemies.values()].find(e=>e.type==='dragon');if(dragon&&step.dragonSummon){dragon.hp=dragon.maxHp;dragon.deadUntil=0;dragon.respawn=0;dragon.statuses={};dragon.stun=0;dragon.phase='idle';dragon.cast=null;dragon.combatAttacks=[];health(room,dragon);}if(dragon&&step.dragonDismiss){dragon.hp=0;dragon.deadUntil=Infinity;dragon.respawn=999999;dragon.cast=null;dragon.combatAttacks=[];dragon.titanAttacks=[];dragon.shots=[];dragon.skillEffects=[];dragon.telegraphs=[];health(room,dragon);}
      colossus.tick(room,s,dt,{targets:()=>aliveTargets(room),hurt:hurtColossus,hurtTrue:(peer,amount)=>{if(!peer.visit&&peer.active&&peer.account.profile.hp>0)hp(peer,-amount,'hazard');}});
      for(const enemy of s.enemies.values()){
        if(enemy.hp>0&&!enemy.pending&&enemy.phase==='return'&&now-(enemy.lastHitAt||0)>4000){enemy.hp=Math.min(enemy.maxHp,enemy.hp+enemy.maxHp*.3*dt);if(enemy.hp===enemy.maxHp)enemy.scaled=false;}
        updateCast(room,enemy,dt,now);
        if(enemy.barrier)stepBarrier(enemy.barrier,dt);enemy.stun=Math.max(0,(enemy.stun||0)-dt);for(const key of STATUS)enemy.statuses[key]=Math.max(0,(enemy.statuses[key]||0)-dt);
        if(enemy.hp<=0&&!enemy.pending&&Number.isFinite(enemy.deadUntil)){enemy.respawn=Math.max(0,(enemy.deadUntil-now)/1000);if(enemy.respawn===0&&active.every(p=>dist(p.pose,enemy.home)>22)){enemy.x=enemy.home.x;enemy.z=enemy.home.z;enemy.hp=enemy.maxHp=enemy.baseMaxHp;enemy.damage=enemy.baseDamage;enemy.scaled=false;enemy.contributors.clear();enemy.generation++;room.killed.delete(enemy.id);if(enemy.barrier)enemy.barrier=newBarrier();if(enemy.elite==='splitter')for(const m of s.enemies.values())if(m.elite==='mini'&&m.parentId===enemy.id&&m.hp>0&&!m.pending){m.hp=0;m.deadUntil=Infinity;m.respawn=999999;health(room,m);}health(room,enemy);}}
      }
      sceneryTick(room,now);
      room.environment=environmentSnapshot(s.environment);
      if(now-s.lastBroadcast>250){s.lastBroadcast=now;publish(room);broadcast(room,{type:'enemies',enemies:room.enemies});broadcast(room,{type:'environment',snapshot:room.environment});}
      for(const peer of active){const e=engineFor(peer);e.sim.update(dt,true);e.environment.authoritative=false;e.environment.time=s.environment.time-dt;e.environment.weather.restore(weatherBefore);e.environment.fireRain=structuredClone(rainBefore);e.environment.lightning=structuredClone(lightningBefore);e.environment.lamps=new Map(s.environment.lamps);e.environment.eclipseUntil=s.environment.eclipseUntil;e.environment.dragonPhase=s.environment.dragonPhase;e.environment.nestLevel=before.nestLevel;
        if(peer.account.ridePlanet===peer.planet&&peer.account.rideUntil>now)e.environment.rideUntil=e.environment.time+(peer.account.rideUntil-now)/1000;
        const traits=Game.activeStats(peer.account.profile),hazard=e.environment.step(dt,peer.pose,{x:0,z:0},{...traits,fireResistance:traits.lavaproof?1:traits.fireResistance,flying:e.sim.statuses.flight>0||e.sim.statuses.bats>0},[]);
        if(hazard.damage>0)hurtPlayer(peer,hazard.damage,'hazard');if(hazard.heal)hp(peer,hazard.heal,'heal');if(traits.regen>0&&peer.account.profile.hp<traits.maxHp)hp(peer,traits.regen*dt,'regen');if(atHome(peer.planet,peer.pose)&&peer.account.profile.hp<traits.maxHp)hp(peer,homeRecoveryBonus(traits.regen)*dt,'rest');

      }
    }
    for(const[id,engine]of engines){if((engine.pendingHealth||engine.healthEvents.length)&&now-engine.hpAt>500)flushHealth(engine);if(!peers.has(id)&&!engine.pendingHealth&&!engine.healthEvents.length&&now-engine.lastSeen>600000)engines.delete(id);}
  }
  /**
   * Breakable scenery (breakables.ts): the server holds each room's ledger and decides every hit, break and regrowth.
   * A client asks with the piece's id (its type and spot) and the hit's source; the server checks the planet, the reach
   * from the explorer's pose and the pace, applies the boss rule from its own creatures, and tells the whole room.
   */
  const SCENERY_PIECE_R={tree:.6,stone:1},HEAVY_GAP=700;
  function sceneryLedger(room){return room.scenery??=new BreakLedger(sceneryRandom);}
  function scenery(peer,id,source){
    const room=rooms.get(peer.room);if(!room||peer.visit||!peer.active||peer.account.profile.hp<=0)return null;
    if(room.id.split(':').at(-1)!==BREAK_PLANET||peer.planet!==BREAK_PLANET)return null;
    const spot=parsePieceId(id);if(!spot||!(hitWorth(spot.type,source)>0))return null;
    const piece={id,type:spot.type,x:spot.x,z:spot.z,r:SCENERY_PIECE_R[breakClass(spot.type)]};if(!inReach(piece,peer.pose,source))return null;
    const e=engineFor(peer),now=Date.now();if(source==='dive'||source==='quake'||source==='power'){const since=now-(e.heavySceneryAt||0);if(since>=HEAVY_GAP)e.heavySceneryAt=now;else if(since>250)return null;} // one heavy blow (all it reaches within 250 ms) per HEAVY_GAP ms
    const bosses=[...state(room).enemies.values()].filter(m=>m.boss&&m.hp>0).map(m=>({x:m.x,z:m.z,hp:m.hp,aggro:fighting(m.phase)}));
    const result=sceneryLedger(room).hit(piece,source,now/1000,bossHolds(piece.x,piece.z,bosses));if(result.outcome==='none')return result;
    broadcast(room,{type:'scenery',id,outcome:result.outcome,hp:result.hp,by:peer.account.id});
    if(result.outcome==='break'&&breakClass(spot.type)==='tree'){const actorId=peer.account.id;internal(actorId,'sceneryDrop',[],records=>{const s=records.get(actorId).profile;const n=grantBreakDrop(s,spot.type,now,(item,k)=>Game.addItem(s,item,k));return {wood:n,count:Object.entries(s.worldRewards.resourceReadyAt).find(([k])=>k.startsWith('break-wood:'))?.[1]||0};}).then(r=>{const got=r?.reply?.result;const live=peers.get(actorId);if(got?.wood>0&&live)send(live.socket,{type:'sceneryWood',wood:got.wood,count:got.count});}).catch(()=>{});}
    return result;
  }
  function sceneryTick(room,now){const ledger=room.scenery;if(!ledger||!ledger.entries.size)return;
    if(now-(room.sceneryRegrowAt||0)>=1000){room.sceneryRegrowAt=now;const players=[...room.members].map(id=>peers.get(id)).filter(p=>p&&p.active&&!p.visit).map(p=>p.pose);
      for(const id of ledger.regrow(now/1000,()=>undefined,(x,z,r)=>players.some(p=>Math.hypot(p.x-x,p.z-z)<r)))broadcast(room,{type:'scenery',id,outcome:'regrow',hp:0});}
    if(ledger.entries.size&&now-(room.scenerySentAt||0)>=3000){room.scenerySentAt=now;broadcast(room,{type:'sceneryState',list:ledger.snapshot(now/1000)});}
  }
  const timer=setInterval(()=>{if(!stopped)try{tick(.05);}catch(error){onError(error);}},50);timer.unref();
  function bomb(peer,radius,multiplier){const room=rooms.get(peer.room);if(!room||peer.visit)return;for(const enemy of state(room).enemies.values())if(enemy.hp>0&&dist(peer.pose,enemy)<=radius+enemy.radius)hit(peer,enemy,{amount:Math.round(Game.attack(combatProfile(peer))*multiplier),critical:false,stun:.5,lift:0,knock:2,direction:{x:0,z:0}});}
  return {acceptSnapshots,basic,swap,skill,damage,scenery,decoys,bomb,engineFor,state,internal,resetPeer,flushPeerHealth,colossus,async close(){stopped=true;clearInterval(timer);for(const engine of engines.values())flushHealth(engine);await Promise.allSettled([...queues.values()]);}};
}
