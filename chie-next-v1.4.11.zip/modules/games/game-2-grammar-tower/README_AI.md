# Grammar Tower — Tháp ngữ pháp — module `game-2-grammar-tower`

Game học số 2 của CHIE NEXT (mã `grammar_tower`). Đọc kèm `MODULE_SDK_CONTRACT.md`.

## Tệp
- `js/game2d.js` — bản 2D (Canvas/DOM), chạy thật tại `assets/js/games/grammar_tower.js`.
- `js/game3d.js` — bản 3D (ES module, three.js r160 qua `assets/js/games3d/engine.js` và `models.js`), chạy thật tại `assets/js/games3d/grammar_tower.js`.
- `module.json` — khai báo:
  - `entry_2d` / `entry_3d`: tệp trang chơi nạp (phải nằm trong `assets/`).
  - `deploy`: tệp nào trong gói được chép đi đâu khi cài.
  - `schema`: các ô cấu hình hiện trong Admin → Game Studio (`"khóa": ["Nhãn", "int|float|bool", min, max]`). Thêm khóa mới ở đây là Admin chỉnh được ngay, game đọc qua cấu hình truyền xuống.
  - `defaults`: giá trị cho nút "Khôi phục mặc định của module" trong Game Studio.

## Quy tắc khi sửa
- Giữ nguyên cách gọi API/biến mà bản hiện tại đang dùng (`window.G` / `G.answer`, `assets/js/games/common.js`, `/api/games/grammar_tower/start`…). Máy chủ chấm điểm và cộng Xu — game chỉ hiển thị.
- `game3d.js` import tương đối `./engine.js`, `./models.js`: sau khi cài, tệp nằm trong `assets/js/games3d/` nên các import này vẫn đúng.
- Tăng `version` trong `module.json`, nén lại cả thư mục rồi tải lên tại Admin → Quản lý Zoo Garden 3D → tab Module.
- Không đưa tệp `.php`, `.sh`, `.htaccess` vào gói.
