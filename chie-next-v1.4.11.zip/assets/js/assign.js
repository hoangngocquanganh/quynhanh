(function () {
  var f = document.getElementById('assign-form'); if (!f) return;
  function sync() {
    var t = (f.querySelector('input[name=type]:checked') || {}).value;
    f.querySelectorAll('[data-type]').forEach(function (el) { el.hidden = el.getAttribute('data-type').split(' ').indexOf(t) < 0; });
    var tg = (f.querySelector('input[name=target]:checked') || {}).value;
    document.getElementById('student-list').hidden = tg !== 'students';
  }
  f.addEventListener('change', sync); sync();
})();
