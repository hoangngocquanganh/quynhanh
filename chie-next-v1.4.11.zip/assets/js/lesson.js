/* Trang bài học: chuyển bước Làm quen → Nghe mẫu → Luyện tập; bắt đầu lượt luyện. */
(function () {
  var root = document.getElementById('lesson');
  if (!root) return;
  var steps = root.querySelectorAll('.lesson-step');
  var dots = root.querySelectorAll('.steps-dots i');
  function go(n) {
    CHIE.speech.stop();
    steps.forEach(function (s) { s.hidden = s.getAttribute('data-step') !== String(n); });
    dots.forEach(function (d, i) { d.classList.toggle('on', i === n - 1); });
    var target = root.querySelector('[data-step="' + n + '"] h2');
    if (target) { target.setAttribute('tabindex', '-1'); target.focus(); }
    window.scrollTo({ top: root.offsetTop - 70, behavior: 'smooth' });
  }
  root.addEventListener('click', function (e) {
    var b = e.target.closest('[data-next-step]');
    if (b) go(parseInt(b.getAttribute('data-next-step'), 10));
  });
  // câu dài: chia cụm, bấm từng cụm để nghe
  root.querySelectorAll('[data-chunks]').forEach(function (el) {
    var text = el.getAttribute('data-chunks');
    if (text.split(/\s+/).length < 7) return;
    var chunks = CHIE.speech.chunk(text);
    el.innerHTML = chunks.map(function (c) { return '<button type="button" class="chunk" data-speak="' + CHIE.esc(c) + '" data-slow>' + CHIE.esc(c) + '</button>'; }).join(' ');
  });
  var start = document.getElementById('start-practice');
  if (start) start.addEventListener('click', function () {
    start.disabled = true;
    CHIE.api('POST', root.getAttribute('data-start-url'), {}).then(function (res) {
      location.href = res.redirect;
    }).catch(function (e) { start.disabled = false; CHIE.toast(e.userMessage || e.message, 'error', 6000); });
  });
})();
