/* CHIE NEXT — lõi phía trình duyệt (không cần build). Chỉ hiển thị + gửi thao tác; máy chủ quyết định điểm/thưởng. */
(function () {
  'use strict';
  var body = document.body;
  var BASE = (body.getAttribute('data-base') || '').replace(/\/$/, '');
  var CSRF = (document.querySelector('meta[name="csrf-token"]') || {}).content || '';
  var CHIE = window.CHIE = window.CHIE || {};
  CHIE.base = BASE;
  CHIE.url = function (path) { return BASE + '/' + String(path).replace(/^\//, ''); };

  /* ---------------- thông báo nhanh ---------------- */
  CHIE.toast = function (msg, type, ms) {
    var wrap = document.getElementById('toasts');
    if (!wrap) return;
    // không xếp chồng cùng một thông báo khi bấm nhiều lần
    for (var i = 0; i < wrap.children.length; i++) { if (wrap.children[i].textContent === String(msg)) return; }
    var el = document.createElement('div');
    el.className = 'toast ' + (type || '');
    el.setAttribute('role', type === 'error' ? 'alert' : 'status');
    el.textContent = msg;
    wrap.appendChild(el);
    setTimeout(function () { el.remove(); }, ms || 4200);
  };

  /* ---------------- mạng ---------------- */
  var netbar = document.getElementById('netbar');
  function setOnline(on) { if (netbar) netbar.classList.toggle('show', !on); }
  window.addEventListener('offline', function () { setOnline(false); });
  window.addEventListener('online', function () { setOnline(true); CHIE.toast('Đã có mạng trở lại.', 'success', 2500); });
  if (navigator.onLine === false) setOnline(false);

  CHIE.api = function (method, path, data, opts) {
    opts = opts || {};
    var init = { method: method, credentials: 'same-origin', headers: { 'Accept': 'application/json', 'X-CSRF-TOKEN': CSRF, 'X-Requested-With': 'XMLHttpRequest' } };
    init.headers['X-Chie-Release'] = document.querySelector('meta[name="chie-release"]')?.content || 'root';
    if (data !== undefined && data !== null) { init.headers['Content-Type'] = 'application/json'; init.body = JSON.stringify(data); }
    var url = /^https?:/.test(path) ? path : CHIE.url(path);
    return fetch(url, init).then(function (res) {
      return res.text().then(function (txt) {
        var json = null;
        try { json = txt ? JSON.parse(txt) : {}; } catch (e) { json = null; }
        if (res.ok) return json || {};
        var msg = (json && json.message) || '';
        if (res.status === 401) { msg = msg || 'Phiên đăng nhập đã hết. Vui lòng đăng nhập lại.'; if (!opts.quiet) setTimeout(function () { location.href = CHIE.url('dang-nhap?next=' + encodeURIComponent(location.pathname + location.search)); }, 1500); }
        else if (res.status === 419) { msg = 'Phiên làm việc đã hết hạn. Trang sẽ tải lại để tiếp tục.'; if (!opts.quiet) setTimeout(function () { location.reload(); }, 1600); }
        else if (res.status === 403) msg = msg || 'Bạn không có quyền thực hiện thao tác này.';
        else if (res.status === 404) msg = msg || 'Không tìm thấy dữ liệu (có thể đã bị xóa hoặc thu hồi).';
        else if (res.status === 429) msg = 'Bạn thao tác hơi nhanh. Chờ vài giây rồi thử lại nhé.';
        else if (res.status === 422 && json && json.errors) { var k = Object.keys(json.errors)[0]; msg = json.errors[k][0] || msg; }
        else if (res.status >= 500) {
          if (!json) msg = 'Máy chủ trả lỗi ' + res.status + ' không phải từ CHIE (có thể tường lửa hosting/ModSecurity chặn, hoặc PHP dừng đột ngột). Admin xem mục Nhật ký lỗi.';
          else msg = msg || 'Máy chủ đang gặp sự cố. Vui lòng thử lại sau ít phút.';
        }
        var err = new Error(msg || ('Lỗi ' + res.status));
        err.status = res.status; err.data = json; err.userMessage = msg;
        throw err;
      });
    }, function (netErr) {
      setOnline(false);
      var err = new Error('Không kết nối được máy chủ. Kiểm tra mạng rồi bấm thử lại.');
      err.status = 0; err.network = true; err.userMessage = err.message;
      throw err;
    });
  };

  /** Gọi API, tự hiện lỗi; trả về null nếu lỗi. */
  CHIE.call = function (method, path, data) {
    return CHIE.api(method, path, data).catch(function (e) { CHIE.toast(e.userMessage || e.message, 'error', 5000); return null; });
  };

  CHIE.idem = function () {
    if (window.crypto && crypto.randomUUID) return crypto.randomUUID();
    return 'k' + Date.now().toString(36) + Math.random().toString(36).slice(2);
  };

  CHIE.esc = function (s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; });
  };
  CHIE.icon = function (name, cls) {
    var href = CHIE.url('assets/img/icons.svg') + '#i-' + name;
    return '<svg class="ic ' + (cls || '') + '" aria-hidden="true"><use href="' + href + '"></use></svg>';
  };

  /* ---------------- giọng đọc: chậm, rõ, không phát chồng ---------------- */
  var speech = CHIE.speech = {
    rate: parseFloat(body.getAttribute('data-tts-rate')) || 0.75,
    slow: parseFloat(body.getAttribute('data-tts-slow')) || 0.65,
    supported: 'speechSynthesis' in window,
    _audio: null, _token: 0, _voice: null,
    pickVoice: function () {
      if (!speech.supported) return null;
      var vs = window.speechSynthesis.getVoices() || [];
      // chấm điểm giọng: giọng tự nhiên (Natural/Online/Neural, Google, Samantha…) và en-US được ưu tiên — phát âm rõ, chuẩn hơn giọng máy cũ
      var best = null, bestScore = -1;
      for (var i = 0; i < vs.length; i++) {
        var lang = (vs[i].lang || '').replace('_', '-'), name = vs[i].name || '';
        if (lang.indexOf('en') !== 0) continue;
        var s = { 'en-US': 30, 'en-GB': 24, 'en-AU': 16 }[lang.slice(0, 5)] || 8;
        if (/natural|neural|online/i.test(name)) s += 40;
        else if (/google/i.test(name)) s += 30;
        else if (/samantha|aria|jenny|guy|ava|allison|serena|daniel/i.test(name)) s += 20;
        if (/espeak|compact|novelty|whisper|bad news|bells|zarvox|trinoids|albert/i.test(name)) s -= 50;
        if (s > bestScore) { best = vs[i]; bestScore = s; }
      }
      return best;
    },
    stop: function () {
      speech._token++;
      if (speech.supported) { try { window.speechSynthesis.cancel(); } catch (e) {} }
      if (speech._audio) { try { speech._audio.pause(); } catch (e) {} speech._audio = null; }
      document.querySelectorAll('.audio-btn.playing, .chunk.playing').forEach(function (b) { b.classList.remove('playing'); });
    },
    /** Đọc 1 đoạn. opts: {rate, onend, button} */
    say: function (text, opts) {
      opts = opts || {};
      speech.stop();
      var token = speech._token;
      if (!text) return;
      if (opts.audioUrl) {
        var a = new Audio(opts.audioUrl);
        a.preservesPitch = true; a.mozPreservesPitch = true; a.webkitPreservesPitch = true;
        a.playbackRate = opts.rate || speech.rate;
        speech._audio = a;
        if (opts.button) opts.button.classList.add('playing');
        a.onended = function () { if (opts.button) opts.button.classList.remove('playing'); if (opts.onend && token === speech._token) opts.onend(); };
        a.play().catch(function () { CHIE.toast('Không phát được âm thanh. Hãy bấm lại.', 'error'); });
        return;
      }
      if (!speech.supported) { CHIE.toast('Trình duyệt này chưa hỗ trợ giọng đọc. Hãy thử Chrome, Edge hoặc Safari mới.', 'error', 5000); return; }
      var u = new SpeechSynthesisUtterance(text);
      u.lang = 'en-US';
      speech._voice = speech._voice || speech.pickVoice();
      if (speech._voice) { u.voice = speech._voice; u.lang = speech._voice.lang; }
      u.rate = opts.rate || speech.rate;
      u.pitch = 1;
      if (opts.button) opts.button.classList.add('playing');
      u.onend = u.onerror = function () { if (opts.button) opts.button.classList.remove('playing'); if (opts.onend && token === speech._token) opts.onend(); };
      // Chrome đôi khi bỏ qua câu nếu gọi ngay sau cancel()
      setTimeout(function () { if (token === speech._token) window.speechSynthesis.speak(u); }, 60);
    },
    /** Đọc theo cụm cho câu dài (dừng ngắn giữa các cụm để kịp nghe). */
    sayChunks: function (chunks, opts) {
      opts = opts || {};
      var i = 0;
      speech.stop();
      var token = speech._token;
      function next() {
        if (token !== speech._token || i >= chunks.length) { if (opts.onend) opts.onend(); return; }
        var el = opts.elements ? opts.elements[i] : null;
        if (el) el.classList.add('playing');
        var t = chunks[i++];
        var u = new SpeechSynthesisUtterance(t);
        u.lang = 'en-US'; u.rate = opts.rate || speech.slow;
        speech._voice = speech._voice || speech.pickVoice();
        if (speech._voice) { u.voice = speech._voice; u.lang = speech._voice.lang; }
        u.onend = u.onerror = function () { if (el) el.classList.remove('playing'); if (token === speech._token) setTimeout(next, 450); };
        window.speechSynthesis.speak(u);
      }
      if (!speech.supported) { CHIE.toast('Trình duyệt này chưa hỗ trợ giọng đọc.', 'error'); return; }
      setTimeout(next, 60);
      speech._token = token;
    },
    chunk: function (sentence) {
      // tách cụm theo dấu câu / liên từ, mỗi cụm tối đa ~5 từ
      var parts = String(sentence).split(/(?<=[,;:.!?])\s+|\s+(?=(?:and|but|because|so|when|if|that|which|who)\b)/i).filter(Boolean);
      var out = [];
      parts.forEach(function (p) {
        var w = p.trim().split(/\s+/);
        while (w.length > 6) { out.push(w.splice(0, 4).join(' ')); }
        if (w.length) out.push(w.join(' '));
      });
      return out;
    },
    setRate: function (r) {
      speech.rate = r;
      try { localStorage.setItem('chie_tts_rate', String(r)); } catch (e) {}
      if (body.getAttribute('data-auth') === '1') CHIE.api('POST', 'api/settings/tts', { rate: r }).catch(function () {});
    }
  };
  if (body.getAttribute('data-auth') !== '1') {
    try { var saved = parseFloat(localStorage.getItem('chie_tts_rate')); if (saved >= 0.5 && saved <= 1.2) speech.rate = saved; } catch (e) {}
  }
  if (speech.supported) { window.speechSynthesis.onvoiceschanged = function () { speech._voice = speech.pickVoice(); }; }
  window.addEventListener('pagehide', speech.stop);
  document.addEventListener('visibilitychange', function () { if (document.hidden) speech.stop(); });

  /* ---------------- tiện ích giao diện ---------------- */
  /* ---------------- chế độ ngoại tuyến (service worker) ---------------- */
  (function () {
    var sw = body.getAttribute('data-sw');
    if (!sw || !('serviceWorker' in navigator) || location.protocol === 'file:') return;
    window.addEventListener('load', function () { navigator.serviceWorker.register(sw, { scope: CHIE.url('') }).catch(function () {}); });
  })();

  /* ---------------- nhắc nghỉ mắt (học sinh) ----------------
     Đếm thời gian dùng liên tục (lưu trong sessionStorage của tab, mất khi đóng trình duyệt).
     Nghỉ > 5 phút thì đếm lại từ đầu. Chỉ nhắc, không khóa màn hình. */
  (function () {
    var mins = parseInt(document.body.getAttribute('data-break') || '0', 10);
    if (!mins) return;
    var KEY = 'chie_use', now = Date.now(), st;
    try { st = JSON.parse(sessionStorage.getItem(KEY) || 'null'); } catch (e) { st = null; }
    if (!st || now - st.last > 5 * 60000) st = { start: now, last: now, warned: 0 };
    function tick() {
      var t = Date.now();
      if (document.hidden) return;
      if (t - st.last > 5 * 60000) st = { start: t, last: t, warned: 0 };
      st.last = t;
      var used = Math.floor((t - st.start) / 60000);
      if (used >= mins && st.warned < Math.floor(used / mins)) {
        st.warned = Math.floor(used / mins);
        CHIE.toast('Bạn đã học ' + used + ' phút liên tục. Hãy đứng dậy, nhìn ra xa và nghỉ mắt 2–3 phút nhé!', 'success', 12000);
      }
      try { sessionStorage.setItem(KEY, JSON.stringify(st)); } catch (e) {}
    }
    tick(); setInterval(tick, 30000);
  })();

  // chọn tất cả ô đánh dấu cùng tên trong form (bảng quản trị)
  document.addEventListener('change', function (e) {
    var all = e.target.closest('[data-check-all]');
    if (!all) return;
    var form = all.form || all.closest('form') || document;
    form.querySelectorAll('input[type=checkbox][name="' + all.getAttribute('data-check-all') + '"]').forEach(function (c) { c.checked = all.checked; });
  });
  document.addEventListener('click', function (e) {
    var t = e.target.closest('[data-speak]');
    if (t) { e.preventDefault(); speech.say(t.getAttribute('data-speak'), { rate: t.hasAttribute('data-slow') ? speech.slow : speech.rate, button: t, audioUrl: t.getAttribute('data-audio') || null }); return; }
    var c = e.target.closest('[data-copy]');
    if (c) {
      e.preventDefault();
      var txt = c.getAttribute('data-copy');
      (navigator.clipboard ? navigator.clipboard.writeText(txt) : Promise.reject()).then(function () { CHIE.toast('Đã sao chép.', 'success', 1800); }, function () { window.prompt('Sao chép nội dung này:', txt); });
      return;
    }
    var o = e.target.closest('[data-open-dialog]');
    if (o) { var d = document.getElementById(o.getAttribute('data-open-dialog')); if (d && d.showModal) { e.preventDefault(); d.showModal(); } return; }
    var x = e.target.closest('[data-close-dialog]');
    if (x) { var dd = x.closest('dialog'); if (dd) { e.preventDefault(); dd.close(); } return; }
    var sp = e.target.closest('[data-speed]');
    if (sp) {
      var r = parseFloat(sp.getAttribute('data-speed'));
      speech.setRate(r);
      sp.parentNode.querySelectorAll('[data-speed]').forEach(function (b) { b.setAttribute('aria-pressed', b === sp ? 'true' : 'false'); });
      CHIE.toast('Tốc độ đọc: ' + r + '×', '', 1500);
    }
  });
  document.addEventListener('submit', function (e) {
    var f = e.target;
    if (f.hasAttribute('data-confirm') && !window.confirm(f.getAttribute('data-confirm'))) { e.preventDefault(); return; }
    // chống bấm gửi 2 lần
    if (f.dataset.submitting === '1') { e.preventDefault(); return; }
    f.dataset.submitting = '1';
    var btn = f.querySelector('[type=submit]');
    if (btn) { btn.setAttribute('aria-busy', 'true'); }
    setTimeout(function () { f.dataset.submitting = '0'; if (btn) btn.removeAttribute('aria-busy'); }, 4000);
  });
  // đánh dấu nút tốc độ đang chọn
  document.querySelectorAll('.speed-select').forEach(function (g) {
    g.querySelectorAll('[data-speed]').forEach(function (b) { b.setAttribute('aria-pressed', Math.abs(parseFloat(b.getAttribute('data-speed')) - speech.rate) < 0.01 ? 'true' : 'false'); });
  });

  document.addEventListener('click', function (e) { document.querySelectorAll('.mobile-more[open]').forEach(function (menu) { if (!menu.contains(e.target)) menu.open = false; }); });
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape') document.querySelectorAll('.mobile-more[open]').forEach(function (menu) { menu.open = false; menu.querySelector('summary').focus(); }); });

  /* ---------------- nhịp trực tuyến (60s ± 10s, tab ẩn 180s) ---------------- */
  if (body.getAttribute('data-auth') === '1') {
    var beat = function () {
      if (navigator.onLine === false || document.hidden) return schedule();
      CHIE.api('POST', 'api/heartbeat', { module: body.getAttribute('data-module') || 'browse', label: document.title.split(' · ')[0] }, { quiet: true }).catch(function () {}).then(schedule);
    };
    var schedule = function () { setTimeout(beat, (document.hidden ? 180000 : 60000) + Math.round((Math.random() * 20000) - 10000)); };
    setTimeout(beat, 4000);
  }

  /* ---------------- báo lỗi phía trình duyệt (giới hạn) ---------------- */
  var sent = 0;
  window.addEventListener('error', function (ev) {
    if (sent++ > 3) return;
    try { CHIE.api('POST', 'api/client-error', { message: String(ev.message || 'error').slice(0, 300), url: location.pathname }, { quiet: true }).catch(function () {}); } catch (e) {}
  });
})();
