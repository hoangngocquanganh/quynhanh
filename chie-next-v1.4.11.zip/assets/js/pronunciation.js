(function () {
  // tabs
  var tabs = document.querySelectorAll('[data-tab]');
  tabs.forEach(function (t) {
    t.addEventListener('click', function () {
      tabs.forEach(function (x) { x.setAttribute('aria-selected', x === t ? 'true' : 'false'); document.getElementById(x.getAttribute('data-tab')).hidden = x !== t; });
      CHIE.speech.stop();
    });
  });
  // đố tai cặp âm
  var data = document.getElementById('mp-data');
  if (!data) return;
  var pairs = JSON.parse(data.textContent), cur = null, target = null;
  var opts = document.getElementById('mp-opts'), msg = document.getElementById('mp-msg'), lab = document.getElementById('mp-pair');
  function next() {
    cur = pairs[Math.floor(Math.random() * pairs.length)];
    target = cur[Math.random() < 0.5 ? 0 : 1];
    lab.textContent = cur[2];
    msg.textContent = '';
    opts.innerHTML = [cur[0], cur[1]].map(function (w) { return '<button type="button" class="btn" lang="en" data-w="' + CHIE.esc(w) + '">' + CHIE.esc(w) + '</button>'; }).join('');
  }
  document.getElementById('mp-play').onclick = function () { if (!cur) next(); CHIE.speech.say(target, { button: this }); };
  opts.addEventListener('click', function (e) {
    var b = e.target.closest('[data-w]'); if (!b || !cur) return;
    var ok = b.getAttribute('data-w') === target;
    msg.innerHTML = ok ? '<b class="text-success">Đúng rồi!</b> Bấm "Nghe từ" để chơi tiếp.' : '<b class="text-danger">Chưa đúng.</b> Từ vừa đọc là <b lang="en">' + CHIE.esc(target) + '</b>. Nghe lại cả hai từ để so sánh nhé.';
    var t = target; setTimeout(next, ok ? 900 : 2500); if (!ok) CHIE.speech.say(t);
  });
  next();
})();
