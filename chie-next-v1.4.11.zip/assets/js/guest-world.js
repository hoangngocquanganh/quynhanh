(function(){
  'use strict';
  var dlg=document.getElementById('guest-world-dialog'), frame=document.getElementById('guest-world-frame'), result=document.getElementById('guest-world-result');
  if(!dlg)return;
  var current=null,busy=false,finished=false;
  function close(){frame.src='about:blank';dlg.close();current=null;busy=false;}
  document.getElementById('guest-world-close').onclick=close;
  dlg.addEventListener('cancel',function(e){e.preventDefault();close();});
  document.addEventListener('click',function(e){var b=e.target.closest('[data-guest-world]');if(!b||busy)return;
    busy=true;b.disabled=true;result.textContent='';
    CHIE.api('POST',b.getAttribute('data-start-url'),{}).then(function(data){
      current=b;finished=false;var url=new URL(data.redirect,location.href);url.searchParams.set('world_guest','1');frame.src=url.toString();dlg.showModal();
    }).catch(function(err){CHIE.toast(err.userMessage||err.message,'error');}).finally(function(){busy=false;b.disabled=false;});
  });
  window.addEventListener('message',function(e){
    if(e.origin!==location.origin||e.source!==frame.contentWindow||!current||finished||!dlg.open)return;
    var d=e.data;if(!d||d.type!=='chie-guest-world-result'||!Number.isInteger(d.total)||d.total<1||d.total>30||!Number.isInteger(d.correct)||d.correct<0||d.correct>d.total)return;
    finished=true;var score=Math.round(d.correct/d.total*100),passed=score>=60,stars=score>=95?3:score>=80?2:passed?1:0;
    result.textContent=score+'/100 · '+(passed?'Đã vượt màn '+('★'.repeat(stars)):'Chưa vượt màn, hãy thử lại!')+' · Không lưu sau khi thoát.';
    var li=current.closest('.lesson-item');
    if(passed){li.classList.remove('current');li.classList.add('done');var badge=li.querySelector('.guest-stars');if(!badge){badge=document.createElement('span');badge.className='badge badge-accent guest-stars';current.before(badge);}var old=Number(current.dataset.stars||0);stars=Math.max(old,stars);current.dataset.stars=stars;badge.textContent='★'.repeat(stars);current.textContent='Chơi lại';}
  });
})();
