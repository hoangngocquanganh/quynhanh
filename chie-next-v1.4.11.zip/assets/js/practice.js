/* Nút bắt đầu luyện tập/ôn tập: [data-start-practice] trong form có data-practice (JSON) hoặc data-url */
(function () {
  document.addEventListener('click', function (e) {
    var b = e.target.closest('[data-start-practice],[data-start-url]');
    if (!b) return;
    e.preventDefault();
    var url = b.getAttribute('data-start-url') || 'api/practice/start';
    var holder = b.closest('[data-practice]');
    var body = holder ? JSON.parse(holder.getAttribute('data-practice')) : JSON.parse(b.getAttribute('data-body') || '{}');
    b.disabled = true;
    CHIE.api('POST', url, body).then(function (res) { location.href = res.redirect; })
      .catch(function (err) { b.disabled = false; CHIE.toast(err.userMessage || err.message, 'error', 6000); });
  });
})();
