/* Ôn thẻ từ ngoại tuyến: dùng gói từ đã lưu trên máy (localStorage) khi còn mạng. Không chấm điểm, không gửi gì lên máy chủ. */
(function () {
  'use strict';
  var box = document.getElementById('o-box');
  document.getElementById('o-retry').onclick = function () { location.reload(); };
  window.addEventListener('online', function () { location.reload(); });
  var pack = null;
  try { pack = JSON.parse(localStorage.getItem('chie_offline_pack') || 'null'); } catch (e) {}
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  if (!pack || !pack.words || !pack.words.length) {
    box.innerHTML = '<h2>Chưa có gói ôn ngoại tuyến</h2><p class="muted">Khi có mạng, vào <b>Học tập → Ôn tập</b> và bấm “Tải gói ôn ngoại tuyến”.</p>';
    return;
  }
  var words = pack.words.slice(), i = 0, known = 0, seen = 0;
  for (var k = words.length - 1; k > 0; k--) { var j = Math.floor(Math.random() * (k + 1)); var t = words[k]; words[k] = words[j]; words[j] = t; }
  function say(text, slow) {
    try { var u = new SpeechSynthesisUtterance(text); u.lang = 'en-US'; u.rate = slow ? 0.65 : 0.75; speechSynthesis.cancel(); speechSynthesis.speak(u); } catch (e) {}
  }
  function show() {
    if (i >= words.length) { box.innerHTML = '<h2>Xong lượt ôn! 🎉</h2><p>Bạn nhớ ' + known + '/' + seen + ' từ.</p><button class="btn btn-primary" id="o-again">Ôn lại</button>'; document.getElementById('o-again').onclick = function () { i = 0; known = 0; seen = 0; show(); }; return; }
    var w = words[i];
    box.innerHTML = '<div class="small muted">Thẻ ' + (i + 1) + '/' + words.length + ' · ' + esc(pack.grade_name || '') + '</div>' +
      '<div class="center" style="padding:18px 0"><div style="font-size:2rem;font-weight:800" lang="en">' + esc(w.word) + '</div>' + (w.ipa ? '<div class="ipa muted">' + esc(w.ipa) + '</div>' : '') +
      '<div class="audio-bar" style="justify-content:center"><button class="audio-btn" type="button" id="o-say">🔊 Nghe</button><button class="audio-btn slow" type="button" id="o-slow">🐌 Chậm</button></div>' +
      '<div id="o-back" hidden><div style="font-size:1.3rem;font-weight:700;margin-top:10px">' + esc(w.meaning) + '</div>' + (w.example ? '<div class="small" lang="en">“' + esc(w.example) + '”</div>' : '') + '</div></div>' +
      '<div class="btn-row" id="o-act"><button class="btn btn-primary btn-block" id="o-flip" type="button">Lật thẻ xem nghĩa</button></div>';
    document.getElementById('o-say').onclick = function () { say(w.word); };
    document.getElementById('o-slow').onclick = function () { say(w.word, true); };
    document.getElementById('o-flip').onclick = function () {
      document.getElementById('o-back').hidden = false;
      document.getElementById('o-act').innerHTML = '<button class="btn btn-success" id="o-yes" type="button">Mình nhớ</button><button class="btn" id="o-no" type="button">Chưa nhớ</button>';
      document.getElementById('o-yes').onclick = function () { known++; seen++; i++; show(); };
      document.getElementById('o-no').onclick = function () { seen++; words.push(w); i++; show(); };
    };
  }
  show();
})();
