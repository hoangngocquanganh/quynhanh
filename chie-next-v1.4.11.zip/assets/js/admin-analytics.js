(function(){
  'use strict';
  var panel=document.getElementById('analytics-panel'), status=document.getElementById('analytics-status');
  if(!panel)return;
  var dirty=false,loading=false;
  function tick(){
    if(document.hidden||dirty||loading)return;
    if(panel.contains(document.activeElement)&&/INPUT|SELECT|SUMMARY/.test(document.activeElement.tagName))return;
    var url=new URL(location.href);
    loading=true;
    fetch(url.toString(),{headers:{'Accept':'application/json'},credentials:'same-origin',cache:'no-store'})
      .then(function(r){if(!r.ok)throw new Error('refresh');return r.json();})
      .then(function(data){if(typeof data.html!=='string')throw new Error('invalid');
        // Preserve expanded data/help tables across refreshes.
        var expanded=Array.from(panel.querySelectorAll('details')).map(function(d){return d.open;});
        panel.innerHTML=data.html;panel.querySelectorAll('details').forEach(function(d,i){d.open=!!expanded[i];});
        if(status)status.textContent='Đã cập nhật lúc '+data.updated_at;
      }).catch(function(){if(status)status.textContent='Chưa làm mới được. Đang giữ số liệu gần nhất.';}).finally(function(){loading=false;});
  }
  panel.addEventListener('change',function(e){var f=e.target.form;if(!f)return;
    dirty=true;
    if(e.target.name==='country'){f.elements.region.value='';f.elements.city.value='';}
    if(e.target.name==='region')f.elements.city.value='';
  });
  setInterval(tick,45000);
})();
