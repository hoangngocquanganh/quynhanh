(function () {
  var form = document.getElementById('reg-form');
  if (!form) return;
  function sync() {
    var role = (form.querySelector('input[name=role]:checked') || {}).value || 'student';
    form.querySelectorAll('[data-for]').forEach(function (el) { el.hidden = el.getAttribute('data-for') !== role; });
  }
  form.addEventListener('change', function (e) { if (e.target.name === 'role') sync(); });
  sync();
})();
