/* Phòng của tôi: lưới 8×6. Chọn món trong túi → bấm ô để đặt; bấm món đã đặt để cất. */
(function () {
  'use strict';
  var root = document.getElementById('room');
  if (!root) return;
  var CHIE = window.CHIE, esc = CHIE.esc;
  var items = JSON.parse(root.getAttribute('data-items')), sel = null, busy = false;
  var grid = document.getElementById('r-grid'), bag = document.getElementById('r-bag'), hint = document.getElementById('r-hint');

  function at(x, y) { return items.find(function (i) { return i.placed && i.x === x && i.y === y; }); }
  function render() {
    var h = '';
    for (var y = 0; y < 6; y++) for (var x = 0; x < 8; x++) {
      var it = at(x, y);
      h += '<button type="button" class="room-cell' + (sel && !it ? ' target' : '') + '" data-x="' + x + '" data-y="' + y + '" aria-label="' +
        (it ? esc(it.name) + ' — bấm để cất' : 'Ô trống hàng ' + (y + 1) + ' cột ' + (x + 1)) + '">' + (it ? esc(it.icon) : '') + '</button>';
    }
    grid.innerHTML = h;
    var free = items.filter(function (i) { return !i.placed; });
    bag.innerHTML = free.length ? free.map(function (i) {
      return '<button type="button" class="chip inv-pick rarity-' + i.rarity + '" style="border-color:var(--r);min-height:44px" data-pick="' + i.id + '" aria-pressed="' + (sel === i.id) + '">' + esc(i.icon) + ' ' + esc(i.name) + '</button>';
    }).join('') : '<span class="small muted">Mọi món đều đã được đặt.</span>';
    var s = items.find(function (i) { return i.id === sel; });
    hint.textContent = s ? 'Đang chọn: ' + s.name + '. Bấm vào ô trống (có viền xanh) để đặt.' : 'Chưa chọn món nào.';
  }
  function place(it, x, y) {
    if (busy) return; busy = true;
    CHIE.api('POST', 'api/room/place', { inventory_id: it.id, x: x, y: y }).then(function (r) {
      if (x === null) { it.placed = false; it.x = it.y = null; } else { it.placed = true; it.x = x; it.y = y; }
      sel = null; document.getElementById('r-beauty').textContent = r.beauty; CHIE.toast(r.message, 'success', 2000); render();
    }).catch(function (e) { CHIE.toast(e.userMessage || e.message, 'error'); }).then(function () { busy = false; });
  }
  root.addEventListener('click', function (e) {
    var p = e.target.closest('[data-pick]');
    if (p) { var id = parseInt(p.getAttribute('data-pick'), 10); sel = sel === id ? null : id; render(); return; }
    var c = e.target.closest('.room-cell');
    if (!c) return;
    var x = parseInt(c.getAttribute('data-x'), 10), y = parseInt(c.getAttribute('data-y'), 10), it = at(x, y);
    if (it) return place(it, null, null);
    if (sel) place(items.find(function (i) { return i.id === sel; }), x, y);
    else CHIE.toast('Hãy chọn một món trong túi đồ trước.', '', 2500);
  });
  render();
})();
