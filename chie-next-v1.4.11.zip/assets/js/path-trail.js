/* Lộ trình kiểu con đường: bấm nút tròn để mở thẻ bài học; bấm ra ngoài / Esc để đóng. */
(function () {
  var open = null;
  function close() {
    if (!open) return;
    open.setAttribute('aria-expanded', 'false');
    document.getElementById(open.getAttribute('aria-controls')).hidden = true;
    open.closest('.trail-step').classList.remove('is-open');
    open = null;
  }
  document.addEventListener('click', function (e) {
    var btn = e.target.closest('.trail-node[aria-controls]');
    if (btn) {
      var same = btn === open;
      close();
      if (same) return;
      btn.setAttribute('aria-expanded', 'true');
      var pop = document.getElementById(btn.getAttribute('aria-controls'));
      pop.hidden = false;
      btn.closest('.trail-step').classList.add('is-open');
      open = btn;
      var link = pop.querySelector('a');
      if (link && e.detail === 0) link.focus(); // mở bằng bàn phím: đưa tiêu điểm vào nút trong thẻ
      return;
    }
    if (open && !e.target.closest('.trail-pop')) close();
  });
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape' && open) { var b = open; close(); b.focus(); }
  });
  // cuộn tới bài đang học khi mở trang
  var cur = document.querySelector('.trail-step.current');
  if (cur && cur.getBoundingClientRect().top > window.innerHeight * .7) {
    cur.scrollIntoView({ block: 'center', behavior: 'auto' });
  }
})();
