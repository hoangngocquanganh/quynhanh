/* Cửa hàng, Hòm quà, Túi đồ. Mọi giao dịch gửi kèm idempotency_key để bấm 2 lần không trừ Xu 2 lần. */
(function () {
  'use strict';
  var root = document.getElementById('shop');
  if (!root) return;
  var CHIE = window.CHIE, esc = CHIE.esc;
  function setXu(x) { var el = document.getElementById('s-xu'); if (el) el.innerHTML = Number(x).toLocaleString('vi-VN') + ' ' + CHIE.icon('coins'); }

  root.addEventListener('click', function (e) {
    var b = e.target.closest('[data-buy-item]');
    if (b) {
      if (!window.confirm('Mua "' + b.getAttribute('data-name') + '" với ' + b.getAttribute('data-price') + ' Xu?')) return;
      b.disabled = true;
      CHIE.api('POST', root.getAttribute('data-buy-url'), { item_id: parseInt(b.getAttribute('data-buy-item'), 10), idempotency_key: CHIE.idem() })
        .then(function (r) { setXu(r.xu); CHIE.toast(r.message, 'success'); })
        .catch(function (err) { CHIE.toast(err.userMessage || err.message, 'error', 6000); })
        .then(function () { b.disabled = false; });
      return;
    }
    var s = e.target.closest('[data-sell-inv]');
    if (s) {
      if (!window.confirm('Bán lại "' + s.getAttribute('data-name') + '" cho CHIE để nhận ' + s.getAttribute('data-price') + ' Xu?')) return;
      s.disabled = true;
      CHIE.api('POST', root.getAttribute('data-sell-url'), { inventory_id: parseInt(s.getAttribute('data-sell-inv'), 10), idempotency_key: CHIE.idem() })
        .then(function (r) { setXu(r.xu); CHIE.toast(r.message, 'success'); var card = s.closest('.item-card'); if (card) card.remove(); })
        .catch(function (err) { CHIE.toast(err.userMessage || err.message, 'error', 6000); s.disabled = false; });
    }
  });

  var spin = document.getElementById('g-spin');
  if (spin) {
    var pending = null; // giữ khóa khi mạng lỗi để gửi lại không quay thêm lượt
    spin.addEventListener('click', function () {
      spin.disabled = true;
      var key = pending || (pending = CHIE.idem());
      var box = document.getElementById('g-result');
      box.className = 'item-card';
      box.innerHTML = '<span class="big" aria-hidden="true">🎁</span><span class="small muted">Đang mở…</span>';
      CHIE.api('POST', root.getAttribute('data-spin-url'), { pool_id: parseInt(root.getAttribute('data-pool'), 10), idempotency_key: key })
        .then(function (r) {
          pending = null;
          box.className = 'item-card rarity-' + r.item.rarity;
          box.innerHTML = '<span class="big" aria-hidden="true">' + esc(r.item.icon) + '</span><span class="name">' + esc(r.item.name) + '</span><span class="rar">' + esc(r.item.rarity_label) + '</span>' +
            (r.was_pity ? '<span class="chip">Bảo đảm</span>' : '');
          setXu(r.xu);
          document.getElementById('g-today').textContent = r.spins_today;
          document.getElementById('g-pity').textContent = r.pity;
          var bar = document.getElementById('g-pity-bar');
          if (bar) { var thr = parseInt(bar.getAttribute('data-max'), 10) || 200; bar.style.width = Math.min(100, Math.round(r.pity / thr * 100)) + '%'; }
          CHIE.toast('Bạn nhận được ' + r.item.name + '!', 'success');
          spin.disabled = false;
        })
        .catch(function (err) {
          if (err.status && err.status < 500) pending = null; // lỗi nghiệp vụ (hết Xu, hết lượt) → khóa mới cho lần sau
          box.innerHTML = '<span class="big" aria-hidden="true">🎁</span><span class="small">' + esc(err.userMessage || err.message) + '</span>';
          spin.disabled = !!(err.status && err.status === 422 && /lượt/.test(err.userMessage || ''));
        });
    });
  }
})();
