/* Khối tự ghi âm dùng chung (trang Nói, Phát âm). */
(function () {
  var wrap = document.getElementById('self-rec');
  if (!wrap || !window.CHIE || !CHIE.Recorder) return;
  var s = document.getElementById('r-status'), bStart = document.getElementById('r-start'), bStop = document.getElementById('r-stop'), bPlay = document.getElementById('r-play');
  if (!CHIE.Recorder.supported) { s.textContent = 'Trình duyệt này chưa hỗ trợ ghi âm. Hãy nghe mẫu và nói theo thành tiếng.'; bStart.disabled = true; return; }
  var rec = new CHIE.Recorder({ canvas: document.getElementById('wave'), onstop: function () { bPlay.disabled = false; bStart.disabled = false; bStop.disabled = true; s.textContent = 'Đã ghi xong — bấm "Nghe lại" để so với giọng mẫu.'; } });
  bStart.onclick = function () { rec.start().then(function () { bStart.disabled = true; bStop.disabled = false; s.textContent = 'Đang thu âm… nói theo câu mẫu (tối đa 15 giây).'; }).catch(function (e) { s.textContent = e.message; }); };
  bStop.onclick = function () { rec.stop(); };
  bPlay.onclick = function () { rec.play(); };
  window.addEventListener('pagehide', function () { rec.dispose(); });
})();
