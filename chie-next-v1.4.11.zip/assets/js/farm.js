/* CHIE Farm — giao diện nông trại. Mọi hành động kinh tế gửi lên máy chủ; thao tác thường ngày không bắt buộc câu hỏi. */
(function () {
  'use strict';
  var root = document.getElementById('farm');
  if (!root) return;
  var busy = false, revision = 0, refreshing = false, nextRefresh = 0;
  var CHIE = window.CHIE, esc = CHIE.esc, ic = CHIE.icon;
  var crops = JSON.parse(root.getAttribute('data-crops'));
  var recipes = JSON.parse(root.getAttribute('data-recipes'));
  var S = JSON.parse(root.getAttribute('data-state'));
  var kinds = JSON.parse(root.getAttribute('data-animals') || '[]');
  // nguyên liệu nấu ăn = nông sản + sản phẩm vật nuôi
  var ingredients = crops.map(function (c) { return { code: c.code, en: c.en }; }).concat(kinds.map(function (k) { return { code: k.product_code, en: k.product_en }; }));
  var dlg = document.getElementById('f-dialog'), body = document.getElementById('f-dialog-body');
  var cropBy = {}; crops.forEach(function (c) { cropBy[c.code] = c; });
  var LOC = { outer: 'Kho Ngoài (có thể bị lấy)', inner: 'Kho Trong (an toàn)', cold: 'Kho Lạnh (an toàn, theo giờ)' };

  function fmt(sec) { sec = Math.max(0, sec | 0); var h = Math.floor(sec / 3600), m = Math.floor(sec % 3600 / 60), s = sec % 60; return h ? h + 'g ' + m + 'p' : m ? m + 'p ' + s + 's' : s + 's'; }

  function render() {
    document.getElementById('f-xu').innerHTML = Number(S.wallet.xu).toLocaleString('vi-VN') + ' ' + ic('coins');
    document.getElementById('f-wall').textContent = 'Lv ' + S.wall_level;
    document.getElementById('f-shield').textContent = S.shield_until ? 'đến ' + new Date(S.shield_until).toLocaleString('vi-VN', { hour: '2-digit', minute: '2-digit', day: '2-digit', month: '2-digit' }) : 'Không';
    var plots = document.getElementById('f-plots');
    plots.innerHTML = S.plots.map(function (p) {
      if (p.locked) return '<button type="button" class="plot locked" data-buy-plot role="listitem" aria-label="Ô đất khóa — mở bằng Xu">' + ic('lock') + '<span class="lbl">' + S.next_plot_price + ' Xu</span></button>';
      if (!p.crop) return '<button type="button" class="plot" data-slot="' + p.slot + '" data-act="plant" role="listitem" aria-label="Ô trống ' + (p.slot + 1) + ' — gieo hạt"><span class="crop" aria-hidden="true">🟫</span><span class="lbl">Gieo hạt</span></button>';
      var stage = p.ready ? 3 : p.progress < 34 ? 0 : p.progress < 67 ? 1 : 2;
      var label = p.ready ? 'Thu hoạch' : p.pest ? 'Có sâu!' : fmt(p.seconds_left);
      return '<button type="button" class="plot ' + (p.ready ? 'ready' : '') + '" data-slot="' + p.slot + '" data-act="' + (p.ready ? 'harvest' : 'care') + '" role="listitem" aria-label="' + esc(p.name) + ': ' + esc(label) + '">' +
        (p.pest ? '<span class="pest" aria-hidden="true">🐛</span>' : '') + '<span class="crop stage-' + stage + '" aria-hidden="true">' + (stage === 0 ? '🌱' : esc(p.icon)) + '</span><span class="lbl" data-left="' + (p.ready ? '' : p.seconds_left) + '">' + esc(label) + '</span></button>';
    }).join('');
    // kho
    var st = document.getElementById('f-storage'), h = '';
    ['outer', 'inner', 'cold'].forEach(function (loc) {
      var items = (S.storage[loc] || []);
      var cap = loc === 'inner' ? ' · ' + S.inner_used + '/' + S.inner_capacity : loc === 'cold' ? (S.cold_until ? ' · ' + S.cold_used + '/' + S.cold_capacity + ' · đến ' + new Date(S.cold_until).toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' }) : ' · chưa thuê') : '';
      h += '<h4 class="mt-1">' + esc(LOC[loc]) + '<span class="small muted">' + cap + '</span></h4>';
      if (!items.length) { h += '<p class="small muted">Trống.</p>'; return; }
      h += items.map(function (it) {
        var acts = '';
        if (loc === 'outer') acts += '<button class="btn btn-sm" data-move="' + it.code + '" data-from="outer" data-to="inner">→ Kho Trong</button>' + (S.cold_until ? '<button class="btn btn-sm" data-move="' + it.code + '" data-from="outer" data-to="cold">→ Kho Lạnh</button>' : '');
        else acts += '<button class="btn btn-sm" data-move="' + it.code + '" data-from="' + loc + '" data-to="outer">→ Kho Ngoài</button>';
        acts += '<button class="btn btn-sm" data-sell="' + it.code + '" data-from="' + loc + '" data-qty="1">Bán 1 (' + it.sell + ' Xu)</button>';
        return '<div class="row between mb-1"><span>' + esc(it.icon) + ' <b>' + esc(it.vi) + '</b> <span class="small muted" lang="en">' + esc(it.en) + '</span> × ' + it.qty + '</span><span class="row" style="gap:4px;justify-content:flex-end">' + acts + '</span></div>';
      }).join('');
    });
    st.innerHTML = h;
    // bếp
    if (!document.getElementById('f-recipes').innerHTML) document.getElementById('f-recipes').innerHTML = recipes.map(function (r) {
      return '<details class="box mb-1"><summary>' + esc(r.icon) + ' ' + esc(r.name) + ' <span class="small muted" lang="en">(' + esc(r.en) + ')</span></summary>' +
        '<p class="mt-1" lang="en"><b>Recipe:</b> ' + esc(r.text) + ' <button type="button" class="icon-btn" data-speak="' + esc(r.text) + '" aria-label="Nghe công thức">' + ic('volume-2') + '</button></p>' +
        '<form data-cook="' + r.code + '"><div class="label small">Chọn nguyên liệu (theo tên tiếng Anh):</div><div class="row">' +
        ingredients.map(function (c) { return '<label class="check" style="min-height:36px"><input type="checkbox" name="ing" value="' + c.code + '"> <span lang="en">' + esc(c.en) + '</span></label>'; }).join('') +
        '</div><button class="btn btn-sm btn-primary mt-1">Nấu (phí ' + r.fee + ' Xu)</button></form></details>';
    }).join('');
    // vật nuôi
    var an = S.animals || [];
    var cnt = document.getElementById('f-animal-count'); if (cnt) cnt.textContent = '(' + an.length + '/' + S.animal_slots + ')';
    var box = document.getElementById('f-animals');
    if (box) box.innerHTML = an.length ? an.map(function (a) {
      var label = a.ready ? 'Lấy ' + a.product : a.hungry ? 'Cho ăn' : fmt(a.seconds_left);
      return '<button type="button" class="plot animal ' + (a.ready ? 'ready' : '') + '" data-animal="' + a.id + '" data-aact="' + (a.ready ? 'collect' : a.hungry ? 'feed' : 'wait') + '" role="listitem" aria-label="' + esc(a.name) + ': ' + esc(label) + '">' +
        '<span class="crop" aria-hidden="true">' + esc(a.icon) + '</span>' + (a.ready ? '<span class="pest" aria-hidden="true">' + esc(a.product_icon) + '</span>' : a.hungry ? '<span class="pest" aria-hidden="true">🍽️</span>' : '') +
        '<span class="lbl"' + (!a.ready && !a.hungry ? ' data-left="' + a.seconds_left + '"' : '') + '>' + esc(label) + '</span></button>';
    }).join('') : '<p class="small muted">Chưa có con vật nào. Mua bên dưới nhé!</p>';
    var shop = document.getElementById('f-animal-shop');
    if (shop) shop.innerHTML = kinds.map(function (k) {
      var locked = S.wallet.level < k.level;
      return '<button type="button" class="btn btn-sm" data-buy-animal="' + k.code + '"' + (locked ? ' disabled' : '') + '>' + esc(k.icon) + ' ' + esc(k.name) + ' · ' + k.price + ' Xu' + (locked ? ' (cấp ' + k.level + ')' : '') + '</button>';
    }).join('');
    document.dispatchEvent(new CustomEvent('farm:state', { detail: S }));
  }

  function call(url, data) {
    if (busy) return Promise.reject(new Error('Đang xử lý thao tác trước.'));
    if (!navigator.onLine) { CHIE.toast('Bạn đang mất mạng. Có thể đi dạo; kết nối lại để lưu thao tác.', 'error'); return Promise.reject(new Error('Offline')); }
    busy = true; revision += 1;
    return CHIE.api('POST', url, data).then(function (res) {
      if (res.state) { S = res.state; render(); }
      document.dispatchEvent(new CustomEvent('farm:action', { detail: { url: url, data: data, result: res } }));
      if (res.message) CHIE.toast(res.message, res.is_correct === false || res.cooked === false ? 'error' : 'success', 4500);
      return res;
    }).catch(function (e) { CHIE.toast(e.userMessage || e.message, 'error', 6000); throw e; }).finally(function () { busy = false; });
  }

  function handleFarmClick(e) {
    var p = e.target.closest('[data-act]');
    if (p) {
      var slot = parseInt(p.getAttribute('data-slot'), 10), act = p.getAttribute('data-act');
      if (act === 'harvest') return call('api/farm/harvest', { slot: slot });
      if (act === 'plant') {
        body.innerHTML = '<h3>Chọn hạt giống</h3><div class="grid grid-2">' + crops.map(function (c) {
          var locked = S.wallet.level < c.level;
          return '<button type="button" class="opt" data-crop="' + c.code + '"' + (locked ? ' disabled' : '') + '><span style="font-size:1.6rem">' + esc(c.icon) + '</span><span><b>' + esc(c.name) + '</b> <span lang="en" class="small">' + esc(c.en) + '</span><br><span class="small muted">' + c.seed + ' Xu · chín sau ' + (c.minutes >= 60 ? Math.round(c.minutes / 6) / 10 + ' giờ' : c.minutes + ' phút') + (locked ? ' · cần cấp ' + c.level : '') + '</span></span></button>';
        }).join('') + '</div>';
        dlg.showModal();
        body.querySelectorAll('[data-crop]').forEach(function (b) {
          b.onclick = function () {
            var code = b.getAttribute('data-crop');
            b.disabled = true; call('api/farm/plant', { slot: slot, crop: code }).then(function () { dlg.close(); }).catch(function () { b.disabled = false; });
          };
        });
        return;
      }
      if (act === 'care') {
        var plot = S.plots.find(function (x) { return x.slot === slot; });
        if (!plot) return;
        var purpose = plot.pest ? 'pest' : 'water';
        if (purpose === 'water' && plot.boosts >= 3) return CHIE.toast('Cây đã được chăm đủ 3 lần. Chờ cây chín nhé!', '', 3000);
        return call('api/farm/water', { slot: slot, purpose: purpose });
      }
    }
    var an = e.target.closest('[data-animal]');
    if (an) {
      var id = parseInt(an.getAttribute('data-animal'), 10), act2 = an.getAttribute('data-aact');
      if (act2 === 'collect') return call('api/farm/animal/collect', { animal: id });
      if (act2 === 'wait') return CHIE.toast('Con vật đang tạo sản phẩm, quay lại sau nhé!', '', 2500);
      return call('api/farm/animal/feed', { animal: id });
    }
    var ba = e.target.closest('[data-buy-animal]');
    if (ba) {
      var k = kinds.filter(function (x) { return x.code === ba.getAttribute('data-buy-animal'); })[0];
      if (!k || !window.confirm('Mua ' + k.name + ' với ' + k.price + ' Xu?')) return;
      return call('api/farm/animal/buy', { kind: k.code });
    }
    if (e.target.closest('[data-buy-plot]')) return call('api/farm/buy', { what: 'plot' });
    var b = e.target.closest('[data-buy]');
    if (b) {
      if (!window.confirm('Dùng Xu để ' + b.textContent.trim() + '?')) return;
      return call('api/farm/buy', { what: b.getAttribute('data-buy'), hours: b.getAttribute('data-hours') ? parseInt(b.getAttribute('data-hours'), 10) : null });
    }
    var mv = e.target.closest('[data-move]');
    if (mv) { var n = parseInt(window.prompt('Chuyển bao nhiêu?', '1'), 10); if (n > 0) call('api/farm/move', { code: mv.getAttribute('data-move'), from: mv.getAttribute('data-from'), to: mv.getAttribute('data-to'), qty: n }).catch(function () {}); return; }
    var sl = e.target.closest('[data-sell]');
    if (sl) return call('api/farm/sell', { code: sl.getAttribute('data-sell'), from: sl.getAttribute('data-from'), qty: 1 });
  }
  root.addEventListener('click', function (e) { Promise.resolve(handleFarmClick(e)).catch(function () {}); });
  root.addEventListener('submit', function (e) {
    var f = e.target.closest('[data-cook]');
    if (!f) return;
    e.preventDefault(); e.stopPropagation(); f.dataset.submitting = '0';
    var ing = Array.prototype.map.call(f.querySelectorAll('input[name=ing]:checked'), function (x) { return x.value; });
    if (!ing.length) return CHIE.toast('Hãy chọn nguyên liệu.', 'error');
    call('api/farm/cook', { recipe: f.getAttribute('data-cook'), ingredients: ing }).catch(function () {});
  }, true);

  // Server refresh is bounded, ignores stale responses and resumes after reconnect.
  function refreshState() {
    if (busy || refreshing || document.hidden || !navigator.onLine || Date.now() < nextRefresh) return;
    refreshing = true; nextRefresh = Date.now() + 15000;
    var version = revision;
    CHIE.api('GET', 'api/farm').then(function (state) {
      if (!busy && version === revision) { S = state; render(); }
    }).catch(function () { document.dispatchEvent(new Event('farm:sync-error')); }).finally(function () { refreshing = false; });
  }
  setInterval(function () {
    if (document.hidden) return;
    document.querySelectorAll('#f-plots [data-left], #f-animals [data-left]').forEach(function (el) {
      var n = parseInt(el.getAttribute('data-left'), 10);
      if (!isNaN(n)) { n = Math.max(0, n - 1); el.setAttribute('data-left', n); el.textContent = n ? fmt(n) : 'Đang kiểm tra…'; }
    });
    refreshState();
  }, 1000);
  window.addEventListener('online', function () { nextRefresh = 0; refreshState(); });
  document.addEventListener('visibilitychange', function () { if (!document.hidden) { nextRefresh = 0; refreshState(); } });
  // cho phần 3D: gọi đúng thao tác như bấm vào ô / con vật trong danh sách
  window.ChieFarm = { state: function () { return S; }, kinds: kinds, crops: crops, openPanel: function (id) { var el = document.getElementById(id); if (el) { root.classList.add('show-list'); el.closest('section').scrollIntoView({ behavior: 'smooth', block: 'center' }); } } };
  render();
})();
