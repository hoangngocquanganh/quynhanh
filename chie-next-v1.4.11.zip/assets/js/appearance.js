(function () {
  'use strict';
  var form = document.getElementById('appearance-form'), preview = document.querySelector('#avatar-preview .avatar-display');
  if (!form || !preview) return;
  function update() {
    var a = form.querySelector('[name=avatar]:checked'), c = form.querySelector('[name=color]:checked'), f = form.querySelector('[name=frame]:checked');
    if (!a || !c || !f) return;
    var al = a.closest('label'), fl = f.closest('label');
    preview.className = 'avatar-display av-xl av-bg-' + c.value + ' av-frame-' + fl.getAttribute('data-frame');
    preview.querySelector('.av-symbol').textContent = al.getAttribute('data-symbol');
    preview.setAttribute('aria-label', 'Xem trước avatar: ' + al.getAttribute('data-label'));
    var select = document.getElementById('avatar-badge'), icon = select.options[select.selectedIndex].getAttribute('data-icon'), pin = preview.querySelector('.av-pin');
    if (!pin) { pin = document.createElement('span'); pin.className = 'av-pin'; preview.appendChild(pin); }
    pin.hidden = !icon; pin.textContent = icon || '';
  }
  form.addEventListener('change', update);
  update();
})();
