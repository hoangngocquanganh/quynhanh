/* Ghi âm để TỰ NGHE LẠI và so sánh với giọng mẫu. Bản ghi chỉ nằm trong bộ nhớ trình duyệt,
   KHÔNG tải lên máy chủ, tự xóa khi rời trang. Không chấm điểm phát âm bằng máy. */
(function () {
  'use strict';
  var CHIE = window.CHIE;
  var supported = !!(navigator.mediaDevices && navigator.mediaDevices.getUserMedia && window.MediaRecorder);
  var SR = window.SpeechRecognition || window.webkitSpeechRecognition;

  function Recorder(opts) {
    this.opts = opts || {};
    this.url = null; this.stream = null; this.rec = null; this.chunks = []; this.state = 'idle';
  }
  Recorder.supported = supported;
  Recorder.recognitionSupported = !!SR;

  Recorder.prototype.start = function () {
    var self = this;
    if (!supported) return Promise.reject(new Error('Trình duyệt này chưa hỗ trợ ghi âm. Bạn vẫn có thể nghe mẫu và nói theo thành tiếng.'));
    CHIE.speech.stop();
    return navigator.mediaDevices.getUserMedia({ audio: true }).then(function (stream) {
      self.stream = stream; self.chunks = [];
      self.rec = new MediaRecorder(stream);
      self.rec.ondataavailable = function (e) { if (e.data && e.data.size) self.chunks.push(e.data); };
      self.rec.onstop = function () {
        if (self.url) URL.revokeObjectURL(self.url);
        self.url = URL.createObjectURL(new Blob(self.chunks, { type: self.rec.mimeType || 'audio/webm' }));
        self.stream.getTracks().forEach(function (t) { t.stop(); });
        self.state = 'recorded';
        if (self.opts.onstop) self.opts.onstop(self.url);
      };
      self.rec.start();
      self.state = 'recording';
      if (self.opts.canvas) self._draw(stream);
      // tự dừng sau 15 giây
      self._timer = setTimeout(function () { self.stop(); }, (self.opts.maxSeconds || 15) * 1000);
    }, function (err) {
      var msg = 'Không mở được micro.';
      if (err && (err.name === 'NotAllowedError' || err.name === 'SecurityError')) msg = 'Bạn chưa cho phép dùng micro. Bấm vào biểu tượng ổ khóa trên thanh địa chỉ → cho phép Micro, rồi thử lại.';
      else if (err && err.name === 'NotFoundError') msg = 'Không tìm thấy micro trên thiết bị này.';
      throw new Error(msg);
    });
  };
  Recorder.prototype.stop = function () {
    clearTimeout(this._timer);
    if (this.rec && this.state === 'recording') this.rec.stop();
    if (this._raf) cancelAnimationFrame(this._raf);
    if (this._ctx) { try { this._ctx.close(); } catch (e) {} this._ctx = null; }
  };
  Recorder.prototype.play = function () {
    if (!this.url) return;
    CHIE.speech.stop();
    var a = new Audio(this.url); a.play();
  };
  Recorder.prototype.dispose = function () {
    this.stop();
    if (this.url) URL.revokeObjectURL(this.url);
    this.url = null;
  };
  Recorder.prototype._draw = function (stream) {
    var canvas = this.opts.canvas, g = canvas.getContext('2d');
    var AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return;
    var ctx = this._ctx = new AC();
    var src = ctx.createMediaStreamSource(stream);
    var an = ctx.createAnalyser(); an.fftSize = 1024;
    src.connect(an);
    var data = new Uint8Array(an.fftSize);
    var self = this;
    var color = getComputedStyle(document.documentElement).getPropertyValue('--c-primary') || '#2E5BE6';
    (function loop() {
      an.getByteTimeDomainData(data);
      g.clearRect(0, 0, canvas.width, canvas.height);
      g.lineWidth = 3; g.strokeStyle = color.trim(); g.beginPath();
      for (var i = 0; i < data.length; i += 4) {
        var x = i / data.length * canvas.width, y = data[i] / 255 * canvas.height;
        if (i === 0) g.moveTo(x, y); else g.lineTo(x, y);
      }
      g.stroke();
      self._raf = requestAnimationFrame(loop);
    })();
  };

  /** Nhận dạng chữ (nếu trình duyệt có) — CHỈ để hiển thị "máy nghe được gì", không phải điểm phát âm. */
  Recorder.recognize = function (onText, onEnd) {
    if (!SR) { onEnd && onEnd(false); return null; }
    var r = new SR();
    r.lang = 'en-US'; r.interimResults = false; r.maxAlternatives = 1;
    r.onresult = function (e) { onText(e.results[0][0].transcript); };
    r.onerror = r.onend = function () { onEnd && onEnd(true); };
    try { r.start(); } catch (e) { onEnd && onEnd(false); return null; }
    return r;
  };

  window.addEventListener('pagehide', function () { document.querySelectorAll('audio').forEach(function (a) { a.pause(); }); });
  CHIE.Recorder = Recorder;
})();
