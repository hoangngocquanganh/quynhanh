/* Tải gói thẻ từ về máy (localStorage) để ôn khi mất mạng; trang offline.html đọc gói này. */
(function () {
  var card = document.getElementById('offline-card');
  if (!card) return;
  var st = document.getElementById('offline-st'), btn = document.getElementById('offline-dl');
  function show() {
    try { var p = JSON.parse(localStorage.getItem('chie_offline_pack') || 'null'); if (p) st.textContent = 'Đã có ' + p.words.length + ' thẻ (' + (p.grade_name || '') + '), tải lúc ' + new Date(p.generated_at).toLocaleString('vi-VN'); } catch (e) {}
  }
  btn.onclick = function () {
    btn.disabled = true;
    CHIE.api('GET', card.getAttribute('data-pack-url')).then(function (p) {
      try { localStorage.setItem('chie_offline_pack', JSON.stringify(p)); CHIE.toast('Đã lưu ' + p.words.length + ' thẻ từ vào máy.', 'success'); }
      catch (e) { CHIE.toast('Máy không cho lưu dữ liệu (chế độ ẩn danh hoặc bộ nhớ đầy).', 'error', 6000); }
      show();
    }).catch(function (e) { CHIE.toast(e.userMessage || e.message, 'error'); }).then(function () { btn.disabled = false; });
  };
  show();
})();
