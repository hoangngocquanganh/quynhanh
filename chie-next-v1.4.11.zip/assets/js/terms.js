(function () {
  var box = document.getElementById('terms-scroll'), cb = document.getElementById('terms-agree');
  if (!box || !cb) return;
  function check() { if (box.scrollTop + box.clientHeight >= box.scrollHeight - 12) { cb.disabled = false; } }
  box.addEventListener('scroll', check);
  setTimeout(check, 300);
  if (cb.checked) cb.disabled = false;
})();
