/* Đấu 1–1: hỏi trạng thái máy chủ ~1,5 giây/lần (không cần WebSocket), trả lời từng câu qua API chấm của máy chủ. */
(function () {
  'use strict';
  var root = document.getElementById('duel');
  if (!root) return;
  var CHIE = window.CHIE, esc = CHIE.esc, ic = CHIE.icon;
  var S = JSON.parse(root.getAttribute('data-state'));
  var panel = document.getElementById('d-panel');
  var items = null, idx = 0, shownAt = 0, busy = false, waitedSince = Date.now(), poll = null, finished = false;

  function emit() { document.dispatchEvent(new CustomEvent('duel:state', { detail: S })); }
  function fmt(s) { s = Math.max(0, s | 0); return Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0'); }
  function board() {
    document.getElementById('d-me-score').textContent = S.me.correct;
    document.getElementById('d-op-score').textContent = S.opponent.correct;
    document.getElementById('d-me-bar').style.width = Math.round(S.me.answered / S.total * 100) + '%';
    document.getElementById('d-op-bar').style.width = Math.round(S.opponent.answered / S.total * 100) + '%';
    document.getElementById('d-op-name').textContent = S.opponent.name || 'Đang tìm đối thủ…';
    var av = document.getElementById('d-op-avatar'), appearance = S.opponent.appearance;
    if (av && appearance) {
      av.className = 'avatar-display av-sm av-bg-' + appearance.color + ' av-frame-' + appearance.style;
      av.querySelector('.av-symbol').textContent = appearance.symbol;
    }
    document.getElementById('d-timer').textContent = S.seconds_left != null ? fmt(S.seconds_left) : '--:--';
  }

  function waiting() {
    if (S.can_accept) {
      panel.innerHTML = '<div class="card center"><h2>' + esc(S.opponent.name) + ' thách đấu bạn!</h2><p class="muted">' + S.total + ' câu trắc nghiệm. Sẵn sàng chưa?</p>' +
        '<div class="btn-row" style="justify-content:center"><button class="btn btn-primary btn-lg" id="d-accept">' + ic('swords') + ' Nhận lời</button><a class="btn" href="' + root.getAttribute('data-home') + '">Để sau</a></div></div>';
      document.getElementById('d-accept').onclick = function () { this.disabled = true; CHIE.api('POST', root.getAttribute('data-accept-url'), {}).then(function (r) { location.href = r.redirect; }).catch(err); };
      return;
    }
    var secs = Math.round((Date.now() - waitedSince) / 1000);
    var bot = esc(S.bot_preview || 'bạn máy');
    panel.innerHTML = '<div class="card center"><div class="spinner" aria-hidden="true"></div><h2 class="mt-1">' + (S.mode === 'challenge' ? 'Đang chờ bạn ấy nhận lời…' : 'Đang tìm đối thủ cùng lớp…') + '</h2>' +
      '<p class="small muted" id="d-wait">' + waitText() + '</p><div class="btn-row" style="justify-content:center">' +
      (S.mode === 'quick' ? '<button class="btn btn-primary" id="d-bot">Đấu ngay với ' + bot + '</button>' : '') +
      '<button class="btn" id="d-cancel">Hủy</button></div><p class="small muted mt-1">Bạn máy chơi vừa sức lứa tuổi và trình độ của bạn. Đấu với máy vẫn được XP/Xu của bài làm, nhưng không có thưởng thắng.</p></div>';
    var b = document.getElementById('d-bot');
    if (b) b.onclick = function () { b.disabled = true; CHIE.api('POST', root.getAttribute('data-bot-url'), {}).then(function (st) { S = st; tick(true); }).catch(err); };
    document.getElementById('d-cancel').onclick = function () { CHIE.api('POST', root.getAttribute('data-cancel-url'), {}).then(function (r) { location.href = r.redirect; }).catch(err); };
  }

  function waitText() {
    var secs = Math.round((Date.now() - waitedSince) / 1000);
    if (S.mode !== 'quick' || S.auto_bot_in == null) return 'Đã chờ ' + secs + ' giây. Trang tự cập nhật.';
    var left = Math.max(0, Math.ceil((autoAt - Date.now()) / 1000));
    return left > 0 ? 'Chưa có ai? Sau ' + left + ' giây bạn sẽ được ghép với ' + (S.bot_preview || 'bạn máy') + '.' : 'Đang ghép với ' + (S.bot_preview || 'bạn máy') + '…';
  }
  var autoAt = Date.now() + ((S.auto_bot_in || 0) * 1000);

  function nextIdx() { for (var i = 0; i < items.length; i++) if (!items[i].answered) return i; return -1; }
  function question() {
    idx = nextIdx();
    if (idx < 0) { panel.innerHTML = '<div class="card center"><div class="spinner"></div><h2 class="mt-1">Bạn đã làm xong!</h2><p class="muted">Chờ đối thủ hoặc hết giờ…</p></div>'; return; }
    var it = items[idx], p = it.prompt || {};
    var h = '<div class="card"><div class="q-instruction">Câu ' + (idx + 1) + '/' + items.length + '</div>' +
      '<div class="q-text">' + esc(p.text || '') + '</div>';
    if (it.type === 'listen_mcq' && (p.speak || p.speak_word)) h += '<div class="audio-bar"><button type="button" class="audio-btn" data-speak="' + esc(p.speak || p.speak_word) + '">' + ic('volume-2') + ' Nghe</button><button type="button" class="audio-btn slow" data-speak="' + esc(p.speak || p.speak_word) + '" data-slow>' + ic('snail') + '</button></div>';
    h += '<div class="options">' + (it.display.options || []).map(function (o, i) { return '<button type="button" class="opt" data-di="' + i + '"><span class="k">' + 'ABCD'[i] + '</span><span>' + esc(o) + '</span></button>'; }).join('') + '</div><div id="d-fb"></div></div>';
    panel.innerHTML = h; shownAt = Date.now();
    panel.querySelectorAll('[data-di]').forEach(function (b) { b.onclick = function () { answer(parseInt(b.getAttribute('data-di'), 10)); }; });
  }
  function answer(choice) {
    if (busy) return; busy = true;
    var it = items[idx];
    panel.querySelectorAll('[data-di]').forEach(function (b) { b.disabled = true; });
    CHIE.api('POST', S.answer_url, { position: it.position, response: { choice: choice }, time_ms: Date.now() - shownAt }).then(function (fb) {
      it.answered = true;
      panel.querySelectorAll('[data-di]').forEach(function (b) { var i = parseInt(b.getAttribute('data-di'), 10); if (i === fb.correct_index) b.classList.add('is-correct'); else if (i === choice) b.classList.add('is-wrong'); });
      document.getElementById('d-fb').innerHTML = '<div class="mt-1 ' + (fb.is_correct ? 'text-success' : 'text-danger') + '"><b>' + (fb.is_correct ? 'Chính xác!' : 'Chưa đúng.') + '</b> ' + (fb.explanation_vi ? esc(fb.explanation_vi) : '') + '</div>';
      S.me.answered++; if (fb.is_correct) S.me.correct++; board();
      document.dispatchEvent(new CustomEvent('duel:hit', { detail: { me: true, ok: fb.is_correct } }));
      setTimeout(function () { busy = false; question(); }, fb.is_correct ? 700 : 1500);
    }).catch(function (e) { busy = false; err(e); tick(true); });
  }

  function result() {
    finished = true; if (poll) clearInterval(poll);
    var w = S.winner, title = w === 'me' ? 'Bạn thắng! 🏆' : w === 'draw' ? 'Hòa! 🤝' : 'Thua sát nút — lần sau nhé! 💪';
    panel.innerHTML = '<div class="card duel-result"><div class="big" aria-hidden="true">' + (w === 'me' ? '🏆' : w === 'draw' ? '🤝' : '🌱') + '</div><h2>' + title + '</h2>' +
      '<p>Bạn đúng <b>' + S.me.correct + '</b>/' + S.total + ' · ' + esc(S.opponent.name || '') + ' đúng <b>' + S.opponent.correct + '</b>/' + S.total + '</p>' +
      (w === 'me' && !S.opponent.bot ? '<p class="small muted">Đã cộng thưởng thắng (trong giới hạn mỗi ngày).</p>' : '') +
      '<div class="btn-row" style="justify-content:center"><a class="btn btn-primary" href="' + root.getAttribute('data-home') + '">Đấu tiếp</a>' +
      (S.my_attempt ? '<a class="btn" href="' + root.getAttribute('data-result-base') + '/' + S.my_attempt + '">Xem lại câu sai</a>' : '') + '</div></div>';
    emit();
  }

  function tick(force) {
    if (finished) return;
    var needItems = S.status === 'active' && !items;
    CHIE.api('GET', root.getAttribute('data-state-url') + (needItems ? '?with_items=1' : ''), null, { quiet: true }).then(function (st) {
      var was = S.status;
      if (st.items) { items = st.items; delete st.items; }
      S = st; if (S.auto_bot_in != null) autoAt = Date.now() + S.auto_bot_in * 1000; board(); emit();
      if (S.status === 'finished') return result();
      if (S.status === 'cancelled' || S.status === 'expired') { finished = true; panel.innerHTML = '<div class="card center"><h2>Trận đã ' + (S.status === 'cancelled' ? 'hủy' : 'hết hạn') + '</h2><a class="btn btn-primary" href="' + root.getAttribute('data-home') + '">Về Đấu 1–1</a></div>'; return; }
      if (S.status === 'waiting') { if (panel.dataset.view !== 'waiting') { panel.dataset.view = 'waiting'; waiting(); } return; }
      panel.dataset.view = S.status;
      if (S.status === 'active') {
        if (!items) return tick(true);
        if (was !== 'active' || force || !panel.querySelector('[data-di]') && nextIdx() >= 0 && !busy) question();
      }
    }).catch(function () {});
  }
  function err(e) { CHIE.toast(e.userMessage || e.message, 'error', 5000); }

  board();
  if (S.status === 'finished') result(); else { tick(true); poll = setInterval(function () { tick(false); }, 1500); }
  // đồng hồ đếm lùi giữa hai lần hỏi máy chủ
  setInterval(function () { if (S.status === 'active' && S.seconds_left > 0) { S.seconds_left--; document.getElementById('d-timer').textContent = fmt(S.seconds_left); } if (S.status === 'waiting') { var p = document.getElementById('d-wait'); if (p) p.textContent = waitText(); } }, 1000);
})();
