/* Trình làm bài: một câu / một nhiệm vụ mỗi bước. Máy chủ chấm; trình duyệt chỉ hiển thị.
   Chế độ: live (bài học/ôn/đề/game-quiz), demo (khách học thử, lưu trong phiên). */
(function () {
  'use strict';
  var root = document.getElementById('player');
  if (!root) return;
  var CHIE = window.CHIE, esc = CHIE.esc, ic = CHIE.icon;
  var URLS = JSON.parse(root.getAttribute('data-urls'));
  var MODE = root.getAttribute('data-mode');
  var guestToken = MODE === 'demo' ? location.hash.slice(1) : null;
  if (guestToken) history.replaceState(null, '', location.pathname + location.search);
  var $body = document.getElementById('p-body'), $foot = document.getElementById('p-foot');
  var $bar = document.querySelector('#p-progress > span'), $count = document.getElementById('p-count'), $timer = document.getElementById('p-timer');
  var V = null, idx = 0, sel = null, shownAt = 0, busy = false, hintUsed = false, rec = null, timerInt = null, deadline = null;

  var INSTR = {
    mcq: 'Chọn đáp án đúng', listen_mcq: 'Nghe rồi chọn đáp án đúng', word_order: 'Bấm các từ theo đúng thứ tự để tạo câu',
    matching: 'Ghép mỗi từ tiếng Anh với nghĩa đúng', fill_blank: 'Điền từ còn thiếu', writing: 'Viết câu trả lời của bạn',
    speaking: 'Nghe mẫu rồi nói theo'
  };
  var SKILL = { vocabulary: 'Từ vựng', grammar: 'Ngữ pháp', listening: 'Nghe', speaking: 'Nói', reading: 'Đọc', writing: 'Viết', pronunciation: 'Phát âm', communication: 'Giao tiếp' };
  var SKILL_IC = { vocabulary: 'sparkles', grammar: 'puzzle', listening: 'headphones', speaking: 'mic', reading: 'book-open', writing: 'pen-line', pronunciation: 'audio-lines', communication: 'message-circle' };
  var GRADABLE = { mcq: 1, listen_mcq: 1, word_order: 1, matching: 1, fill_blank: 1 };

  function immediate() { return V && V.feedback === 'immediate'; }
  function item() { return V.items[idx]; }

  function load() {
    if (MODE === 'demo' && !guestToken) {
      $body.innerHTML = '<div class="empty"><h2>Bắt đầu một lượt học mới</h2><p>Chế độ khách không lưu lượt học khi tải lại hoặc rời trang.</p><a class="btn btn-primary" href="' + esc(URLS.exit) + '">Chọn bài học</a></div>';
      return;
    }
    (MODE === 'demo' ? CHIE.api('POST', URLS.show, { guest_token: guestToken }) : CHIE.api('GET', URLS.show)).then(function (v) {
      V = v;
      if (V.status !== 'in_progress' && URLS.result) { location.href = URLS.result; return; }
      // tới câu đầu tiên chưa trả lời
      idx = 0;
      for (var i = 0; i < V.items.length; i++) { if (!V.items[i].answered) { idx = i; break; } if (i === V.items.length - 1) idx = i; }
      if (V.seconds_left !== null && V.seconds_left !== undefined) startTimer(V.seconds_left);
      render();
    }).catch(function (e) {
      $body.innerHTML = '<div class="empty">' + ic('wifi-off') + '<h3>Chưa tải được bài</h3><p>' + esc(e.userMessage || e.message) + '</p><button class="btn btn-primary" id="p-retry">Thử lại</button></div>';
      document.getElementById('p-retry').onclick = load;
    });
  }

  function startTimer(sec) {
    deadline = Date.now() + sec * 1000;
    $timer.hidden = false;
    var span = $timer.querySelector('span');
    clearInterval(timerInt);
    timerInt = setInterval(function () {
      var left = Math.max(0, Math.round((deadline - Date.now()) / 1000));
      span.textContent = String(Math.floor(left / 60)).padStart(2, '0') + ':' + String(left % 60).padStart(2, '0');
      $timer.classList.toggle('low', left <= 60);
      if (left <= 0) { clearInterval(timerInt); CHIE.toast('Hết giờ! Bài được nộp tự động.', '', 3000); submit(true); }
    }, 1000);
  }

  function updateTop() {
    var answered = V.items.filter(function (x) { return x.answered; }).length;
    $bar.style.width = Math.round(answered / V.items.length * 100) + '%';
    document.getElementById('p-progress').setAttribute('aria-valuenow', Math.round(answered / V.items.length * 100));
    $count.textContent = 'Câu ' + (idx + 1) + '/' + V.items.length;
  }

  /* ---------------- vẽ câu hỏi ---------------- */
  function render() {
    CHIE.speech.stop();
    if (rec) { rec.dispose(); rec = null; }
    sel = null; hintUsed = false; shownAt = Date.now();
    var it = item();
    updateTop();
    var p = it.prompt || {}, h = '';
    h += '<div class="q-kicker sk-' + esc(it.skill || '') + '">' + ic(SKILL_IC[it.skill] || 'sparkles') + '<span>' + esc(it.from_srs ? 'Ôn lại' : (SKILL[it.skill] || 'Luyện tập')) + '</span>' +
         (it.phase === 'guided' && immediate() ? '<span class="badge badge-accent">Có hướng dẫn</span>' : '') + '</div>';
    h += '<div class="q-instruction">' + esc(INSTR[it.type] || '') + '</div>';
    if (p.lines && p.lines.length) {
      h += '<ul class="dialogue">' + p.lines.map(function (l) {
        var m = /^([AB]):\s*(.*)$/.exec(l), who = m ? m[1] : '', txt = m ? m[2] : l;
        return '<li class="' + (who === 'B' ? 'b' : '') + '"><span class="who">' + esc(who) + '</span><span lang="en">' + esc(txt) + '</span></li>';
      }).join('') + '</ul>';
    }
    var speakText = it.type === 'listen_mcq' ? (p.speak || p.speak_word) : (it.type === 'speaking' ? (p.speak || p.model || p.text) : null);
      h += '<h1 class="q-text" id="q-title" tabindex="-1">' + esc(it.type === 'listen_mcq' ? (p.text || 'Bạn nghe được gì?') : (p.text || '')) + '</h1>';
      if (p.ipa && it.type !== 'listen_mcq') h += '<div class="ipa muted mb-1">' + esc(p.ipa) + '</div>';
    if (speakText) {
      h += '<div class="audio-bar"><button type="button" class="audio-btn" id="a-play" aria-label="Nghe">' + ic('volume-2') + '<span>Nghe</span></button>' +
           '<button type="button" class="audio-btn slow" id="a-slow" aria-label="Nghe chậm">' + ic('snail') + '<span>Nghe chậm</span></button></div>';
    }
    h += '<div id="q-area"></div>';
    if (it.phase === 'guided' && immediate() && it.hint_vi && !it.answered) h += '<button type="button" class="btn btn-ghost btn-sm mt-1" id="q-hint">' + ic('lightbulb') + ' Xem gợi ý</button><div id="q-hint-box"></div>';
    h += '<div class="row mt-2"><button type="button" class="link-btn small muted" id="q-report">' + ic('flag') + ' Báo câu hỏi có lỗi</button></div>';
    $body.innerHTML = h;
    var area = document.getElementById('q-area');
    ({ mcq: renderMcq, listen_mcq: renderMcq, word_order: renderOrder, matching: renderMatch, fill_blank: renderFill, writing: renderWriting, speaking: renderSpeaking }[it.type] || renderMcq)(area, it);
    if (speakText) {
      document.getElementById('a-play').onclick = function () { CHIE.speech.say(speakText, { button: this }); };
      document.getElementById('a-slow').onclick = function () { CHIE.speech.say(speakText, { button: this, rate: CHIE.speech.slow }); };
    }
    var hb = document.getElementById('q-hint');
    if (hb) hb.onclick = function () { hintUsed = true; document.getElementById('q-hint-box').innerHTML = '<div class="hint-box">' + ic('lightbulb') + ' ' + esc(it.hint_vi) + '</div>'; hb.remove(); };
    document.getElementById('q-report').onclick = reportQuestion;
    if (it.answered && immediate()) showFeedback({ is_correct: it.is_correct, correct_text: it.correct_text, correct_index: it.correct_index, explanation_vi: it.explanation_vi, tips: it.tips, example_after: (it.prompt || {}).example_after }, true);
    else renderFoot();
    var t = document.getElementById('q-title'); if (t) t.focus({ preventScroll: true });
    window.scrollTo(0, 0);
  }

  function renderMcq(area, it) {
    var opts = (it.display && it.display.options) || [];
    var prev = it.response && typeof it.response.choice === 'number' ? it.response.choice : null;
    // có hình cho mọi phương án → thẻ hình; không thì thẻ chữ. Phím số 1–4 để chọn nhanh.
    area.innerHTML = '<div class="options words" role="group" aria-label="Các lựa chọn">' + opts.map(function (o, i) {
      return '<button type="button" class="opt" data-i="' + i + '" aria-pressed="' + (prev === i ? 'true' : 'false') + '">' +
        '<span class="t" lang="' + (isEn(o) ? 'en' : 'vi') + '">' + esc(o) + '</span><span class="k" aria-hidden="true">' + (i + 1) + '</span></button>';
    }).join('') + '</div>';
    if (prev !== null) sel = { choice: prev };
    area.querySelectorAll('.opt').forEach(function (b) {
      b.onclick = function () {
        if (it.answered && immediate()) return;
        area.querySelectorAll('.opt').forEach(function (x) { x.setAttribute('aria-pressed', 'false'); });
        b.setAttribute('aria-pressed', 'true');
        var i = parseInt(b.getAttribute('data-i'), 10);
        sel = { choice: i };
        renderFoot();
      };
    });
  }

  function isEn(s) { return /[a-z]/i.test(s || '') && !/[àáạảãâầấậẩẫăằắặẳẵèéẹẻẽêềếệểễìíịỉĩòóọỏõôồốộổỗơờớợởỡùúụủũưừứựửữỳýỵỷỹđ]/i.test(s); }

  function renderOrder(area, it) {
    var tokens = (it.display && it.display.tokens) || [];
    var order = it.response && it.response.order ? it.response.order.slice() : [];
    function draw() {
      area.innerHTML = '<div class="wordbank answer" aria-label="Câu của bạn">' + (order.length ? order.map(function (ti, k) {
        return '<button type="button" class="token" data-k="' + k + '" lang="en">' + esc(tokens[ti]) + '</button>';
      }).join('') : '<span class="muted small" style="align-self:center">Bấm các từ bên dưới để ghép câu…</span>') + '</div>' +
        '<div class="wordbank" aria-label="Các từ">' + tokens.map(function (t, i) {
          return '<button type="button" class="token ' + (order.indexOf(i) >= 0 ? 'used' : '') + '" data-i="' + i + '" lang="en"' + (order.indexOf(i) >= 0 ? ' tabindex="-1" aria-hidden="true"' : '') + '>' + esc(t) + '</button>';
        }).join('') + '</div>';
      area.querySelectorAll('.wordbank.answer .token').forEach(function (b) { b.onclick = function () { if (it.answered && immediate()) return; order.splice(parseInt(b.getAttribute('data-k'), 10), 1); draw(); }; });
      area.querySelectorAll('.wordbank:not(.answer) .token').forEach(function (b) { b.onclick = function () { if (it.answered && immediate()) return; var i = parseInt(b.getAttribute('data-i'), 10); if (order.indexOf(i) < 0) { order.push(i); draw(); } }; });
      sel = order.length ? { order: order.slice() } : null;
      if (!(it.answered && immediate())) renderFoot();
    }
    draw();
  }

  function renderMatch(area, it) {
    var left = it.display.left || [], right = it.display.right || [];
    var pairs = it.response && it.response.pairs ? Object.assign({}, it.response.pairs) : {}, pickL = null;
    function draw() {
      var usedR = Object.keys(pairs).map(function (k) { return pairs[k]; });
      area.innerHTML = '<div class="match-grid"><div class="col">' + left.map(function (l, i) {
        return '<button type="button" class="match-btn ' + (pickL === i ? 'sel' : '') + (pairs[i] !== undefined ? ' paired' : '') + '" data-l="' + i + '" lang="en">' + esc(l) + (pairs[i] !== undefined ? ' <span class="small">→ ' + esc(right[pairs[i]]) + '</span>' : '') + '</button>';
      }).join('') + '</div><div class="col">' + right.map(function (r, j) {
        return '<button type="button" class="match-btn ' + (usedR.indexOf(j) >= 0 ? 'paired' : '') + '" data-r="' + j + '">' + esc(r) + '</button>';
      }).join('') + '</div></div><p class="small muted mt-1">Chọn một từ bên trái, rồi chọn nghĩa bên phải. Bấm lại từ bên trái để bỏ ghép.</p>';
      area.querySelectorAll('[data-l]').forEach(function (b) { b.onclick = function () { if (it.answered && immediate()) return; var i = parseInt(b.getAttribute('data-l'), 10); if (pairs[i] !== undefined) { delete pairs[i]; pickL = null; } else { pickL = i; } draw(); }; });
      area.querySelectorAll('[data-r]').forEach(function (b) { b.onclick = function () {
        if (it.answered && immediate() || pickL === null) return;
        var j = parseInt(b.getAttribute('data-r'), 10);
        Object.keys(pairs).forEach(function (k) { if (pairs[k] === j) delete pairs[k]; });
        pairs[pickL] = j; pickL = null; draw();
      }; });
      sel = Object.keys(pairs).length === left.length ? { pairs: pairs } : null;
      if (!(it.answered && immediate())) renderFoot();
    }
    draw();
  }

  function renderFill(area, it) {
    area.innerHTML = '<label class="sr-only" for="fill">Câu trả lời</label><input class="input" id="fill" autocomplete="off" autocapitalize="off" spellcheck="false" lang="en" placeholder="Nhập từ tiếng Anh…" value="' + esc(it.response && it.response.text || '') + '">';
    var inp = document.getElementById('fill');
    inp.oninput = function () { sel = inp.value.trim() ? { text: inp.value } : null; renderFoot(); };
    inp.onkeydown = function (e) { if (e.key === 'Enter') { e.preventDefault(); check(); } };
    if (inp.value) sel = { text: inp.value };
  }

  function renderWriting(area, it) {
    area.innerHTML = '<label class="sr-only" for="wr">Bài viết</label><textarea class="input" id="wr" rows="6" lang="en" placeholder="Viết bằng tiếng Anh…">' + esc(it.response && it.response.text || '') + '</textarea><p class="small muted">Bài viết được giáo viên chấm và nhận xét.</p>';
    var t = document.getElementById('wr');
    t.oninput = function () { sel = t.value.trim().length >= 3 ? { text: t.value } : null; renderFoot(); };
  }

  function renderSpeaking(area, it) {
    var canRec = CHIE.Recorder && CHIE.Recorder.supported;
    area.innerHTML = '<div class="card flat"><p class="mb-1"><b>Cách luyện:</b> Nghe mẫu (có thể nghe chậm) → bấm Thu âm và nói theo → nghe lại bản của bạn, so với mẫu → tự đánh giá.</p>' +
      (canRec ? '<canvas id="wave" width="600" height="80" style="width:100%;height:80px;background:var(--c-surface-2);border-radius:12px"></canvas>' +
        '<div class="btn-row mt-1"><button type="button" class="btn btn-danger" id="r-start">' + ic('mic') + ' Thu âm</button><button type="button" class="btn" id="r-stop" disabled>' + ic('square') + ' Dừng</button><button type="button" class="btn" id="r-play" disabled>' + ic('play') + ' Nghe lại bản của tôi</button></div>' +
        '<p class="small muted mt-1" id="r-status">Bản ghi chỉ lưu tạm trong trình duyệt của bạn, không gửi lên máy chủ.</p>'
        : '<div class="alert alert-info">' + ic('info') + '<div>Trình duyệt này chưa hỗ trợ ghi âm. Hãy nghe mẫu và nói theo thành tiếng 3 lần, rồi tự đánh giá.</div></div>') +
      '<div id="heard" class="small muted"></div></div>' +
      '<p class="label mt-2">Bạn tự thấy mình nói thế nào?</p><div class="radio-cards">' +
      [['tot', 'Rõ, giống mẫu'], ['kha', 'Gần giống'], ['can_luyen', 'Cần luyện thêm']].map(function (o) {
        return '<label class="radio-card"><input type="radio" name="self" value="' + o[0] + '"><span>' + o[1] + '</span></label>';
      }).join('') + '</div>';
    area.querySelectorAll('input[name=self]').forEach(function (r) { r.onchange = function () { sel = { self: r.value, heard: (document.getElementById('heard').getAttribute('data-t') || '') }; renderFoot(); }; });
    if (!canRec) return;
    rec = new CHIE.Recorder({ canvas: document.getElementById('wave'), onstop: function () { document.getElementById('r-play').disabled = false; document.getElementById('r-status').textContent = 'Đã ghi xong. Bấm "Nghe lại" để so với mẫu.'; } });
    var bStart = document.getElementById('r-start'), bStop = document.getElementById('r-stop');
    bStart.onclick = function () {
      rec.start().then(function () {
        bStart.disabled = true; bStop.disabled = false; document.getElementById('r-status').textContent = 'Đang thu âm… (tối đa 15 giây)';
        if (CHIE.Recorder.recognitionSupported) CHIE.Recorder.recognize(function (t) {
          var h = document.getElementById('heard'); if (!h) return;
          h.setAttribute('data-t', t);
          h.innerHTML = 'Máy nhận dạng được chữ: “<span lang="en">' + esc(t) + '</span>”. <em>(Chỉ để tham khảo — đây không phải điểm phát âm.)</em>';
        });
      }).catch(function (e) { CHIE.toast(e.message, 'error', 7000); });
    };
    bStop.onclick = function () { rec.stop(); bStart.disabled = false; bStop.disabled = true; };
    document.getElementById('r-play').onclick = function () { rec.play(); };
  }

  /* ---------------- chân trang: kiểm tra / tiếp ---------------- */
  function renderFoot() {
    $foot.className = 'player-foot';
    var it = item(), last = idx === V.items.length - 1;
    if (immediate()) {
      var canSkip = GRADABLE[it.type] && !it.answered;
      $foot.innerHTML = '<div class="foot-in">' +
        (canSkip ? '<button type="button" class="btn btn-lg f-skip" id="f-skip">Bỏ qua</button>' : '<span></span>') +
        '<button type="button" class="btn btn-success btn-lg f-main" id="f-check" ' + (sel ? '' : 'disabled') + '>' + (it.type === 'speaking' || it.type === 'writing' ? 'Hoàn thành' : 'Kiểm tra') + '</button></div>';
      document.getElementById('f-check').onclick = check;
      if (canSkip) document.getElementById('f-skip').onclick = function () { sel = {}; check(); };
    } else {
      // đề thi: lưu từng câu, điều hướng tự do, nộp cuối
      var nav = V.items.map(function (x, i) { return '<button type="button" data-go="' + i + '" class="' + (x.answered ? 'done ' : '') + (i === idx ? 'cur' : '') + '" aria-label="Câu ' + (i + 1) + (x.answered ? ' (đã làm)' : '') + '">' + (i + 1) + '</button>'; }).join('');
      $foot.innerHTML = '<details class="mb-1"><summary class="small">Danh sách câu</summary><div class="q-nav mt-1">' + nav + '</div></details>' +
        '<div class="row between nowrap"><button type="button" class="btn" id="f-prev" ' + (idx === 0 ? 'disabled' : '') + '>' + ic('chevron-left') + '</button>' +
        (last ? '<button type="button" class="btn btn-primary btn-lg grow" id="f-submit">Nộp bài</button>' : '<button type="button" class="btn btn-primary btn-lg grow" id="f-next">Lưu & câu tiếp ' + ic('chevron-right') + '</button>') + '</div>';
      $foot.querySelectorAll('[data-go]').forEach(function (b) { b.onclick = function () { saveThen(parseInt(b.getAttribute('data-go'), 10)); }; });
      document.getElementById('f-prev').onclick = function () { saveThen(idx - 1); };
      if (last) document.getElementById('f-submit').onclick = function () { saveThen(null, true); };
      else document.getElementById('f-next').onclick = function () { saveThen(idx + 1); };
    }
  }

  function payload() {
    var p = { position: item().position, response: sel || {}, time_ms: Date.now() - shownAt, hint_used: hintUsed };
    if (MODE === 'demo') {
      p.guest_token = guestToken; p.responses = {};
      V.items.forEach(function (it) { if (it.answered) p.responses[it.position] = it.response || {}; });
    }
    return p;
  }

  function check() {
    if (!sel || busy) return;
    busy = true;
    var btn = document.getElementById('f-check'); if (btn) btn.disabled = true;
    CHIE.api('POST', URLS.answer, payload()).then(function (fb) {
      busy = false;
      var it = item();
      it.answered = true; it.is_correct = fb.is_correct; it.response = sel; it.correct_text = fb.correct_text; it.correct_index = fb.correct_index;
      it.explanation_vi = fb.explanation_vi; it.tips = fb.tips;
      if (MODE === 'demo' && fb.demo_done) { V.demoDone = true; V.demoCorrect = fb.demo_correct; }
      showFeedback(fb, false);
      updateTop();
    }).catch(function (e) {
      busy = false;
      $foot.className = 'player-foot bad';
      $foot.innerHTML = '<div class="fb-title">' + ic('wifi-off') + ' Chưa gửi được câu trả lời</div><div class="fb-body">' + esc(e.userMessage || e.message) + '</div><button type="button" class="btn btn-primary btn-block" id="f-retry">Thử lại</button>';
      document.getElementById('f-retry').onclick = function () { renderFoot(); check(); };
      if (e.status === 422 && /hết giờ|đã nộp/i.test(e.userMessage || '')) setTimeout(function () { location.href = URLS.result || URLS.exit; }, 1800);
    });
  }

  function markOptions(fb) {
    var it = item();
    if (it.type === 'mcq' || it.type === 'listen_mcq') {
      document.querySelectorAll('#q-area .opt').forEach(function (b) {
        var i = parseInt(b.getAttribute('data-i'), 10);
        b.disabled = true;
        if (i === fb.correct_index) b.classList.add('is-correct');
        else if (b.getAttribute('aria-pressed') === 'true') b.classList.add('is-wrong');
      });
    }
    if (it.type === 'matching' || it.type === 'word_order') document.querySelectorAll('#q-area button').forEach(function (b) { b.disabled = true; });
  }

  function showFeedback(fb, restored) {
    var it = item(), ok = fb.is_correct, last = idx === V.items.length - 1;
    markOptions(fb);
    var selfAssessed = fb.is_correct === null || fb.is_correct === undefined;
    var title = selfAssessed ? 'Đã ghi nhận!' : (ok ? ['Chính xác!', 'Giỏi lắm!', 'Đúng rồi!'][Math.floor(Math.random() * 3)] : 'Chưa đúng — cùng xem lại nhé');
    var bodyH = '';
    if (!selfAssessed && !ok && fb.correct_text) bodyH += '<div><b>Đáp án đúng:</b> <span lang="en">' + esc(fb.correct_text) + '</span></div>';
    if (fb.explanation_vi) bodyH += '<div class="mt-1"><b>Vì sao:</b> ' + esc(fb.explanation_vi) + '</div>';
    if (!ok && fb.tips && fb.tips.length) bodyH += fb.tips.map(function (t) { return '<div class="tip-box"><b>' + esc(t.title) + ':</b> ' + esc(t.tip) + '</div>'; }).join('');
    if (fb.example_after) bodyH += '<div class="mt-1 small">Ví dụ: <span lang="en">“' + esc(fb.example_after) + '”</span></div>';
    if (!ok && !selfAssessed && MODE !== 'demo') bodyH += '<div class="small mt-1 muted">' + ic('repeat') + ' Câu này đã vào Sổ lỗi để ôn lại sau 1 ngày.</div>';
    $foot.className = 'player-foot ' + (selfAssessed || ok ? 'ok' : 'bad');
    $foot.innerHTML = '<div class="foot-in fb">' +
      '<div class="fb-main"><span class="fb-badge" aria-hidden="true">' + ic(selfAssessed || ok ? 'check' : 'x') + '</span><div class="fb-text">' +
      '<div class="fb-title">' + esc(title) + (fb.streak >= 3 && ok ? ' <span class="badge badge-accent">' + ic('flame') + ' ' + fb.streak + ' câu liên tiếp</span>' : '') + '</div>' +
      (bodyH ? '<div class="fb-body">' + bodyH + '</div>' : '') + '</div></div>' +
      '<button type="button" class="btn ' + (selfAssessed || ok ? 'btn-success' : 'btn-danger') + ' btn-lg f-main" id="f-next">' + (allAnswered() ? (MODE === 'demo' ? 'Xem kết quả' : 'Hoàn thành bài') : 'Tiếp tục') + '</button></div>';
    var nb = document.getElementById('f-next');
    nb.onclick = function () { if (allAnswered()) finish(); else { idx = nextUnanswered(); render(); } };
    if (!restored) {
      nb.focus();
    }
  }

  function allAnswered() { return V.items.every(function (x) { return x.answered; }); }
  function nextUnanswered() {
    for (var k = 1; k <= V.items.length; k++) { var j = (idx + k) % V.items.length; if (!V.items[j].answered) return j; }
    return idx;
  }

  function saveThen(target, submitAfter) {
    if (busy) return;
    var go = function () {
      if (submitAfter) {
        var left = V.items.filter(function (x) { return !x.answered; }).length;
        if (!window.confirm(left ? ('Bạn còn ' + left + ' câu chưa làm. Vẫn nộp bài?') : 'Nộp bài ngay? Sau khi nộp bạn sẽ xem được đáp án và giải thích.')) return;
        submit(false);
      } else if (target !== null && target >= 0 && target < V.items.length) { idx = target; render(); }
    };
    if (!sel) return go();
    busy = true;
    CHIE.api('POST', URLS.answer, payload()).then(function () {
      busy = false; var it = item(); it.answered = true; it.response = sel; go();
    }).catch(function (e) {
      busy = false; CHIE.toast(e.userMessage || e.message, 'error', 5000);
      if (e.status === 422) setTimeout(function () { location.href = URLS.result || URLS.exit; }, 1500);
    });
  }

  function finish() {
    if (MODE === 'demo') {
      var total = V.items.length, correct = V.items.filter(function (x) { return x.is_correct; }).length;
      var score = Math.round(correct / total * 100);
      if (window.parent !== window && new URLSearchParams(location.search).get('world_guest') === '1') {
        window.parent.postMessage({type:'chie-guest-world-result',correct:correct,total:total},location.origin);
      }
      $foot.innerHTML = ''; $foot.className = 'player-foot';
      $body.innerHTML = '<div class="result-hero"><div class="score">' + score + '<small>/100</small></div><p>Bạn đúng ' + correct + '/' + total + ' câu trong bài học thử.</p>' +
          '<p class="muted">Kết quả chỉ hiển thị trong lượt này. Không lưu điểm, XP/Xu hoặc lịch sử.</p><div class="btn-row" style="justify-content:center">' +
          '<a class="btn btn-primary btn-lg" href="' + URLS.exit + '">Tiếp tục học</a><a class="btn" href="' + root.getAttribute('data-register') + '">Tạo tài khoản để lưu tiến độ</a></div></div>';
        guestToken = null;
        return;
    }
    submit(false);
  }

  function submit(auto) {
    if (busy && !auto) return;
    busy = true;
    $foot.innerHTML = '<div class="row" style="justify-content:center"><span class="spinner"></span> Đang nộp bài…</div>';
    CHIE.api('POST', URLS.submit, { idempotency_key: CHIE.idem() }).then(function (res) {
      location.href = res.redirect;
    }).catch(function (e) {
      busy = false;
      $foot.innerHTML = '<div class="fb-title">' + ic('wifi-off') + ' Chưa nộp được</div><div class="fb-body">' + esc(e.userMessage || e.message) + ' Bài làm đã được lưu, bấm thử lại khi có mạng.</div><button class="btn btn-primary btn-block" id="f-resubmit">Nộp lại</button>';
      document.getElementById('f-resubmit').onclick = function () { submit(false); };
    });
  }

  function reportQuestion() {
    var msg = window.prompt('Câu hỏi này có lỗi gì? (ví dụ: sai đáp án, lỗi chính tả, âm thanh không rõ)');
    if (!msg || MODE === 'demo') { if (msg) CHIE.toast('Cảm ơn bạn! Đăng nhập để gửi báo lỗi.', '', 3000); return; }
    var it = item();
    if (!it.question_id && !V.items[idx]) return;
    CHIE.api('POST', 'api/questions/0/report', { message: msg, attempt_id: V.id, position: it.position }).then(function () { CHIE.toast('Đã gửi báo lỗi. Cảm ơn bạn!', 'success'); }).catch(function (e) { CHIE.toast(e.userMessage, 'error'); });
  }

  document.addEventListener('keydown', function (e) {
    if (!V || e.target.matches('input, textarea')) return;
    var it = item();
    if ((it.type === 'mcq' || it.type === 'listen_mcq') && /^[1-6]$/.test(e.key) && !(it.answered && immediate())) {
      var b = document.querySelector('#q-area .opt[data-i="' + (parseInt(e.key, 10) - 1) + '"]'); if (b) b.click();
    }
    if (e.key === 'Enter') {
      var n = document.getElementById('f-next') || document.getElementById('f-check');
      var ae = document.activeElement;
      if (n && !n.disabled && ae && (ae.tagName !== 'BUTTON' || ae.classList.contains('opt'))) { e.preventDefault(); n.click(); }
    }
  });
  window.addEventListener('beforeunload', function () { CHIE.speech.stop(); if (rec) rec.dispose(); });
  load();
})();
