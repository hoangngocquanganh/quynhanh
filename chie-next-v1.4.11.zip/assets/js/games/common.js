/* Lõi game dùng chung: lấy câu hỏi từ máy chủ, gửi từng câu trả lời để MÁY CHỦ chấm, nộp lượt chơi để nhận điểm/thưởng.
   Đồ họa tự vẽ bằng Canvas; âm thanh hiệu ứng tạo bằng Web Audio (không dùng tệp ngoài). */
(function () {
  'use strict';
  var CHIE = window.CHIE, esc = CHIE.esc;
  var root = document.getElementById('game');
  if (!root) return;
  var G = CHIE.Game = { code: root.getAttribute('data-code'), items: [], urls: null, config: {}, idx: 0, busy: false, muted: false, ended: false, correct: 0, answered: 0, streak: 0, best: 0 };
  try { G.muted = localStorage.getItem('chie_sfx_muted') === '1'; } catch (e) {}
  var reduce = document.documentElement.getAttribute('data-motion') === 'reduce' || window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  G.reduceMotion = reduce;

  /* ---------- âm thanh hiệu ứng ---------- */
  var ac = null;
  function tone(freq, dur, type, vol, when) {
    if (G.muted) return;
    try {
      ac = ac || new (window.AudioContext || window.webkitAudioContext)();
      var o = ac.createOscillator(), g = ac.createGain(), t = ac.currentTime + (when || 0);
      o.type = type || 'sine'; o.frequency.setValueAtTime(freq, t);
      g.gain.setValueAtTime(vol || 0.08, t); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
      o.connect(g); g.connect(ac.destination); o.start(t); o.stop(t + dur + 0.02);
    } catch (e) {}
  }
  G.sfx = {
    ok: function () { tone(660, 0.12, 'triangle'); tone(880, 0.16, 'triangle', 0.08, 0.1); },
    bad: function () { tone(220, 0.25, 'sawtooth', 0.05); },
    pop: function () { tone(520, 0.08, 'square', 0.04); },
    win: function () { [523, 659, 784, 1047].forEach(function (f, i) { tone(f, 0.18, 'triangle', 0.07, i * 0.12); }); }
  };
  var muteBtn = document.getElementById('g-mute');
  function syncMute() { muteBtn.innerHTML = CHIE.icon(G.muted ? 'volume-2' : 'volume-2') + (G.muted ? '<span class="sr-only">Đang tắt</span>' : ''); muteBtn.style.opacity = G.muted ? 0.4 : 1; }
  muteBtn.onclick = function () { G.muted = !G.muted; try { localStorage.setItem('chie_sfx_muted', G.muted ? '1' : '0'); } catch (e) {} syncMute(); };
  syncMute();

  /* ---------- canvas ---------- */
  G.canvas = document.getElementById('g-canvas');
  G.ctx = G.canvas.getContext('2d');
  G.W = 720; G.H = 440;
  function fit() {
    var dpr = Math.min(2, window.devicePixelRatio || 1);
    G.canvas.width = G.W * dpr; G.canvas.height = G.H * dpr;
    G.ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  }
  fit();
  window.addEventListener('resize', fit);
  G.toCanvas = function (ev) {
    var r = G.canvas.getBoundingClientRect();
    return { x: (ev.clientX - r.left) / r.width * G.W, y: (ev.clientY - r.top) / r.height * G.H };
  };
  G.roundRect = function (x, y, w, h, r, fill, stroke) {
    var c = G.ctx; c.beginPath(); c.moveTo(x + r, y); c.arcTo(x + w, y, x + w, y + h, r); c.arcTo(x + w, y + h, x, y + h, r); c.arcTo(x, y + h, x, y, r); c.arcTo(x, y, x + w, y, r); c.closePath();
    if (fill) { c.fillStyle = fill; c.fill(); } if (stroke) { c.strokeStyle = stroke; c.lineWidth = 3; c.stroke(); }
  };
  G.text = function (s, x, y, size, color, align, maxW, weight) {
    var c = G.ctx; c.fillStyle = color || '#fff'; c.textAlign = align || 'center'; c.textBaseline = 'middle';
    var sz = size; c.font = (weight || 700) + ' ' + sz + 'px "Be Vietnam Pro", system-ui, sans-serif';
    if (maxW) { while (c.measureText(s).width > maxW && sz > 10) { sz -= 1; c.font = (weight || 700) + ' ' + sz + 'px "Be Vietnam Pro", system-ui, sans-serif'; } }
    c.fillText(s, x, y);
  };
  G.particles = [];
  G.burst = function (x, y, color, n) {
    if (reduce) return;
    for (var i = 0; i < (n || 14); i++) G.particles.push({ x: x, y: y, vx: (Math.random() - 0.5) * 6, vy: (Math.random() - 0.9) * 6, life: 40, color: color });
  };
  G.drawParticles = function () {
    var c = G.ctx;
    G.particles = G.particles.filter(function (p) { return p.life > 0; });
    G.particles.forEach(function (p) { p.x += p.vx; p.y += p.vy; p.vy += 0.2; p.life--; c.globalAlpha = Math.max(0, p.life / 40); c.fillStyle = p.color; c.fillRect(p.x, p.y, 5, 5); });
    c.globalAlpha = 1;
  };

  /* ---------- vòng lặp ---------- */
  var running = false, last = 0;
  G.loop = function (fn) {
    running = true;
    function frame(t) {
      if (!running) return;
      var dt = Math.min(50, t - (last || t)); last = t;
      if (!document.hidden) fn(dt / 16.67);
      requestAnimationFrame(frame);
    }
    requestAnimationFrame(frame);
  };
  G.stop = function () { running = false; };

  /* ---------- HUD / thống kê ---------- */
  G.hud = function (html) { document.getElementById('g-hud').innerHTML = html; };
  G.updateStat = function () {
    var total = G.items.length;
    document.getElementById('g-prog').style.width = Math.round(G.answered / Math.max(1, total) * 100) + '%';
    document.getElementById('g-stat').textContent = 'Đúng ' + G.correct + '/' + total;
  };

  /* ---------- bảng câu hỏi (dễ dùng bằng chạm/bàn phím, không phụ thuộc canvas) ---------- */
  var panel = document.getElementById('g-panel');
  G.item = function () { return G.items[G.idx]; };
  G.speakItem = function (it, slow) {
    var p = it.prompt || {}, t = it.type === 'listen_mcq' || it.type === 'speaking' ? (p.speak || p.speak_word) : null;
    if (t) CHIE.speech.say(t, { rate: slow ? CHIE.speech.slow : CHIE.speech.rate });
  };
  G.showQuestion = function (it, opts) {
    opts = opts || {};
    var p = it.prompt || {}, h = '<div class="card">';
    h += '<div class="q-instruction">Câu ' + (G.idx + 1) + '/' + G.items.length + (opts.instruction ? ' · ' + esc(opts.instruction) : '') + '</div>';
    if (p.lines && p.lines.length) h += '<ul class="dialogue">' + p.lines.map(function (l) { return '<li><span lang="en">' + esc(l) + '</span></li>'; }).join('') + '</ul>';
    if (!opts.hideText) h += '<div class="q-text" style="font-size:1.1rem">' + esc(p.text || '') + '</div>';
    if ((it.type === 'listen_mcq' || it.type === 'speaking') && (p.speak || p.speak_word)) h += '<div class="audio-bar"><button type="button" class="audio-btn" data-g-say>' + CHIE.icon('volume-2') + ' Nghe</button><button type="button" class="audio-btn slow" data-g-slow>' + CHIE.icon('snail') + ' Chậm</button></div>';
    if (it.type === 'word_order') {
      h += '<div class="wordbank answer" id="wo-ans"></div><div class="wordbank" id="wo-bank">' + it.display.tokens.map(function (t, i) { return '<button type="button" class="token" data-tok="' + i + '" lang="en">' + esc(t) + '</button>'; }).join('') + '</div><button type="button" class="btn btn-success" id="wo-ok" disabled>Kiểm tra</button>';
    } else if (!opts.noOptions) {
      h += '<div class="options">' + (it.display.options || []).map(function (o, i) { return '<button type="button" class="opt" data-gi="' + i + '"><span class="k">' + 'ABCD'[i] + '</span><span>' + esc(o) + '</span></button>'; }).join('') + '</div>';
    }
    if (opts.hint && it.hint_vi) h += '<button type="button" class="btn btn-ghost btn-sm mt-1" id="g-hint">' + CHIE.icon('lightbulb') + ' Gợi ý (' + opts.hint + ')</button><div id="g-hintbox"></div>';
    h += '<div id="g-fb"></div></div>';
    panel.innerHTML = h;
    var say = panel.querySelector('[data-g-say]'); if (say) say.onclick = function () { G.speakItem(it); };
    var slow = panel.querySelector('[data-g-slow]'); if (slow) slow.onclick = function () { G.speakItem(it, true); };
    panel.querySelectorAll('[data-gi]').forEach(function (b) { b.onclick = function () { if (opts.onPick) opts.onPick(parseInt(b.getAttribute('data-gi'), 10)); }; });
    var hb = document.getElementById('g-hint');
    if (hb) hb.onclick = function () { if (opts.onHint && opts.onHint() === false) return; document.getElementById('g-hintbox').innerHTML = '<div class="hint-box">' + esc(it.hint_vi) + '</div>'; hb.remove(); };
    if (it.type === 'word_order') {
      var order = [];
      var drawWo = function () {
        document.getElementById('wo-ans').innerHTML = order.map(function (i, k) { return '<button type="button" class="token" data-k="' + k + '" lang="en">' + esc(it.display.tokens[i]) + '</button>'; }).join('');
        panel.querySelectorAll('[data-tok]').forEach(function (b) { b.classList.toggle('used', order.indexOf(parseInt(b.getAttribute('data-tok'), 10)) >= 0); });
        panel.querySelectorAll('#wo-ans [data-k]').forEach(function (b) { b.onclick = function () { order.splice(parseInt(b.getAttribute('data-k'), 10), 1); drawWo(); }; });
        document.getElementById('wo-ok').disabled = !order.length;
      };
      panel.querySelectorAll('[data-tok]').forEach(function (b) { b.onclick = function () { var i = parseInt(b.getAttribute('data-tok'), 10); if (order.indexOf(i) < 0) { order.push(i); drawWo(); } }; });
      document.getElementById('wo-ok').onclick = function () { if (opts.onOrder) opts.onOrder(order.slice()); };
      drawWo();
    }
  };
  G.markPanel = function (fb, chosen) {
    panel.querySelectorAll('[data-gi]').forEach(function (b) {
      var i = parseInt(b.getAttribute('data-gi'), 10); b.disabled = true;
      if (i === fb.correct_index) b.classList.add('is-correct'); else if (i === chosen) b.classList.add('is-wrong');
    });
    panel.querySelectorAll('.token, #wo-ok').forEach(function (b) { b.disabled = true; });
    var box = document.getElementById('g-fb');
    if (!box) return;
    var h = '<div class="mt-1 ' + (fb.is_correct ? 'text-success' : 'text-danger') + '"><b>' + (fb.is_correct ? 'Chính xác!' : 'Chưa đúng.') + '</b>' + (!fb.is_correct && fb.correct_text ? ' Đáp án: <b lang="en">' + esc(fb.correct_text) + '</b>' : '') + '</div>';
    if (fb.explanation_vi) h += '<div class="small">' + esc(fb.explanation_vi) + '</div>';
    if (!fb.is_correct && fb.tips && fb.tips.length) h += '<div class="tip-box"><b>' + esc(fb.tips[0].title) + ':</b> ' + esc(fb.tips[0].tip) + '</div>';
    box.innerHTML = h;
  };
  G.clearPanel = function () { panel.innerHTML = ''; };

  /* ---------- máy chủ ---------- */
  G.answer = function (response, timeMs) {
    var it = G.item();
    G.busy = true;
    return CHIE.api('POST', G.urls.answer, { position: it.position, response: response, time_ms: timeMs || null, guest_token: G.guestToken || undefined, responses: G.guestToken ? G.guestResponses : undefined }).then(function (fb) {
      if (G.guestToken) G.guestResponses[it.position] = response;
      G.busy = false;
      it.answered = true; G.answered++;
      if (fb.is_correct) { G.correct++; G.streak++; G.best = Math.max(G.best, G.streak); G.sfx.ok(); } else { G.streak = 0; G.sfx.bad(); }
      G.updateStat();
      return fb;
    }).catch(function (e) {
      G.busy = false;
      CHIE.toast(e.userMessage || e.message, 'error', 5000);
      throw e;
    });
  };
  G.finish = function (reasonText) {
    if (G.ended) return;
    G.ended = true;
    G.stop();
    CHIE.speech.stop();
    G.sfx.win();
    var ov = document.getElementById('g-overlay');
    ov.hidden = false;
    if (G.guestToken) {
      ov.innerHTML = '<div class="card"><h2>Hoàn thành!</h2><p>Đúng ' + G.correct + '/' + G.items.length + ' câu.</p><p class="muted">Chế độ khách: kết quả chỉ hiện tại đây, không lưu điểm, XP/Xu hoặc lịch sử.</p><div class="btn-row"><button class="btn btn-primary" id="g-again">Chơi lại</button><a class="btn" href="' + esc(root.getAttribute('data-exit')) + '">Chọn game khác</a></div></div>';
      document.getElementById('g-again').onclick = function () { location.reload(); };
      G.guestToken = null; G.guestResponses = {};
      return;
    }
    ov.innerHTML = '<div class="card"><h2>' + esc(reasonText || 'Hoàn thành!') + '</h2><p>Đúng ' + G.correct + '/' + G.items.length + ' câu · chuỗi dài nhất ' + G.best + '</p><div class="spinner"></div> Đang lưu kết quả…</div>';
    CHIE.api('POST', G.urls.submit, { idempotency_key: CHIE.idem() }).then(function (res) { location.href = res.redirect; })
      .catch(function (e) { ov.innerHTML = '<div class="card"><h2>Chưa lưu được kết quả</h2><p>' + esc(e.userMessage || e.message) + '</p><button class="btn btn-primary" id="g-retry">Thử lại</button></div>'; document.getElementById('g-retry').onclick = function () { G.ended = false; G.finish(reasonText); }; });
  };
  G.next = function () {
    for (var i = 0; i < G.items.length; i++) { if (!G.items[i].answered) { G.idx = i; return true; } }
    return false;
  };

  document.getElementById('g-start').onclick = function () {
    var btn = this; btn.disabled = true;
    CHIE.api('POST', root.getAttribute('data-start'), {}).then(function (res) {
      G.items = res.attempt.items; G.urls = res.urls; G.config = res.config || {}; G.extra = res.extra || {};
      G.guestToken = res.guest_token || null; G.guestResponses = {};
      G.idx = 0; G.updateStat();
      document.getElementById('g-overlay').hidden = true;
      if (window.ChieGame && window.ChieGame.start) window.ChieGame.start(G);
    }).catch(function (e) { btn.disabled = false; CHIE.toast(e.userMessage || e.message, 'error', 7000); });
  };
  // chọn mức đồ họa (lưu trên máy này), áp dụng bằng cách tải lại trang
  var gfx = document.getElementById('g-gfx');
  if (gfx) {
    try { gfx.value = localStorage.getItem('chie_gfx') || 'auto'; } catch (e) {}
    gfx.onchange = function () { try { localStorage.setItem('chie_gfx', gfx.value); } catch (e) {} location.reload(); };
  }
  window.addEventListener('pagehide', function () { CHIE.speech.stop(); });
})();
