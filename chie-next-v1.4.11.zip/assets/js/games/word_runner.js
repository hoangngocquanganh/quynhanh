/* Word Runner — Săn Từ Vựng. Đổi làn để lao vào cổng có đáp án đúng. Máy chủ chấm từng câu. */
(function () {
  var G, c, rush = false, lanes = 3, lane = 1, targetX = 0, px = 0, hearts = 3, speed = 3, gate = null, phase = 'idle', t0 = 0, scroll = 0, flash = null, touchX = null;
  var HORIZON = 120, BOTTOM = 420;
  function laneX(i, y) {
    // phối cảnh: làn hẹp ở xa, rộng ở gần
    var k = (y - HORIZON) / (BOTTOM - HORIZON), w = 160 + k * 440, left = 360 - w / 2;
    return left + w * (i + 0.5) / lanes;
  }
  function newGate() {
    var it = G.item();
    lanes = Math.max(2, Math.min(4, (it.display.options || []).length));
    if (lane >= lanes) lane = lanes - 1;
    gate = { y: HORIZON + 4, opts: it.display.options, result: null };
    rush = false; phase = 'run'; t0 = Date.now();
    G.showQuestion(it, { instruction: 'Chạy vào cổng đúng', onPick: function (i) { lane = i; rush = true; } });  // bấm đáp án: đổi làn và lao nhanh tới cổng
    if (it.type === 'listen_mcq') setTimeout(function () { G.speakItem(it); }, 300);
    if (it.prompt && it.prompt.speak_word && it.type !== 'listen_mcq') setTimeout(function () { G.speakItem(it); }, 300);
  }
  function hit() {
    phase = 'wait';
    var chosen = lane;
    G.answer({ choice: chosen }, Date.now() - t0).then(function (fb) {
      gate.result = { ok: fb.is_correct, correct: fb.correct_index, chosen: chosen };
      G.markPanel(fb, chosen);
      if (fb.is_correct) { speed += (G.config.speed_step || 0.25); G.burst(laneX(chosen, BOTTOM - 40), BOTTOM - 60, '#FFC23D', 18); flash = { color: 'rgba(23,149,90,.25)', t: 12 }; }
      else { hearts--; flash = { color: 'rgba(217,58,63,.3)', t: 14 }; }
      phase = 'result';
      setTimeout(function () {
        if (hearts <= 0) return G.finish('Hết tim rồi! Bạn đã cố gắng rất tốt.');
        if (!G.next()) return G.finish('Về đích!');
        newGate();
      }, fb.is_correct ? 1200 : 2600);
    }).catch(function () { phase = 'run'; gate.y = BOTTOM - 140; });
  }
  function draw(dt) {
    var W = G.W, H = G.H;
    // bầu trời + mặt đất
    var sky = c.createLinearGradient(0, 0, 0, HORIZON); sky.addColorStop(0, '#7EC8F7'); sky.addColorStop(1, '#C9ECFF');
    c.fillStyle = sky; c.fillRect(0, 0, W, HORIZON);
    c.fillStyle = '#7CC56B'; c.fillRect(0, HORIZON, W, H - HORIZON);
    // núi xa
    c.fillStyle = '#5BA7D9'; c.beginPath(); c.moveTo(0, HORIZON); for (var x = 0; x <= W; x += 60) c.lineTo(x, HORIZON - 30 - 25 * Math.sin(x / 70 + 1)); c.lineTo(W, HORIZON); c.fill();
    // đường
    c.fillStyle = '#E9D7B4'; c.beginPath(); c.moveTo(280, HORIZON); c.lineTo(440, HORIZON); c.lineTo(580, BOTTOM + 20); c.lineTo(140, BOTTOM + 20); c.closePath(); c.fill();
    // vạch làn chạy
    if (phase === 'run') scroll = (scroll + speed * dt * 2) % 40;
    c.strokeStyle = 'rgba(255,255,255,.8)'; c.lineWidth = 3; c.setLineDash([16, 24]); c.lineDashOffset = -scroll;
    for (var i = 1; i < lanes; i++) { c.beginPath(); c.moveTo(280 + 160 * i / lanes, HORIZON); c.lineTo(140 + 440 * i / lanes, BOTTOM + 20); c.stroke(); }
    c.setLineDash([]);
    // cổng
    if (gate) {
      if (phase === 'run') { gate.y += speed * dt * (rush ? 6 : 1.15); if (gate.y >= BOTTOM - 70) { gate.y = BOTTOM - 70; hit(); } }
      var k = (gate.y - HORIZON) / (BOTTOM - HORIZON), gw = (160 + k * 440) / lanes - 10, gh = 24 + 44 * k;
      for (var j = 0; j < lanes; j++) {
        var gx = laneX(j, gate.y) - gw / 2, col = '#2E5BE6';
        if (gate.result) col = j === gate.result.correct ? '#17955A' : (j === gate.result.chosen ? '#D93A3F' : '#8A93A8');
        G.roundRect(gx, gate.y - gh, gw, gh, 10, col);
        G.text(String(gate.opts[j] || ''), gx + gw / 2, gate.y - gh / 2, 10 + 12 * k, '#fff', 'center', gw - 8);
      }
    }
    // người chạy
    targetX = laneX(lane, BOTTOM - 30);
    px += (targetX - px) * Math.min(1, 0.25 * dt);
    var bob = phase === 'run' && !G.reduceMotion ? Math.sin(Date.now() / 90) * 3 : 0;
    c.fillStyle = 'rgba(0,0,0,.15)'; c.beginPath(); c.ellipse(px, BOTTOM + 2, 26, 7, 0, 0, Math.PI * 2); c.fill();
    c.fillStyle = '#FFC23D'; c.beginPath(); c.arc(px, BOTTOM - 28 + bob, 24, 0, Math.PI * 2); c.fill();
    c.fillStyle = '#3DBE7A'; c.beginPath(); c.ellipse(px - 9, BOTTOM - 56 + bob, 10, 5, -0.5, 0, Math.PI * 2); c.ellipse(px + 9, BOTTOM - 56 + bob, 10, 5, 0.5, 0, Math.PI * 2); c.fill();
    c.fillStyle = '#1C2333'; c.beginPath(); c.arc(px - 8, BOTTOM - 31 + bob, 3.5, 0, Math.PI * 2); c.arc(px + 8, BOTTOM - 31 + bob, 3.5, 0, Math.PI * 2); c.fill();
    G.drawParticles();
    if (flash && flash.t-- > 0) { c.fillStyle = flash.color; c.fillRect(0, 0, W, H); }
    var boss = G.config.boss_every && (G.idx + 1) % G.config.boss_every === 0;
    G.hud('<span>' + '❤️'.repeat(Math.max(0, hearts)) + '</span><span>' + (boss ? '👾 Boss từ vựng! ' : '') + '🔥 ' + G.streak + '</span>');
  }
  function onKey(e) {
    if (e.target.matches('input,textarea')) return;
    if (e.key === 'ArrowLeft') { lane = Math.max(0, lane - 1); e.preventDefault(); }
    if (e.key === 'ArrowRight') { lane = Math.min(lanes - 1, lane + 1); e.preventDefault(); }
  }
  window.ChieGame = {
    start: function (game) {
      G = game; c = G.ctx; hearts = G.config.hearts || 3; speed = G.config.speed_base || 3; px = 360;
      if (G.reduceMotion) speed = Math.min(speed, 2.2);
      document.addEventListener('keydown', onKey);
      G.canvas.addEventListener('pointerdown', function (e) { touchX = e.clientX; var p = G.toCanvas(e); if (gate && phase === 'run') { for (var j = 0; j < lanes; j++) { if (Math.abs(p.x - laneX(j, BOTTOM - 30)) < 220 / lanes) lane = j; } } });
      G.canvas.addEventListener('pointerup', function (e) { if (touchX === null) return; var dx = e.clientX - touchX; if (Math.abs(dx) > 30) lane = Math.max(0, Math.min(lanes - 1, lane + (dx > 0 ? 1 : -1))); touchX = null; });
      newGate();
      G.loop(draw);
    }
  };
})();
