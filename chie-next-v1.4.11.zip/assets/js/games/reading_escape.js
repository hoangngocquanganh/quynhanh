/* Reading Escape — Thoát Khỏi Thư Viện. Bấm sách phát sáng để mở câu đố; giải hết các câu trong phòng thì cửa mở. */
(function () {
  var G, c, rooms = [], room = 0, books = [], open = null, hintsLeft = 3, doorOpen = 0, t0 = 0, roomStart = 0, msg = '';
  var SPOTS = [[120, 150], [230, 250], [360, 140], [470, 250], [590, 150], [300, 330], [520, 330], [170, 330]];
  function buildRooms() {
    var per = Math.max(1, Math.ceil(G.items.length / (G.config.rooms || 3)));
    for (var i = 0; i < G.items.length; i += per) rooms.push(G.items.slice(i, i + per).map(function (it) { return G.items.indexOf(it); }));
  }
  function enterRoom() {
    books = rooms[room].map(function (qi, k) { return { qi: qi, x: SPOTS[k % SPOTS.length][0], y: SPOTS[k % SPOTS.length][1], state: G.items[qi].answered ? 'done' : 'glow' }; });
    doorOpen = 0; roomStart = Date.now();
    msg = 'Phòng ' + (room + 1) + '/' + rooms.length + ': tìm và giải ' + books.length + ' câu đố.';
    document.getElementById('g-panel').innerHTML = '<div class="card small">' + CHIE.icon('book-open') + ' ' + msg + ' Bấm vào cuốn sách phát sáng trong thư viện.</div>';
  }
  function openBook(b) {
    if (open || b.state !== 'glow') return;
    open = b; G.idx = b.qi; t0 = Date.now();
    var it = G.item();
    G.showQuestion(it, { instruction: 'Câu đố trong sách', hint: hintsLeft, onHint: function () { if (hintsLeft <= 0) return false; hintsLeft--; },
      onPick: function (i) { submit({ choice: i }, i); }, onOrder: function (order) { submit({ order: order }, null); } });
    document.getElementById('g-panel').scrollIntoView({ behavior: G.reduceMotion ? 'auto' : 'smooth', block: 'nearest' });
  }
  function submit(resp, chosen) {
    if (!open || G.busy) return;
    var b = open;
    G.answer(resp, Date.now() - t0).then(function (fb) {
      G.markPanel(fb, chosen);
      b.state = fb.is_correct ? 'key' : 'done';
      if (fb.is_correct) G.burst(b.x, b.y, '#FFC23D', 18);
      open = null;
      var box = document.getElementById('g-fb');
      if (books.every(function (x) { return x.state !== 'glow'; })) {
        box.insertAdjacentHTML('beforeend', '<button class="btn btn-primary mt-1" id="g-door">' + (room + 1 < rooms.length ? 'Cửa đã mở — sang phòng tiếp' : 'Thoát khỏi thư viện!') + '</button>');
        doorOpen = 0.01;
        document.getElementById('g-door').onclick = function () { room++; if (room >= rooms.length) return G.finish('Bạn đã thoát khỏi thư viện!'); enterRoom(); };
      }
    }).catch(function () {});
  }
  function draw(dt) {
    var W = G.W, H = G.H;
    c.fillStyle = '#4A2F1E'; c.fillRect(0, 0, W, H);
    c.fillStyle = '#6B4529'; c.fillRect(0, H - 70, W, 70);
    // kệ sách nền
    for (var s = 0; s < 3; s++) {
      var y = 60 + s * 110;
      c.fillStyle = '#7A5233'; c.fillRect(30, y + 70, W - 60, 10);
      for (var x = 40; x < W - 50; x += 22) { c.fillStyle = ['#A33B3B', '#2E5BA8', '#3E8E5A', '#C9902E', '#6E4BA3'][(x / 22 + s) % 5 | 0]; c.fillRect(x, y + 70 - (30 + (x * 7 % 25)), 16, 30 + (x * 7 % 25)); }
    }
    // cửa
    var dx = W - 110, dy = H - 230;
    G.roundRect(dx, dy, 80, 160, 10, '#2B1A10');
    doorOpen = doorOpen > 0 ? Math.min(1, doorOpen + 0.03 * dt) : 0;
    c.fillStyle = doorOpen > 0 ? 'rgba(255,214,120,' + (0.4 + 0.5 * doorOpen) + ')' : '#5C3B22'; c.fillRect(dx + 8, dy + 8, 64 * (1 - doorOpen * 0.8), 144);
    G.text(doorOpen > 0 ? 'MỞ' : '🔒', dx + 40, dy - 16, 14, '#FFD27A');
    // đèn
    c.fillStyle = 'rgba(255,200,90,.12)'; c.beginPath(); c.arc(360, 0, 260, 0, Math.PI); c.fill();
    // sách manh mối
    var t = Date.now() / 300;
    books.forEach(function (b) {
      var glow = b.state === 'glow' ? (G.reduceMotion ? 0.6 : 0.4 + 0.3 * Math.sin(t + b.x)) : 0;
      if (glow) { c.fillStyle = 'rgba(255,214,90,' + glow + ')'; c.beginPath(); c.arc(b.x, b.y, 38, 0, Math.PI * 2); c.fill(); }
      G.roundRect(b.x - 20, b.y - 26, 40, 52, 6, b.state === 'key' ? '#D4880F' : b.state === 'done' ? '#7C8597' : '#2E5BE6', '#1C2333');
      G.text(b.state === 'key' ? '🔑' : b.state === 'done' ? '✓' : '?', b.x, b.y, 20, '#fff');
    });
    G.drawParticles();
    var keys = books.filter(function (b) { return b.state === 'key'; }).length;
    var limit = G.config.room_seconds || 0, left = limit ? Math.max(0, limit - Math.round((Date.now() - roomStart) / 1000)) : null;
    G.hud('<span>Phòng ' + (room + 1) + '/' + rooms.length + ' · 🔑 ' + keys + '/' + books.length + '</span><span>💡 ' + hintsLeft + (left !== null ? ' · ⏳ ' + Math.floor(left / 60) + ':' + String(left % 60).padStart(2, '0') : '') + '</span>');
  }
  window.ChieGame = {
    start: function (game) {
      G = game; c = G.ctx; hintsLeft = G.config.hints != null ? G.config.hints : 3;
      buildRooms(); enterRoom();
      G.canvas.addEventListener('pointerdown', function (e) {
        var p = G.toCanvas(e);
        books.forEach(function (b) { if (Math.abs(p.x - b.x) < 30 && Math.abs(p.y - b.y) < 34) openBook(b); });
      });
      // bàn phím: Tab tới nút "Mở sách tiếp theo"
      document.getElementById('g-panel').insertAdjacentHTML('afterend', '<button class="btn btn-sm mt-1" id="g-nextbook" type="button">Mở cuốn sách tiếp theo</button>');
      document.getElementById('g-nextbook').onclick = function () { var b = books.find(function (x) { return x.state === 'glow'; }); if (b) openBook(b); };
      G.loop(draw);
    }
  };
})();
