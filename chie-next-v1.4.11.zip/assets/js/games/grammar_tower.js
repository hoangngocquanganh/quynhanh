/* Grammar Tower — Thủ Thành Ngữ Pháp. Mỗi quái mang 1 câu ngữ pháp; trả lời đúng → tháp bắn hạ, sai/hết đường → thành mất máu. */
(function () {
  var G, c, hp, maxHp, enemy = null, towers = [], shots = [], phase = 'idle', t0 = 0, wave = 1, killed = 0;
  var TYPES = [['Hiện tại', '#2E5BE6'], ['Quá khứ', '#8B4FD8'], ['Tương lai', '#0E7C9B'], ['Điều kiện', '#D4880F'], ['Bị động', '#D93A3F'], ['Giới từ', '#17955A']];
  var PADS = [[150, 120], [300, 300], [430, 110], [560, 290], [250, 190], [480, 200]];
  // đường đi của quái (polyline)
  var PATH = [[-20, 230], [120, 230], [200, 80], [360, 80], [380, 360], [540, 360], [620, 200], [690, 200]];
  var segLen = [], total = 0;
  for (var i = 1; i < PATH.length; i++) { var l = Math.hypot(PATH[i][0] - PATH[i - 1][0], PATH[i][1] - PATH[i - 1][1]); segLen.push(l); total += l; }
  function posAt(d) {
    for (var i = 0; i < segLen.length; i++) {
      if (d <= segLen[i]) { var t = d / segLen[i]; return [PATH[i][0] + (PATH[i + 1][0] - PATH[i][0]) * t, PATH[i][1] + (PATH[i + 1][1] - PATH[i][1]) * t]; }
      d -= segLen[i];
    }
    return PATH[PATH.length - 1];
  }
  function spawn() {
    var it = G.item();
    enemy = { d: 0, hp: 1, dead: false, wobble: Math.random() * 6 };
    phase = 'run'; t0 = Date.now();
    var per = G.config.enemies_per_wave || 5;
    wave = Math.floor(G.idx / per) + 1;
    G.showQuestion(it, { instruction: 'Sửa câu để tháp bắn hạ quái', onPick: answer });
  }
  function answer(i) {
    if (phase !== 'run') return;
    phase = 'wait';
    G.answer({ choice: i }, Date.now() - t0).then(function (fb) { G.markPanel(fb, i); resolve(fb.is_correct); })
      .catch(function () { phase = 'run'; });
  }
  function resolve(ok) {
    if (ok) {
      killed++;
      var slot = (killed - 1) % PADS.length, level = Math.floor((killed - 1) / PADS.length) + 1;
      if (!towers[slot]) towers[slot] = { level: 1, type: slot }; else towers[slot].level = Math.min(3, level);
      var p = posAt(enemy.d);
      shots.push({ x: PADS[slot][0], y: PADS[slot][1] - 30, tx: p[0], ty: p[1], t: 0, color: TYPES[slot][1] });
      phase = 'result';
      setTimeout(next, 1300);
    } else {
      phase = 'march';  // quái tiến thẳng về thành
    }
  }
  function next() {
    if (hp <= 0) return G.finish('Thành đã bị phá! Ôn lại ngữ pháp rồi thử lần nữa nhé.');
    if (!G.next()) return G.finish('Bảo vệ thành thành công!');
    spawn();
  }
  function draw(dt) {
    c.fillStyle = '#8FD27A'; c.fillRect(0, 0, G.W, G.H);
    c.fillStyle = '#7BC266'; for (var gx = 0; gx < G.W; gx += 48) for (var gy = (gx / 48) % 2 * 24; gy < G.H; gy += 48) c.fillRect(gx, gy, 24, 24);
    // đường
    c.strokeStyle = '#D9C08F'; c.lineWidth = 44; c.lineJoin = 'round'; c.beginPath(); PATH.forEach(function (p, i) { if (i) c.lineTo(p[0], p[1]); else c.moveTo(p[0], p[1]); }); c.stroke();
    c.strokeStyle = '#C9AE7A'; c.lineWidth = 2; c.stroke();
    // thành
    var cx = 680, cy = 200;
    G.roundRect(cx - 34, cy - 60, 68, 90, 8, '#B9BFCC', '#8A93A8');
    c.fillStyle = '#8A93A8'; for (var k = 0; k < 4; k++) c.fillRect(cx - 34 + k * 20, cy - 74, 12, 14);
    c.fillStyle = '#5B4636'; c.fillRect(cx - 12, cy, 24, 30);
    for (var h = 0; h < maxHp; h++) { c.fillStyle = h < hp ? '#D93A3F' : 'rgba(0,0,0,.2)'; c.fillRect(cx - 34 + h * (68 / maxHp), cy - 90, 68 / maxHp - 3, 8); }
    // bệ + tháp
    PADS.forEach(function (p, i) {
      c.fillStyle = 'rgba(0,0,0,.15)'; c.beginPath(); c.ellipse(p[0], p[1] + 6, 28, 10, 0, 0, Math.PI * 2); c.fill();
      var t = towers[i];
      if (!t) { G.roundRect(p[0] - 22, p[1] - 10, 44, 16, 6, '#C9C2B2'); return; }
      var col = TYPES[i][1], tall = 30 + t.level * 10;
      G.roundRect(p[0] - 18, p[1] - tall, 36, tall + 6, 6, col);
      c.fillStyle = '#fff'; c.beginPath(); c.arc(p[0], p[1] - tall, 9, 0, Math.PI * 2); c.fill();
      G.text(TYPES[i][0], p[0], p[1] + 18, 11, '#1C2333');
      G.text('Lv' + t.level, p[0], p[1] - tall / 2, 11, '#fff');
    });
    // quái
    if (enemy && !enemy.dead) {
      var sp = (G.config.enemy_speed || 0.35) * (G.reduceMotion ? 0.7 : 1);
      if (phase === 'run') enemy.d += sp * dt;
      if (phase === 'march') enemy.d += sp * dt * 6;
      if (enemy.d >= total - 30) {
        enemy.dead = true;
        if (phase === 'run') { // hết đường mà chưa trả lời
          phase = 'wait';
          G.answer({ choice: -1 }, Date.now() - t0).then(function (fb) { G.markPanel(fb, -1); }).catch(function () {});
        }
        hp--; G.sfx.bad(); G.burst(cx, cy, '#D93A3F', 20);
        setTimeout(next, 2400);
      }
      var p = posAt(enemy.d), wob = G.reduceMotion ? 0 : Math.sin(Date.now() / 150 + enemy.wobble) * 3;
      c.fillStyle = '#6C3FC9'; c.beginPath(); c.ellipse(p[0], p[1] - 14 + wob, 20, 18, 0, 0, Math.PI * 2); c.fill();
      c.fillStyle = '#fff'; c.beginPath(); c.arc(p[0] - 7, p[1] - 18 + wob, 5, 0, Math.PI * 2); c.arc(p[0] + 7, p[1] - 18 + wob, 5, 0, Math.PI * 2); c.fill();
      c.fillStyle = '#1C2333'; c.beginPath(); c.arc(p[0] - 6, p[1] - 17 + wob, 2.5, 0, Math.PI * 2); c.arc(p[0] + 8, p[1] - 17 + wob, 2.5, 0, Math.PI * 2); c.fill();
      G.roundRect(p[0] - 14, p[1] - 52 + wob, 28, 20, 6, '#fff'); G.text('?', p[0], p[1] - 42 + wob, 14, '#6C3FC9');
    }
    // đạn
    shots = shots.filter(function (s) { return s.t < 1; });
    shots.forEach(function (s) {
      s.t += 0.06 * dt;
      var x = s.x + (s.tx - s.x) * s.t, y = s.y + (s.ty - s.y) * s.t - Math.sin(s.t * Math.PI) * 60;
      c.fillStyle = s.color; c.beginPath(); c.arc(x, y, 8, 0, Math.PI * 2); c.fill();
      if (s.t >= 1 && enemy && !enemy.dead) { enemy.dead = true; G.burst(s.tx, s.ty - 10, s.color, 22); }
    });
    G.drawParticles();
    G.hud('<span>🏰 ' + Math.max(0, hp) + '/' + maxHp + '</span><span>Đợt ' + wave + ' · 🔥 ' + G.streak + '</span>');
  }
  window.ChieGame = {
    start: function (game) {
      G = game; c = G.ctx; maxHp = hp = G.config.castle_hp || 5;
      spawn();
      G.loop(draw);
    }
  };
})();
