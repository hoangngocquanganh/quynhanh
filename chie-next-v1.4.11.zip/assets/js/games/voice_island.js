/* Voice Island — Đảo Âm Thanh. Nghe (mặc định chậm) rồi bấm bong bóng đúng; cuối màn có Phòng thu luyện nói đuổi.
   Không chấm điểm phát âm bằng máy: phần nói chỉ để tự luyện và tự nghe lại. */
(function () {
  var G, c, bubbles = [], phase = 'idle', t0 = 0, gems = 0, wave = 0;
  function spawn() {
    var it = G.item();
    var opts = it.display.options || [];
    bubbles = opts.map(function (o, i) {
      return { i: i, text: o, x: 90 + (540 / Math.max(1, opts.length - 1 || 1)) * i + (opts.length === 1 ? 270 : 0), y: -40 - i * 50, r: 52, hue: 190 + i * 35, state: null };
    });
    phase = 'run'; t0 = Date.now();
    G.showQuestion(it, { instruction: it.type === 'listen_mcq' ? 'Nghe rồi chọn' : 'Chọn đáp án đúng', hideText: false, onPick: pick });
    if (it.prompt && (it.prompt.speak || it.prompt.speak_word)) setTimeout(function () { G.speakItem(it); }, 350);
  }
  function pick(i) {
    if (phase !== 'run') return;
    phase = 'wait';
    G.answer({ choice: i }, Date.now() - t0).then(function (fb) {
      G.markPanel(fb, i);
      bubbles.forEach(function (b) { b.state = b.i === fb.correct_index ? 'ok' : (b.i === i ? 'bad' : 'fade'); });
      if (fb.is_correct) { gems++; var b = bubbles[i]; G.burst(b.x, b.y, '#4FC3E0', 20); }
      phase = 'result';
      setTimeout(function () { if (!G.next()) return studio(); spawn(); }, fb.is_correct ? 1300 : 2600);
    }).catch(function () { phase = 'run'; });
  }
  function draw(dt) {
    var W = G.W, H = G.H, sp = (G.config.fall_speed || 1) * (G.reduceMotion ? 0.6 : 1);
    var sky = c.createLinearGradient(0, 0, 0, H); sky.addColorStop(0, '#FDE7F3'); sky.addColorStop(0.55, '#BFE7F7'); sky.addColorStop(1, '#3FA7D6');
    c.fillStyle = sky; c.fillRect(0, 0, W, H);
    wave += 0.03 * dt;
    c.fillStyle = 'rgba(255,255,255,.35)';
    for (var k = 0; k < 3; k++) { c.beginPath(); c.moveTo(0, H - 40 + k * 14); for (var x = 0; x <= W; x += 20) c.lineTo(x, H - 40 + k * 14 + Math.sin(x / 40 + wave + k) * 5); c.lineTo(W, H); c.lineTo(0, H); c.fill(); }
    // đảo
    c.fillStyle = '#F4D58D'; c.beginPath(); c.ellipse(620, H - 40, 90, 26, 0, 0, Math.PI * 2); c.fill();
    c.strokeStyle = '#8B5E34'; c.lineWidth = 8; c.beginPath(); c.moveTo(620, H - 60); c.quadraticCurveTo(610, H - 130, 640, H - 170); c.stroke();
    c.fillStyle = '#2FA866'; for (var a = 0; a < 5; a++) { c.beginPath(); c.ellipse(640 + Math.cos(a * 1.25) * 30, H - 172 + Math.sin(a * 1.25) * 12, 34, 10, a * 1.25, 0, Math.PI * 2); c.fill(); }
    // bong bóng
    bubbles.forEach(function (b) {
      if (phase === 'run') { b.y += sp * dt * 1.2; if (b.y > H - 70) { b.y = -50; if (b.i === 0) { var it = G.item(); if (it.prompt && (it.prompt.speak || it.prompt.speak_word)) G.speakItem(it, true); } } }
      var col = b.state === 'ok' ? 'rgba(23,149,90,.85)' : b.state === 'bad' ? 'rgba(217,58,63,.85)' : b.state === 'fade' ? 'rgba(160,170,190,.5)' : 'hsla(' + b.hue + ',75%,55%,.85)';
      c.fillStyle = col; c.beginPath(); c.arc(b.x, b.y, b.r, 0, Math.PI * 2); c.fill();
      c.fillStyle = 'rgba(255,255,255,.45)'; c.beginPath(); c.arc(b.x - 18, b.y - 18, 10, 0, Math.PI * 2); c.fill();
      G.text(b.text, b.x, b.y, 16, '#fff', 'center', b.r * 1.8);
    });
    G.drawParticles();
    G.hud('<span>💎 Ngọc giọng nói: ' + gems + '</span><span>🔥 ' + G.streak + '</span>');
  }
  function studio() {
    phase = 'studio';
    var list = (G.extra && G.extra.sentences) || [];
    if (!list.length) return G.finish('Hoàn thành Đảo Âm Thanh!');
    var i = 0, done = 0, rec = null;
    var panel = document.getElementById('g-panel');
    function show() {
      if (rec) rec.dispose();
      var s = list[i];
      panel.innerHTML = '<div class="card"><div class="card-title">🎙️ Phòng thu — luyện nói đuổi (' + (i + 1) + '/' + list.length + ')</div>' +
        '<p class="small muted">Nghe câu mẫu, nói đuổi theo, thu âm rồi nghe lại để tự so sánh. Không chấm điểm bằng máy; bản ghi không rời khỏi máy bạn.</p>' +
        '<div class="q-text" lang="en">' + CHIE.esc(s) + '</div>' +
        '<div class="audio-bar"><button class="audio-btn" id="s-play">' + CHIE.icon('volume-2') + ' Nghe</button><button class="audio-btn slow" id="s-slow">' + CHIE.icon('snail') + ' Chậm theo cụm</button></div>' +
        (CHIE.Recorder.supported ? '<canvas id="wave" width="600" height="60" style="width:100%;height:60px;background:var(--c-surface-2);border-radius:12px"></canvas><div class="btn-row mt-1"><button class="btn btn-danger" id="s-rec">' + CHIE.icon('mic') + ' Thu âm</button><button class="btn" id="s-stop" disabled>Dừng</button><button class="btn" id="s-me" disabled>' + CHIE.icon('play') + ' Nghe lại tôi</button></div>' : '<p class="small">Trình duyệt chưa hỗ trợ ghi âm — hãy nói theo thành tiếng 3 lần.</p>') +
        '<div class="btn-row mt-2"><button class="btn btn-success" id="s-done">Đã luyện xong câu này</button><button class="btn btn-ghost" id="s-skip">Kết thúc phòng thu</button></div></div>';
      document.getElementById('s-play').onclick = function () { CHIE.speech.say(s, { button: this }); };
      document.getElementById('s-slow').onclick = function () { CHIE.speech.sayChunks(CHIE.speech.chunk(s)); };
      if (CHIE.Recorder.supported) {
        rec = new CHIE.Recorder({ canvas: document.getElementById('wave'), onstop: function () { document.getElementById('s-me').disabled = false; document.getElementById('s-rec').disabled = false; document.getElementById('s-stop').disabled = true; } });
        document.getElementById('s-rec').onclick = function () { var b = this; rec.start().then(function () { b.disabled = true; document.getElementById('s-stop').disabled = false; }).catch(function (e) { CHIE.toast(e.message, 'error', 7000); }); };
        document.getElementById('s-stop').onclick = function () { rec.stop(); };
        document.getElementById('s-me').onclick = function () { rec.play(); };
      }
      document.getElementById('s-done').onclick = function () { done++; gems++; G.sfx.ok(); i++; if (i >= list.length) end(); else show(); };
      document.getElementById('s-skip').onclick = end;
    }
    function end() { if (rec) rec.dispose(); G.finish('Hoàn thành Đảo Âm Thanh! Đã luyện nói ' + done + ' câu.'); }
    show();
  }
  window.ChieGame = {
    start: function (game) {
      G = game; c = G.ctx;
      G.canvas.addEventListener('pointerdown', function (e) {
        if (phase !== 'run') return;
        var p = G.toCanvas(e);
        bubbles.forEach(function (b) { if (Math.hypot(p.x - b.x, p.y - b.y) < b.r) pick(b.i); });
      });
      spawn();
      G.loop(draw);
    }
  };
})();
