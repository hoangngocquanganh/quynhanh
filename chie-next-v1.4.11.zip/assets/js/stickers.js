/* v1.3.3 — Học theo sticker: thẻ chi tiết, bóc sticker, ôn, nghe & chọn hình. Không dùng script nội tuyến (CSP). */
(function () {
  'use strict';
  var esc = CHIE.esc;
  var LEVEL = ['Chưa có', 'Đồng', 'Bạc', 'Vàng'];
  var cards = {};
  try {
    var el = document.getElementById('stk-cards');
    if (el) JSON.parse(el.textContent || '[]').forEach(function (c) { cards[c.id] = c; });
  } catch (e) { /* bỏ qua */ }

  function say(text, slow, btn) {
    if (!text) return;
    CHIE.speech.say(text, { rate: slow ? CHIE.speech.slow : CHIE.speech.rate, button: btn || null });
  }
  function open(d) { if (d && !d.open) { if (d.showModal) d.showModal(); else d.setAttribute('open', ''); } }
  function close(d) { if (d && d.open) { if (d.close) d.close(); else d.removeAttribute('open'); } CHIE.speech.stop(); }

  function cardHtml(c, big) {
    return '<div class="stk-card">' +
      '<span class="sticker lvl-' + (c.level == null ? 3 : c.level) + (big ? ' big' : '') + '"><span class="e" aria-hidden="true">' + esc(c.emoji) + '</span></span>' +
      '<p class="stk-card-w" lang="en">' + esc(c.word) + '</p>' +
      (c.ipa ? '<p class="ipa">' + esc(c.ipa) + '</p>' : '') +
      '<p class="stk-card-m">' + esc(c.vi) + '</p>' +
      '<div class="row center">' +
        '<button class="audio-btn" type="button" data-say="' + esc(c.word) + '">' + CHIE.icon('volume-2') + ' Nghe</button>' +
        '<button class="audio-btn slow" type="button" data-say="' + esc(c.word) + '" data-slow="1">' + CHIE.icon('snail') + ' Chậm</button>' +
      '</div>' +
      (c.ex_en ? '<p class="stk-card-ex"><span lang="en">' + esc(c.ex_en) + '</span> <button class="linkish" type="button" data-say="' + esc(c.ex_en) + '" aria-label="Nghe câu ví dụ">' + CHIE.icon('volume-2') + '</button>' + (c.ex_vi ? '<br><span class="muted">' + esc(c.ex_vi) + '</span>' : '') + '</p>' : '') +
      (c.note ? '<p class="stk-note">' + CHIE.icon('lightbulb') + ' ' + esc(c.note) + '</p>' : '') +
      '</div>';
  }

  /* ---------- nghe / thẻ chi tiết ---------- */
  document.addEventListener('click', function (e) {
    var b = e.target.closest('[data-say]');
    if (b) { e.preventDefault(); say(b.getAttribute('data-say'), b.hasAttribute('data-slow'), b); return; }
    var c = e.target.closest('[data-stk-card]');
    if (c) {
      var card = cards[c.getAttribute('data-stk-card')];
      var d = document.getElementById('stk-detail');
      if (!card || !d) return;
      var locked = !card.level;
      d.querySelector('.stk-detail-body').innerHTML = (locked ? '<p class="stk-locked">' + CHIE.icon('lock') + ' Sticker chưa bóc — xem trước thẻ học, rồi bấm "Bóc sticker mới" để dán vào album.</p>' : '<p class="stk-lv">Hạng: <b>' + LEVEL[card.level] + '</b></p>') + cardHtml(card, true);
      open(d);
      say(card.word);
      return;
    }
    var x = e.target.closest('[data-stk-close]');
    if (x) { var dd = x.closest('dialog'); if (dd && dd.id === 'stk-player') endSession(); else close(dd); return; }
    var s = e.target.closest('[data-stk-start]');
    if (s) { e.preventDefault(); start(s.getAttribute('data-stk-start'), s.getAttribute('data-pack'), s); }
  });

  /* ---------- một lượt học ---------- */
  var P = document.getElementById('stk-player');
  var stage = document.getElementById('stk-stage');
  var foot = document.getElementById('stk-foot');
  var st = null;   // {items, i, mode, pack, results, busy}
  var dirty = false;   // album đã thay đổi → tải lại trang khi đóng

  function start(mode, pack, btn) {
    if (!P) return;
    if (btn) btn.disabled = true;
    CHIE.api('POST', 'api/sticker/session', { mode: mode, pack: pack || null }).then(function (res) {
      if (btn) btn.disabled = false;
      st = { items: res.items || [], i: 0, mode: mode, pack: pack, results: [], busy: false };
      if (!st.items.length) { CHIE.toast('Chưa có sticker để học.', 'error'); return; }
      open(P);
      step();
    }).catch(function (err) {
      if (btn) btn.disabled = false;
      CHIE.toast(err.userMessage || err.message, 'error', 5000);
    });
  }

  function setProgress() {
    var bar = P.querySelector('.stk-progress span');
    if (bar) bar.style.width = Math.round(st.i / st.items.length * 100) + '%';
    var n = P.querySelector('.stk-count');
    if (n) n.textContent = Math.min(st.i + 1, st.items.length) + '/' + st.items.length;
  }

  function step() {
    setProgress();
    foot.hidden = true; foot.className = 'stk-foot'; foot.innerHTML = '';
    if (st.i >= st.items.length) return summary();
    var it = st.items[st.i];
    if (it.is_new && !it.seen && it.type !== 'listen') return learnCard(it);
    ask(it);
  }

  function learnCard(it) {
    it.seen = true;
    stage.innerHTML = '<p class="stk-step-k">' + CHIE.icon('sparkles') + ' Sticker mới — nhìn, nghe và đọc to theo nhé</p>' + cardHtml(Object.assign({ level: 0 }, it.sticker), true) +
      '<div class="stk-cta"><button class="btn btn-primary btn-lg" type="button" data-stk-ask>Mình nhớ rồi ' + CHIE.icon('arrow-right') + '</button></div>';
    say(it.sticker.word);
    var nb = stage.querySelector('[data-stk-ask]'); if (nb) nb.focus();
  }

  function ask(it) {
    var s = it.sticker, q = '', optCls = 'stk-opts';
    if (it.type === 'pick_word') q = '<span class="sticker lvl-0 big q"><span class="e" aria-hidden="true">' + esc(s.emoji) + '</span></span><h2>Đây là gì trong tiếng Anh?</h2>';
    else if (it.type === 'pick_vi') q = '<h2 class="stk-q-word" lang="en">' + esc(s.word) + '</h2>' + (s.ipa ? '<p class="ipa">' + esc(s.ipa) + '</p>' : '') +
      '<button class="audio-btn slow" type="button" data-say="' + esc(s.word) + '">' + CHIE.icon('volume-2') + ' Nghe</button><p class="muted">Chọn nghĩa tiếng Việt đúng</p>';
    else if (it.type === 'pick_en') q = '<h2 class="stk-q-word">' + esc(s.vi) + '</h2><p class="muted">Tiếng Anh nói thế nào?</p>';
    else { q = '<button class="audio-btn big" type="button" data-say="' + esc(s.word) + '">' + CHIE.icon('volume-2') + ' Nghe lại</button><h2>Nghe và chọn hình đúng</h2>'; optCls += ' emoji'; }
    stage.innerHTML = '<div class="stk-q">' + q + '</div><div class="' + optCls + '" role="group" aria-label="Các phương án">' +
      it.options.map(function (o, k) {
        return '<button class="stk-opt" type="button" data-opt="' + o.id + '"><kbd>' + (k + 1) + '</kbd><span' + (it.type === 'listen' ? ' class="e" aria-label="Phương án ' + (k + 1) + '"' : (it.type === 'pick_vi' ? '' : ' lang="en"')) + '>' + esc(o.label) + '</span></button>';
      }).join('') + '</div>';
    if (it.type === 'listen' || it.type === 'pick_vi') say(s.word);
  }

  function choose(btn) {
    if (!st || st.busy || !btn) return;
    var it = st.items[st.i];
    st.busy = true;
    stage.querySelectorAll('.stk-opt').forEach(function (b) { b.disabled = true; });
    btn.classList.add('picked');
    CHIE.api('POST', 'api/sticker/answer', { sticker_id: it.sticker.id, choice_id: parseInt(btn.getAttribute('data-opt'), 10) }).then(function (r) {
      st.busy = false; dirty = true;
      st.results.push({ it: it, r: r });
      stage.querySelectorAll('.stk-opt').forEach(function (b) {
        if (parseInt(b.getAttribute('data-opt'), 10) === r.answer_id) b.classList.add('ok');
      });
      if (!r.correct) btn.classList.add('bad');
      var msg;
      if (r.correct) {
        msg = r.new ? '<b>Bóc được sticker mới!</b> <span class="sticker lvl-1 peel"><span class="e">' + esc(it.sticker.emoji) + '</span></span>'
          : (r.level_up ? '<b>Lên hạng ' + LEVEL[r.level] + '!</b>' : '<b>Chính xác!</b>');
        if (r.xp) msg += ' <span class="stk-xp">+' + r.xp + ' XP' + (r.xu ? ' · +' + r.xu + ' Xu' : '') + '</span>';
        if (r.note) msg += '<br>' + esc(r.note);
      } else {
        msg = '<b>Chưa đúng.</b> Đáp án: <span lang="en">' + esc(it.sticker.word) + '</span> — ' + esc(it.sticker.vi) + '. Sticker này sẽ được nhắc ôn lại.';
      }
      foot.className = 'stk-foot ' + (r.correct ? 'ok' : 'bad');
      foot.innerHTML = '<div class="grow">' + msg + '</div><button class="btn btn-lg ' + (r.correct ? 'btn-primary' : 'btn-danger') + '" type="button" data-stk-next>Tiếp tục</button>';
      foot.hidden = false;
      say(it.sticker.word);
      var nb = foot.querySelector('[data-stk-next]'); if (nb) nb.focus();
      if (cards[it.sticker.id]) cards[it.sticker.id].level = r.level;
    }).catch(function (err) {
      st.busy = false;
      stage.querySelectorAll('.stk-opt').forEach(function (b) { b.disabled = false; });
      btn.classList.remove('picked');
      CHIE.toast(err.userMessage || err.message, 'error', 5000);
    });
  }

  function summary() {
    var ok = st.results.filter(function (x) { return x.r.correct; }).length;
    var got = st.results.filter(function (x) { return x.r.new; });
    var xp = st.results.reduce(function (a, x) { return a + (x.r.xp || 0); }, 0);
    var bar = P.querySelector('.stk-progress span'); if (bar) bar.style.width = '100%';
    stage.innerHTML = '<div class="stk-sum"><h2>' + (ok === st.results.length ? 'Xuất sắc! 🎉' : 'Hoàn thành lượt học!') + '</h2>' +
      '<p>Đúng ' + ok + '/' + st.results.length + ' câu' + (xp ? ' · +' + xp + ' XP' : '') + '</p>' +
      (got.length ? '<p class="stk-step-k">Sticker mới trong album:</p><div class="stk-sum-row">' + got.map(function (x) {
        return '<span class="stk-mini"><span class="sticker lvl-1 peel"><span class="e">' + esc(x.it.sticker.emoji) + '</span></span><span lang="en">' + esc(x.it.sticker.word) + '</span></span>';
      }).join('') + '</div>' : '') +
      '<div class="stk-cta"><button class="btn btn-primary btn-lg" type="button" data-stk-again>' + CHIE.icon('repeat') + ' Học tiếp</button>' +
      '<button class="btn btn-lg" type="button" data-stk-close>Về album</button></div></div>';
  }

  function endSession() {
    close(P);
    if (dirty) location.reload();
    st = null;
  }

  if (P) {
    P.addEventListener('click', function (e) {
      var o = e.target.closest('.stk-opt'); if (o) { choose(o); return; }
      if (e.target.closest('[data-stk-ask]')) { ask(st.items[st.i]); return; }
      if (e.target.closest('[data-stk-next]')) { st.i++; step(); return; }
      if (e.target.closest('[data-stk-again]')) { var m = st.mode, p = st.pack; close(P); start(m, p); }
    });
    P.addEventListener('cancel', function (e) { e.preventDefault(); endSession(); });
    P.addEventListener('keydown', function (e) {
      if (!st) return;
      if (/^[1-4]$/.test(e.key)) { var bs = stage.querySelectorAll('.stk-opt'); var b = bs[parseInt(e.key, 10) - 1]; if (b && !b.disabled) choose(b); }
    });
  }
})();
