/* Voice Island 3D — Đảo Âm Thanh. Nghe (mặc định chậm), chạm vào bong bóng mang đáp án đúng nổi lên từ biển.
   Cuối màn có Phòng thu luyện nói đuổi: tự ghi âm và nghe lại, KHÔNG chấm điểm phát âm bằng máy. */
import { THREE, createEngine, use3D, fontsReady } from './engine.js';
import { C, mascot, animateMascot, island, water, bubble, forest } from './models.js';

if (use3D()) boot();

function boot() {
  const stage = document.getElementById('g-stage');
  const E = createEngine(stage, { sky: 0xfde7f3, fogColor: 0xd9eefa, fogNear: 30, fogFar: 70, label: 'Đảo Âm Thanh 3D', reduceMotion: document.documentElement.getAttribute('data-motion') === 'reduce' });
  const { scene, camera } = E;
  // trời hoàng hôn: nền chuyển màu bằng một quả cầu lớn tô màu theo đỉnh
  const skyG = new THREE.SphereGeometry(90, 16, 12); const cols = [];
  const pos = skyG.attributes.position, c1 = new THREE.Color(0x7ec8f7), c2 = new THREE.Color(0xfde7f3), tmp = new THREE.Color();
  for (let i = 0; i < pos.count; i++) { const y = pos.getY(i) / 90; tmp.copy(c2).lerp(c1, Math.max(0, y)); cols.push(tmp.r, tmp.g, tmp.b); }
  skyG.setAttribute('color', new THREE.Float32BufferAttribute(cols, 3));
  const sky = new THREE.Mesh(skyG, new THREE.MeshBasicMaterial({ vertexColors: true, side: THREE.BackSide, fog: false })); scene.add(sky);

  const sea = water(E, 120, E.tier === 'low' ? 14 : 28, 0x3fa7d6); scene.add(sea);
  const isl = island(E, 3.2, C.sand); isl.position.set(0, -0.15, -4); scene.add(isl);
  const palms = forest(E, [{ x: -1.8, z: -5.2, s: 1.1 }, { x: 1.9, z: -5, s: 0.9 }, { x: 0.6, z: -6.2, s: 1.3 }], [C.leaf, C.leafDark]); palms.position.y = 0.35; scene.add(palms);
  const hero = mascot(E, 0.95); hero.position.set(0, 0.35, -3); scene.add(hero);
  const far = [[-14, -22, 2.5], [15, -26, 3.5], [-4, -34, 2]];
  far.forEach(([x, z, r]) => { const f = island(E, r, C.grass); f.position.set(x, -0.2, z); scene.add(f); });

  camera.position.set(0, 3.6, 7.5); camera.lookAt(0, 2.2, -3);
  E.onResize = (w, h) => { const narrow = w / h < 1.2; camera.fov = narrow ? 68 : 55; camera.position.set(0, narrow ? 3.1 : 3.6, narrow ? 6.4 : 7.5); camera.updateProjectionMatrix(); camera.lookAt(0, 2.3, -2); };

  let G = null, phase = 'idle', t0 = 0, gems = 0, bubbles = [];
  const HUES = [0x4fc3e0, 0xff7eb6, 0x8b4fd8, 0xffb22e];

  function clearBubbles() { bubbles.forEach(b => { scene.remove(b.g); b.lbl.material.map.dispose(); b.lbl.material.dispose(); b.lbl.geometry.dispose(); b.ball.material.dispose(); }); bubbles = []; }
  function spawn() {
    clearBubbles();
    const it = G.item(), opts = it.display.options || [], n = opts.length;
    opts.forEach((o, i) => {
      const g = new THREE.Group();
      const ball = bubble(E, HUES[i % HUES.length]); g.add(ball);
      const lbl = E.label(o, { w: 2.0, h: 1.15, bg: 'rgba(255,255,255,.92)', fg: '#1c2333', radius: 40 }); lbl.position.set(0, 0, 0.72); g.add(lbl);
      const x = (i - (n - 1) / 2) * (n > 3 ? 2.15 : 2.6);
      g.position.set(x, -1.5, -0.5 - (i % 2) * 0.6); g.userData.i = i;
      scene.add(g);
      bubbles.push({ g, ball, lbl, i, x, baseY: 2.2 + (i % 2) * 0.9, phase: Math.random() * 6, state: null });
      E.tween(g.position, { y: 2.2 + (i % 2) * 0.9 }, 700 + i * 150, 'back');
    });
    phase = 'run'; t0 = Date.now();
    G.showQuestion(it, { instruction: it.type === 'listen_mcq' ? 'Nghe rồi chạm bong bóng đúng' : 'Chọn đáp án đúng', onPick: pick });
    if (it.prompt && (it.prompt.speak || it.prompt.speak_word)) setTimeout(() => G.speakItem(it, true), 500);
  }
  function pick(i) {
    if (phase !== 'run') return;
    phase = 'wait';
    G.answer({ choice: i }, Date.now() - t0).then(fb => {
      G.markPanel(fb, i);
      bubbles.forEach(b => {
        if (b.i === fb.correct_index) { b.state = 'ok'; b.ball.material.color.set(C.green); }
        else if (b.i === i) { b.state = 'bad'; b.ball.material.color.set(C.red); }
        else { b.state = 'fade'; b.ball.material.opacity = 0.3; }
      });
      const target = bubbles.find(b => b.i === fb.correct_index);
      if (fb.is_correct && target) {
        gems++;
        E.burst(target.g.position, 0x4fc3e0, 30, 6);
        E.tween(target.g.scale, { x: 1.4, y: 1.4, z: 1.4 }, 200, 'out', () => E.tween(target.g.scale, { x: 0.01, y: 0.01, z: 0.01 }, 220, 'out'));
        hero.userData.jump = 1;
      } else { E.shake(0.2, 250); }
      phase = 'result';
      setTimeout(() => { if (!G.next()) return studio(); spawn(); }, fb.is_correct ? 1400 : 2700);
    }).catch(() => { phase = 'run'; });
  }

  let jumpY = 0, jumpV = 0;
  E.onFrame((dt, t) => {
    sea.userData.wave(t);
    bubbles.forEach(b => {
      if (b.state === 'fade' || !b.g.parent) return;
      b.g.position.y += Math.sin(t * 1.6 + b.phase) * 0.004;
      b.g.position.x = b.x + Math.sin(t * 0.8 + b.phase) * 0.15;
      b.g.rotation.z = Math.sin(t + b.phase) * 0.05;
    });
    if (hero.userData.jump) { jumpV = 6; hero.userData.jump = 0; }
    jumpV -= 18 * dt; jumpY = Math.max(0, jumpY + jumpV * dt); if (!jumpY) jumpV = 0;
    hero.position.y = 0.35 + jumpY;
    animateMascot(hero, t, 0.4, false);
    if (G) G.hud(`<span>💎 Ngọc giọng nói: ${gems}</span><span>🔥 ${G.streak}</span>`);
  });
  E.canvas.addEventListener('pointerup', e => {
    if (phase !== 'run') return;
    const h = E.pick(e, bubbles.map(b => b.g));
    if (h) { let o = h.object; while (o && o.userData.i === undefined) o = o.parent; if (o) pick(o.userData.i); }
  });

  // ---------- phòng thu luyện nói đuổi (tự ghi âm, tự nghe lại, không chấm máy) ----------
  function studio() {
    phase = 'studio'; clearBubbles();
    const CHIE = window.CHIE, list = (G.extra && G.extra.sentences) || [];
    if (!list.length) return G.finish('Hoàn thành Đảo Âm Thanh!');
    let i = 0, done = 0, rec = null;
    const panel = document.getElementById('g-panel');
    function show() {
      if (rec) rec.dispose();
      const s = list[i];
      panel.innerHTML = '<div class="card"><div class="card-title">🎙️ Phòng thu — luyện nói đuổi (' + (i + 1) + '/' + list.length + ')</div>' +
        '<p class="small muted">Nghe câu mẫu, nói đuổi theo, thu âm rồi nghe lại để tự so sánh. Không chấm điểm bằng máy; bản ghi không rời khỏi máy bạn.</p>' +
        '<div class="q-text" lang="en">' + CHIE.esc(s) + '</div>' +
        '<div class="audio-bar"><button class="audio-btn" id="s-play">' + CHIE.icon('volume-2') + ' Nghe</button><button class="audio-btn slow" id="s-slow">' + CHIE.icon('snail') + ' Chậm theo cụm</button></div>' +
        (CHIE.Recorder && CHIE.Recorder.supported ? '<canvas id="wave" width="600" height="60" style="width:100%;height:60px;background:var(--c-surface-2);border-radius:12px"></canvas><div class="btn-row mt-1"><button class="btn btn-danger" id="s-rec">' + CHIE.icon('mic') + ' Thu âm</button><button class="btn" id="s-stop" disabled>Dừng</button><button class="btn" id="s-me" disabled>' + CHIE.icon('play') + ' Nghe lại tôi</button></div>' : '<p class="small">Trình duyệt chưa hỗ trợ ghi âm — hãy nói theo thành tiếng 3 lần.</p>') +
        '<div class="btn-row mt-2"><button class="btn btn-success" id="s-done">Đã luyện xong câu này</button><button class="btn btn-ghost" id="s-skip">Kết thúc phòng thu</button></div></div>';
      document.getElementById('s-play').onclick = function () { CHIE.speech.say(s, { button: this }); };
      document.getElementById('s-slow').onclick = function () { CHIE.speech.sayChunks(CHIE.speech.chunk(s)); };
      if (CHIE.Recorder && CHIE.Recorder.supported) {
        rec = new CHIE.Recorder({ canvas: document.getElementById('wave'), onstop() { document.getElementById('s-me').disabled = false; document.getElementById('s-rec').disabled = false; document.getElementById('s-stop').disabled = true; } });
        document.getElementById('s-rec').onclick = function () { const b = this; rec.start().then(() => { b.disabled = true; document.getElementById('s-stop').disabled = false; }).catch(e => CHIE.toast(e.message, 'error', 7000)); };
        document.getElementById('s-stop').onclick = () => rec.stop();
        document.getElementById('s-me').onclick = () => rec.play();
      }
      document.getElementById('s-done').onclick = () => { done++; gems++; G.sfx.ok(); hero.userData.jump = 1; i++; if (i >= list.length) end(); else show(); };
      document.getElementById('s-skip').onclick = end;
    }
    function end() { if (rec) rec.dispose(); G.finish('Hoàn thành Đảo Âm Thanh! Đã luyện nói ' + done + ' câu.'); }
    show();
  }

  E.onResize(E.size.w, E.size.h);
  fontsReady().then(() => E.start());
  window.ChieGame = { is3D: true, start(game) { G = game; spawn(); } };
}
