/* Mô hình low-poly dựng bằng hình khối (không tải tệp ngoài). Dùng chung cho game 3D và nông trại 3D. */
import { THREE } from './engine.js';

const G = {}; // cache hình học dùng lại
function geo(key, make) { return G[key] || (G[key] = make()); }

export const C = {
  orange: 0xffb22e, leaf: 0x3dbe7a, leafDark: 0x2f9e62, ink: 0x1c2333, white: 0xffffff, blush: 0xff8f8f,
  wood: 0x9b6a3c, woodDark: 0x6e4526, grass: 0x8fd27a, grassDark: 0x6fb85a, dirt: 0xa8754a, dirtDark: 0x7d5232,
  stone: 0xb9bfcc, stoneDark: 0x8a93a8, blue: 0x2e5be6, sky: 0xbfe7ff, water: 0x3fa7d6, sand: 0xf4d58d,
  red: 0xd93a3f, green: 0x17955a, purple: 0x8b4fd8, gold: 0xffc23d, pink: 0xff7eb6,
};

/** Bé Mầm — linh vật CHIE (quả cam có hai lá). */
export function mascot(E, scale = 1) {
  const g = new THREE.Group();
  const body = E.mesh(geo('mbody', () => new THREE.SphereGeometry(0.62, 20, 16)), C.orange);
  body.position.y = 0.7; g.add(body);
  const belly = E.mesh(geo('mbelly', () => new THREE.SphereGeometry(0.5, 16, 12)), 0xffd27a, { cast: false });
  belly.scale.set(0.8, 0.7, 0.4); belly.position.set(0, 0.6, 0.38); g.add(belly);
  const stem = E.mesh(geo('mstem', () => new THREE.CylinderGeometry(0.05, 0.07, 0.25, 6)), C.woodDark);
  stem.position.y = 1.37; g.add(stem);
  const leafG = geo('mleaf', () => { const s = new THREE.SphereGeometry(0.28, 10, 6); s.scale(1, 0.25, 0.55); return s; });
  const l1 = E.mesh(leafG, C.leaf); l1.position.set(-0.24, 1.45, 0); l1.rotation.z = 0.5; g.add(l1);
  const l2 = E.mesh(leafG, C.leafDark); l2.position.set(0.24, 1.45, 0); l2.rotation.z = -0.5; g.add(l2);
  const eyeG = geo('meye', () => new THREE.SphereGeometry(0.075, 10, 8));
  [-0.2, 0.2].forEach(x => { const e = E.mesh(eyeG, C.ink, { cast: false }); e.position.set(x, 0.85, 0.55); g.add(e); });
  const cheekG = geo('mcheek', () => new THREE.SphereGeometry(0.08, 8, 6));
  [-0.36, 0.36].forEach(x => { const c = E.mesh(cheekG, C.blush, { cast: false }); c.scale.set(1, 0.6, 0.4); c.position.set(x, 0.7, 0.5); g.add(c); });
  const footG = geo('mfoot', () => { const s = new THREE.SphereGeometry(0.17, 10, 8); s.scale(1, 0.6, 1.3); return s; });
  const f1 = E.mesh(footG, C.woodDark); f1.position.set(-0.25, 0.1, 0.05); g.add(f1);
  const f2 = E.mesh(footG, C.woodDark); f2.position.set(0.25, 0.1, 0.05); g.add(f2);
  g.userData = { body, feet: [f1, f2], leaves: [l1, l2] };
  g.scale.setScalar(scale);
  return g;
}

/** Hoạt ảnh chạy/nhún cho Mầm. */
export function animateMascot(m, t, speed = 1, running = true) {
  const u = m.userData;
  if (running) {
    const s = Math.sin(t * 12 * speed);
    u.feet[0].position.z = 0.05 + s * 0.18; u.feet[1].position.z = 0.05 - s * 0.18;
    u.body.position.y = 0.7 + Math.abs(s) * 0.08;
  } else {
    u.body.position.y = 0.7 + Math.sin(t * 3) * 0.03;
  }
  u.leaves[0].rotation.z = 0.5 + Math.sin(t * 6) * 0.08;
  u.leaves[1].rotation.z = -0.5 - Math.sin(t * 6) * 0.08;
}

/** Cây tròn low-poly (thân + tán). Dùng instancing khi cần nhiều cây. */
export function treeGeometries() {
  return {
    trunk: geo('trunk', () => new THREE.CylinderGeometry(0.15, 0.22, 1, 6).translate(0, 0.5, 0)),
    crown: geo('crown', () => new THREE.IcosahedronGeometry(0.9, 0).translate(0, 1.55, 0)),
  };
}
export function forest(E, positions, colors = [C.leaf, C.leafDark, 0x58c785]) {
  const tg = treeGeometries(), n = positions.length;
  const trunks = new THREE.InstancedMesh(tg.trunk, E.mat(C.wood), n);
  const crowns = new THREE.InstancedMesh(tg.crown, E.mat(0xffffff), n);
  const m = new THREE.Matrix4(), q = new THREE.Quaternion(), s = new THREE.Vector3(), col = new THREE.Color();
  positions.forEach((p, i) => {
    const sc = p.s || 1; s.set(sc, sc, sc); q.setFromAxisAngle(new THREE.Vector3(0, 1, 0), p.r || 0);
    m.compose(new THREE.Vector3(p.x, p.y || 0, p.z), q, s);
    trunks.setMatrixAt(i, m); crowns.setMatrixAt(i, m);
    crowns.setColorAt(i, col.set(colors[i % colors.length]));
  });
  if (E.tier === 'high') { trunks.castShadow = crowns.castShadow = true; }
  const g = new THREE.Group(); g.add(trunks, crowns);
  g.userData = { trunks, crowns, set(i, p) { const sc = p.s || 1; s.set(sc, sc, sc); m.compose(new THREE.Vector3(p.x, p.y || 0, p.z), q, s); trunks.setMatrixAt(i, m); crowns.setMatrixAt(i, m); }, commit() { trunks.instanceMatrix.needsUpdate = true; crowns.instanceMatrix.needsUpdate = true; } };
  return g;
}

export function rock(E, s = 1) {
  const r = E.mesh(geo('rock', () => new THREE.DodecahedronGeometry(0.5, 0)), C.stoneDark);
  r.scale.set(s, s * 0.7, s); return r;
}

/** Quái vật dễ thương (mang câu ngữ pháp). */
export function monster(E, color = C.purple, scale = 1) {
  const g = new THREE.Group();
  const body = E.mesh(geo('mon', () => new THREE.SphereGeometry(0.6, 14, 10)), color);
  body.scale.set(1, 0.9, 1); body.position.y = 0.6; g.add(body);
  const eyeW = geo('monEyeW', () => new THREE.SphereGeometry(0.16, 10, 8));
  const eyeB = geo('monEyeB', () => new THREE.SphereGeometry(0.08, 8, 6));
  [-0.22, 0.22].forEach(x => {
    const w = E.mesh(eyeW, C.white, { cast: false }); w.position.set(x, 0.78, 0.48); g.add(w);
    const b = E.mesh(eyeB, C.ink, { cast: false }); b.position.set(x, 0.78, 0.6); g.add(b);
  });
  const hornG = geo('horn', () => new THREE.ConeGeometry(0.1, 0.3, 6));
  [-0.3, 0.3].forEach(x => { const h = E.mesh(hornG, C.gold); h.position.set(x, 1.15, 0); h.rotation.z = -x; g.add(h); });
  g.userData.body = body;
  g.scale.setScalar(scale);
  return g;
}

/** Tháp phòng thủ. */
export function tower(E, color = C.blue) {
  const g = new THREE.Group();
  const base = E.mesh(geo('twb', () => new THREE.CylinderGeometry(0.55, 0.7, 0.5, 8)), C.stone); base.position.y = 0.25; g.add(base);
  const body = E.mesh(geo('twm', () => new THREE.CylinderGeometry(0.42, 0.5, 1.4, 8)), color); body.position.y = 1.2; g.add(body);
  const top = E.mesh(geo('twt', () => new THREE.ConeGeometry(0.6, 0.7, 8)), C.red); top.position.y = 2.25; g.add(top);
  const orb = E.mesh(geo('two', () => new THREE.SphereGeometry(0.16, 10, 8)), C.gold, { emissive: 0x664400 }); orb.position.y = 2.75; g.add(orb);
  g.userData = { body, orb };
  return g;
}

export function castle(E) {
  const g = new THREE.Group();
  const wall = E.mesh(geo('cw', () => new THREE.BoxGeometry(2.4, 1.6, 1.2)), C.stone); wall.position.y = 0.8; g.add(wall);
  const tg = geo('ct', () => new THREE.CylinderGeometry(0.45, 0.5, 2.4, 8));
  const rg = geo('cr', () => new THREE.ConeGeometry(0.6, 0.8, 8));
  [-1.2, 1.2].forEach(x => { const t = E.mesh(tg, C.stoneDark); t.position.set(x, 1.2, 0); g.add(t); const r = E.mesh(rg, C.blue); r.position.set(x, 2.8, 0); g.add(r); });
  const door = E.mesh(geo('cd', () => new THREE.BoxGeometry(0.6, 0.9, 0.1)), C.woodDark, { cast: false }); door.position.set(0, 0.45, 0.61); g.add(door);
  const flag = E.mesh(geo('cf', () => new THREE.PlaneGeometry(0.5, 0.3)), C.red, { unique: true }); flag.material.side = THREE.DoubleSide; flag.position.set(0.25, 1.95, 0); g.add(flag);
  const pole = E.mesh(geo('cp', () => new THREE.CylinderGeometry(0.02, 0.02, 0.8, 4)), C.ink); pole.position.set(0, 1.9, 0); g.add(pole);
  g.userData.flag = flag;
  return g;
}

export function book(E, color = C.blue) {
  const g = new THREE.Group();
  const cover = E.mesh(geo('bk', () => new THREE.BoxGeometry(0.5, 0.7, 0.14)), color, { unique: true }); g.add(cover);
  const pages = E.mesh(geo('bkp', () => new THREE.BoxGeometry(0.44, 0.64, 0.15)), 0xfff7e6, { cast: false }); pages.position.x = 0.04; g.add(pages);
  g.userData.cover = cover;
  return g;
}

export function bookshelf(E, w = 3, h = 2.6) {
  const g = new THREE.Group();
  const frame = E.mesh(geo('bs' + w + h, () => new THREE.BoxGeometry(w, h, 0.5)), C.woodDark, { receive: true }); frame.position.y = h / 2; g.add(frame);
  const cols = [0xa33b3b, 0x2e5ba8, 0x3e8e5a, 0xc9902e, 0x6e4ba3];
  const bg = geo('bsb', () => new THREE.BoxGeometry(0.16, 0.5, 0.36));
  const shelves = 3, per = Math.floor((w - 0.3) / 0.19);
  const inst = new THREE.InstancedMesh(bg, E.mat(0xffffff), shelves * per);
  const m = new THREE.Matrix4(), col = new THREE.Color(); let k = 0;
  for (let s = 0; s < shelves; s++) for (let i = 0; i < per; i++) {
    const hh = 0.75 + ((i * 7 + s * 3) % 5) * 0.06;
    m.makeScale(1, hh, 1); m.setPosition(-w / 2 + 0.25 + i * 0.19, 0.4 + s * (h / shelves) + 0.25 * hh, 0.1);
    inst.setMatrixAt(k, m); inst.setColorAt(k, col.set(cols[(i + s) % cols.length])); k++;
  }
  g.add(inst);
  return g;
}

/** Ô đất nông trại. */
export function plotTile(E) {
  const g = new THREE.Group();
  const soil = E.mesh(geo('soil', () => new THREE.BoxGeometry(1.7, 0.3, 1.7)), C.dirt, { receive: true, cast: false }); soil.position.y = 0.15; g.add(soil);
  const rows = E.mesh(geo('soilr', () => { const b = new THREE.BoxGeometry(1.5, 0.08, 0.22); return b; }), C.dirtDark, { cast: false });
  [-0.5, 0, 0.5].forEach(z => { const r = rows.clone(); r.position.set(0, 0.32, z); g.add(r); });
  g.userData.soil = soil;
  return g;
}

/** Cây trồng theo giai đoạn (0 mầm → 3 chín). color = màu quả. */
export function crop(E, stage, color = C.red, kind = 'round') {
  const g = new THREE.Group();
  const stemH = [0.25, 0.5, 0.75, 0.85][stage];
  const st = E.mesh(geo('cstem' + stage, () => new THREE.CylinderGeometry(0.04, 0.05, stemH, 5).translate(0, stemH / 2, 0)), C.leafDark);
  const lf = geo('cleaf', () => { const s = new THREE.SphereGeometry(0.18, 8, 6); s.scale(1, 0.3, 0.6); return s; });
  [[-0.14, 0.6], [0.14, -0.6]].forEach(([x, r], i) => { if (stage === 0 && i) return; const l = E.mesh(lf, C.leaf); l.position.set(x, stemH * 0.7, 0); l.rotation.z = r; g.add(l); });
  g.add(st);
  if (stage >= 2) {
    const fr = kind === 'long' ? geo('cfl', () => new THREE.ConeGeometry(0.12, 0.45, 7).rotateX(Math.PI)) : geo('cfr', () => new THREE.SphereGeometry(0.15, 10, 8));
    const s = stage === 3 ? 1 : 0.6;
    const f = E.mesh(fr, color); f.scale.setScalar(s); f.position.set(0, stemH + 0.05, 0); g.add(f);
    if (stage === 3) { const f2 = f.clone(); f2.position.set(0.18, stemH * 0.65, 0.08); g.add(f2); }
  }
  return g;
}

/** Vật nuôi. */
export function animal(E, kind) {
  const g = new THREE.Group();
  if (kind === 'chicken') {
    const b = E.mesh(geo('chb', () => new THREE.SphereGeometry(0.3, 10, 8)), C.white); b.scale.set(1, 0.9, 1.2); b.position.y = 0.38; g.add(b);
    const h = E.mesh(geo('chh', () => new THREE.SphereGeometry(0.17, 10, 8)), C.white); h.position.set(0, 0.68, 0.24); g.add(h);
    const beak = E.mesh(geo('chk', () => new THREE.ConeGeometry(0.05, 0.12, 5).rotateX(Math.PI / 2)), C.gold); beak.position.set(0, 0.66, 0.43); g.add(beak);
    const comb = E.mesh(geo('chc', () => new THREE.SphereGeometry(0.07, 6, 5)), C.red); comb.position.set(0, 0.85, 0.24); g.add(comb);
    const leg = geo('chl', () => new THREE.CylinderGeometry(0.025, 0.025, 0.18, 4));
    [-0.1, 0.1].forEach(x => { const l = E.mesh(leg, C.gold); l.position.set(x, 0.09, 0); g.add(l); });
    g.userData.head = h;
  } else if (kind === 'cow') {
    const b = E.mesh(geo('cwb', () => new THREE.BoxGeometry(0.7, 0.5, 1.1)), C.white); b.position.y = 0.65; g.add(b);
    const spot = E.mesh(geo('cws', () => new THREE.BoxGeometry(0.72, 0.26, 0.35)), C.ink, { cast: false }); spot.position.set(0, 0.72, -0.15); g.add(spot);
    const h = E.mesh(geo('cwh', () => new THREE.BoxGeometry(0.42, 0.38, 0.4)), C.white); h.position.set(0, 0.85, 0.68); g.add(h);
    const nose = E.mesh(geo('cwn', () => new THREE.BoxGeometry(0.36, 0.18, 0.12)), C.pink, { cast: false }); nose.position.set(0, 0.76, 0.9); g.add(nose);
    const leg = geo('cwl', () => new THREE.BoxGeometry(0.14, 0.42, 0.14));
    [[-0.22, 0.38], [0.22, 0.38], [-0.22, -0.38], [0.22, -0.38]].forEach(([x, z]) => { const l = E.mesh(leg, C.white); l.position.set(x, 0.21, z); g.add(l); });
    g.userData.head = h;
  } else { // sheep
    const b = E.mesh(geo('shb', () => new THREE.IcosahedronGeometry(0.42, 1)), 0xf5f2ea); b.scale.set(1, 0.85, 1.2); b.position.y = 0.6; g.add(b);
    const h = E.mesh(geo('shh', () => new THREE.SphereGeometry(0.2, 10, 8)), C.ink); h.scale.set(1, 1, 1.2); h.position.set(0, 0.72, 0.5); g.add(h);
    const leg = geo('shl', () => new THREE.CylinderGeometry(0.05, 0.05, 0.36, 5));
    [[-0.18, 0.25], [0.18, 0.25], [-0.18, -0.25], [0.18, -0.25]].forEach(([x, z]) => { const l = E.mesh(leg, C.ink); l.position.set(x, 0.18, z); g.add(l); });
    g.userData.head = h;
  }
  return g;
}

export function fence(E, len = 4) {
  const g = new THREE.Group();
  const post = geo('fp', () => new THREE.BoxGeometry(0.12, 0.6, 0.12));
  const rail = geo('fr' + len, () => new THREE.BoxGeometry(len, 0.08, 0.06));
  for (let i = 0; i <= len; i++) { const p = E.mesh(post, C.wood); p.position.set(-len / 2 + i, 0.3, 0); g.add(p); }
  [0.2, 0.45].forEach(y => { const r = E.mesh(rail, C.wood); r.position.y = y; g.add(r); });
  return g;
}

export function barn(E) {
  const g = new THREE.Group();
  const b = E.mesh(geo('bb', () => new THREE.BoxGeometry(2.4, 1.6, 2)), C.red); b.position.y = 0.8; g.add(b);
  const roof = E.mesh(geo('br', () => new THREE.ConeGeometry(1.9, 1, 4).rotateY(Math.PI / 4)), C.woodDark); roof.scale.set(1, 1, 0.85); roof.position.y = 2.1; g.add(roof);
  const door = E.mesh(geo('bd', () => new THREE.BoxGeometry(0.8, 1, 0.06)), C.white, { cast: false }); door.position.set(0, 0.5, 1.01); g.add(door);
  return g;
}

/** Cổng đáp án (khung vòm) cho Word Runner. */
export function gate(E, width = 2) {
  const g = new THREE.Group();
  const post = geo('gp', () => new THREE.CylinderGeometry(0.09, 0.09, 2.2, 6).translate(0, 1.1, 0));
  const l = E.mesh(post, C.woodDark); l.position.x = -width / 2; g.add(l);
  const r = E.mesh(post, C.woodDark); r.position.x = width / 2; g.add(r);
  return g;
}

export function bubble(E, color) {
  return E.mesh(geo('bub', () => new THREE.SphereGeometry(0.7, 18, 14)), color, { opacity: 0.82, unique: true, flat: true, cast: false });
}

export function island(E, r = 3, color = C.grass) {
  const g = new THREE.Group();
  const top = E.mesh(new THREE.CylinderGeometry(r, r * 0.92, 0.5, 10), color, { receive: true }); top.position.y = 0.25; g.add(top);
  const bottom = E.mesh(new THREE.ConeGeometry(r * 0.92, r * 1.1, 10).rotateX(Math.PI), C.dirtDark); bottom.position.y = -r * 0.55; g.add(bottom);
  return g;
}

export function coin(E) {
  return E.mesh(geo('coin', () => new THREE.CylinderGeometry(0.3, 0.3, 0.08, 14).rotateX(Math.PI / 2)), C.gold, { emissive: 0x553300 });
}

/** Sóng nước đơn giản (mặt phẳng nhấp nhô bằng CPU, ít đỉnh). */
export function water(E, size = 80, seg = 24, color = C.water) {
  const g = new THREE.PlaneGeometry(size, size, seg, seg).rotateX(-Math.PI / 2);
  const m = E.mesh(g, color, { flat: true, unique: true, cast: false, receive: false });
  const base = g.attributes.position.array.slice();
  m.userData.wave = (t) => {
    const p = g.attributes.position.array;
    for (let i = 0; i < p.length; i += 3) p[i + 1] = Math.sin(base[i] * 0.35 + t * 1.3) * 0.12 + Math.cos(base[i + 2] * 0.3 + t) * 0.12;
    g.attributes.position.needsUpdate = true;
  };
  return m;
}
