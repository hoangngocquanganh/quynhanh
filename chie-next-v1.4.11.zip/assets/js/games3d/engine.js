/* CHIE 3D — bộ máy dựng hình dùng chung cho game 3D (three.js, ES module, không cần build).
   Tối ưu cho điện thoại phổ thông:
   - Tự chọn mức đồ họa (cao / vừa / nhẹ) theo thiết bị, và tự hạ độ phân giải khi khung hình chậm.
   - Không dùng ảnh/texture tải ngoài: hình khối low-poly + vật liệu toon, chữ vẽ bằng canvas.
   - Ngừng vẽ khi tab ẩn, giải phóng bộ nhớ GPU khi rời trang.
   Người dùng có thể chọn "2D" hoặc mức đồ họa trong Cài đặt game (lưu trên máy). */
import * as THREE from '../../vendor/three/three.module.min.js';

export { THREE };

const GFX_KEY = 'chie_gfx'; // auto | high | mid | low | 2d

export function gfxPref() {
  try { return localStorage.getItem(GFX_KEY) || 'auto'; } catch (e) { return 'auto'; }
}
export function setGfxPref(v) { try { localStorage.setItem(GFX_KEY, v); } catch (e) {} }

export function webglOK() {
  try {
    const c = document.createElement('canvas');
    return !!(window.WebGLRenderingContext && (c.getContext('webgl2') || c.getContext('webgl')));
  } catch (e) { return false; }
}

/** 3D có nên chạy không (có WebGL và người dùng không chọn 2D). */
export function use3D() { return webglOK() && gfxPref() !== '2d'; }

function detectTier() {
  const pref = gfxPref();
  if (pref === 'high' || pref === 'mid' || pref === 'low') return pref;
  const mem = navigator.deviceMemory || 4;
  const cores = navigator.hardwareConcurrency || 4;
  const small = Math.min(screen.width, screen.height) < 500;
  const saveData = navigator.connection && navigator.connection.saveData;
  if (saveData || mem <= 2 || cores <= 2) return 'low';
  if (mem >= 6 && cores >= 6 && !small) return 'high';
  return 'mid';
}

const TIER = {
  high: { maxRatio: 2, shadows: true, antialias: true, particles: 160 },
  mid: { maxRatio: 1.5, shadows: false, antialias: true, particles: 90 },
  low: { maxRatio: 1, shadows: false, antialias: false, particles: 40 },
};

export function createEngine(stage, opts = {}) {
  const tier = detectTier();
  const T = TIER[tier];
  const reduce = !!opts.reduceMotion;
  const aspect = opts.aspect || (720 / 440);

  const canvas = document.createElement('canvas');
  canvas.className = 'g3d-canvas';
  canvas.setAttribute('role', 'img');
  canvas.setAttribute('aria-label', opts.label || 'Màn chơi 3D');
  stage.insertBefore(canvas, stage.firstChild);
  stage.classList.add('is-3d');

  const renderer = new THREE.WebGLRenderer({ canvas, antialias: T.antialias, powerPreference: 'high-performance', alpha: false, stencil: false });
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.shadowMap.enabled = T.shadows;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;

  const scene = new THREE.Scene();
  scene.background = new THREE.Color(opts.sky || 0xbfe7ff);
  if (opts.fog !== false) scene.fog = new THREE.Fog(opts.fogColor || opts.sky || 0xbfe7ff, opts.fogNear || 30, opts.fogFar || 90);

  const camera = new THREE.PerspectiveCamera(opts.fov || 55, aspect, 0.1, 200);
  const hemi = new THREE.HemisphereLight(0xffffff, 0x88aa77, 1.15);
  scene.add(hemi);
  const sun = new THREE.DirectionalLight(0xfff2dd, 1.6);
  sun.position.set(8, 16, 10);
  if (T.shadows) {
    sun.castShadow = true;
    sun.shadow.mapSize.set(1024, 1024);
    const s = sun.shadow.camera; s.left = -18; s.right = 18; s.top = 18; s.bottom = -18; s.near = 1; s.far = 60;
    sun.shadow.bias = -0.0005;
  }
  scene.add(sun);

  // vật liệu toon có bậc sáng (đẹp, nhẹ); máy yếu dùng Lambert
  const grad = new THREE.DataTexture(new Uint8Array([90, 170, 255]), 3, 1, THREE.RedFormat);
  grad.minFilter = grad.magFilter = THREE.NearestFilter; grad.needsUpdate = true;
  const matCache = new Map();
  function mat(color, o = {}) {
    const key = color + '|' + (o.emissive || 0) + '|' + (o.opacity || 1) + '|' + (o.flat ? 1 : 0);
    if (!o.unique && matCache.has(key)) return matCache.get(key);
    const base = { color, transparent: (o.opacity || 1) < 1, opacity: o.opacity || 1 };
    if (o.emissive) base.emissive = new THREE.Color(o.emissive);
    const m = tier === 'low' || o.flat ? new THREE.MeshLambertMaterial(base) : new THREE.MeshToonMaterial({ ...base, gradientMap: grad });
    if (!o.unique) matCache.set(key, m);
    return m;
  }
  function mesh(geo, color, o = {}) {
    const m = new THREE.Mesh(geo, o.material || mat(color, o));
    if (T.shadows) { m.castShadow = o.cast !== false; m.receiveShadow = !!o.receive; }
    return m;
  }

  /* ---------- kích thước & độ phân giải động ---------- */
  let ratio = Math.min(T.maxRatio, window.devicePixelRatio || 1);
  let W = 0, H = 0;
  function fit() {
    const w = stage.clientWidth || 360;
    const h = opts.fillHeight ? Math.max(320, stage.clientHeight) : Math.round(w / (window.innerWidth < 600 ? (opts.mobileAspect || 4 / 3.4) : aspect));
    W = w; H = h;
    canvas.style.width = w + 'px'; canvas.style.height = h + 'px';
    renderer.setPixelRatio(ratio);
    renderer.setSize(w, h, false);
    camera.aspect = w / h; camera.updateProjectionMatrix();
    if (api.onResize) api.onResize(w, h);
  }
  const ro = typeof ResizeObserver !== 'undefined' ? new ResizeObserver(fit) : null;
  if (ro) ro.observe(stage); else window.addEventListener('resize', fit);

  let frameMs = 16, frames = 0, adjustAt = 0;
  function adapt(dtMs) {
    frameMs = frameMs * 0.94 + dtMs * 0.06;
    if (++frames < 90 || performance.now() < adjustAt) return;
    if (frameMs > 26 && ratio > 0.6) { ratio = Math.max(0.6, ratio - 0.15); renderer.setPixelRatio(ratio); adjustAt = performance.now() + 1500; }
    else if (frameMs < 15 && ratio < Math.min(T.maxRatio, window.devicePixelRatio || 1)) { ratio = Math.min(T.maxRatio, ratio + 0.1); renderer.setPixelRatio(ratio); adjustAt = performance.now() + 3000; }
  }

  /* ---------- vòng lặp ---------- */
  const updaters = new Set();
  let running = false, last = 0, elapsed = 0;
  function frame(t) {
    const dtMs = Math.min(60, last ? t - last : 16); last = t;
    if (document.hidden) return;
    const dt = dtMs / 1000; elapsed += dt;
    tweens.step(dtMs);
    updaters.forEach(fn => fn(dt, elapsed));
    stepParticles(dt);
    stepShake(dt);
    renderer.render(scene, camera);
    adapt(dtMs);
  }
  function start() { if (running) return; running = true; last = 0; renderer.setAnimationLoop(frame); }
  function stop() { running = false; renderer.setAnimationLoop(null); }
  function onVis() { if (document.hidden) renderer.setAnimationLoop(null); else if (running) { last = 0; renderer.setAnimationLoop(frame); } }
  document.addEventListener('visibilitychange', onVis);

  /* ---------- tween đơn giản ---------- */
  const EASE = {
    linear: t => t, out: t => 1 - Math.pow(1 - t, 3), inOut: t => t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2,
    back: t => { const c = 1.7; return 1 + (c + 1) * Math.pow(t - 1, 3) + c * Math.pow(t - 1, 2); },
    bounce: t => { const n = 7.5625, d = 2.75; if (t < 1 / d) return n * t * t; if (t < 2 / d) return n * (t -= 1.5 / d) * t + 0.75; if (t < 2.5 / d) return n * (t -= 2.25 / d) * t + 0.9375; return n * (t -= 2.625 / d) * t + 0.984375; },
  };
  const tweens = {
    list: [],
    step(ms) {
      this.list = this.list.filter(tw => {
        tw.t += ms; const k = Math.min(1, tw.t / tw.ms), e = tw.ease(k);
        for (const p in tw.to) tw.obj[p] = tw.from[p] + (tw.to[p] - tw.from[p]) * e;
        if (tw.onUpdate) tw.onUpdate(e);
        if (k >= 1) { if (tw.done) tw.done(); return false; }
        return true;
      });
    },
  };
  function tween(obj, to, ms, ease = 'out', done, onUpdate) {
    if (reduce) ms = Math.min(ms, 120);
    const from = {}; for (const p in to) from[p] = obj[p];
    const tw = { obj, from, to, ms: Math.max(1, ms), t: 0, ease: EASE[ease] || EASE.out, done, onUpdate };
    tweens.list.push(tw); return tw;
  }
  function wait(ms) { return new Promise(r => tween({ v: 0 }, { v: 1 }, ms, 'linear', r)); }

  /* ---------- hạt (pool dùng chung, 1 draw call) ---------- */
  const PN = T.particles;
  const pGeo = new THREE.BufferGeometry();
  const pPos = new Float32Array(PN * 3), pCol = new Float32Array(PN * 3);
  const pVel = new Float32Array(PN * 3), pLife = new Float32Array(PN);
  pGeo.setAttribute('position', new THREE.BufferAttribute(pPos, 3));
  pGeo.setAttribute('color', new THREE.BufferAttribute(pCol, 3));
  const pMat = new THREE.PointsMaterial({ size: tier === 'low' ? 0.35 : 0.28, vertexColors: true, transparent: true, depthWrite: false });
  const points = new THREE.Points(pGeo, pMat); points.frustumCulled = false; scene.add(points);
  for (let i = 0; i < PN; i++) pPos[i * 3 + 1] = -999;
  let pNext = 0;
  const tmpC = new THREE.Color();
  function burst(pos, color = 0xffc23d, n = 18, power = 5) {
    if (reduce) n = Math.min(n, 6);
    tmpC.set(color);
    for (let k = 0; k < n; k++) {
      const i = pNext; pNext = (pNext + 1) % PN;
      pPos[i * 3] = pos.x; pPos[i * 3 + 1] = pos.y; pPos[i * 3 + 2] = pos.z;
      pVel[i * 3] = (Math.random() - 0.5) * power; pVel[i * 3 + 1] = Math.random() * power * 0.9 + 1; pVel[i * 3 + 2] = (Math.random() - 0.5) * power;
      pCol[i * 3] = tmpC.r; pCol[i * 3 + 1] = tmpC.g; pCol[i * 3 + 2] = tmpC.b;
      pLife[i] = 0.8 + Math.random() * 0.5;
    }
  }
  function stepParticles(dt) {
    let any = false;
    for (let i = 0; i < PN; i++) {
      if (pLife[i] <= 0) continue;
      any = true;
      pLife[i] -= dt;
      pVel[i * 3 + 1] -= 9 * dt;
      pPos[i * 3] += pVel[i * 3] * dt; pPos[i * 3 + 1] += pVel[i * 3 + 1] * dt; pPos[i * 3 + 2] += pVel[i * 3 + 2] * dt;
      if (pLife[i] <= 0) pPos[i * 3 + 1] = -999;
    }
    if (any) { pGeo.attributes.position.needsUpdate = true; pGeo.attributes.color.needsUpdate = true; }
  }

  /* ---------- rung camera ---------- */
  let shakeT = 0, shakeA = 0; const camBase = new THREE.Vector3();
  function shake(a = 0.25, ms = 250) { if (reduce) return; shakeA = a; shakeT = ms / 1000; camBase.copy(camera.position); }
  function stepShake(dt) {
    if (shakeT <= 0) return;
    shakeT -= dt;
    if (shakeT <= 0) { camera.position.copy(camBase); return; }
    camera.position.set(camBase.x + (Math.random() - 0.5) * shakeA, camBase.y + (Math.random() - 0.5) * shakeA, camBase.z);
  }

  /* ---------- chữ trên vật thể (canvas → texture) ---------- */
  const FONT = '"Be Vietnam Pro", system-ui, sans-serif';
  function drawLabel(ctx, cw, chh, text, o) {
    ctx.clearRect(0, 0, cw, chh);
    const r = o.radius != null ? o.radius : chh * 0.22;
    if (o.bg) {
      ctx.fillStyle = o.bg;
      ctx.beginPath(); ctx.moveTo(r, 0); ctx.arcTo(cw, 0, cw, chh, r); ctx.arcTo(cw, chh, 0, chh, r); ctx.arcTo(0, chh, 0, 0, r); ctx.arcTo(0, 0, cw, 0, r); ctx.closePath(); ctx.fill();
      if (o.border) { ctx.lineWidth = chh * 0.06; ctx.strokeStyle = o.border; ctx.stroke(); }
    }
    ctx.fillStyle = o.fg || '#1c2333';
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    // tự xuống dòng tối đa 3 dòng, tự thu nhỏ chữ
    let size = o.size || chh * 0.42;
    const maxW = cw * 0.9, words = String(text).split(/\s+/);
    let lines;
    for (; size > 10; size -= 2) {
      ctx.font = `800 ${size}px ${FONT}`;
      lines = []; let cur = '';
      for (const w of words) {
        const t = cur ? cur + ' ' + w : w;
        if (ctx.measureText(t).width <= maxW || !cur) cur = t; else { lines.push(cur); cur = w; }
      }
      if (cur) lines.push(cur);
      if (lines.length <= (o.maxLines || 3) && lines.every(l => ctx.measureText(l).width <= maxW) && lines.length * size * 1.15 <= chh * 0.92) break;
    }
    const lh = size * 1.15, y0 = chh / 2 - (lines.length - 1) * lh / 2;
    lines.forEach((l, i) => ctx.fillText(l, cw / 2, y0 + i * lh));
  }
  function label(text, o = {}) {
    const wU = o.w || 2, hU = o.h || 0.8, px = tier === 'low' ? 96 : 160;
    const cw = Math.round(wU * px), chh = Math.round(hU * px);
    const c = document.createElement('canvas'); c.width = cw; c.height = chh;
    const ctx = c.getContext('2d');
    drawLabel(ctx, cw, chh, text, o);
    const tex = new THREE.CanvasTexture(c);
    tex.colorSpace = THREE.SRGBColorSpace;
    tex.anisotropy = tier === 'high' ? 4 : 1;
    const m = new THREE.Mesh(new THREE.PlaneGeometry(wU, hU), new THREE.MeshBasicMaterial({ map: tex, transparent: true, depthWrite: o.depthWrite !== false, side: THREE.DoubleSide, toneMapped: false }));
    m.userData.setText = (t, o2 = {}) => { drawLabel(ctx, cw, chh, t, { ...o, ...o2 }); tex.needsUpdate = true; };
    m.renderOrder = o.renderOrder || 2;
    return m;
  }

  /* ---------- chọn vật thể bằng chạm/chuột ---------- */
  const ray = new THREE.Raycaster(), ndc = new THREE.Vector2();
  function pick(ev, objects) {
    const r = canvas.getBoundingClientRect();
    ndc.x = ((ev.clientX - r.left) / r.width) * 2 - 1;
    ndc.y = -((ev.clientY - r.top) / r.height) * 2 + 1;
    ray.setFromCamera(ndc, camera);
    const hits = ray.intersectObjects(objects, true);
    return hits.length ? hits[0] : null;
  }

  /* ---------- dọn dẹp ---------- */
  function dispose() {
    stop();
    document.removeEventListener('visibilitychange', onVis);
    if (ro) ro.disconnect();
    scene.traverse(o => {
      if (o.geometry) o.geometry.dispose();
      if (o.material) (Array.isArray(o.material) ? o.material : [o.material]).forEach(m => { if (m.map) m.map.dispose(); m.dispose(); });
    });
    renderer.dispose();
    try { renderer.forceContextLoss(); } catch (e) {}
  }
  window.addEventListener('pagehide', dispose, { once: true });

  const api = {
    THREE, renderer, scene, camera, canvas, sun, hemi, tier, reduce,
    mat, mesh, label, pick, burst, shake, tween, wait, EASE,
    onFrame(fn) { updaters.add(fn); return () => updaters.delete(fn); },
    start, stop, dispose, fit,
    get size() { return { w: W, h: H }; },
    get elapsed() { return elapsed; },
    onResize: null,
  };
  fit();
  return api;
}

/** Chờ phông chữ để chữ trên vật thể không bị đổi phông giữa chừng. */
export function fontsReady() {
  if (!document.fonts || !document.fonts.load) return Promise.resolve();
  return Promise.race([
    Promise.all([document.fonts.load('800 40px "Be Vietnam Pro"'), document.fonts.load('700 40px "Be Vietnam Pro"')]),
    new Promise(r => setTimeout(r, 1200)),
  ]).catch(() => {});
}
