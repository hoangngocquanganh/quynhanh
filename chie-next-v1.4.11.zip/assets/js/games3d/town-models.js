/* Original Mầm Xanh models. Shared geometry/materials keep the town light on mobile. */
import { THREE } from './engine.js?v=town-1.2.0';
export function townModels(E) {
  const box = new THREE.BoxGeometry(1,1,1), ball = new THREE.IcosahedronGeometry(1,1), cyl = new THREE.CylinderGeometry(1,1,1,10), cone = new THREE.ConeGeometry(1,1,4);
  function part(g, geo, color, x,y,z, sx,sy,sz) { const m=E.mesh(geo,color,{receive:true});m.position.set(x,y,z);m.scale.set(sx,sy,sz);g.add(m);return m; }
  const block=(g,c,x,y,z,a,b,d)=>part(g,box,c,x,y,z,a,b,d);
  const orb=(g,c,x,y,z,a,b=a,d=a)=>part(g,ball,c,x,y,z,a,b,d);
  function house(color, roofColor, w=4, d=3) {
    const g=new THREE.Group();
    block(g,0xeedbc1,0,.15,0,w+.5,.3,d+.5);
    block(g,color,0,1.55,0,w,2.8,d);
    const roof=part(g,cone,roofColor,0,3.35,0,w*.86,1.8,d*1.18);roof.rotation.y=Math.PI/4;
    block(g,0xfff0d7,0,1.3,d/2+.02,1.1,2.2,.18);
    block(g,0x597a77,0,1.22,d/2+.13,.8,1.95,.08);
    orb(g,0xffdc79,.25,1.2,d/2+.2,.07);
    for(const x of [-w*.31,w*.31]) {
      block(g,0xfff5de,x,1.65,d/2+.06,.9,1.1,.15);
      block(g,0x98d9e0,x,1.65,d/2+.15,.69,.87,.1);
      block(g,0xfff5de,x,1.65,d/2+.23,.07,.9,.04);
      block(g,0xfff5de,x,1.65,d/2+.23,.72,.07,.04);
      block(g,0xb8835c,x,1.05,d/2+.3,1,.23,.45);
      for(let i=0;i<3;i++)orb(g,i%2?0xffcf79:0xf390a5,x+(i-1)*.26,1.27,d/2+.3,.19);
    }
    block(g,0xe3baa0,w*.27,3.65,-.4,.5,1.3,.55);
    return g;
  }
  function stall() {
    const g=new THREE.Group();block(g,0xca9970,0,.65,0,3,1.3,1.5);
    for(const x of [-1.4,1.4])block(g,0x805845,x,1.55,0,.12,3.1,.12);
    for(let i=0;i<6;i++)block(g,i%2?0xfff4d8:0xeb9c73,(i-2.5)*.58,2.9,0,.58,.2,2.1);
    for(let i=0;i<8;i++)orb(g,i%2?0xedbb48:0xed6a54,(i%4-1.5)*.55,1.42,Math.floor(i/4)*.5-.25,.23);
    return g;
  }
  function person(shirt=0x7d9ead,hat=0xe8b86a) {
    const g=new THREE.Group();
    const torso=block(g,shirt,0,1.03,0,.58,.65,.36);
    orb(g,0xf2c7a6,0,1.65,0,.37,.4,.34);
    orb(g,0x594137,0,1.89,-.02,.37,.2,.34);
    part(g,cyl,hat,0,1.98,0,.48,.08,.45);part(g,cyl,hat,0,2.08,0,.3,.2,.3);
    [-.12,.12].forEach(x=>orb(g,0x363936,x,1.7,.31,.035,.055,.03));
    const legs=[-.16,.16].map(x=>{const p=new THREE.Group();p.position.set(x,.76,0);g.add(p);block(p,0x536575,0,-.25,0,.22,.52,.24);block(p,0xfff1d7,0,-.51,.06,.25,.16,.36);return p;});
    const arms=[-.4,.4].map(x=>{const p=new THREE.Group();p.position.set(x,1.27,0);g.add(p);block(p,shirt,0,-.15,0,.2,.34,.25);orb(p,0xf2c7a6,0,-.4,0,.12,.17,.12);return p;});
    g.userData={legs,arms,torso};return g;
  }
  function lamp() {const g=new THREE.Group();part(g,cyl,0x55756b,0,1.4,0,.075,2.8,.075);block(g,0x54766c,0,2.75,0,.5,.12,.5);block(g,0xffe7a7,0,2.5,0,.32,.4,.32);return g;}
  function bench() {const g=new THREE.Group();for(let i=0;i<3;i++)block(g,0xb88960,0,.6,(i-1)*.2,1.8,.1,.16);block(g,0xb88960,0,1,-.3,1.8,.5,.1);for(const x of [-.65,.65])block(g,0x507e6e,x,.3,0,.12,.6,.5);return g;}
  return {block,orb,part,house,person,stall,lamp,bench,box,ball,cyl};
}
