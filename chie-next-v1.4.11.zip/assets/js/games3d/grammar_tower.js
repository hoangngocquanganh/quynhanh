/* Grammar Tower 3D — Thủ Thành Ngữ Pháp. Quái mang câu ngữ pháp đi theo đường tới lâu đài.
   Trả lời đúng: tháp mọc lên/nâng cấp và bắn hạ quái. Sai hoặc hết đường: quái lao vào thành, thành mất máu. */
import { THREE, createEngine, use3D, fontsReady } from './engine.js';
import { C, monster, tower, castle, forest, rock } from './models.js';

if (use3D()) boot();

function boot() {
  const stage = document.getElementById('g-stage');
  const E = createEngine(stage, { sky: 0xcfeaff, fogNear: 40, fogFar: 80, label: 'Bản đồ Thủ Thành Ngữ Pháp 3D', reduceMotion: document.documentElement.getAttribute('data-motion') === 'reduce' });
  const { scene, camera } = E;

  const billboards = [];
  // ---------- bản đồ ----------
  const ground = E.mesh(new THREE.BoxGeometry(30, 0.6, 22), C.grass, { receive: true, cast: false }); ground.position.y = -0.3; scene.add(ground);
  const PATH = [[-13, 4], [-8, 4], [-6, -4], [0, -4], [1, 5], [7, 5], [8, -1], [11.5, -1]].map(([x, z]) => new THREE.Vector3(x, 0, z));
  const curve = new THREE.CatmullRomCurve3(PATH, false, 'catmullrom', 0.2);
  const LEN = curve.getLength();
  // đường đất: chuỗi ô phẳng dọc theo đường cong (instanced)
  const N = 90, tileG = new THREE.BoxGeometry(1.8, 0.08, 0.6);
  const tiles = new THREE.InstancedMesh(tileG, E.mat(0xd9c08f), N);
  const M4 = new THREE.Matrix4(), q = new THREE.Quaternion(), up = new THREE.Vector3(0, 1, 0);
  for (let i = 0; i < N; i++) {
    const t = i / (N - 1), p = curve.getPointAt(t), tan = curve.getTangentAt(t);
    q.setFromAxisAngle(up, Math.atan2(tan.x, tan.z) + Math.PI / 2);
    M4.compose(p.clone().setY(0.03), q, new THREE.Vector3(1, 1, 1)); tiles.setMatrixAt(i, M4);
  }
  if (E.tier === 'high') tiles.receiveShadow = true;
  scene.add(tiles);
  const home = castle(E); home.position.set(12.6, 0, -1); home.rotation.y = -Math.PI / 2; scene.add(home);
  const spawn = E.mesh(new THREE.TorusGeometry(0.9, 0.18, 8, 20).rotateY(Math.PI / 2), C.purple, { emissive: 0x330055 }); spawn.position.set(-13.5, 0.9, 4); scene.add(spawn);
  // cây viền bản đồ
  const trees = [];
  for (let i = 0; i < 26; i++) { const a = i / 26 * Math.PI * 2; trees.push({ x: Math.cos(a) * 14 + (Math.random() - 0.5) * 2, z: Math.sin(a) * 10 + (Math.random() - 0.5) * 1.5, s: 0.7 + Math.random() * 0.6, r: a }); }
  scene.add(forest(E, trees));
  [[-3, 1.5], [4, 1], [-10, -2], [9, 7.5]].forEach(([x, z]) => { const r = rock(E, 0.9); r.position.set(x, 0.2, z); scene.add(r); });

  // bệ tháp (6 vị trí, mỗi bệ một loại ngữ pháp)
  const TYPES = [['Hiện tại', C.blue], ['Quá khứ', C.purple], ['Tương lai', 0x0e7c9b], ['Điều kiện', 0xd4880f], ['Bị động', C.red], ['Giới từ', C.green]];
  const PADS = [[-9.5, 0.5], [-3, -6.5], [-2.5, 0.5], [3.8, 1.8], [4.5, 8], [10, 2.5]];
  const pads = PADS.map(([x, z], i) => {
    const pad = E.mesh(new THREE.CylinderGeometry(0.9, 1, 0.25, 10), C.stone, { receive: true }); pad.position.set(x, 0.12, z); scene.add(pad);
    const lbl = E.label(TYPES[i][0], { w: 1.8, h: 0.42, bg: 'rgba(255,255,255,.88)', fg: '#1c2333', size: 30 }); lbl.position.set(x, 0.9, z); scene.add(lbl); billboards.push(lbl);
    return { x, z, tower: null, level: 0 };
  });

  camera.position.set(0, 21, 15); camera.lookAt(0, 0, 0.5);
  E.onResize = (w, h) => {
    // màn hình dọc: nhìn bản đồ theo chiều dọc (trục dài của bản đồ chạy từ xa tới gần) để quái và tháp to rõ
    const narrow = w / h < 1.2;
    if (narrow) { camera.position.set(21, 23, 0.5); camera.fov = 52; } else { camera.position.set(0, 21, 15); camera.fov = 50; }
    camera.updateProjectionMatrix(); camera.lookAt(narrow ? 2.2 : 0, 0, 0.5);
    billboards.forEach(b => b.quaternion.copy(camera.quaternion));
  };
  // ---------- trạng thái ----------
  let G = null, phase = 'idle', enemy = null, dist = 0, hp = 5, maxHp = 5, t0 = 0, killed = 0, travel = 16;
  const shots = [];
  const hpBar = E.label('', { w: 3, h: 0.5, bg: 'rgba(0,0,0,0)', fg: '#d93a3f', size: 34 });
  hpBar.position.set(12.6, 4.2, -1); scene.add(hpBar); billboards.push(hpBar);
  function drawHp() { hpBar.userData.setText('❤'.repeat(Math.max(0, hp)) + '♡'.repeat(Math.max(0, maxHp - hp)), { fg: '#d93a3f' }); }

  function spawnEnemy() {
    if (enemy) scene.remove(enemy);
    const it = G.item(), boss = (G.idx + 1) % (G.config.enemies_per_wave || 5) === 0;
    enemy = monster(E, boss ? C.red : [C.purple, 0x6c3fc9, 0x8b4fd8][G.idx % 3], boss ? 1.5 : 1);
    const tag = E.label('?', { w: 0.8, h: 0.8, bg: '#ffffff', fg: '#6c3fc9', radius: 40, size: 70 }); tag.position.y = boss ? 2.6 : 1.9; enemy.add(tag); enemy.userData.tag = tag;
    scene.add(enemy); dist = 0;
    const base = G.config.question_seconds || (document.documentElement.getAttribute('data-stage') === 'tieu_hoc' ? 22 : 16);
    travel = Math.max(9, base - Math.min(5, G.streak * 0.6));
    phase = 'run'; t0 = Date.now();
    G.showQuestion(it, { instruction: 'Chọn đáp án đúng để tháp bắn hạ quái', onPick: answer, onOrder: order => answerResp({ order }, null) });
  }
  function answer(i) { answerResp({ choice: i }, i); }
  function answerResp(resp, chosen) {
    if (phase !== 'run') return;
    phase = 'wait';
    G.answer(resp, Date.now() - t0).then(fb => { G.markPanel(fb, chosen); resolve(fb.is_correct); }).catch(() => { phase = 'run'; });
  }
  function resolve(ok) {
    if (ok) {
      killed++;
      const slot = (killed - 1) % pads.length, pad = pads[slot];
      if (!pad.tower) {
        pad.tower = tower(E, TYPES[slot][1]); pad.tower.position.set(pad.x, 0.25, pad.z); pad.tower.scale.setScalar(0.01); scene.add(pad.tower);
        E.tween(pad.tower.scale, { x: 1, y: 1, z: 1 }, 450, 'back');
      } else if (pad.level < 3) { pad.level++; E.tween(pad.tower.scale, { y: 1 + pad.level * 0.25 }, 350, 'back'); }
      // bắn từ mọi tháp đã có (tháp vừa trả lời bắn trước)
      const target = enemy.position.clone().setY(1);
      pads.filter(p => p.tower).forEach((p, k) => {
        const from = p.tower.position.clone().setY(2.9 * p.tower.scale.y);
        const ball = E.mesh(new THREE.SphereGeometry(0.22, 8, 6), TYPES[pads.indexOf(p)][1], { emissive: 0x333333, unique: true });
        ball.position.copy(from); scene.add(ball);
        shots.push({ ball, from, to: target, t: -k * 0.08, main: p === pad });
      });
      phase = 'shooting';
      setTimeout(next, 1500);
    } else {
      phase = 'march';
    }
  }
  function next() {
    if (hp <= 0) return G.finish('Thành đã bị phá! Ôn lại ngữ pháp rồi thử lần nữa nhé.');
    if (!G.next()) return G.finish('Bảo vệ thành thành công!');
    spawnEnemy();
  }
  function enemyArrives() {
    if (phase === 'run') { // hết thời gian mà chưa trả lời → tính là sai
      phase = 'wait';
      G.answer({ choice: -1 }, Date.now() - t0).then(fb => G.markPanel(fb, -1)).catch(() => {});
    }
    hp--; drawHp(); E.shake(0.5, 400); E.burst(home.position.clone().setY(2), C.red, 30, 7);
    scene.remove(enemy); enemy = null; phase = 'hit';
    setTimeout(next, 2400);
  }

  E.onFrame((dt, t) => {
    spawn.rotation.x += dt * 1.5;
    home.userData.flag.rotation.y = Math.sin(t * 4) * 0.3;
    if (enemy) {
      if (phase === 'run') dist += LEN / travel * dt;
      else if (phase === 'march') dist += LEN / 2.2 * dt;
      if (phase === 'run' || phase === 'march' || phase === 'wait') {
        const k = Math.min(1, dist / LEN), p = curve.getPointAt(k), tan = curve.getTangentAt(k);
        enemy.position.copy(p); enemy.rotation.y = Math.atan2(tan.x, tan.z);
        enemy.userData.body.position.y = 0.6 + Math.abs(Math.sin(t * 8)) * 0.12;
        enemy.userData.tag.lookAt(camera.position);
        if (k >= 0.985 && phase !== 'wait') enemyArrives();
        else if (k >= 0.985 && phase === 'wait') { /* chờ máy chủ */ }
      }
    }
    for (let i = shots.length - 1; i >= 0; i--) {
      const s = shots[i]; s.t += dt * 1.6;
      if (s.t < 0) continue;
      const k = Math.min(1, s.t);
      s.ball.position.lerpVectors(s.from, s.to, k); s.ball.position.y += Math.sin(k * Math.PI) * 3;
      if (k >= 1) {
        const col = s.ball.material.color.getHex();
        scene.remove(s.ball); s.ball.geometry.dispose(); s.ball.material.dispose(); shots.splice(i, 1);
        E.burst(s.to, col, 12, 5);
        if (s.main && enemy) { const e = enemy; enemy = null; E.tween(e.scale, { x: 0.01, y: 0.01, z: 0.01 }, 300, 'out', () => scene.remove(e)); E.burst(s.to, C.gold, 30, 7); }
      }
    }
    pads.forEach(p => { if (p.tower) p.tower.userData.orb.position.y = 2.75 + Math.sin(t * 3 + p.x) * 0.1; });
    if (G) G.hud(`<span>🏰 ${Math.max(0, hp)}/${maxHp}</span><span>Đợt ${Math.floor(G.idx / (G.config.enemies_per_wave || 5)) + 1} · 🔥 ${G.streak}</span>`);
  });

  E.onResize(E.size.w, E.size.h);
  fontsReady().then(() => { drawHp(); E.start(); });
  window.ChieGame = {
    is3D: true,
    start(game) { G = game; maxHp = hp = G.config.castle_hp || 5; drawHp(); spawnEnemy(); },
  };
}
