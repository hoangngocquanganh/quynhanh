/* Word Runner 3D — Bé Mầm chạy trên đường làng, lao vào cổng có đáp án đúng.
   Máy chủ chấm từng câu (G.answer); 3D chỉ là phần hình ảnh. */
import { THREE, createEngine, use3D, fontsReady } from './engine.js';
import { C, mascot, animateMascot, forest, gate, monster, rock } from './models.js';

if (use3D()) boot();

function boot() {
  const stage = document.getElementById('g-stage');
  const E = createEngine(stage, { sky: 0xbfe7ff, fogNear: 35, fogFar: 95, label: 'Đường chạy Word Runner 3D', reduceMotion: document.documentElement.getAttribute('data-motion') === 'reduce' });
  const { scene, camera } = E;
  const LANE_W = 2.3, START_Z = -78, HIT_Z = -0.6;

  // ---------- cảnh ----------
  const ground = E.mesh(new THREE.PlaneGeometry(220, 220).rotateX(-Math.PI / 2), C.grass, { receive: true, cast: false });
  ground.position.z = -60; scene.add(ground);
  const road = E.mesh(new THREE.PlaneGeometry(1, 220).rotateX(-Math.PI / 2), 0xe9d7b4, { receive: true, cast: false });
  road.position.set(0, 0.01, -60); scene.add(road);
  const edgeG = new THREE.BoxGeometry(0.25, 0.12, 220);
  const edgeL = E.mesh(edgeG, 0xd2b98d, { cast: false }), edgeR = E.mesh(edgeG, 0xd2b98d, { cast: false });
  edgeL.position.set(0, 0.06, -60); edgeR.position.set(0, 0.06, -60); scene.add(edgeL, edgeR);

  // vạch chia làn (instanced, trôi về phía người chơi)
  const DASH = 26, dashGeo = new THREE.BoxGeometry(0.12, 0.03, 1.4);
  let dashes = new THREE.InstancedMesh(dashGeo, E.mat(0xffffff, { flat: true }), DASH * 3);
  scene.add(dashes);
  let lanes = 3, dashOff = 0;
  const M4 = new THREE.Matrix4();
  function layoutRoad() {
    const w = lanes * LANE_W + 0.6;
    road.scale.x = w; edgeL.position.x = -w / 2; edgeR.position.x = w / 2;
  }
  function drawDashes() {
    let k = 0;
    for (let l = 1; l < lanes; l++) for (let i = 0; i < DASH; i++) {
      M4.makeTranslation(-lanes * LANE_W / 2 + l * LANE_W, 0.03, -i * 4 + (dashOff % 4) + 6);
      dashes.setMatrixAt(k++, M4);
    }
    dashes.count = k; dashes.instanceMatrix.needsUpdate = true;
  }

  // cây hai bên đường, tái sử dụng khi trôi qua camera
  const TREES = E.tier === 'low' ? 24 : 44;
  const treeData = [];
  for (let i = 0; i < TREES; i++) {
    const side = i % 2 ? 1 : -1;
    treeData.push({ x: side * (6 + Math.random() * 14), z: -i * (110 / TREES) + 8, s: 0.8 + Math.random() * 0.9, r: Math.random() * 6 });
  }
  const trees = forest(E, treeData); scene.add(trees);
  const rocks = [];
  for (let i = 0; i < 8; i++) { const r = rock(E, 0.6 + Math.random()); r.position.set((i % 2 ? 1 : -1) * (5 + Math.random() * 3), 0.2, -i * 13); scene.add(r); rocks.push(r); }
  // mây
  const cloudG = new THREE.IcosahedronGeometry(1.4, 0);
  const clouds = new THREE.InstancedMesh(cloudG, E.mat(0xffffff, { flat: true }), 18); const cloudPos = [];
  for (let i = 0; i < 6; i++) { const cx = -30 + i * 12, cy = 14 + Math.random() * 6, cz = -70 - Math.random() * 20; for (let k = 0; k < 3; k++) cloudPos.push([cx + k * 1.6, cy + (k === 1 ? 0.6 : 0), cz]); }
  cloudPos.forEach((p, i) => { M4.makeScale(1.4, 0.8, 1); M4.setPosition(p[0], p[1], p[2]); clouds.setMatrixAt(i, M4); });
  scene.add(clouds);

  const hero = mascot(E, 0.9); scene.add(hero);
  camera.position.set(0, 4.3, 7.8); camera.lookAt(0, 1.2, -7);
  E.onResize = (w, h) => { const narrow = w / h < 1.2; camera.position.set(0, narrow ? 5.4 : 4.3, narrow ? 9.5 : 7.8); camera.fov = narrow ? 62 : 55; camera.updateProjectionMatrix(); camera.lookAt(0, 1.2, -7); };
  E.onResize(E.size.w, E.size.h);

  // ---------- trạng thái ----------
  let G = null, phase = 'idle', lane = 1, gateObj = null, travel = 9, rush = false, hearts = 3, t0 = 0, speedLook = 8;
  let boss = null, heroY = 0, heroVy = 0;
  const laneX = i => -lanes * LANE_W / 2 + LANE_W * (i + 0.5);

  function setLane(i) {
    if (phase !== 'run') return;
    lane = Math.max(0, Math.min(lanes - 1, i));
    E.tween(hero.position, { x: laneX(lane) }, 160, 'out');
    E.tween(hero.rotation, { z: 0 }, 160, 'out');
  }

  function clearGate() {
    if (!gateObj) return;
    scene.remove(gateObj);
    gateObj.traverse(o => { if (o.userData && o.userData.isLabel) { o.material.map.dispose(); o.material.dispose(); o.geometry.dispose(); } });
    gateObj = null;
  }

  function newGate() {
    clearGate();
    const it = G.item(), opts = it.display.options || [];
    lanes = Math.max(2, Math.min(4, opts.length));
    lane = Math.min(lane, lanes - 1);
    layoutRoad(); hero.position.x = laneX(lane);
    gateObj = new THREE.Group();
    gateObj.userData.labels = [];
    for (let i = 0; i < lanes; i++) {
      const g = gate(E, LANE_W * 0.92); g.position.x = laneX(i); gateObj.add(g);
      const lbl = E.label(opts[i] || '', { w: LANE_W * 0.96, h: 1.35, bg: '#2E5BE6', fg: '#ffffff', border: '#ffffff' });
      lbl.position.set(laneX(i), 2.45, 0); lbl.userData.isLabel = true; lbl.userData.lane = i;
      gateObj.add(lbl); gateObj.userData.labels.push(lbl);
    }
    gateObj.position.z = START_Z;
    scene.add(gateObj);
    const per = G.config.boss_every || 5;
    if (boss) { scene.remove(boss); boss = null; }
    if ((G.idx + 1) % per === 0) { boss = monster(E, C.purple, 2.2); boss.position.set(0, 0, START_Z - 4); scene.add(boss); }
    // thời gian cổng chạy tới: theo cấu hình, nhanh dần khi trả lời đúng liên tiếp (tối thiểu 5 giây)
    const base = G.config.question_seconds || (document.documentElement.getAttribute('data-stage') === 'tieu_hoc' ? 12 : 9);
    travel = Math.max(5, base - Math.min(3, G.streak * 0.4));
    rush = false; phase = 'run'; t0 = Date.now();
    G.showQuestion(it, { instruction: 'Chạy vào cổng đúng', onPick: i => { setLane(i); rush = true; document.querySelectorAll('#g-panel [data-gi]').forEach(b => b.classList.toggle('is-picked', +b.getAttribute('data-gi') === i)); } });
    if (it.type === 'listen_mcq' || (it.prompt && it.prompt.speak_word)) setTimeout(() => G.speakItem(it), 300);
  }

  function hit() {
    phase = 'wait';
    const chosen = lane;
    G.answer({ choice: chosen }, Date.now() - t0).then(fb => {
      G.markPanel(fb, chosen);
      gateObj.userData.labels.forEach((l, i) => {
        if (i === fb.correct_index) l.userData.setText((G.item().display.options || [])[i], { bg: '#17955A' });
        else if (i === chosen) l.userData.setText((G.item().display.options || [])[i], { bg: '#D93A3F' });
        else l.userData.setText((G.item().display.options || [])[i], { bg: '#8A93A8' });
      });
      const p = new THREE.Vector3(hero.position.x, 1.6, 0);
      if (fb.is_correct) {
        E.burst(p, C.gold, 26, 6); heroVy = 6.5;
        if (boss) { E.tween(boss.scale, { x: 0.01, y: 0.01, z: 0.01 }, 500, 'back'); E.burst(boss.position.clone().setY(2), C.purple, 30, 8); }
      } else {
        hearts--; E.shake(0.35, 300); E.burst(p, C.red, 14, 3);
        E.tween(hero.rotation, { z: 0.6 }, 140, 'out', () => E.tween(hero.rotation, { z: 0 }, 300, 'bounce'));
      }
      phase = 'result';
      setTimeout(() => {
        if (hearts <= 0) return G.finish('Hết tim rồi! Bạn đã cố gắng rất tốt.');
        if (!G.next()) return G.finish('Về đích!');
        newGate();
      }, fb.is_correct ? 1200 : 2600);
    }).catch(() => { phase = 'run'; gateObj.position.z = -8; });
  }

  // ---------- vòng lặp ----------
  E.onFrame((dt, t) => {
    const moving = phase === 'run' || phase === 'idle';
    let v = phase === 'idle' ? 6 : (moving ? (-START_Z / travel) * (rush ? 9 : 1) : 2);
    if (E.reduce && phase === 'idle') v = 2;
    speedLook += (v - speedLook) * Math.min(1, dt * 3);
    const dz = speedLook * dt;
    dashOff += dz; drawDashes();
    // cây/đá trôi
    treeData.forEach((p, i) => { p.z += dz; if (p.z > 12) p.z -= 120; trees.userData.set(i, p); });
    trees.userData.commit();
    rocks.forEach(r => { r.position.z += dz; if (r.position.z > 12) r.position.z -= 104; });
    if (gateObj && phase === 'run') {
      gateObj.position.z += (-START_Z / travel) * (rush ? 9 : 1) * dt;
      if (boss) boss.position.z = gateObj.position.z - 4;
      // nhãn nghiêng nhẹ về phía camera để dễ đọc
      if (gateObj.position.z >= HIT_Z) { gateObj.position.z = HIT_Z; hit(); }
    }
    if (boss) { boss.rotation.y = Math.sin(t * 2) * 0.3; boss.userData.body.position.y = 0.6 + Math.abs(Math.sin(t * 4)) * 0.2; }
    // nhảy
    heroVy -= 18 * dt; heroY = Math.max(0, heroY + heroVy * dt); if (heroY === 0) heroVy = 0;
    hero.position.y = heroY;
    animateMascot(hero, t, speedLook / 10, phase !== 'result' || heroY > 0);
    if (G) G.hud(`<span>${'❤️'.repeat(Math.max(0, hearts))}</span><span>${boss ? '👾 Boss! ' : ''}🔥 ${G.streak}</span>`);
  });

  // ---------- điều khiển ----------
  document.addEventListener('keydown', e => {
    if (e.target.matches('input,textarea')) return;
    if (e.key === 'ArrowLeft') { setLane(lane - 1); e.preventDefault(); }
    if (e.key === 'ArrowRight') { setLane(lane + 1); e.preventDefault(); }
    if (e.key === 'ArrowUp' || e.key === ' ') { if (phase === 'run') { rush = true; e.preventDefault(); } }
  });
  let sx = null, sy = null;
  E.canvas.addEventListener('pointerdown', e => { sx = e.clientX; sy = e.clientY; });
  E.canvas.addEventListener('pointerup', e => {
    if (sx === null || phase !== 'run') return;
    const dx = e.clientX - sx, dy = e.clientY - sy; sx = null;
    if (Math.abs(dx) > 30 && Math.abs(dx) > Math.abs(dy)) return setLane(lane + (dx > 0 ? 1 : -1));
    if (dy < -40) { rush = true; return; }
    // chạm vào biển đáp án → chọn làn đó
    const h = gateObj && E.pick(e, gateObj.userData.labels);
    if (h) { setLane(h.object.userData.lane); rush = true; return; }
    const r = E.canvas.getBoundingClientRect(), rel = (e.clientX - r.left) / r.width;
    if (rel < 0.33) setLane(lane - 1); else if (rel > 0.67) setLane(lane + 1);
  });

  layoutRoad(); drawDashes();
  fontsReady().then(() => E.start());

  window.ChieGame = {
    is3D: true,
    start(game) {
      G = game; hearts = G.config.hearts || 3;
      newGate();
    },
  };
}
