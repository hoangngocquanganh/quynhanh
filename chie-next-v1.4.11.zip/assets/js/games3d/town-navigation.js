/* Grid pathfinding is cosmetic only; inventories/timers/rewards stay server-owned. */
export function createNavigation(obstacles, bounds=25) {
  const blocked=(x,z)=> Math.abs(x)>bounds || Math.abs(z)>bounds || obstacles.some(o=>x>o.x-o.w/2-.38&&x<o.x+o.w/2+.38&&z>o.z-o.d/2-.38&&z<o.z+o.d/2+.38);
  function route(from,to) {
    const start=[Math.round(from.x),Math.round(from.z)], goal=[Math.round(to.x),Math.round(to.z)], key=(x,z)=>`${x},${z}`;
    if(blocked(...goal))return [];
    const queue=[start],prev=new Map([[key(...start),null]]);let end=null;
    for(let i=0;i<queue.length&&i<11000;i++) {
      const [x,z]=queue[i];if(x===goal[0]&&z===goal[1]){end=[x,z];break;}
      for(const [dx,dz] of [[1,0],[-1,0],[0,1],[0,-1]]) {const a=x+dx,b=z+dz,k=key(a,b);if(!prev.has(k)&&!blocked(a,b)){prev.set(k,[x,z]);queue.push([a,b]);}}
    }
    if(!end)return [];
    const path=[];for(let c=end;prev.get(key(...c));c=prev.get(key(...c)))path.unshift({x:c[0],z:c[1]});
    return path;
  }
  return {blocked,route};
}
