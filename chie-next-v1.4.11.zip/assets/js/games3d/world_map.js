/* Bản đồ 3D Vương Quốc CHIE: mỗi màn là một hòn đảo nổi; đã qua có cờ vàng + sao, đang mở thì sáng, chưa mở thì xám.
   Chạm đảo đang mở = bấm nút "Vào màn" tương ứng (máy chủ vẫn kiểm tra quyền mở màn). */
import { THREE, createEngine, use3D, fontsReady } from './engine.js';
import { C, island, mascot, animateMascot, forest, water, castle, monster } from './models.js';

const box = document.getElementById('world3d');
if (box && use3D()) boot();

function boot() {
  box.hidden = false;
  const levels = JSON.parse(box.getAttribute('data-levels') || '[]');
  const E = createEngine(box, { sky: 0x9fd8f5, fogNear: 25, fogFar: 60, aspect: 16 / 7, mobileAspect: 4 / 3, label: 'Bản đồ Vương Quốc CHIE' });
  const { scene, camera } = E;
  const sea = water(E, 160, E.tier === 'low' ? 12 : 24, 0x4cb3e0); sea.position.y = -0.6; scene.add(sea);
  const STEP = 4.2;
  const nodes = levels.map((lv, i) => {
    const x = i * STEP, z = Math.sin(i * 0.9) * 2.4;
    const color = lv.passed ? C.grass : lv.open ? 0x9be27e : 0xa9b1bf;
    const isl = island(E, 1.5, color); isl.position.set(x, 0, z); isl.scale.setScalar(lv.mode === 'boss' ? 1.35 : 1);
    isl.userData.levelId = lv.id; scene.add(isl);
    if (lv.mode === 'boss') { const c = castle(E); c.scale.setScalar(0.55); c.position.set(0, 0.5, 0); isl.add(c); }
    else if (i % 3 === 1) { const f = forest(E, [{ x: -0.7, z: -0.4, s: 0.55 }, { x: 0.6, z: -0.6, s: 0.45 }]); f.position.y = 0.5; isl.add(f); }
    if (lv.passed) {
      const pole = E.mesh(new THREE.CylinderGeometry(0.04, 0.04, 1.2, 5), C.ink); pole.position.set(0.7, 1.1, 0.4); isl.add(pole);
      const flag = E.mesh(new THREE.PlaneGeometry(0.5, 0.32), C.gold, { unique: true }); flag.material.side = THREE.DoubleSide; flag.position.set(0.95, 1.55, 0.4); isl.add(flag);
    }
    const lbl = E.label((i + 1) + '. ' + lv.title + (lv.stars ? ' ' + '★'.repeat(lv.stars) : ''), { w: 3.4, h: 0.9, bg: lv.open ? 'rgba(255,255,255,.95)' : 'rgba(220,224,232,.9)', fg: '#1c2333' });
    lbl.position.set(x, lv.mode === 'boss' ? 3.4 : 2.4, z); scene.add(lbl);
    if (!lv.open) { const lock = E.label('🔒', { w: 0.6, h: 0.6, size: 60 }); lock.position.set(x, 1.3, z + 0.3); scene.add(lock); }
    return { lv, isl, lbl, x, z };
  });
  // cầu nối giữa các đảo
  for (let i = 0; i + 1 < nodes.length; i++) {
    const a = nodes[i], b = nodes[i + 1], dx = b.x - a.x, dz = b.z - a.z, len = Math.hypot(dx, dz) - 2.6;
    const br = E.mesh(new THREE.BoxGeometry(len, 0.1, 0.5), nodes[i].lv.passed ? C.wood : 0x9aa3b5, { receive: true }); br.position.set((a.x + b.x) / 2, 0.42, (a.z + b.z) / 2); br.rotation.y = -Math.atan2(dz, dx); scene.add(br);
  }
  const cur = nodes.findIndex(n => n.lv.open && !n.lv.passed);
  const at = nodes[cur >= 0 ? cur : Math.max(0, nodes.length - 1)];
  const hero = mascot(E, 0.6); hero.position.set(at.x, 0.5, at.z + 0.6); scene.add(hero);
  const boss = nodes.find(n => n.lv.mode === 'boss');
  if (boss && !boss.lv.passed) { const m = monster(E, C.red, 0.8); m.position.set(0.4, 1.35, -0.2); boss.isl.add(m); }

  let camX = at.x, targetX = at.x;
  const maxX = Math.max(0, (nodes.length - 1) * STEP);
  function placeCam() { const narrow = E.size.w / E.size.h < 1.6; camera.position.set(camX, narrow ? 5.6 : 6, narrow ? 7.2 : 8.5); camera.lookAt(camX, 0.8, 0); }
  E.onResize = () => placeCam();
  E.onFrame((dt, t) => {
    sea.userData.wave(t);
    camX += (targetX - camX) * Math.min(1, dt * 5); placeCam();
    nodes.forEach((n, i) => { n.isl.position.y = Math.sin(t * 1.2 + i) * 0.12; n.lbl.position.y = (n.lv.mode === 'boss' ? 3.4 : 2.4) + n.isl.position.y; n.lbl.quaternion.copy(camera.quaternion); });
    hero.position.y = 0.5 + at.isl.position.y; animateMascot(hero, t, 0.4, false);
  });
  // kéo ngang để xem; chạm đảo để vào màn
  let down = null, moved = false;
  E.canvas.addEventListener('pointerdown', e => { down = { x: e.clientX, cam: targetX }; moved = false; });
  E.canvas.addEventListener('pointermove', e => {
    if (!down) return; const dx = e.clientX - down.x; if (Math.abs(dx) > 6) moved = true;
    targetX = Math.max(0, Math.min(maxX, down.cam - dx / E.size.w * 14));
  });
  E.canvas.addEventListener('pointerup', e => {
    const wasDrag = moved; down = null; if (wasDrag) return;
    const h = E.pick(e, nodes.map(n => n.isl)); if (!h) return;
    let o = h.object; while (o && o.userData.levelId === undefined) o = o.parent;
    const n = o && nodes.find(x => x.isl === o); if (!n) return;
    targetX = n.x;
    const btn = document.querySelector('[data-level="' + n.lv.id + '"]');
    if (btn) btn.click(); else window.CHIE.toast('Màn này chưa mở — hãy vượt màn trước.', '', 3000);
  });
  E.canvas.addEventListener('pointerleave', () => { down = null; });
  fontsReady().then(() => E.start());
}
