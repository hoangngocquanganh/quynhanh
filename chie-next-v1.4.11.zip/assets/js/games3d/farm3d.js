/* Mầm Xanh town: original explorable scene; all economic mutations use existing authenticated farm APIs. */
import { THREE, createEngine, use3D, fontsReady } from './engine.js?v=town-1.2.0';
import { forest, plotTile, crop, animal, fence } from './models.js?v=town-1.2.0';
import { townModels } from './town-models.js?v=town-1.2.0';
import { createNavigation } from './town-navigation.js?v=town-1.2.0';
const box=document.getElementById('farm3d'),root=document.getElementById('farm');
async function boot(){
 await fontsReady();box.hidden=false;
 const E=createEngine(box,{sky:0xc4dfd5,fogNear:38,fogFar:85,fillHeight:true,label:'Thị trấn Mầm Xanh. Dùng phím WASD hoặc mũi tên để đi, E để tương tác.',reduceMotion:matchMedia('(prefers-reduced-motion: reduce)').matches||document.documentElement.dataset.motion==='reduce'});
 root.classList.add('has-3d');
 const {scene,camera}=E,M=townModels(E),V=(x=0,y=0,z=0)=>new THREE.Vector3(x,y,z);
 const esc=window.CHIE.esc;
 box.insertAdjacentHTML('beforeend',`<div class="town-top"><div class="town-brand"><small>CHIE • LITTLE WORLD</small><strong>Thị trấn Mầm Xanh</strong></div><div class="town-purse"><span>✦</span><div><b id="town-coins"></b><small id="town-level"></small></div></div></div>
 <div class="town-status" id="town-status">● Đã kết nối · Nông trại của bạn</div>
 <aside class="town-quest"><small>MỘT NGÀY THẢNH THƠI</small><b>Vườn nhỏ, niềm vui lớn</b><div id="town-goals"></div><button id="town-journal">Mở sổ tay →</button></aside>
 <div class="town-controls"><button data-town="map" aria-label="Bản đồ thị trấn" title="Bản đồ">⌖</button><button data-town="rotate" aria-label="Xoay góc nhìn" title="Xoay góc nhìn">↻</button><button data-town="zoom-in" aria-label="Phóng to">+</button><button data-town="zoom-out" aria-label="Thu nhỏ">−</button><button data-town="expand" aria-label="Mở rộng màn chơi" title="Toàn màn hình">⛶</button><button data-town="help" aria-label="Hướng dẫn">?</button></div>
 <div class="town-tip" id="town-tip">Chạm đường để đi · Chạm cây hoặc cửa hàng để tương tác</div><div class="town-toast" id="town-toast" role="status" aria-live="polite"></div>
 <div class="town-stick" id="town-stick" role="group" aria-label="Cần điều khiển cảm ứng; dùng bàn phím hoặc chạm đường cũng được"><i></i></div>
 <button class="town-interact" id="town-interact" disabled><span>✋</span><b>Tương tác</b></button>
 <nav class="town-dock" aria-label="Chức năng thị trấn"><button data-town="garden" class="active"><span>🌱</span>Vườn nhà</button><button data-town="market"><span>🧺</span>Kho & chợ</button><button data-town="animals"><span>🐔</span>Vật nuôi</button><button data-town="cook"><span>🍳</span>Bếp nhỏ</button><button data-town="wardrobe"><span>👒</span>Nhân vật</button><button data-town="journal"><span>📖</span>Sổ tay</button></nav>
 <section class="town-panel" id="town-panel" role="dialog" aria-label="Thông tin thị trấn" hidden><header class="town-panel-head"><h2 id="town-panel-title"></h2><button id="town-close" aria-label="Đóng bảng">×</button></header><div id="town-panel-body"></div></section>`);
 const $=id=>document.getElementById(id),panel=$('town-panel'),panelBody=$('town-panel-body');
 let moved=null,placeholder=null,returnFocus=null,toastTimer;
 function say(text){$('town-toast').textContent=text;clearTimeout(toastTimer);toastTimer=setTimeout(()=>$('town-toast').textContent='',4500);}
 function closePanel(){if(moved){placeholder.replaceWith(moved);moved=null;placeholder=null;}panel.hidden=true;panelBody.replaceChildren();returnFocus?.focus({preventScroll:true});}
 function openPanel(title,html,section){closePanel();path=[];pending=null;stick.set(0,0);keys.clear();returnFocus=document.activeElement;$('town-panel-title').textContent=title;panel.hidden=false;
   if(section){moved=section;placeholder=document.createComment('town-panel-origin');section.replaceWith(placeholder);panelBody.append(section);}else panelBody.innerHTML=html;
   $('town-close').focus({preventScroll:true});
 }
 $('town-close').onclick=closePanel;
 panel.addEventListener('keydown',e=>{if(e.key!=='Tab')return;const items=[...panel.querySelectorAll('button:not(:disabled),a[href],input,select,textarea,summary,[tabindex="0"]')];const first=items[0],last=items.at(-1);if(e.shiftKey&&document.activeElement===first){e.preventDefault();last.focus();}else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first.focus();}});
 const sections={market:$('f-storage').closest('section'),animals:$('f-animals').closest('section'),cook:$('f-recipes').closest('section'),upgrades:$('f-buy').closest('section'),plots:$('f-plots').closest('section')};
 let S=window.ChieFarm.state();
 const ground=E.mesh(new THREE.BoxGeometry(56,1,56),0x9fbe77,{receive:true,cast:false});ground.position.y=-.55;scene.add(ground);
 // Broad sand paths link the square, homes, plots and ranch.
 M.block(scene,0xe4d4b1,0,-.015,4,49,.12,3.8);M.block(scene,0xe4d4b1,3,-.01,-7,3.8,.13,24);M.block(scene,0xebddbd,-5,-.005,5,12,.14,10);
 for(let i=0;i<20;i++)M.block(scene,0xd4c3a2,-23+i*2.4,.06,2.15,1.9,.08,.13);
 const obstacles=[],targets=[],labels=[],wanderers=[],plotObjects=new Map(),animalObjects=new Map();
 function place(obj,x,z){obj.position.set(x,0,z);scene.add(obj);return obj;}
 function obstacle(x,z,w,d){obstacles.push({x,z,w,d});}
 function sign(text,x,y,z,w=3){const l=E.label(text,{w,h:.65,bg:'#fffdf0',fg:'#526b50',size:33,depthWrite:false});l.position.set(x,y,z);scene.add(l);labels.push(l);return l;}
 function destination(obj,x,z,name,act){obj.userData.interaction={name,act,point:V(x,0,z)};targets.push(obj);}
 function home(x,z,color,roof,name,action,w=4,d=3){const h=place(M.house(color,roof,w,d),x,z);obstacle(x,z,w+.6,d+.6);sign(name,x,4.7,z,w+1);destination(h,x,z+d/2+1.5,name,action);return h;}
 home(-18,-11,0xf3e5c8,0x879b7d,'NHÀ CỦA BẠN',()=>show('wardrobe'),5,4);
 home(-9,-13,0xf0d3b5,0xcd967b,'TIỆM HẠT GIỐNG',()=>show('seeds'),4,3.5);
 home(8,-14,0xe9c4ab,0xa07670,'BẾP NHỎ',()=>show('cook'),4,4);
 home(18,-12,0xefdfa9,0x83a29a,'KHO & NÂNG CẤP',()=>show('upgrades'),4,4);
 const shop=place(M.stall(),-12,-3);obstacle(-12,-3,3.5,2);sign('CHỢ MẦM XANH',-12,3.6,-3,4);destination(shop,-12,0,'Ghé chợ',()=>show('market'));
 const shop2=place(M.stall(),-18,-3);obstacle(-18,-3,3.5,2);destination(shop2,-18,0,'Hạt giống',()=>show('seeds'));
 // Pond, little bridge and flowers.
 M.part(scene,new THREE.CylinderGeometry(1,1,1,40),0xdcc9a0,-17,-.03,15,7,.2,5.5);
 const water=M.part(scene,new THREE.CylinderGeometry(1,1,1,40),0x78b9b4,-17,.06,15,6.3,.1,4.8);obstacle(-17,15,12.5,9.5);
 for(let i=0;i<11;i++)M.block(scene,0xba956c,-17+i*.65,.35,9.6,.58,.25,2.5);
 for(let i=0;i<6;i++){M.orb(scene,0x7b9d58,-20+i*.8,.16,15+Math.sin(i)*2,.4,.04,.3);M.orb(scene,0xf0c4c9,-20+i*.8,.22,15+Math.sin(i)*2,.15,.12,.15);}
 // A tiled fountain square.
 M.part(scene,new THREE.CylinderGeometry(2.2,2.4,.35,24),0xc1bda2,-4,.2,5,1,1,1);obstacle(-4,5,4.8,4.8);
 M.part(scene,new THREE.CylinderGeometry(1.95,1.95,.12,24),0x87c3c1,-4,.4,5,1,1,1);
 M.part(scene,new THREE.CylinderGeometry(.3,.5,1.5,12),0xdad3b8,-4,1.1,5,1,1,1);
 M.part(scene,new THREE.CylinderGeometry(1,1.15,.2,16),0xe5dfc4,-4,1.85,5,1,1,1);
 M.orb(scene,0x9acdc5,-4,2.15,5,.18,.5,.18);
 for(const [x,z,r] of [[-8,8,0],[0,8,0],[-8,1,Math.PI],[0,1,Math.PI]]){const b=place(M.bench(),x,z);b.rotation.y=r;obstacle(x,z,2,1);}
 for(const [x,z] of [[-21,2],[-9,2],[7,2],[20,2],[1,-10],[5,15]])place(M.lamp(),x,z);
 // Ranch entrance is open so the player can reach animals.
 [[17,-4,0,9],[21.5,-.5,Math.PI/2,7],[12.5,-.5,Math.PI/2,7]].forEach(([x,z,r,len])=>{const f=place(fence(E,len),x,z);f.rotation.y=r;obstacle(x,z,r? .22:len,r?len:.22);});
 M.block(scene,0xb0c98b,17,-.01,-.5,9,.12,7);sign('CHUỒNG NHỎ',17,3,-3,4);
 const ranch=place(M.bench(),22,5);destination(ranch,21,5,'Vật nuôi',()=>show('animals'));
 // Forest is instanced; decorative details reuse geometries.
 const trees=[];for(let i=0;i<55;i++){let x,z;if(i<28){x=-26+i*1.9;z=-23+(i%3);}else{x=i%2?-26:26;z=-19+(i-28)*1.6;}trees.push({x,z,s:1.6+(i%4)*.2});}
 scene.add(forest(E,trees,[0x6f9e6d,0x80ab76,0x94b780]));
 for(const [x,z] of [[-23,0],[-23,-9],[11,8],[22,13],[5,19],[-6,20]]){scene.add(forest(E,[{x,z,s:1.5}]));obstacle(x,z,1,1);}
 // Flowerbeds and path stones.
 for(let i=0;i<32;i++){const x=7+(i%8)*1.65,z=18+Math.floor(i/8)*.55;M.orb(scene,0x6f9c60,x,.22,z,.25,.35,.25);M.orb(scene,[0xe9b0ab,0xf2d785,0xd7b1d4][i%3],x,.55,z,.16);}
 for(let i=0;i<12;i++)M.block(scene,0xe2d8bc,-18,.03,-8+i*.65,1,.08,.42);
 const clouds=[];for(let i=0;i<4;i++){const g=new THREE.Group();for(let j=0;j<3;j++)M.orb(g,0xf4f4df,j*1.4,0,0,1.8,1,1);g.position.set(-20+i*13,13+(i%2)*2,-22);scene.add(g);clouds.push(g);}
 // NPCs are explicitly local town characters, not fabricated online players.
 const npc=place(M.person(0xd59f8d,0xf1d395),-11,1);sign('Cô Mây · cư dân',-11,2.8,1,3.5);destination(npc,-10,1,'Trò chuyện với cô Mây',()=>show('letter'));
 for(const [x,z,c] of [[5,5,0x98a4bf],[-20,4,0xc0a0b6],[9,5,0xe3bf78]]){const n=place(M.person(c),x,z);wanderers.push({m:n,x,z});destination(n,x,z+1,'Chào người hàng xóm',()=>say('Hello, neighbour! · Chào người hàng xóm!'));}
 const player=place(M.person(),3,8);let shirt=0x7d9ead;try{const saved=JSON.parse(localStorage.getItem('chie-town-look')||'null');if(saved&&[0x7d9ead,0xc690a8,0x82a883,0xd8ac66].includes(saved.shirt))shirt=saved.shirt;}catch{}
 player.userData.torso.material=E.mat(shirt);
 const marker=E.mesh(new THREE.RingGeometry(.35,.48,24),0xfff1a4,{cast:false});marker.rotation.x=-Math.PI/2;marker.position.y=.13;marker.visible=false;scene.add(marker);
 const nav=createNavigation(obstacles,25),keys=new Set(),stick=new THREE.Vector2();let path=[],pending=null,near=null,angle=0,zoom=19,walkTime=0,lastMap=0,lastActionLabel='';
 E.canvas.tabIndex=0;
 const look=V(0,0,3),camTarget=V(),delta=V(),dir=V(),aim=V();
 function go(point,action){path=nav.route(player.position,point);pending=action||null;marker.position.set(point.x,.13,point.z);marker.visible=path.length>0;if(!path.length){if(player.position.distanceTo(point)<2.2){pending?.();pending=null;}else{pending=null;say('Chọn lối đi thoáng để đến gần hơn nhé.');}}}
 function section(name,title){openPanel(title,'',sections[name]);}
 function show(name){
   if(name==='garden'){closePanel();go(V(5,0,10));return;}
   if(name==='market')return section('market','Kho & chợ nông sản');
   if(name==='animals')return section('animals','Chuồng vật nuôi');
   if(name==='cook')return section('cook','Bếp nhỏ · học tự chọn');
   if(name==='upgrades')return section('upgrades','Mở rộng nông trại');
   if(name==='seeds'){const p=S.plots.find(p=>!p.locked&&!p.crop);if(p){closePanel();document.querySelector(`#f-plots [data-slot="${p.slot}"]`)?.click();}else say('Vườn đang đầy. Thu hoạch hoặc mở thêm ô đất nhé.');return;}
   if(name==='wardrobe'){openPanel('Góc thay đồ','<p>Chọn màu áo cho nhân vật. Ngoại hình được nhớ trên thiết bị này.</p>'+[[0x7d9ead,'Xanh sương'],[0xc690a8,'Hồng mận'],[0x82a883,'Xanh lá'],[0xd8ac66,'Vàng mật']].map(([v,n])=>`<button class="town-choice" data-shirt="${v}" aria-pressed="${shirt===v}"><span style="display:inline-block;width:20px;height:20px;background:#${v.toString(16)};border-radius:50%;vertical-align:middle;margin-right:12px"></span>${n}</button>`).join(''));return;}
   if(name==='journal'){openPanel('Sổ tay một ngày vui',`<p>Không cần vội. Chăm khu vườn theo cách của bạn.</p><div class="town-letter"><b>Hôm nay ở nông trại</b><p>${S.plots.filter(p=>p.crop).length} ô đang trồng · ${S.plots.filter(p=>p.ready).length} ô chín<br>${(S.animals||[]).length} vật nuôi · ${Object.values(S.storage).flat().reduce((n,i)=>n+i.qty,0)} món trong kho</p></div><button class="town-choice" data-town="seeds">🌱 Gieo một hạt giống</button><button class="town-choice" data-town="animals">🐔 Chăm vật nuôi</button><button class="town-choice" data-town="letter">✉ Một lời nhắn tiếng Anh · tùy thích</button><p>Tên đồ vật có bản dịch ngay bên cạnh. Chỉ mở bếp hoặc lời nhắn khi bạn muốn học thêm; việc học không chặn chăm vườn.</p>`);return;}
   if(name==='letter'){openPanel('Lời nhắn của cô Mây',`<p>Cô Mây đang tưới khu vườn. Cô ấy nhờ bạn một việc nhỏ:</p><div class="town-letter"><b>“Water the flowers, please.”</b><small>Nhấn “Xem nghĩa” nếu cần. Hoạt động này không tính XP.</small></div><button class="town-choice" data-speak="Water the flowers, please.">🔊 Nghe cô Mây nói</button><button class="town-choice" id="town-translate">Xem nghĩa tiếng Việt</button><button class="town-choice" id="town-flower-task">Mang bình tưới ra vườn hoa</button><p id="town-letter-feedback" role="status"></p>`);$('town-translate').onclick=()=>$('town-letter-feedback').textContent='Làm ơn tưới những bông hoa nhé.';$('town-flower-task').onclick=()=>{closePanel();go(V(12,0,17),()=>{E.burst(V(12,1,18),0x89d6dd,24,3);say('Thank you! · Cảm ơn bạn. Vườn hoa thật tươi!');});};return;}
   if(name==='map'){openPanel('Bản đồ thị trấn',`<svg class="town-map" viewBox="0 0 320 160" role="img" aria-label="Phía bắc là nhà và cửa hàng, phía nam là hồ và vườn"><path d="M20 70H300M180 20V140" stroke="#e9d9b9" stroke-width="15"/><rect x="25" y="15" width="65" height="30" rx="6" fill="#ce9e81"/><rect x="110" y="20" width="40" height="25" rx="5" fill="#dfba77"/><rect x="220" y="20" width="60" height="25" rx="5" fill="#acc2a0"/><ellipse cx="65" cy="120" rx="40" ry="23" fill="#82bcb7"/><rect x="210" y="100" width="65" height="35" rx="5" fill="#b18d65"/><circle id="town-map-player" r="5" fill="#eb7558" stroke="white" stroke-width="2"/><text x="35" y="35" font-size="10">Nhà</text><text x="115" y="37" font-size="10">Chợ</text><text x="226" y="36" font-size="10">Chuồng</text><text x="50" y="124" font-size="10">Hồ</text><text x="225" y="122" font-size="10">Ruộng</text></svg><p>Chọn nơi đến; nhân vật sẽ đi theo lối trống.</p>`+[['Nhà mình',-18,-7],['Chợ Mầm Xanh',-12,0],['Vườn rau',5,10],['Chuồng nhỏ',17,4],['Bờ hồ',-14,8]].map(([n,x,z])=>`<button class="town-choice" data-trip="${x},${z}">${n} →</button>`).join(''));return;}
   if(name==='help'){openPanel('Chơi theo nhịp của bạn',`<p><b>Máy tính:</b> WASD / phím mũi tên để đi, E hoặc nút bàn tay để tương tác. Chạm ô đất sẽ đi đến và mở thao tác.</p><p><b>Điện thoại:</b> kéo cần tròn phía trái; chạm đường để tự đi. Nút ↻ xoay góc nhìn, + / − đổi độ gần.</p><p><b>Nông trại:</b> chọn hạt → trồng → tưới tối đa 3 lần → thu hoạch → bán tại chợ. Không có câu hỏi bắt buộc.</p><p><b>Tiếng Anh nhẹ nhàng:</b> tên song ngữ, lời nhắn của cô Mây và bếp tự chọn. Cư dân trong cảnh là NPC, không phải người chơi trực tuyến.</p><p><b>Mất mạng:</b> vẫn có thể đi dạo. Mua bán và chăm cây cần kết nối để máy chủ lưu đúng dữ liệu.</p><button class="town-choice" data-town="list">Mở giao diện danh sách dễ truy cập</button>`);return;}
   if(name==='list'){closePanel();root.classList.toggle('show-list');if(root.classList.contains('show-list'))sections.plots.scrollIntoView({behavior:'smooth'});return;}
 }
 box.addEventListener('click',e=>{const b=e.target.closest('[data-town]');if(b){const a=b.dataset.town;if(a==='rotate')angle+=Math.PI/2;else if(a==='zoom-in')zoom=Math.max(11,zoom-3);else if(a==='zoom-out')zoom=Math.min(32,zoom+3);else if(a==='expand'){box.classList.toggle('is-expanded');document.body.classList.toggle('town-expanded',box.classList.contains('is-expanded'));E.fit();}else show(a);}
   const s=e.target.closest('[data-shirt]');if(s){shirt=Number(s.dataset.shirt);player.userData.torso.material=E.mat(shirt);try{localStorage.setItem('chie-town-look',JSON.stringify({shirt}));}catch{}panelBody.querySelectorAll('[data-shirt]').forEach(b=>b.setAttribute('aria-pressed',String(b===s)));}
   const t=e.target.closest('[data-trip]');if(t){const [x,z]=t.dataset.trip.split(',').map(Number);closePanel();go(V(x,0,z));}
 });
 $('town-journal').onclick=()=>show('journal');
 function focusIsUI(){const t=document.activeElement;return !panel.hidden||document.querySelector('dialog[open]')||t?.matches('input,textarea,select,[contenteditable=true]');}
 function interact(){if(near&&!focusIsUI())go(near.point,near.act);}
 $('town-interact').onclick=interact;
 document.addEventListener('keydown',e=>{if(e.key==='Escape'){closePanel();box.classList.remove('is-expanded');document.body.classList.remove('town-expanded');E.fit();return;}if(focusIsUI())return;if(!box.contains(document.activeElement))return;const k=e.key.toLowerCase();if(['w','a','s','d','arrowup','arrowdown','arrowleft','arrowright','e'].includes(k)){e.preventDefault();keys.add(k);if(k==='e'&&!e.repeat)interact();}});
 document.addEventListener('keyup',e=>keys.delete(e.key.toLowerCase()));
 function resetInput(){keys.clear();stick.set(0,0);$('town-stick').firstElementChild.style.transform='';}
 window.addEventListener('blur',resetInput);document.addEventListener('visibilitychange',resetInput);
 const joystick=$('town-stick');let stickId=null;
 joystick.addEventListener('pointerdown',e=>{stickId=e.pointerId;joystick.setPointerCapture(e.pointerId);path=[];pending=null;e.preventDefault();});
 joystick.addEventListener('pointermove',e=>{if(e.pointerId!==stickId)return;const r=joystick.getBoundingClientRect();stick.set((e.clientX-r.left-r.width/2)/32,(e.clientY-r.top-r.height/2)/32);if(stick.length()>1)stick.normalize();joystick.firstElementChild.style.transform=`translate(${stick.x*23}px,${stick.y*23}px)`;});
 for(const event of ['pointerup','pointercancel','lostpointercapture'])joystick.addEventListener(event,()=>{stickId=null;resetInput();});
 let down=null;
 E.canvas.addEventListener('pointerdown',e=>{down={x:e.clientX,y:e.clientY};E.canvas.focus({preventScroll:true});});
 E.canvas.addEventListener('pointerup',e=>{if(!down||Math.hypot(e.clientX-down.x,e.clientY-down.y)>12)return;down=null;if(!panel.hidden)return;const hit=E.pick(e,targets);if(hit){let o=hit.object;while(o&&!o.userData.interaction)o=o.parent;if(o){go(o.userData.interaction.point,o.userData.interaction.act);return;}}const h=E.pick(e,[ground]);if(h)go(h.point.setY(0));});
 E.canvas.addEventListener('pointercancel',()=>down=null);
 // Updates reuse unchanged scene nodes. No rebuilds on every server poll.
 const colors={wheat:0xe4bc65,carrot:0xf0954b,cabbage:0x89b36b,strawberry:0xda727b,sunflower:0xf6cb61,grape:0x9874a7,rose:0xe998a8,golden_tree:0xefce70};
 function removeTarget(g){const i=targets.indexOf(g);if(i>=0)targets.splice(i,1);scene.remove(g);const dead=[];g.traverse(o=>{if(o.material?.map){o.material.map.dispose();o.material.dispose();o.geometry.dispose();dead.push(o);}});for(const l of dead){const i=labels.indexOf(l);if(i>=0)labels.splice(i,1);}}
 function sync(state){S=state;$('town-coins').textContent=Number(S.wallet.xu).toLocaleString('vi-VN');$('town-level').textContent='Xu · Cấp '+S.wallet.level;
 $('town-goals').innerHTML=`<p>🌱 ${S.plots.filter(p=>p.crop).length} ô đang lớn · ${S.plots.filter(p=>p.ready).length} ô chín</p><p>🐔 ${(S.animals||[]).length} người bạn trong chuồng</p>`;
 const seen=new Set();for(const p of S.plots){seen.add(p.slot);const stage=p.ready?3:p.progress<34?0:p.progress<67?1:2;const sig=JSON.stringify([p.crop,p.locked,p.pest,stage,p.ready]);const old=plotObjects.get(p.slot);if(old?.sig===sig)continue;if(old)removeTarget(old.g);
   const g=new THREE.Group(),x=7+(p.slot%6)*2.25,z=7+Math.floor(p.slot/6)*2.05;g.position.set(x,0,z);scene.add(g);g.add(plotTile(E));
   if(p.crop)for(const [a,b] of [[-.45,-.45],[.45,-.45],[-.45,.45],[.45,.45]]){const c=crop(E,stage,colors[p.crop]||0xeaa45e,p.crop==='wheat'?'long':'round');c.position.set(a,.3,b);g.add(c);}
   const text=p.locked?'＋':p.ready?'✓':p.pest?'!':p.crop?'':'＋';if(text){const l=E.label(text,{w:.65,h:.65,bg:p.ready?'#fbe8a9':'#fff9e7',fg:'#597253',size:52,depthWrite:false});l.position.set(0,p.crop?1.65:.55,0);g.add(l);labels.push(l);}
   destination(g,x,z+1,p.locked?'Mở đất':p.ready?'Thu hoạch':p.crop?'Chăm cây':'Gieo hạt',()=>{const b=p.locked?document.querySelector('#f-plots [data-buy-plot]'):document.querySelector(`#f-plots [data-slot="${p.slot}"]`);if(p.locked){show('upgrades');return;}b?.click();});
   plotObjects.set(p.slot,{g,sig});
 }
 for(const [id,o] of plotObjects)if(!seen.has(id)){removeTarget(o.g);plotObjects.delete(id);}
 const animalSeen=new Set();(S.animals||[]).forEach((a,i)=>{animalSeen.add(a.id);let o=animalObjects.get(a.id);if(!o){const g=place(animal(E,a.kind),14+(i%3)*2.1,-1+Math.floor(i/3)*1.8);o={g};animalObjects.set(a.id,o);destination(g,g.position.x,g.position.z+1.4,a.name,()=>document.querySelector(`#f-animals [data-animal="${a.id}"]`)?.click());}o.g.userData.interaction.name=a.ready?'Lấy sản phẩm':a.hungry?'Cho ăn':a.name;
 });for(const [id,o] of animalObjects)if(!animalSeen.has(id)){removeTarget(o.g);animalObjects.delete(id);}
 }
 document.addEventListener('farm:state',e=>{sync(e.detail);if(navigator.onLine)$('town-status').textContent='● Đã đồng bộ · Nông trại của bạn';});sync(S);
 document.addEventListener('farm:sync-error',()=>{$('town-status').textContent='○ Chưa đồng bộ · Kiểm tra kết nối';});
 document.addEventListener('farm:action',e=>{const {url,result}=e.detail;if(result.is_correct===false)return;if(/harvest|collect/.test(url))E.burst(player.position.clone().add(V(0,1,0)),0xf2cf73,20,4);else if(/water|plant|feed/.test(url))E.burst(player.position.clone().add(V(0,1,0)),0x99d8c0,12,2);});
 function network(){$('town-status').textContent=navigator.onLine?'● Đang kết nối · Có thể đi dạo':'○ Ngoại tuyến · Chỉ đi dạo';}
 window.addEventListener('offline',network);window.addEventListener('online',network);if(!navigator.onLine)network();
 const shadow=E.mesh(new THREE.CircleGeometry(.6,20),0x4f7855,{opacity:.25,cast:false});shadow.rotation.x=-Math.PI/2;scene.add(shadow);
 E.onFrame((dt,t)=>{
   const blocked=focusIsUI();let moving=false;dir.set(0,0,0);
   if(!blocked){let dx=stick.x+(keys.has('d')||keys.has('arrowright')?1:0)-(keys.has('a')||keys.has('arrowleft')?1:0),dz=stick.y+(keys.has('s')||keys.has('arrowdown')?1:0)-(keys.has('w')||keys.has('arrowup')?1:0);
     if(dx||dz){path=[];pending=null;dir.set(dx,0,dz).applyAxisAngle(V(0,1,0),angle);if(dir.length()>1)dir.normalize();}
     else if(path.length){const p=path[0];delta.set(p.x-player.position.x,0,p.z-player.position.z);if(delta.length()<.16){path.shift();}else dir.copy(delta).normalize();}
     if(dir.lengthSq()){const speed=4.2*dt;const nx=player.position.x+dir.x*speed,nz=player.position.z+dir.z*speed;if(!nav.blocked(nx,player.position.z))player.position.x=nx;if(!nav.blocked(player.position.x,nz))player.position.z=nz;player.rotation.y=Math.atan2(dir.x,dir.z);moving=true;}
     if(!path.length&&pending){const fn=pending;pending=null;marker.visible=false;fn();}
   }
   walkTime+=dt*(moving?10:2);const swing=moving&&!E.reduce?Math.sin(walkTime)*.5:0;player.userData.legs.forEach((l,i)=>l.rotation.x=i?swing:-swing);player.userData.arms.forEach((a,i)=>a.rotation.x=i?-swing:swing);player.position.y=moving&&!E.reduce?Math.abs(Math.sin(walkTime))*.06:0;
   shadow.position.set(player.position.x,.08,player.position.z);
   aim.set(player.position.x*.65,0,player.position.z*.65);look.lerp(aim,E.reduce?1:1-Math.exp(-dt*4));
   const distance=zoom*(E.size.w/E.size.h<1?1.18:1);camTarget.set(look.x+Math.sin(angle)*distance*.8,distance*.85,look.z+Math.cos(angle)*distance*.8);camera.position.lerp(camTarget,E.reduce?1:1-Math.exp(-dt*5));camera.lookAt(look);
   for(const l of labels)l.quaternion.copy(camera.quaternion);
   if(!E.reduce){clouds.forEach((c,i)=>c.position.x=-20+i*13+Math.sin(t*.025+i)*1.5);water.position.y=.06+Math.sin(t)*.012;wanderers.forEach((o,i)=>{o.m.rotation.y=Math.sin(t*.4+i)*.2;o.m.userData.arms[0].rotation.x=Math.sin(t+i)*.08;});}
   near=null;let nearest=2.8;for(const obj of targets){const v=obj.userData.interaction,d=player.position.distanceTo(v.point);if(d<nearest){nearest=d;near=v;}}
   $('town-interact').disabled=!near||blocked;const actionLabel=near?near.name:'Tương tác';if(actionLabel!==lastActionLabel){$('town-interact').querySelector('b').textContent=actionLabel;lastActionLabel=actionLabel;}
   if(t-lastMap>1){lastMap=t;const m=$('town-map-player');if(m){m.setAttribute('cx',String(160+player.position.x*5));m.setAttribute('cy',String(65+player.position.z*3));}}
 });
 camera.position.set(3,19,24);camera.lookAt(look);E.start();
 // Restore GPU resources on back/forward-cache navigation by reloading the page.
 window.addEventListener('pageshow',e=>{if(e.persisted)location.reload();});
}
if(box&&root&&use3D())boot().catch(err=>{console.error('Town initialization failed',err);root.classList.remove('has-3d');box.hidden=true;window.CHIE?.toast('Không mở được 3D. Bạn vẫn có thể chăm vườn bằng danh sách bên dưới.','error');});
