/* Reading Escape 3D — Thoát Khỏi Thư Viện. Chạm vào cuốn sách phát sáng để mở câu đố đọc hiểu.
   Giải hết sách trong phòng → cửa mở, camera đi sang phòng tiếp theo. */
import { THREE, createEngine, use3D, fontsReady } from './engine.js';
import { C, book, bookshelf, mascot, animateMascot } from './models.js';

if (use3D()) boot();

function boot() {
  const stage = document.getElementById('g-stage');
  const E = createEngine(stage, { sky: 0x2b1a10, fog: false, label: 'Thư viện bí ẩn 3D', reduceMotion: document.documentElement.getAttribute('data-motion') === 'reduce' });
  const { scene, camera, THREE: T } = E;
  E.hemi.intensity = 0.55; E.sun.intensity = 0.9; E.sun.position.set(3, 8, 6);
  const lamp = new T.PointLight(0xffc878, 18, 14, 1.6); lamp.position.set(0, 4.2, 0); scene.add(lamp);

  const ROOM_W = 10, ROOM_D = 8, ROOM_H = 4.6;
  const ROOM_COLORS = [[0x7a5233, 0x5c3b22], [0x3e5c7a, 0x2b4157], [0x5a3e7a, 0x3f2b57]];
  const room = new T.Group(); scene.add(room);
  const floor = E.mesh(new T.BoxGeometry(ROOM_W, 0.2, ROOM_D), C.woodDark, { receive: true, cast: false, unique: true }); floor.position.y = -0.1; room.add(floor);
  const rug = E.mesh(new T.CylinderGeometry(2.2, 2.2, 0.03, 24), 0xa33b3b, { receive: true, cast: false }); rug.position.y = 0.02; room.add(rug);
  const back = E.mesh(new T.BoxGeometry(ROOM_W, ROOM_H, 0.2), 0x7a5233, { receive: true, cast: false, unique: true }); back.position.set(0, ROOM_H / 2, -ROOM_D / 2); room.add(back);
  const left = E.mesh(new T.BoxGeometry(0.2, ROOM_H, ROOM_D), 0x7a5233, { receive: true, cast: false, unique: true }); left.position.set(-ROOM_W / 2, ROOM_H / 2, 0); room.add(left);
  const right = left.clone(); right.position.x = ROOM_W / 2; room.add(right);
  const shelves = [];
  [[-2.9, -ROOM_D / 2 + 0.35, 0], [-ROOM_W / 2 + 0.35, -0.8, Math.PI / 2], [ROOM_W / 2 - 0.35, -0.8, -Math.PI / 2]].forEach(([x, z, r]) => {
    const s = bookshelf(E, 3.2, 3); s.position.set(x, 0, z); s.rotation.y = r; room.add(s); shelves.push(s);
  });
  const table = new T.Group();
  const top = E.mesh(new T.BoxGeometry(2.2, 0.15, 1.2), C.wood); top.position.y = 0.9; table.add(top);
  const legG = new T.BoxGeometry(0.12, 0.9, 0.12);
  [[-1, -0.5], [1, -0.5], [-1, 0.5], [1, 0.5]].forEach(([x, z]) => { const l = E.mesh(legG, C.woodDark); l.position.set(x, 0.45, z); table.add(l); });
  table.position.set(1.8, 0, 0.6); room.add(table);
  // cửa
  const doorFrame = E.mesh(new T.BoxGeometry(1.8, 3, 0.25), 0x2b1a10); doorFrame.position.set(2.8, 1.5, -ROOM_D / 2 + 0.05); room.add(doorFrame);
  const doorPivot = new T.Group(); doorPivot.position.set(2.05, 0, -ROOM_D / 2 + 0.2); room.add(doorPivot);
  const door = E.mesh(new T.BoxGeometry(1.5, 2.8, 0.12), 0x8b5e34); door.position.set(0.75, 1.4, 0); doorPivot.add(door);
  const knob = E.mesh(new T.SphereGeometry(0.07, 8, 6), C.gold); knob.position.set(1.3, 1.4, 0.1); doorPivot.add(knob);
  const lockLbl = E.label('🔒', { w: 0.7, h: 0.7, size: 70 }); lockLbl.position.set(2.8, 3.35, -ROOM_D / 2 + 0.3); room.add(lockLbl);
  const glow = E.mesh(new T.PlaneGeometry(1.5, 2.8), 0xffd27a, { opacity: 0.0, unique: true, flat: true, cast: false }); glow.material.emissive = new T.Color(0xffc23d); glow.position.set(2.8, 1.4, -ROOM_D / 2 + 0.1); room.add(glow);
  const hero = mascot(E, 0.8); hero.position.set(-0.5, 0, 1.6); room.add(hero);

  camera.position.set(0, 4.6, 7.2); camera.lookAt(0, 1.4, -1.5);
  E.onResize = (w, h) => { const narrow = w / h < 1.2; camera.fov = narrow ? 70 : 58; camera.position.set(0, narrow ? 5 : 4.6, narrow ? 7.8 : 7.2); camera.updateProjectionMatrix(); camera.lookAt(0, 1.3, -1.5); };

  // vị trí sách phát sáng (trên kệ, trên bàn, trên sàn)
  const SPOTS = [[-3.6, 2.35, -3.4], [-2.1, 1.35, -3.4], [-4.5, 1.4, -1.6], [4.5, 2.4, 0.2], [1.3, 1.13, 0.5], [2.3, 1.13, 0.8], [-1.8, 0.3, 1.2], [4.5, 1.4, -1.8]];
  const BOOK_COLORS = [C.blue, C.purple, C.green, 0xd4880f, C.red, 0x0e7c9b];

  let G = null, rooms = [], roomIdx = 0, books = [], open = null, hints = 3, roomStart = 0;
  const pickables = [];

  function buildRooms() {
    const per = Math.max(1, Math.ceil(G.items.length / (G.config.rooms || 3)));
    for (let i = 0; i < G.items.length; i += per) rooms.push(G.items.slice(i, i + per).map(it => G.items.indexOf(it)));
  }
  function paintRoom() {
    const [wall, shade] = ROOM_COLORS[roomIdx % ROOM_COLORS.length];
    back.material.color.set(wall); left.material.color.set(shade); right.material.color.set(shade);
  }
  function enterRoom() {
    books.forEach(b => room.remove(b.g)); books = []; pickables.length = 0;
    paintRoom();
    doorPivot.rotation.y = 0; glow.material.opacity = 0; lockLbl.userData.setText('🔒');
    rooms[roomIdx].forEach((qi, k) => {
      const g = book(E, BOOK_COLORS[k % BOOK_COLORS.length]); const s = SPOTS[k % SPOTS.length];
      g.position.set(s[0], s[1], s[2]); g.rotation.y = s[0] > 4 ? -Math.PI / 2 : s[0] < -4 ? Math.PI / 2 : 0;
      g.userData.qi = qi; g.scale.setScalar(1.35); room.add(g);
      const halo = E.mesh(new T.SphereGeometry(0.62, 12, 10), 0xffe27a, { opacity: 0.32, unique: true, flat: true, cast: false }); halo.material.depthWrite = false; g.add(halo);
      const b = { g, qi, halo, state: G.items[qi].answered ? 'done' : 'glow' };
      books.push(b); pickables.push(g);
    });
    roomStart = Date.now();
    document.getElementById('g-panel').innerHTML = '<div class="card small">' + window.CHIE.icon('book-open') + ' Phòng ' + (roomIdx + 1) + '/' + rooms.length + ': chạm vào ' + books.length + ' cuốn sách phát sáng để giải câu đố. Giải hết thì cửa sẽ mở.</div>';
  }
  function openBook(b) {
    if (open || b.state !== 'glow') return;
    open = b; G.idx = b.qi;
    E.tween(b.g.position, { y: b.g.position.y + 0.4 }, 300, 'back');
    E.tween(b.g.rotation, { y: b.g.rotation.y + Math.PI * 2 }, 500, 'out');
    E.tween(hero.position, { x: Math.max(-3.5, Math.min(3.5, b.g.position.x)), z: Math.min(2, b.g.position.z + 1.6) }, 600, 'inOut');
    const t0 = Date.now();
    G.showQuestion(G.item(), {
      instruction: 'Câu đố trong sách', hint: hints, onHint() { if (hints <= 0) return false; hints--; },
      onPick: i => submit({ choice: i }, i, t0), onOrder: o => submit({ order: o }, null, t0),
    });
    document.getElementById('g-panel').scrollIntoView({ behavior: E.reduce ? 'auto' : 'smooth', block: 'nearest' });
  }
  function submit(resp, chosen, t0) {
    if (!open || G.busy) return;
    const b = open;
    G.answer(resp, Date.now() - t0).then(fb => {
      G.markPanel(fb, chosen);
      b.state = fb.is_correct ? 'key' : 'done';
      b.halo.material.color.set(fb.is_correct ? 0xffc23d : 0x8a93a8); b.halo.material.opacity = fb.is_correct ? 0.4 : 0.1;
      if (fb.is_correct) { E.burst(b.g.getWorldPosition(new T.Vector3()), C.gold, 22, 5); const k = E.label('🔑', { w: 0.6, h: 0.6, size: 60 }); k.position.y = 0.75; b.g.add(k); }
      open = null;
      if (books.every(x => x.state !== 'glow')) unlockDoor();
    }).catch(() => {});
  }
  function unlockDoor() {
    lockLbl.userData.setText('🔓');
    E.tween(doorPivot.rotation, { y: -Math.PI / 1.9 }, 900, 'out');
    E.tween(glow.material, { opacity: 0.85 }, 900, 'out');
    const box = document.getElementById('g-fb') || document.getElementById('g-panel');
    box.insertAdjacentHTML('beforeend', '<button class="btn btn-primary mt-1" id="g-door">' + (roomIdx + 1 < rooms.length ? 'Cửa đã mở — sang phòng tiếp' : 'Thoát khỏi thư viện!') + '</button>');
    document.getElementById('g-door').onclick = () => {
      E.tween(hero.position, { x: 2.8, z: -ROOM_D / 2 + 0.6 }, 700, 'inOut', () => {
        roomIdx++;
        if (roomIdx >= rooms.length) return G.finish('Bạn đã thoát khỏi thư viện!');
        hero.position.set(-0.5, 0, 1.6); enterRoom();
      });
    };
  }

  E.onFrame((dt, t) => {
    books.forEach(b => {
      if (b.state === 'glow') { const s = 1 + (E.reduce ? 0 : Math.sin(t * 3 + b.qi) * 0.12); b.halo.scale.setScalar(s); b.halo.material.opacity = 0.32 + Math.sin(t * 3 + b.qi) * 0.12; }
    });
    lamp.intensity = 18 + Math.sin(t * 7) * 0.6;
    animateMascot(hero, t, 0.5, false);
    if (G && rooms.length) {
      const keys = books.filter(b => b.state === 'key').length, lim = G.config.room_seconds || 0;
      const left = lim ? Math.max(0, lim - Math.round((Date.now() - roomStart) / 1000)) : null;
      G.hud(`<span>Phòng ${roomIdx + 1}/${rooms.length} · 🔑 ${keys}/${books.length}</span><span>💡 ${hints}${left !== null ? ' · ⏳ ' + Math.floor(left / 60) + ':' + String(left % 60).padStart(2, '0') : ''}</span>`);
    }
  });
  E.canvas.addEventListener('pointerup', e => {
    const h = E.pick(e, pickables);
    if (!h) return;
    let o = h.object; while (o && o.userData.qi === undefined) o = o.parent;
    const b = o && books.find(x => x.g === o); if (b) openBook(b);
  });

  E.onResize(E.size.w, E.size.h);
  fontsReady().then(() => E.start());
  window.ChieGame = {
    is3D: true,
    start(game) {
      G = game; hints = G.config.hints != null ? G.config.hints : 3;
      buildRooms(); enterRoom();
      // dùng bàn phím: nút mở sách tiếp theo
      document.getElementById('g-panel').insertAdjacentHTML('afterend', '<button class="btn btn-sm mt-1" id="g-nextbook" type="button">Mở cuốn sách tiếp theo</button>');
      document.getElementById('g-nextbook').onclick = () => { const b = books.find(x => x.state === 'glow'); if (b) openBook(b); };
    },
  };
}
