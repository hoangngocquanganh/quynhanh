/* Sân đấu 3D cho Đấu 1–1: Bé Mầm (bạn) và đối thủ đứng trên hai bục. Trả lời đúng → bắn quả cầu năng lượng. */
import { THREE, createEngine, use3D } from './engine.js';
import { C, mascot, animateMascot, monster, island } from './models.js';

const stage = document.getElementById('g-stage');
if (stage && document.getElementById('duel') && use3D()) boot();

function boot() {
  const E = createEngine(stage, { sky: 0x1e2a55, fogColor: 0x1e2a55, fogNear: 18, fogFar: 40, aspect: 16 / 6, mobileAspect: 16 / 9, label: 'Sân đấu 1–1' });
  const { scene, camera } = E;
  E.hemi.intensity = 0.9;
  const stars = new THREE.BufferGeometry(), sp = [];
  for (let i = 0; i < 300; i++) sp.push((Math.random() - 0.5) * 80, Math.random() * 30 + 4, -15 - Math.random() * 20);
  stars.setAttribute('position', new THREE.Float32BufferAttribute(sp, 3));
  scene.add(new THREE.Points(stars, new THREE.PointsMaterial({ color: 0xffffff, size: 0.15 })));
  const pA = island(E, 1.6, 0x5b8cff); pA.position.set(-3.2, -0.2, 0); scene.add(pA);
  const pB = island(E, 1.6, 0xff6b6b); pB.position.set(3.2, -0.2, 0); scene.add(pB);
  const me = mascot(E, 1); me.position.set(-3.2, 0.3, 0); me.rotation.y = Math.PI / 2.4; scene.add(me);
  let S = JSON.parse(document.getElementById('duel').getAttribute('data-state'));
  let op = null;
  function makeOp() {
    if (op) scene.remove(op);
    if (S.opponent && S.opponent.bot) { op = monster(E, C.purple, 1.1); }
    else { op = mascot(E, 1); op.userData.body.material = E.mat(0xff7eb6); }
    op.position.set(3.2, 0.3, 0); op.rotation.y = -Math.PI / 2.4; op.visible = !!(S.opponent && S.opponent.name); scene.add(op);
  }
  makeOp();
  camera.position.set(0, 3.2, 8.5); camera.lookAt(0, 1, 0);
  E.onResize = (w, h) => { camera.position.z = w / h < 1.3 ? 11 : 8.5; camera.lookAt(0, 1, 0); };
  E.onResize(E.size.w, E.size.h);

  const orbs = [];
  function fire(fromMe) {
    const from = (fromMe ? me : op).position.clone().setY(1.2), to = (fromMe ? op : me).position.clone().setY(1);
    const orb = E.mesh(new THREE.SphereGeometry(0.28, 12, 10), fromMe ? 0x7fb2ff : 0xff8fa3, { emissive: fromMe ? 0x2244aa : 0xaa2244, unique: true });
    orb.position.copy(from); scene.add(orb); orbs.push({ orb, from, to, t: 0, fromMe });
  }
  let jumpMe = 0, jumpOp = 0, lastOp = S.opponent ? S.opponent.correct : 0, end = null;
  document.addEventListener('duel:hit', e => { if (e.detail.me && e.detail.ok) { jumpMe = 1; fire(true); } });
  document.addEventListener('duel:state', e => {
    const prevBot = S.opponent && S.opponent.bot, prevName = S.opponent && S.opponent.name;
    S = e.detail;
    if ((S.opponent && S.opponent.bot) !== prevBot || (S.opponent && S.opponent.name) !== prevName) makeOp();
    if (S.opponent && S.opponent.correct > lastOp) { for (let i = lastOp; i < S.opponent.correct; i++) setTimeout(() => { jumpOp = 1; fire(false); }, (i - lastOp) * 300); lastOp = S.opponent.correct; }
    if (S.status === 'finished') end = S.winner;
  });

  let vMe = 0, yMe = 0, vOp = 0, yOp = 0;
  E.onFrame((dt, t) => {
    [pA, pB].forEach((p, i) => p.position.y = -0.2 + Math.sin(t * 1.5 + i) * 0.08);
    if (jumpMe) { vMe = 6; jumpMe = 0; } if (jumpOp) { vOp = 6; jumpOp = 0; }
    if (end === 'me' && yMe === 0) vMe = 5; if (end === 'opponent' && yOp === 0) vOp = 5;
    vMe -= 16 * dt; yMe = Math.max(0, yMe + vMe * dt); if (!yMe) vMe = Math.max(0, vMe);
    vOp -= 16 * dt; yOp = Math.max(0, yOp + vOp * dt); if (!yOp) vOp = Math.max(0, vOp);
    me.position.y = 0.3 + pA.position.y + 0.2 + yMe; if (op) op.position.y = 0.3 + pB.position.y + 0.2 + yOp;
    animateMascot(me, t, 0.5, false); if (op && op.userData.leaves) animateMascot(op, t, 0.5, false);
    if (end === 'opponent') me.rotation.z = Math.sin(t * 6) * 0.15; if (end === 'me' && op) op.rotation.z = Math.sin(t * 6) * 0.15;
    for (let i = orbs.length - 1; i >= 0; i--) {
      const o = orbs[i]; o.t += dt * 1.8; const k = Math.min(1, o.t);
      o.orb.position.lerpVectors(o.from, o.to, k); o.orb.position.y += Math.sin(k * Math.PI) * 1.2;
      if (k >= 1) { E.burst(o.to, o.fromMe ? 0x7fb2ff : 0xff8fa3, 18, 4); E.shake(0.12, 150); scene.remove(o.orb); o.orb.geometry.dispose(); o.orb.material.dispose(); orbs.splice(i, 1); }
    }
  });
  E.start();
}
