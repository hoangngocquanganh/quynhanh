/* v1.3 — trang /nong-trai: phóng toàn màn hình khung Zoo Garden (Fullscreen API + giả lập cho iPhone). */
(function () {
  var host = document.getElementById('zoo-host');
  var frame = document.getElementById('zoo-frame');
  var btn = document.getElementById('zoo-fs-btn');
  if (!host || !frame) return;
  var nativeFs = function () { return document.fullscreenElement || document.webkitFullscreenElement; };
  function sync() {
    var on = !!nativeFs() || host.classList.contains('is-fs');
    document.body.classList.toggle('zoo-immersive', on);
    if (btn) btn.setAttribute('aria-pressed', on ? 'true' : 'false');
    try { frame.contentWindow && frame.contentWindow.dispatchEvent(new Event('resize')); } catch (e) {}
  }
  function exit() {
    if (nativeFs()) { (document.exitFullscreen || document.webkitExitFullscreen).call(document); }
    host.classList.remove('is-fs');
    sync();
  }
  function enter() {
    var req = host.requestFullscreen || host.webkitRequestFullscreen;
    host.classList.add('is-fs');
    if (req) {
      try {
        var p = req.call(host, { navigationUI: 'hide' });
        if (p && p.then) p.then(function () {
          try { screen.orientation && screen.orientation.lock && screen.orientation.lock('landscape').catch(function () {}); } catch (e) {}
        }).catch(function () {});
      } catch (e) { /* giữ chế độ giả lập */ }
    }
    sync();
    try { frame.focus(); } catch (e) {}
  }
  function toggle() { (nativeFs() || host.classList.contains('is-fs')) ? exit() : enter(); }
  if (btn) btn.addEventListener('click', toggle);
  document.addEventListener('fullscreenchange', function () { if (!nativeFs()) host.classList.remove('is-fs'); sync(); });
  document.addEventListener('webkitfullscreenchange', function () { if (!nativeFs()) host.classList.remove('is-fs'); sync(); });
  window.addEventListener('message', function (e) {
    if (e.origin !== location.origin || !e.data || e.data.type !== 'chie-zoo-fullscreen') return;
    toggle();
  });
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && host.classList.contains('is-fs') && !nativeFs()) exit(); });
  try { frame.focus(); } catch (e) {}
})();
