<?php
/**
 * CHIE NEXT — front controller.
 * Toàn bộ ứng dụng nằm trong một thư mục (ví dụ public_html/chie hoặc public_html),
 * file này nhận mọi request. Thư mục nội bộ đã bị chặn bởi .htaccess.
 */
use Illuminate\Http\Request;

define('LARAVEL_START', microtime(true));

if (version_compare(PHP_VERSION, '8.2.0', '<')) {
    http_response_code(500);
    header('Content-Type: text/html; charset=utf-8');
    echo '<h1>CHIE NEXT cần PHP 8.2 trở lên</h1><p>Phiên bản hiện tại: ' . htmlspecialchars(PHP_VERSION) . '. Hãy chọn PHP 8.2+ trong cPanel → Select PHP Version.</p>';
    exit;
}

if (file_exists($maintenance = __DIR__ . '/storage/framework/maintenance.php')) {
    require $maintenance;
}

// Lần chạy đầu tiên: tạo .env tối thiểu (khóa ứng dụng ngẫu nhiên) để trình cài đặt hoạt động.
if (!file_exists(__DIR__ . '/.env') && file_exists(__DIR__ . '/.env.example')) {
    $env = file_get_contents(__DIR__ . '/.env.example');
    $env = preg_replace('/^APP_KEY=.*$/m', 'APP_KEY=base64:' . base64_encode(random_bytes(32)), $env);
    @file_put_contents(__DIR__ . '/.env', $env, LOCK_EX);
    @chmod(__DIR__ . '/.env', 0640);
}

$runtime = __DIR__;
if (is_file(__DIR__ . '/release-loader.php')) {
    require __DIR__ . '/release-loader.php';
    $apiRequest = str_contains((string) parse_url($_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH), '/api/');
    $runtime = chie_runtime_path(__DIR__, $apiRequest ? ($_SERVER['HTTP_X_CHIE_RELEASE'] ?? null) : null);
}
require $runtime . '/vendor/autoload.php';

/** @var \Illuminate\Foundation\Application $app */
$app = require_once $runtime . '/bootstrap/app.php';

$app->handleRequest(Request::capture());
