<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

/**
 * Dữ liệu nền (idempotent — chạy lại không nhân đôi):
 * môn học, 12 khối lớp, điều khoản terms-1, khung đề luyện, danh mục vật phẩm + hòm Gacha,
 * cây trồng + công thức nấu (từ ZIP + phụ lục yêu cầu), cấu hình 5 game, thế giới phiêu lưu (từ ZIP).
 * Mọi giá/tỉ lệ là GIÁ TRỊ MẶC ĐỊNH, Admin chỉnh được.
 */
class BaseDataSeeder extends Seeder
{
    public function run(): void
    {
        $now = now();
        DB::table('subjects')->updateOrInsert(['code' => 'en'], [
            'name' => 'Tiếng Anh', 'is_published' => true, 'updated_at' => $now, 'created_at' => $now,
            'manifest' => json_encode(['skills' => array_keys(\App\Models\Question::SKILLS), 'question_types' => array_keys(\App\Models\Question::TYPES), 'renderer' => 'text', 'scoring' => 'score_100'], JSON_UNESCAPED_UNICODE),
        ]);
        $subjectId = DB::table('subjects')->where('code', 'en')->value('id');

        $cefr = [1 => 'Pre-A1', 2 => 'Pre-A1', 3 => 'A1', 4 => 'A1', 5 => 'A1', 6 => 'A2', 7 => 'A2', 8 => 'A2', 9 => 'A2', 10 => 'B1', 11 => 'B1', 12 => 'B1'];
        for ($g = 1; $g <= 12; $g++) {
            DB::table('grades')->updateOrInsert(['id' => $g], [
                'subject_id' => $subjectId, 'name' => 'Lớp ' . $g, 'stage' => $g <= 5 ? 'tieu_hoc' : ($g <= 9 ? 'thcs' : 'thpt'),
                'cefr' => $cefr[$g], 'framework_level' => $g <= 2 ? 'Làm quen' : ($g <= 5 ? 'Bậc 1' : ($g <= 9 ? 'Bậc 2' : 'Bậc 3')),
                'is_visible' => true, 'updated_at' => $now, 'created_at' => $now,
            ]);
        }

        $content = file_get_contents(database_path('content/terms-1.md'));
        if (!DB::table('terms_versions')->where('version', 'terms-1')->exists()) {
            DB::table('terms_versions')->insert(['version' => 'terms-1', 'title' => 'Thỏa thuận sử dụng & Tuyên bố miễn trừ trách nhiệm', 'content' => $content,
                'content_sha256' => hash('sha256', $content), 'is_active' => !DB::table('terms_versions')->where('is_active', true)->exists(), 'published_at' => $now, 'created_at' => $now, 'updated_at' => $now]);
        }

        // ---- Khung đề luyện (đề mô phỏng, không phải đề chính thức)
        $bps = [
            ['daily5', 'Daily 5 — Ôn nhanh mỗi ngày', 'daily5', 1, 12, 5, 5, null, 'Ưu tiên câu chưa gặp'],
            ['daily10', 'Daily 10 — Ôn nâng cao', 'daily10', 1, 12, 10, 10, null, null],
            ['quiz15', 'Kiểm tra 15 phút', 'quiz15', 3, 12, 15, 15, ['vocabulary' => 35, 'grammar' => 35, 'reading' => 15, 'communication' => 15], null],
            ['unit20', 'Luyện tổng hợp 20 câu', 'unit20', 3, 12, 20, 20, null, null],
            ['midterm', 'Đề giữa kỳ (mô phỏng)', 'midterm', 3, 12, 30, 45, ['vocabulary' => 30, 'grammar' => 30, 'pronunciation' => 10, 'reading' => 15, 'communication' => 10, 'writing' => 5], null],
            ['final', 'Đề cuối kỳ (mô phỏng)', 'final', 3, 12, 40, 60, ['vocabulary' => 25, 'grammar' => 30, 'pronunciation' => 10, 'reading' => 20, 'communication' => 10, 'writing' => 5], null],
            ['mock10', 'Đề mô phỏng ôn vào lớp 10', 'mock10', 9, 9, 40, 60, ['pronunciation' => 10, 'vocabulary' => 25, 'grammar' => 30, 'communication' => 10, 'reading' => 20, 'writing' => 5], 'Cấu trúc tham khảo, mỗi tỉnh có thể khác'],
            ['mockgrad', 'Đề mô phỏng ôn tốt nghiệp THPT', 'mockgrad', 12, 12, 40, 50, ['vocabulary' => 25, 'grammar' => 30, 'communication' => 10, 'reading' => 30, 'writing' => 5], 'Kiểm tra lại cấu trúc đề công bố của năm thi'],
        ];
        foreach ($bps as $i => [$code, $title, $type, $from, $to, $count, $dur, $mix, $note]) {
            DB::table('exam_blueprints')->updateOrInsert(['code' => $code], ['title' => $title, 'type' => $type, 'grade_from' => $from, 'grade_to' => $to,
                'question_count' => $count, 'duration_min' => $dur, 'skill_mix' => $mix ? json_encode($mix) : null, 'note' => $note, 'is_active' => true, 'sort' => $i,
                'updated_at' => $now, 'created_at' => $now]);
        }

        // ---- Vật phẩm (trang trí/sưu tầm — chỉ thẩm mỹ, không ảnh hưởng điểm học)
        $items = [
            ['plant_pot', 'Chậu cây xanh', 'Potted plant', 'decor', 'common', 80, 1, '🪴', 2], ['wood_chair', 'Ghế gỗ', 'Wooden chair', 'decor', 'common', 90, 1, '🪑', 2],
            ['desk_lamp', 'Đèn bàn', 'Desk lamp', 'decor', 'common', 100, 1, '💡', 2], ['bookshelf', 'Kệ sách', 'Bookshelf', 'decor', 'common', 150, 2, '📚', 3],
            ['wall_clock', 'Đồng hồ treo tường', 'Wall clock', 'decor', 'common', 120, 1, '🕰️', 2], ['teddy', 'Gấu bông', 'Teddy bear', 'decor', 'common', 130, 1, '🧸', 3],
            ['painting', 'Tranh phong cảnh', 'Landscape painting', 'decor', 'common', 140, 2, '🖼️', 3], ['sunflower_vase', 'Bình hoa hướng dương', 'Sunflower vase', 'decor', 'common', 110, 1, '🌻', 2],
            ['fish_tank', 'Bể cá mini', 'Mini fish tank', 'decor', 'rare', 380, 5, '🐠', 6], ['guitar', 'Đàn guitar', 'Guitar', 'decor', 'rare', 420, 5, '🎸', 6],
            ['telescope', 'Kính thiên văn', 'Telescope', 'decor', 'rare', 480, 6, '🔭', 7], ['globe', 'Quả địa cầu', 'Globe', 'decor', 'rare', 350, 4, '🌍', 6],
            ['lantern', 'Đèn ông sao', 'Star lantern', 'decor', 'rare', 300, 3, '🏮', 5],
            ['piano', 'Đàn piano', 'Piano', 'decor', 'epic', 1800, 10, '🎹', 15], ['robot', 'Robot mini', 'Mini robot', 'decor', 'epic', 2200, 12, '🤖', 16],
            ['castle', 'Lâu đài đồ chơi', 'Toy castle', 'decor', 'epic', 2500, 14, '🏰', 18],
            ['frame_leaf', 'Khung ảnh Lá Xanh', 'Green leaf frame', 'avatar_frame', 'common', 150, 2, '🍃', 1], ['frame_star', 'Khung ảnh Sao Vàng', 'Gold star frame', 'avatar_frame', 'rare', 450, 6, '⭐', 2],
            ['title_bookworm', 'Danh hiệu: Mọt Sách Nhí', 'Little Bookworm', 'title', 'common', 200, 3, '📖', 1], ['title_speaker', 'Danh hiệu: Giọng Đọc Vàng', 'Golden Voice', 'title', 'rare', 500, 8, '🎤', 1],
            // chỉ có trong Gacha
            ['g_kite', 'Diều sáo', 'Kite', 'gacha_only', 'common', null, 1, '🪁', 3], ['g_snowglobe', 'Quả cầu tuyết', 'Snow globe', 'gacha_only', 'common', null, 1, '🔮', 3],
            ['g_drum', 'Trống cơm', 'Rice drum', 'gacha_only', 'rare', null, 1, '🥁', 6], ['g_rocket', 'Tên lửa đồ chơi', 'Toy rocket', 'gacha_only', 'rare', null, 1, '🚀', 7],
            ['g_unicorn', 'Kỳ lân pha lê', 'Crystal unicorn', 'gacha_only', 'epic', null, 1, '🦄', 18],
            ['g_dragon', 'Rồng giấy may mắn', 'Lucky paper dragon', 'gacha_only', 'curated', null, 1, '🐉', 40],
        ];
        foreach ($items as [$code, $vi, $en, $cat, $rar, $price, $lvl, $icon, $beauty]) {
            DB::table('shop_items')->updateOrInsert(['code' => $code], ['name_vi' => $vi, 'name_en' => $en, 'category' => $cat, 'rarity' => $rar,
                'price_xu' => $price, 'min_level' => $lvl, 'icon' => $icon, 'beauty' => $beauty, 'is_active' => true, 'updated_at' => $now, 'created_at' => $now]);
        }
        DB::table('gacha_pools')->updateOrInsert(['code' => 'chie-box'], ['name' => 'Hòm CHIE', 'price_xu' => 100, 'daily_limit' => 10, 'pity_threshold' => 200,
            'rates' => json_encode(['common' => 85.0, 'rare' => 12.0, 'epic' => 2.9, 'curated' => 0.1]), 'is_active' => true, 'updated_at' => $now, 'created_at' => $now]);
        $poolId = DB::table('gacha_pools')->where('code', 'chie-box')->value('id');
        foreach (DB::table('shop_items')->whereIn('category', ['decor', 'gacha_only'])->pluck('id') as $itemId) {
            DB::table('gacha_pool_items')->insertOrIgnore(['gacha_pool_id' => $poolId, 'shop_item_id' => $itemId]);
        }

        // ---- Cây trồng: 5 loại từ ZIP (FarmApiController) + phụ lục bảng cây trồng mẫu trong yêu cầu
        $crops = [
            ['wheat', 'Lúa mì', 'Wheat', '🌾', 30, 10, 8, 3, 1, [['wheat', 'lúa mì'], ['bread', 'bánh mì'], ['field', 'cánh đồng']]],
            ['carrot', 'Cà rốt', 'Carrot', '🥕', 60, 12, 10, 3, 1, [['carrot', 'cà rốt'], ['orange', 'màu cam'], ['vegetable', 'rau củ']]],
            ['cabbage', 'Bắp cải', 'Cabbage', '🥬', 120, 15, 14, 3, 2, [['cabbage', 'bắp cải'], ['green', 'màu xanh lá'], ['soup', 'món canh']]],
            ['strawberry', 'Dâu tây', 'Strawberry', '🍓', 240, 30, 25, 3, 3, [['strawberry', 'quả dâu tây'], ['sweet', 'ngọt'], ['red', 'màu đỏ'], ['fruit', 'trái cây']]],
            ['sunflower', 'Hướng dương', 'Sunflower', '🌻', 180, 25, 22, 3, 3, [['sunflower', 'hoa hướng dương'], ['yellow', 'màu vàng'], ['sun', 'mặt trời']]],
            ['grape', 'Nho', 'Grape', '🍇', 480, 60, 45, 3, 5, [['grape', 'quả nho'], ['purple', 'màu tím'], ['juice', 'nước ép']]],
            ['rose', 'Hoa hồng', 'Rose', '🌹', 720, 100, 80, 3, 8, [['rose', 'hoa hồng'], ['beautiful', 'đẹp'], ['gift', 'món quà']]],
            ['golden_tree', 'Cây Vàng', 'Golden Tree', '🌳', 1440, 600, 500, 3, 15, [['golden', 'bằng vàng'], ['rare', 'hiếm'], ['treasure', 'kho báu']]],
        ];
        foreach ($crops as $i => [$code, $vi, $en, $icon, $min, $seed, $sell, $yield, $lvl, $words]) {
            DB::table('farm_crops')->updateOrInsert(['code' => $code], ['name_vi' => $vi, 'name_en' => $en, 'icon' => $icon, 'grow_minutes' => $min, 'seed_price' => $seed,
                'sell_price' => $sell, 'yield' => $yield, 'min_level' => $lvl, 'words' => json_encode($words, JSON_UNESCAPED_UNICODE), 'is_active' => true, 'sort' => $i,
                'updated_at' => $now, 'created_at' => $now]);
        }
        $recipes = [  // 4 công thức từ ZIP (tên "Nước nho không cồn" theo yêu cầu) + 1 bổ sung
            ['strawberry_jam', 'Mứt dâu', 'Strawberry Jam', '🍯', ['strawberry' => 2], 10, 90, 'Boil two strawberries with sugar to make sweet jam.'],
            ['fresh_bread', 'Bánh mì', 'Fresh Bread', '🍞', ['wheat' => 3], 8, 40, 'Mix three handfuls of wheat flour with water, then bake the bread.'],
            ['grape_juice_no_alcohol', 'Nước nho (không cồn)', 'Grape Juice (non-alcoholic)', '🧃', ['grape' => 2], 12, 120, 'Press two bunches of grapes to make fresh juice.'],
            ['sunflower_perfume', 'Nước hoa hướng dương', 'Sunflower Perfume', '🧴', ['sunflower' => 1, 'strawberry' => 1], 15, 70, 'Mix one sunflower and one strawberry to make a sweet perfume.'],
            ['carrot_soup', 'Súp cà rốt', 'Carrot Soup', '🥣', ['carrot' => 2, 'cabbage' => 1], 8, 50, 'Cook two carrots and one cabbage in hot water.'],
            // món dùng sản phẩm vật nuôi (bản 1.1)
            ['fried_egg', 'Trứng ốp la', 'Fried Egg', '🍳', ['egg' => 2], 5, 30, 'Crack two eggs into a hot pan and fry them.'],
            ['strawberry_milkshake', 'Sữa lắc dâu', 'Strawberry Milkshake', '🥤', ['milk' => 1, 'strawberry' => 1], 8, 70, 'Blend one glass of milk with one strawberry.'],
            ['pancake', 'Bánh kếp', 'Pancake', '🥞', ['wheat' => 1, 'egg' => 1, 'milk' => 1], 10, 90, 'Mix one handful of wheat flour, one egg and one glass of milk, then cook the pancake.'],
        ];
        foreach ($recipes as [$code, $vi, $en, $icon, $inputs, $fee, $sell, $text]) {
            DB::table('farm_recipes')->updateOrInsert(['code' => $code], ['name_vi' => $vi, 'name_en' => $en, 'icon' => $icon, 'inputs' => json_encode($inputs),
                'fee_xu' => $fee, 'sell_price' => $sell, 'recipe_en' => $text, 'is_active' => true, 'updated_at' => $now, 'created_at' => $now]);
        }

        // ---- Vật nuôi (bản 1.1): cho ăn = trả lời câu hỏi; có sản phẩm sau thời gian chờ
        $animals = [
            ['chicken', 'Gà mái', 'Hen', '🐔', 150, 1, 'egg', 'Trứng', 'Egg', '🥚', 8, 60, [['hen', 'gà mái'], ['egg', 'quả trứng'], ['feather', 'lông vũ'], ['farm', 'nông trại']]],
            ['sheep', 'Cừu', 'Sheep', '🐑', 400, 3, 'wool', 'Len', 'Wool', '🧶', 20, 240, [['sheep', 'con cừu'], ['wool', 'len'], ['soft', 'mềm'], ['warm', 'ấm áp']]],
            ['cow', 'Bò sữa', 'Cow', '🐄', 500, 4, 'milk', 'Sữa', 'Milk', '🥛', 25, 180, [['cow', 'con bò'], ['milk', 'sữa'], ['grass', 'cỏ'], ['drink', 'uống']]],
        ];
        foreach ($animals as $i => [$code, $vi, $en, $icon, $price, $lvl, $pc, $pvi, $pen, $picon, $psell, $min, $words]) {
            DB::table('farm_animal_kinds')->updateOrInsert(['code' => $code], ['name_vi' => $vi, 'name_en' => $en, 'icon' => $icon, 'price_xu' => $price, 'min_level' => $lvl,
                'product_code' => $pc, 'product_vi' => $pvi, 'product_en' => $pen, 'product_icon' => $picon, 'product_sell' => $psell, 'produce_minutes' => $min,
                'words' => json_encode($words, JSON_UNESCAPED_UNICODE), 'is_active' => true, 'sort' => $i, 'updated_at' => $now, 'created_at' => $now]);
        }

        // ---- Cấu hình 4 game học (Game Studio) — dùng chung ngân hàng câu đã duyệt
        $games = [
            'word_runner' => ['Word Runner: Săn Từ Vựng', ['lanes' => 3, 'hearts' => 3, 'speed_base' => 3.0, 'speed_step' => 0.25, 'question_count' => 20, 'boss_every' => 5, 'hide_vietnamese_challenge' => false]],
            'grammar_tower' => ['Grammar Tower: Thủ Thành Ngữ Pháp', ['waves' => 4, 'enemies_per_wave' => 5, 'castle_hp' => 5, 'enemy_speed' => 0.35, 'question_count' => 20]],
            'voice_island' => ['Voice Island: Đảo Âm Thanh', ['question_count' => 12, 'shadowing_sentences' => 5, 'fall_speed' => 1.0]],
            'reading_escape' => ['Reading Escape: Thoát Khỏi Thư Viện', ['rooms' => 3, 'questions_per_room' => 4, 'hints' => 3, 'room_seconds' => 300]],
        ];
        foreach ($games as $code => [$title, $config]) {
            if (!DB::table('game_configs')->where('game_code', $code)->exists()) {
                DB::table('game_configs')->insert(['game_code' => $code, 'title' => $title, 'enabled' => true, 'config' => json_encode($config), 'version' => 1, 'created_at' => $now, 'updated_at' => $now]);
                DB::table('game_config_versions')->insert(['game_code' => $code, 'version' => 1, 'enabled' => true, 'config' => json_encode($config), 'created_at' => $now]);
            }
        }
    }
}
