<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        // Một số host đã ghi nhận migration trước nhưng chưa có bảng hoặc nhập dữ liệu bị lỗi.
        if (!Schema::hasTable('grammar_topics')) {
            $migration = require __DIR__ . '/2026_10_20_000011_add_grammar_topics.php';
            $migration->up();
        }
        if (!Schema::hasTable('grammar_topics')) throw new RuntimeException('Không tạo được bảng grammar_topics.');
        if (!\Illuminate\Support\Facades\DB::table('subjects')->where('code', 'en')->exists()) return;
        foreach (glob(database_path('content/chie_grammar_*.json')) ?: [] as $path) {
            (new \App\Services\ContentImporter())->run($path);
        }
    }

    public function down(): void
    {
        // Bản vá chỉ bổ sung dữ liệu, không xóa bảng hoặc nội dung đã có.
    }
};
