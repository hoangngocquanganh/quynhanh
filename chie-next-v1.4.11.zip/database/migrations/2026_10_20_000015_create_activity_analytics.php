<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
return new class extends Migration {
    public function up(): void {
        if (Schema::hasTable('activity_analytics')) return;
        Schema::create('activity_analytics', function(Blueprint $t) {
            $t->id(); $t->foreignId('user_id')->constrained()->cascadeOnDelete();
            $t->dateTime('bucket_at'); $t->string('module',20); $t->string('role',20);
            $t->string('country',2)->default(''); $t->string('region',80)->default(''); $t->string('city',80)->default('');
            $t->string('geo_key',64); $t->unsignedInteger('page_views')->default(0);
            $t->dateTime('first_seen_at'); $t->dateTime('last_seen_at');
            $t->unique(['user_id','bucket_at','module','geo_key'],'activity_unique');
            $t->index(['bucket_at','role']); $t->index('last_seen_at'); $t->index(['country','bucket_at']);
        });
    }
    public function down(): void { Schema::dropIfExists('activity_analytics'); }
};
