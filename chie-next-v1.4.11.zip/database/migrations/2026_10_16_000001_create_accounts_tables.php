<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * Tài khoản, vai trò, điều khoản, nhật ký, cấu hình, thông báo.
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::create('users', function (Blueprint $t) {
            $t->id();
            $t->string('name', 60);                         // tên hiển thị (đã lọc)
            $t->string('full_name', 120)->nullable();       // họ tên thật — chỉ admin/giáo viên phụ trách/phụ huynh thấy
            $t->string('username', 40)->nullable()->unique();// đăng nhập cho tài khoản con do phụ huynh tạo
            $t->string('email', 190)->nullable()->unique();
            $t->string('canonical_email', 190)->nullable()->unique();
            $t->string('password');
            $t->enum('role', ['admin', 'teacher', 'parent', 'student'])->index();
            $t->enum('status', ['active', 'suspended'])->default('active')->index();
            $t->enum('teacher_status', ['pending', 'approved', 'rejected'])->nullable()->index();
            $t->unsignedTinyInteger('grade_level')->nullable()->index(); // lớp học liệu của học sinh
            $t->unsignedSmallInteger('birth_year')->nullable();
            $t->foreignId('created_by_parent_id')->nullable()->constrained('users')->nullOnDelete();
            $t->timestamp('email_verified_at')->nullable();
            $t->json('settings')->nullable();               // tts_rate, theme, font_scale, reduced_motion...
            $t->timestamp('last_login_at')->nullable();
            $t->timestamp('grade_changed_at')->nullable();
            $t->rememberToken();
            $t->timestamps();
        });

        Schema::create('password_reset_tokens', function (Blueprint $t) {
            $t->string('email')->primary();
            $t->string('token');
            $t->timestamp('created_at')->nullable();
        });

        Schema::create('email_verifications', function (Blueprint $t) {
            $t->id();
            $t->foreignId('user_id')->constrained()->cascadeOnDelete();
            $t->string('code_hash', 64);
            $t->unsignedTinyInteger('attempts')->default(0);
            $t->timestamp('expires_at')->useCurrent();
            $t->timestamp('used_at')->nullable();
            $t->timestamps();
            $t->index(['user_id', 'used_at']);
        });

        Schema::create('terms_versions', function (Blueprint $t) {
            $t->id();
            $t->string('version', 20)->unique();
            $t->string('title', 190);
            $t->longText('content');
            $t->char('content_sha256', 64);
            $t->boolean('is_active')->default(false)->index();
            $t->timestamp('published_at')->nullable();
            $t->timestamps();
        });

        Schema::create('user_terms_consents', function (Blueprint $t) {
            $t->id();
            $t->foreignId('user_id')->constrained()->cascadeOnDelete();
            $t->string('terms_version', 20);
            $t->char('content_sha256', 64);
            $t->timestamp('accepted_at')->useCurrent();
            $t->char('ip_hash', 64)->nullable();
            $t->string('user_agent', 255)->nullable();
            $t->foreignId('accepted_by_user_id')->nullable()->constrained('users')->nullOnDelete(); // phụ huynh đồng ý thay con
            $t->unique(['user_id', 'terms_version']);
        });

        Schema::create('settings', function (Blueprint $t) {
            $t->string('key', 100)->primary();
            $t->json('value')->nullable();
            $t->foreignId('updated_by')->nullable()->constrained('users')->nullOnDelete();
            $t->timestamps();
        });

        Schema::create('audit_logs', function (Blueprint $t) {
            $t->id();
            $t->foreignId('actor_user_id')->nullable()->constrained('users')->nullOnDelete();
            $t->string('actor_role', 20)->nullable();
            $t->string('action', 80)->index();
            $t->string('target_type', 60)->nullable();
            $t->unsignedBigInteger('target_id')->nullable();
            $t->json('old_values')->nullable();
            $t->json('new_values')->nullable();
            $t->string('note', 255)->nullable();
            $t->char('ip_hash', 64)->nullable();
            $t->timestamp('created_at')->useCurrent()->index();
            $t->index(['target_type', 'target_id']);
        });

        Schema::create('notifications_inbox', function (Blueprint $t) {
            $t->id();
            $t->foreignId('user_id')->constrained()->cascadeOnDelete();
            $t->string('type', 40);
            $t->string('title', 190);
            $t->string('body', 500)->nullable();
            $t->string('url', 255)->nullable();
            $t->timestamp('read_at')->nullable();
            $t->timestamp('created_at')->useCurrent();
            $t->index(['user_id', 'read_at']);
        });

        Schema::create('user_live_status', function (Blueprint $t) {
            $t->foreignId('user_id')->primary()->constrained()->cascadeOnDelete();
            $t->string('module', 30)->nullable();
            $t->string('label', 190)->nullable();
            $t->timestamp('last_seen_at')->nullable()->index();
        });

        Schema::create('word_filters', function (Blueprint $t) {
            $t->id();
            $t->string('term', 80);
            $t->enum('list', ['block', 'allow'])->default('block');
            $t->string('category', 30)->default('tuc_tiu');
            $t->enum('match', ['word', 'substring'])->default('substring');
            $t->timestamps();
            $t->unique(['term', 'list']);
        });

        Schema::create('error_reports', function (Blueprint $t) {
            $t->id();
            $t->foreignId('user_id')->nullable()->constrained()->nullOnDelete();
            $t->string('kind', 30);          // question_report, client_error
            $t->unsignedBigInteger('ref_id')->nullable();
            $t->string('message', 500);
            $t->string('url', 255)->nullable();
            $t->enum('status', ['open', 'resolved'])->default('open')->index();
            $t->timestamps();
        });
    }

    public function down(): void
    {
        foreach (['error_reports', 'word_filters', 'user_live_status', 'notifications_inbox', 'audit_logs', 'settings',
                  'user_terms_consents', 'terms_versions', 'email_verifications', 'password_reset_tokens', 'users'] as $t) {
            Schema::dropIfExists($t);
        }
    }
};
