<?php

use App\Services\StickerService;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/** v1.3.3 — Album sticker học từ vựng (chủ đề gần gũi Việt Nam, chia theo lớp). Chỉ thêm bảng mới. */
return new class extends Migration
{
    public function up(): void
    {
        if (!Schema::hasTable('sticker_packs')) {
            Schema::create('sticker_packs', function (Blueprint $t) {
                $t->id();
                $t->string('code', 60)->unique();
                $t->string('title_vi', 120);
                $t->string('title_en', 120)->nullable();
                $t->string('emoji', 16)->nullable();
                $t->string('color', 20)->default('green');
                $t->string('theme', 30)->default('everyday');
                $t->string('description', 255)->nullable();
                $t->unsignedTinyInteger('grade_from')->default(1);
                $t->unsignedTinyInteger('grade_to')->default(12);
                $t->unsignedSmallInteger('sort')->default(0);
                $t->enum('status', ['draft', 'published', 'archived'])->default('published');
                $t->string('source', 120)->nullable();
                $t->timestamps();
                $t->index(['status', 'grade_from', 'grade_to']);
            });
        }
        if (!Schema::hasTable('stickers')) {
            Schema::create('stickers', function (Blueprint $t) {
                $t->id();
                $t->foreignId('pack_id')->constrained('sticker_packs')->cascadeOnDelete();
                $t->string('code', 140)->unique();
                $t->string('emoji', 16);
                $t->string('word', 120);
                $t->string('ipa', 120)->nullable();
                $t->string('meaning_vi', 190);
                $t->string('example_en', 255)->nullable();
                $t->string('example_vi', 255)->nullable();
                $t->string('note_vi', 255)->nullable();
                $t->unsignedSmallInteger('sort')->default(0);
                $t->boolean('is_active')->default(true);
                $t->timestamps();
            });
        }
        if (!Schema::hasTable('user_stickers')) {
            Schema::create('user_stickers', function (Blueprint $t) {
                $t->id();
                $t->foreignId('user_id')->constrained()->cascadeOnDelete();
                $t->foreignId('sticker_id')->constrained('stickers')->cascadeOnDelete();
                $t->unsignedTinyInteger('level')->default(0);      // 0 chưa có · 1 đồng · 2 bạc · 3 vàng
                $t->unsignedSmallInteger('correct')->default(0);
                $t->unsignedSmallInteger('wrong')->default(0);
                $t->date('last_correct_on')->nullable();
                $t->timestamp('due_at')->nullable();                // cần ôn lại (trả lời sai)
                $t->timestamp('collected_at')->nullable();
                $t->timestamps();
                $t->unique(['user_id', 'sticker_id']);
                $t->index(['user_id', 'due_at']);
            });
        }
        try {
            StickerService::importFile(database_path('content/chie_stickers_v1_3_3.json'));
        } catch (\Throwable $e) {
            report($e);   // Admin nhập lại được ở Admin → Sticker học tập
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('user_stickers');
        Schema::dropIfExists('stickers');
        Schema::dropIfExists('sticker_packs');
    }
};
