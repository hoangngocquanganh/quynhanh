<?php

use App\Services\ContentImporter;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;

/**
 * v1.3 — khi NÂNG CẤP từ 1.2: tự nhập 2 gói mới (Lớp 2 + ôn tập Lớp 7/9/12, khung đề theo lớp).
 * Idempotent, không ghi đè nội dung Admin đã sửa; câu/bài mới ở trạng thái "Chờ duyệt".
 * Cài mới: bảng còn trống ở bước migrate nên bỏ qua — trình cài đặt sẽ nhập gói như mọi gói khác.
 */
return new class extends Migration
{
    public function up(): void
    {
        try {
            if (!DB::table('subjects')->where('code', 'en')->exists()) return;
        } catch (\Throwable $e) {
            return;
        }
        foreach (['chie_supplement_v1_3.json', 'chie_exam_blueprints_v1_3.json'] as $f) {
            $path = database_path('content/' . $f);
            if (!is_file($path)) continue;
            try {
                (new ContentImporter())->run($path);
            } catch (\Throwable $e) {
                report($e);   // không chặn nâng cấp; Admin có thể nhập lại ở Admin → Nhập dữ liệu
            }
        }
    }

    public function down(): void
    {
        // nội dung đã nhập giữ nguyên (Admin quản lý trong mục Học liệu)
    }
};
