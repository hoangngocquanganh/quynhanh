<?php

use Illuminate\Database\Migrations\Migration;
use App\Services\StickerService;

return new class extends Migration
{
    public function up(): void
    {
        if (!StickerService::available()) {
            $original = require __DIR__.'/2026_10_19_000010_add_sticker_tables.php';
            $original->up();
        }
        $path = database_path('content/chie_stickers_v1_3_3.json');
        if (!is_file($path)) throw new RuntimeException('Thiếu gói nội dung Sticker trong bản cập nhật.');
        StickerService::importFile($path);
    }

    public function down(): void
    {
        // Repair only: never remove student albums or existing content.
    }
};
