<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * Học liệu: môn (Subject Manifest), khối lớp, unit, bài, câu hỏi (+phiên bản), từ vựng, bài đọc, khung đề, lượt nhập.
 * Trạng thái nội dung: draft → review → published → archived.
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::create('subjects', function (Blueprint $t) {
            $t->id();
            $t->string('code', 20)->unique();
            $t->string('name', 80);
            $t->json('manifest')->nullable();
            $t->boolean('is_published')->default(false);
            $t->timestamps();
        });

        Schema::create('grades', function (Blueprint $t) {
            $t->unsignedTinyInteger('id')->primary();         // id == số lớp (1..12)
            $t->foreignId('subject_id')->constrained();
            $t->string('name', 30);
            $t->enum('stage', ['tieu_hoc', 'thcs', 'thpt']);
            $t->string('cefr', 10);
            $t->string('framework_level', 30);
            $t->boolean('is_visible')->default(true);         // hiện trong bộ chọn lớp
            $t->timestamps();
        });

        Schema::create('units', function (Blueprint $t) {
            $t->id();
            $t->unsignedTinyInteger('grade_id');
            $t->foreign('grade_id')->references('id')->on('grades');
            $t->unsignedTinyInteger('grade_to')->nullable();   // unit dùng chung cho dải lớp (vd. góc phát âm 3–5)
            $t->unsignedTinyInteger('semester')->default(1);
            $t->unsignedSmallInteger('sort')->default(0);
            $t->string('title_vi', 190);
            $t->string('title_en', 190)->nullable();
            $t->string('kind', 20)->default('core');           // core | focus (chuyên đề phát âm/lỗi thường gặp)
            $t->text('description')->nullable();
            $t->enum('status', ['draft', 'review', 'published', 'archived'])->default('draft')->index();
            $t->string('source', 120)->nullable();
            $t->string('source_key', 120)->nullable()->unique();
            $t->json('flags')->nullable();
            $t->timestamps();
            $t->index(['grade_id', 'status', 'sort']);
        });

        Schema::create('lessons', function (Blueprint $t) {
            $t->id();
            $t->foreignId('unit_id')->constrained()->cascadeOnDelete();
            $t->unsignedSmallInteger('sort')->default(0);
            $t->string('title_vi', 190);
            $t->string('title_en', 190)->nullable();
            $t->enum('lesson_type', ['core', 'review', 'focus'])->default('core');
            $t->unsignedTinyInteger('difficulty')->default(1);
            $t->json('objectives')->nullable();
            $t->json('content')->nullable();   // intro, vocab_ids, examples[], grammar_note, mistakes[]
            $t->boolean('is_public')->default(false);           // khách xem/học thử được
            $t->enum('status', ['draft', 'review', 'published', 'archived'])->default('draft')->index();
            $t->unsignedInteger('version')->default(1);
            $t->string('source', 120)->nullable();
            $t->string('source_key', 120)->nullable()->unique();
            $t->foreignId('created_by')->nullable()->constrained('users')->nullOnDelete();
            $t->foreignId('reviewed_by')->nullable()->constrained('users')->nullOnDelete();
            $t->timestamp('reviewed_at')->nullable();
            $t->timestamps();
            $t->index(['unit_id', 'status', 'sort']);
        });

        Schema::create('questions', function (Blueprint $t) {
            $t->id();
            $t->foreignId('subject_id')->constrained();
            $t->unsignedTinyInteger('grade_id');
            $t->foreign('grade_id')->references('id')->on('grades');
            $t->foreignId('unit_id')->nullable()->constrained()->nullOnDelete();
            $t->string('skill', 20)->index();      // vocabulary, grammar, listening, speaking, reading, writing, pronunciation, communication
            $t->string('type', 20);                // mcq, listen_mcq, word_order, matching, fill_blank, writing, speaking
            $t->unsignedTinyInteger('difficulty')->default(1);
            $t->json('prompt');
            $t->json('options')->nullable();
            $t->json('answer');
            $t->text('explanation_vi')->nullable();
            $t->json('tags')->nullable();
            $t->enum('status', ['draft', 'review', 'published', 'archived'])->default('draft')->index();
            $t->unsignedInteger('version')->default(1);
            $t->char('content_hash', 40)->unique();
            $t->string('source', 120)->nullable();
            $t->string('source_ref', 120)->nullable();
            $t->json('flags')->nullable();
            $t->foreignId('created_by')->nullable()->constrained('users')->nullOnDelete();
            $t->foreignId('reviewed_by')->nullable()->constrained('users')->nullOnDelete();
            $t->timestamp('reviewed_at')->nullable();
            $t->timestamps();
            $t->index(['grade_id', 'status', 'skill']);
        });

        Schema::create('question_versions', function (Blueprint $t) {
            $t->id();
            $t->foreignId('question_id')->constrained()->cascadeOnDelete();
            $t->unsignedInteger('version');
            $t->json('snapshot');
            $t->foreignId('created_by')->nullable()->constrained('users')->nullOnDelete();
            $t->timestamp('created_at')->useCurrent();
            $t->unique(['question_id', 'version']);
        });

        Schema::create('lesson_question', function (Blueprint $t) {
            $t->id();
            $t->foreignId('lesson_id')->constrained()->cascadeOnDelete();
            $t->foreignId('question_id')->constrained()->cascadeOnDelete();
            $t->unsignedSmallInteger('sort')->default(0);
            $t->unique(['lesson_id', 'question_id']);
        });

        Schema::create('lexicon_items', function (Blueprint $t) {
            $t->id();
            $t->foreignId('subject_id')->constrained();
            $t->string('word', 120);
            $t->string('word_key', 120)->unique();
            $t->string('pos', 20)->nullable();            // noun, verb, adj...
            $t->string('ipa_uk', 120)->nullable();
            $t->string('ipa_us', 120)->nullable();
            $t->string('meaning_vi', 190);
            $t->string('example_en', 255)->nullable();
            $t->string('example_vi', 255)->nullable();
            $t->string('emoji', 16)->nullable();
            $t->string('topic', 60)->nullable()->index();
            $t->unsignedTinyInteger('grade_id')->index();  // lớp sớm nhất dùng từ này
            $t->enum('status', ['draft', 'review', 'published', 'archived'])->default('draft')->index();
            $t->string('source', 120)->nullable();
            $t->json('flags')->nullable();
            $t->timestamps();
        });

        Schema::create('reading_passages', function (Blueprint $t) {
            $t->id();
            $t->unsignedTinyInteger('grade_id')->index();
            $t->string('title', 190);
            $t->text('body_en');
            $t->json('glossary')->nullable();
            $t->unsignedSmallInteger('word_count')->default(0);
            $t->enum('status', ['draft', 'review', 'published', 'archived'])->default('draft')->index();
            $t->string('source', 120)->nullable();
            $t->json('flags')->nullable();
            $t->timestamps();
        });

        Schema::create('exam_blueprints', function (Blueprint $t) {
            $t->id();
            $t->string('code', 40)->unique();
            $t->string('title', 190);
            $t->string('type', 20);          // daily5, daily10, unit20, quiz15, midterm, final, mock10, mockgrad, custom
            $t->unsignedTinyInteger('grade_from')->default(1);
            $t->unsignedTinyInteger('grade_to')->default(12);
            $t->unsignedSmallInteger('question_count');
            $t->unsignedSmallInteger('duration_min');
            $t->json('skill_mix')->nullable();      // {"vocabulary":40,"grammar":30,...}
            $t->text('note')->nullable();
            $t->boolean('is_active')->default(true);
            $t->unsignedSmallInteger('sort')->default(0);
            $t->timestamps();
        });

        Schema::create('import_runs', function (Blueprint $t) {
            $t->id();
            $t->string('source', 190);
            $t->char('source_sha256', 64)->nullable();
            $t->foreignId('actor_user_id')->nullable()->constrained('users')->nullOnDelete();
            $t->boolean('dry_run')->default(false);
            $t->json('stats')->nullable();
            $t->longText('report')->nullable();
            $t->timestamp('started_at')->useCurrent();
            $t->timestamp('finished_at')->nullable();
        });

        Schema::create('media_files', function (Blueprint $t) {
            $t->id();
            $t->string('path', 255)->unique();
            $t->string('original_name', 190);
            $t->string('mime', 80);
            $t->unsignedInteger('size');
            $t->char('sha256', 64);
            $t->string('license', 60)->nullable();
            $t->string('license_source', 255)->nullable();
            $t->foreignId('uploaded_by')->nullable()->constrained('users')->nullOnDelete();
            $t->timestamps();
        });
    }

    public function down(): void
    {
        foreach (['media_files', 'import_runs', 'exam_blueprints', 'reading_passages', 'lexicon_items', 'lesson_question',
                  'question_versions', 'questions', 'lessons', 'units', 'grades', 'subjects'] as $t) {
            Schema::dropIfExists($t);
        }
    }
};
