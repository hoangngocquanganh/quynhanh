<?php

use App\Services\ContentImporter;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

/**
 * v1.4 — Ngữ pháp theo chương trình GDPT 2018 (lớp 1–12).
 * grammar_topics: chủ điểm ngữ pháp theo lớp + học kì + mạch (core = theo chương trình, exam10 = ôn thi vào 10, examgrad = ôn thi tốt nghiệp THPT).
 * Câu hỏi nằm trong bảng questions (skill = grammar…), gắn nhãn "gp:<mã chủ điểm>"; difficulty 1–2 = cơ bản, 3+ = nâng cao.
 * Tự nhập gói database/content/chie_grammar_*.json — câu hỏi ở trạng thái "Chờ duyệt".
 */
return new class extends Migration
{
    public function up(): void
    {
        if (!Schema::hasTable('grammar_topics')) {
            Schema::create('grammar_topics', function (Blueprint $t) {
                $t->id();
                $t->string('code', 40)->unique();
                $t->unsignedTinyInteger('grade_id')->index();
                $t->unsignedTinyInteger('semester')->default(1);           // 1 | 2 (mạch ôn thi: 0)
                $t->string('track', 12)->default('core')->index();         // core | exam10 | examgrad
                $t->unsignedSmallInteger('sort')->default(0);
                $t->string('title_vi', 160);
                $t->string('title_en', 160)->nullable();
                $t->string('summary_vi', 255)->nullable();
                $t->json('theory')->nullable();                            // form[], use[], ex[[en,vi]], tip[], err[[sai, đúng, vì sao]]
                $t->enum('status', ['draft', 'review', 'published', 'archived'])->default('published')->index();
                $t->string('source', 120)->nullable();
                $t->timestamps();
                $t->index(['grade_id', 'track', 'semester', 'sort']);
            });
        }

        try {
            if (!DB::table('subjects')->where('code', 'en')->exists()) return;   // cài mới: trình cài đặt tự nhập gói
        } catch (\Throwable $e) {
            return;
        }
        foreach (glob(database_path('content/chie_grammar_*.json')) ?: [] as $path) {
            try {
                (new ContentImporter())->run($path);
            } catch (\Throwable $e) {
                report($e);   // không chặn nâng cấp; Admin có thể nhập lại ở Admin → Nhập dữ liệu
            }
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('grammar_topics');
    }
};
