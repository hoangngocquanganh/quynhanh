<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * Quan hệ: phụ huynh–học sinh (đã xác minh), giáo viên–lớp–học sinh, mã mời.
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::create('guardian_links', function (Blueprint $t) {
            $t->id();
            $t->foreignId('parent_id')->constrained('users')->cascadeOnDelete();
            $t->foreignId('student_id')->constrained('users')->cascadeOnDelete();
            $t->enum('status', ['active', 'revoked'])->default('active')->index();
            $t->enum('verified_via', ['student_code', 'created_by_parent', 'admin']);
            $t->string('relation', 30)->nullable();     // bố, mẹ, người giám hộ...
            $t->timestamp('verified_at')->useCurrent();
            $t->timestamp('revoked_at')->nullable();
            $t->foreignId('revoked_by')->nullable()->constrained('users')->nullOnDelete();
            $t->timestamps();
            $t->unique(['parent_id', 'student_id']);
        });

        // Mã liên kết do HỌC SINH tạo trong tài khoản của mình rồi đưa cho phụ huynh.
        Schema::create('guardian_link_codes', function (Blueprint $t) {
            $t->id();
            $t->foreignId('student_id')->constrained('users')->cascadeOnDelete();
            $t->char('code_hash', 64)->unique();
            $t->timestamp('expires_at')->useCurrent();
            $t->timestamp('used_at')->nullable();
            $t->foreignId('used_by')->nullable()->constrained('users')->nullOnDelete();
            $t->timestamp('revoked_at')->nullable();
            $t->timestamps();
        });

        Schema::create('classrooms', function (Blueprint $t) {
            $t->id();
            $t->string('name', 120);
            $t->unsignedTinyInteger('grade_level')->index();
            $t->string('school_name', 190)->nullable();
            $t->string('school_year', 20)->nullable();
            $t->enum('status', ['active', 'archived'])->default('active')->index();
            $t->enum('join_policy', ['auto', 'approval'])->default('auto');
            $t->foreignId('created_by')->nullable()->constrained('users')->nullOnDelete();
            $t->timestamps();
        });

        Schema::create('classroom_teachers', function (Blueprint $t) {
            $t->id();
            $t->foreignId('classroom_id')->constrained()->cascadeOnDelete();
            $t->foreignId('teacher_id')->constrained('users')->cascadeOnDelete();
            $t->enum('role', ['main', 'assistant'])->default('main');
            $t->timestamp('assigned_at')->useCurrent();
            $t->timestamp('revoked_at')->nullable()->index();
            $t->foreignId('assigned_by')->nullable()->constrained('users')->nullOnDelete();
            $t->index(['teacher_id', 'revoked_at']);
            $t->index(['classroom_id', 'revoked_at']);
        });

        Schema::create('classroom_members', function (Blueprint $t) {
            $t->id();
            $t->foreignId('classroom_id')->constrained()->cascadeOnDelete();
            $t->foreignId('student_id')->constrained('users')->cascadeOnDelete();
            $t->enum('status', ['pending', 'active', 'left', 'removed'])->default('active')->index();
            $t->timestamp('joined_at')->nullable();
            $t->timestamp('left_at')->nullable();
            $t->foreignId('changed_by')->nullable()->constrained('users')->nullOnDelete();
            $t->timestamps();
            $t->unique(['classroom_id', 'student_id']);
            $t->index(['student_id', 'status']);
        });

        Schema::create('class_invites', function (Blueprint $t) {
            $t->id();
            $t->foreignId('classroom_id')->constrained()->cascadeOnDelete();
            $t->string('code', 16)->unique();
            $t->timestamp('expires_at')->useCurrent();
            $t->unsignedInteger('max_uses')->default(50);
            $t->unsignedInteger('uses')->default(0);
            $t->timestamp('revoked_at')->nullable();
            $t->foreignId('created_by')->nullable()->constrained('users')->nullOnDelete();
            $t->timestamps();
        });
    }

    public function down(): void
    {
        foreach (['class_invites', 'classroom_members', 'classroom_teachers', 'classrooms', 'guardian_link_codes', 'guardian_links'] as $t) {
            Schema::dropIfExists($t);
        }
    }
};
