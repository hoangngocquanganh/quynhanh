<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

/**
 * Bản 1.1: vật nuôi nông trại, đấu 1–1, đội trong lớp, thử thách gia đình, nhật ký cập nhật hệ thống.
 */
return new class extends Migration
{
    public function up(): void
    {
        // lượt làm bài loại mới
        DB::statement("ALTER TABLE attempts MODIFY kind ENUM('lesson','exam','review','game','raid','assignment','demo','duel','family') NOT NULL");

        Schema::create('farm_animal_kinds', function (Blueprint $t) {
            $t->id();
            $t->string('code', 30)->unique();
            $t->string('name_vi', 60);
            $t->string('name_en', 60);
            $t->string('icon', 16);
            $t->unsignedInteger('price_xu');
            $t->unsignedSmallInteger('min_level')->default(1);
            $t->string('product_code', 30);
            $t->string('product_vi', 60);
            $t->string('product_en', 60);
            $t->string('product_icon', 16);
            $t->unsignedInteger('product_sell');
            $t->unsignedInteger('produce_minutes');
            $t->json('words')->nullable();          // từ vựng học khi cho ăn
            $t->boolean('is_active')->default(true);
            $t->unsignedSmallInteger('sort')->default(0);
            $t->timestamps();
        });

        Schema::create('farm_animals', function (Blueprint $t) {
            $t->id();
            $t->foreignId('user_id')->constrained()->cascadeOnDelete();
            $t->string('kind', 30);
            $t->string('name', 40)->nullable();
            $t->timestamp('fed_at')->nullable();
            $t->timestamp('ready_at')->nullable();     // có sản phẩm khi đã cho ăn và hết thời gian
            $t->unsignedInteger('collected')->default(0);
            $t->timestamps();
            $t->index('user_id');
        });

        Schema::create('duel_matches', function (Blueprint $t) {
            $t->id();
            $t->foreignId('player_a')->constrained('users')->cascadeOnDelete();
            $t->foreignId('player_b')->nullable()->constrained('users')->cascadeOnDelete();
            $t->enum('mode', ['quick', 'challenge']);
            $t->unsignedTinyInteger('grade_level');
            $t->enum('status', ['waiting', 'active', 'finished', 'cancelled', 'expired'])->default('waiting')->index();
            $t->json('snapshots');                    // cùng một bộ câu (đã xáo) cho cả hai người
            $t->foreignId('attempt_a')->nullable()->constrained('attempts')->nullOnDelete();
            $t->foreignId('attempt_b')->nullable()->constrained('attempts')->nullOnDelete();
            $t->unsignedSmallInteger('score_a')->default(0);
            $t->unsignedSmallInteger('score_b')->default(0);
            $t->foreignId('winner_id')->nullable()->constrained('users')->nullOnDelete();
            $t->timestamp('started_at')->nullable();
            $t->timestamp('ends_at')->nullable();
            $t->timestamp('finished_at')->nullable();
            $t->timestamps();
            $t->index(['mode', 'status', 'grade_level']);
        });

        Schema::create('teams', function (Blueprint $t) {
            $t->id();
            $t->foreignId('classroom_id')->constrained()->cascadeOnDelete();
            $t->string('name', 40);
            $t->string('emoji', 16)->default('⭐');
            $t->unsignedInteger('weekly_goal')->default(500);   // điểm học (XP) mục tiêu mỗi tuần
            $t->foreignId('created_by')->nullable()->constrained('users')->nullOnDelete();
            $t->timestamps();
        });
        Schema::create('team_members', function (Blueprint $t) {
            $t->id();
            $t->foreignId('team_id')->constrained()->cascadeOnDelete();
            $t->foreignId('student_id')->constrained('users')->cascadeOnDelete();
            $t->foreignId('classroom_id')->constrained()->cascadeOnDelete();
            $t->timestamps();
            $t->unique(['classroom_id', 'student_id']);           // mỗi lớp chỉ ở 1 đội
        });

        Schema::create('family_challenges', function (Blueprint $t) {
            $t->id();
            $t->foreignId('parent_id')->constrained('users')->cascadeOnDelete();
            $t->foreignId('student_id')->constrained('users')->cascadeOnDelete();
            $t->string('title', 120);
            $t->unsignedTinyInteger('grade_level');
            $t->json('snapshots');
            $t->foreignId('parent_attempt_id')->nullable()->constrained('attempts')->nullOnDelete();
            $t->foreignId('child_attempt_id')->nullable()->constrained('attempts')->nullOnDelete();
            $t->enum('status', ['open', 'done', 'expired', 'cancelled'])->default('open')->index();
            $t->string('message', 200)->nullable();     // lời nhắn động viên của phụ huynh
            $t->timestamp('expires_at')->useCurrent();
            $t->timestamps();
        });

        Schema::create('app_updates', function (Blueprint $t) {
            $t->id();
            $t->string('version_from', 20);
            $t->string('version_to', 20)->nullable();
            $t->string('file_sha256', 64);
            $t->enum('status', ['checked', 'applied', 'failed', 'rolled_back']);
            $t->json('log')->nullable();
            $t->string('backup_path', 255)->nullable();
            $t->foreignId('actor_user_id')->nullable()->constrained('users')->nullOnDelete();
            $t->timestamps();
        });

        // dữ liệu nền mới của bản 1.1 (chỉ thêm nếu chưa có — không ghi đè chỉnh sửa của Admin)
        $now = now();
        $animals = [
            ['chicken', 'Gà mái', 'Hen', '🐔', 150, 1, 'egg', 'Trứng', 'Egg', '🥚', 8, 60, [['hen', 'gà mái'], ['egg', 'quả trứng'], ['feather', 'lông vũ'], ['farm', 'nông trại']]],
            ['sheep', 'Cừu', 'Sheep', '🐑', 400, 3, 'wool', 'Len', 'Wool', '🧶', 20, 240, [['sheep', 'con cừu'], ['wool', 'len'], ['soft', 'mềm'], ['warm', 'ấm áp']]],
            ['cow', 'Bò sữa', 'Cow', '🐄', 500, 4, 'milk', 'Sữa', 'Milk', '🥛', 25, 180, [['cow', 'con bò'], ['milk', 'sữa'], ['grass', 'cỏ'], ['drink', 'uống']]],
        ];
        foreach ($animals as $i => [$code, $vi, $en, $icon, $price, $lvl, $pc, $pvi, $pen, $picon, $psell, $min, $words]) {
            DB::table('farm_animal_kinds')->insertOrIgnore(['code' => $code, 'name_vi' => $vi, 'name_en' => $en, 'icon' => $icon, 'price_xu' => $price, 'min_level' => $lvl,
                'product_code' => $pc, 'product_vi' => $pvi, 'product_en' => $pen, 'product_icon' => $picon, 'product_sell' => $psell, 'produce_minutes' => $min,
                'words' => json_encode($words, JSON_UNESCAPED_UNICODE), 'is_active' => true, 'sort' => $i, 'created_at' => $now, 'updated_at' => $now]);
        }
        if (Schema::hasTable('farm_recipes')) {
            foreach ([
                ['fried_egg', 'Trứng ốp la', 'Fried Egg', '🍳', ['egg' => 2], 5, 30, 'Crack two eggs into a hot pan and fry them.'],
                ['strawberry_milkshake', 'Sữa lắc dâu', 'Strawberry Milkshake', '🥤', ['milk' => 1, 'strawberry' => 1], 8, 70, 'Blend one glass of milk with one strawberry.'],
                ['pancake', 'Bánh kếp', 'Pancake', '🥞', ['wheat' => 1, 'egg' => 1, 'milk' => 1], 10, 90, 'Mix one handful of wheat flour, one egg and one glass of milk, then cook the pancake.'],
            ] as [$code, $vi, $en, $icon, $inputs, $fee, $sell, $text]) {
                DB::table('farm_recipes')->insertOrIgnore(['code' => $code, 'name_vi' => $vi, 'name_en' => $en, 'icon' => $icon, 'inputs' => json_encode($inputs),
                    'fee_xu' => $fee, 'sell_price' => $sell, 'recipe_en' => $text, 'is_active' => true, 'created_at' => $now, 'updated_at' => $now]);
            }
        }
    }

    public function down(): void
    {
        foreach (['app_updates', 'family_challenges', 'team_members', 'teams', 'duel_matches', 'farm_animals', 'farm_animal_kinds'] as $t) Schema::dropIfExists($t);
        DB::statement("ALTER TABLE attempts MODIFY kind ENUM('lesson','exam','review','game','raid','assignment','demo') NOT NULL");
    }
};
