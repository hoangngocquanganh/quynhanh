<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (Schema::hasTable('user_badges')) return;
        Schema::create('user_badges', function (Blueprint $t) {
            $t->id();
            $t->foreignId('user_id')->constrained()->cascadeOnDelete();
            $t->string('code', 40);
            $t->timestamp('earned_at');
            $t->unique(['user_id', 'code']);
        });
    }

    public function down(): void { Schema::dropIfExists('user_badges'); }
};
