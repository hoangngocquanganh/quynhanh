<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * Một hệ ví duy nhất (wallets + xu_ledger). Vật phẩm, Gacha, đổi đồ, nông trại, cướp trại, thế giới phiêu lưu,
 * cấu hình game có phiên bản.
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::create('wallets', function (Blueprint $t) {
            $t->foreignId('user_id')->primary()->constrained()->cascadeOnDelete();
            $t->unsignedBigInteger('xp')->default(0);
            $t->unsignedSmallInteger('level')->default(1);
            $t->unsignedBigInteger('xu')->default(0);
            $t->unsignedInteger('gacha_pity')->default(0);
            $t->unsignedSmallInteger('streak_days')->default(0);
            $t->date('last_active_date')->nullable();
            $t->timestamps();
        });

        Schema::create('xu_ledger', function (Blueprint $t) {
            $t->id();
            $t->foreignId('user_id')->constrained()->cascadeOnDelete();
            $t->integer('delta_xu')->default(0);
            $t->integer('delta_xp')->default(0);
            $t->unsignedBigInteger('balance_after');
            $t->string('type', 40)->index();       // learn_reward, game_reward, shop_buy, sell_back, gacha_spin, farm_seed...
            $t->string('ref', 120)->nullable();
            $t->string('idempotency_key', 120)->unique();
            $t->json('meta')->nullable();
            $t->foreignId('actor_user_id')->nullable()->constrained('users')->nullOnDelete(); // admin điều chỉnh
            $t->timestamp('created_at')->useCurrent()->index();
            $t->index(['user_id', 'created_at']);
        });

        Schema::create('daily_counters', function (Blueprint $t) {
            $t->id();
            $t->foreignId('user_id')->constrained()->cascadeOnDelete();
            $t->date('day');
            $t->string('key', 60);
            $t->unsignedInteger('value')->default(0);
            $t->unique(['user_id', 'day', 'key']);
        });

        Schema::create('shop_items', function (Blueprint $t) {
            $t->id();
            $t->string('code', 60)->unique();
            $t->string('name_vi', 120);
            $t->string('name_en', 120)->nullable();
            $t->enum('category', ['decor', 'avatar_frame', 'title', 'farm_tool', 'gacha_only']);
            $t->enum('rarity', ['common', 'rare', 'epic', 'curated'])->default('common');
            $t->unsignedInteger('price_xu')->nullable();      // null = không bán trong shop
            $t->unsignedSmallInteger('min_level')->default(1);
            $t->string('icon', 40);                            // mã icon trong sprite / emoji
            $t->string('description', 255)->nullable();
            $t->unsignedSmallInteger('beauty')->default(1);    // điểm độ đẹp khi đặt trong phòng/trại
            $t->boolean('is_active')->default(true);
            $t->timestamp('season_ends_at')->nullable();
            $t->timestamps();
        });

        Schema::create('inventory_items', function (Blueprint $t) {
            $t->id();
            $t->foreignId('user_id')->constrained()->cascadeOnDelete();
            $t->foreignId('shop_item_id')->constrained();
            $t->enum('source', ['shop', 'gacha', 'reward', 'trade', 'admin']);
            $t->unsignedInteger('acquired_price')->default(0);
            $t->timestamp('trade_locked_until')->nullable();
            $t->unsignedTinyInteger('trades_count')->default(0);
            $t->boolean('placed')->default(false);
            $t->smallInteger('pos_x')->nullable();
            $t->smallInteger('pos_y')->nullable();
            $t->timestamps();
            $t->index(['user_id', 'shop_item_id']);
        });

        Schema::create('gacha_pools', function (Blueprint $t) {
            $t->id();
            $t->string('code', 40)->unique();
            $t->string('name', 120);
            $t->unsignedInteger('price_xu')->default(100);
            $t->unsignedSmallInteger('daily_limit')->default(10);
            $t->unsignedSmallInteger('pity_threshold')->default(200);
            $t->json('rates');           // {"common":85,"rare":12,"epic":2.9,"curated":0.1} — tổng 100
            $t->boolean('is_active')->default(true);
            $t->timestamps();
        });

        Schema::create('gacha_pool_items', function (Blueprint $t) {
            $t->id();
            $t->foreignId('gacha_pool_id')->constrained()->cascadeOnDelete();
            $t->foreignId('shop_item_id')->constrained();
            $t->unique(['gacha_pool_id', 'shop_item_id']);
        });

        Schema::create('gacha_logs', function (Blueprint $t) {
            $t->id();
            $t->foreignId('user_id')->constrained()->cascadeOnDelete();
            $t->foreignId('gacha_pool_id')->constrained();
            $t->foreignId('shop_item_id')->constrained();
            $t->foreignId('inventory_item_id')->nullable()->constrained()->nullOnDelete();
            $t->string('rarity', 20);
            $t->boolean('was_pity')->default(false);
            $t->unsignedInteger('roll');
            $t->unsignedInteger('xu_spent');
            $t->string('idempotency_key', 120)->unique();
            $t->timestamp('created_at')->useCurrent();
            $t->index(['user_id', 'created_at']);
        });

        Schema::create('trade_offers', function (Blueprint $t) {
            $t->id();
            $t->foreignId('sender_id')->constrained('users')->cascadeOnDelete();
            $t->foreignId('receiver_id')->constrained('users')->cascadeOnDelete();
            $t->boolean('is_family')->default(false);
            $t->enum('kind', ['decor', 'produce']);
            $t->foreignId('sender_inventory_id')->nullable()->constrained('inventory_items')->nullOnDelete();
            $t->foreignId('receiver_inventory_id')->nullable()->constrained('inventory_items')->nullOnDelete();
            $t->string('sender_produce', 40)->nullable();
            $t->string('receiver_produce', 40)->nullable();
            $t->string('rarity', 20)->nullable();
            $t->enum('status', ['pending', 'accepted', 'declined', 'cancelled', 'expired'])->default('pending')->index();
            $t->timestamp('resolved_at')->nullable();
            $t->timestamps();
            $t->index(['sender_id', 'receiver_id', 'created_at']);
        });

        // ------------------------------------------------------------- Nông trại
        Schema::create('farm_crops', function (Blueprint $t) {
            $t->id();
            $t->string('code', 40)->unique();
            $t->string('name_vi', 80);
            $t->string('name_en', 80);
            $t->string('icon', 16);
            $t->unsignedInteger('grow_minutes');
            $t->unsignedInteger('seed_price');
            $t->unsignedInteger('sell_price');
            $t->unsignedSmallInteger('yield')->default(2);
            $t->unsignedSmallInteger('min_level')->default(1);
            $t->json('words')->nullable();       // từ vựng gắn với cây (học khi gieo)
            $t->boolean('is_active')->default(true);
            $t->unsignedSmallInteger('sort')->default(0);
            $t->timestamps();
        });

        Schema::create('farm_recipes', function (Blueprint $t) {
            $t->id();
            $t->string('code', 40)->unique();
            $t->string('name_vi', 80);
            $t->string('name_en', 80);
            $t->string('icon', 16);
            $t->json('inputs');                  // {"strawberry":2}
            $t->unsignedInteger('fee_xu');
            $t->unsignedInteger('sell_price');
            $t->string('recipe_en', 255);        // công thức đọc bằng tiếng Anh
            $t->boolean('is_active')->default(true);
            $t->timestamps();
        });

        Schema::create('farms', function (Blueprint $t) {
            $t->foreignId('user_id')->primary()->constrained()->cascadeOnDelete();
            $t->string('name', 40)->nullable();
            $t->unsignedTinyInteger('plots_unlocked')->default(6);
            $t->unsignedTinyInteger('wall_level')->default(1);
            $t->unsignedInteger('inner_capacity')->default(20);
            $t->timestamp('shield_until')->nullable();
            $t->timestamp('cold_until')->nullable();
            $t->unsignedInteger('cold_capacity')->default(0);
            $t->unsignedInteger('beauty_score')->default(0);
            $t->timestamps();
        });

        Schema::create('farm_plots', function (Blueprint $t) {
            $t->id();
            $t->foreignId('user_id')->constrained()->cascadeOnDelete();
            $t->unsignedTinyInteger('slot');
            $t->string('crop_code', 40)->nullable();
            $t->timestamp('planted_at')->nullable();
            $t->timestamp('matures_at')->nullable();
            $t->unsignedTinyInteger('boosts')->default(0);
            $t->boolean('has_pest')->default(false);
            $t->timestamps();
            $t->unique(['user_id', 'slot']);
        });

        Schema::create('farm_storage', function (Blueprint $t) {
            $t->id();
            $t->foreignId('user_id')->constrained()->cascadeOnDelete();
            $t->enum('location', ['outer', 'inner', 'cold']);
            $t->string('item_code', 40);
            $t->unsignedInteger('qty')->default(0);
            $t->timestamps();
            $t->unique(['user_id', 'location', 'item_code']);
        });

        Schema::create('farm_raids', function (Blueprint $t) {
            $t->id();
            $t->foreignId('attacker_id')->constrained('users')->cascadeOnDelete();
            $t->foreignId('defender_id')->constrained('users')->cascadeOnDelete();
            $t->foreignId('attempt_id')->nullable()->constrained()->nullOnDelete();
            $t->unsignedTinyInteger('wall_level');
            $t->unsignedInteger('fee_burned');
            $t->enum('status', ['in_progress', 'won', 'lost', 'expired'])->default('in_progress')->index();
            $t->json('loot_taken')->nullable();
            $t->json('loot_received')->nullable();
            $t->json('loot_destroyed')->nullable();
            $t->timestamp('expires_at')->useCurrent();
            $t->timestamp('finished_at')->nullable();
            $t->timestamps();
            $t->index(['defender_id', 'created_at']);
            $t->index(['attacker_id', 'defender_id', 'created_at']);
        });

        Schema::create('farm_daily_losses', function (Blueprint $t) {
            $t->id();
            $t->foreignId('user_id')->constrained()->cascadeOnDelete();
            $t->date('day');
            $t->unsignedInteger('baseline_units');   // tổng Kho Ngoài lúc bị cướp lần đầu trong ngày
            $t->unsignedInteger('lost_units')->default(0);
            $t->unique(['user_id', 'day']);
        });

        // ------------------------------------------------------------- Thế giới phiêu lưu
        Schema::create('worlds', function (Blueprint $t) {
            $t->id();
            $t->string('code', 60)->unique();
            $t->string('title', 120);
            $t->string('description', 255)->nullable();
            $t->boolean('is_active')->default(true);
            $t->unsignedSmallInteger('sort')->default(0);
            $t->timestamps();
        });

        Schema::create('world_levels', function (Blueprint $t) {
            $t->id();
            $t->foreignId('world_id')->constrained()->cascadeOnDelete();
            $t->string('code', 60)->unique();
            $t->string('chapter', 80);
            $t->string('title', 120);
            $t->string('description', 255)->nullable();
            $t->unsignedSmallInteger('sort')->default(0);
            $t->unsignedTinyInteger('difficulty')->default(1);
            $t->enum('mode', ['adventure', 'daily', 'survival', 'boss']);
            $t->unsignedSmallInteger('question_count')->default(10);
            $t->enum('unlock_rule', ['first', 'prev_level', 'always', 'chapter_complete'])->default('prev_level');
            $t->unsignedTinyInteger('pass_score')->default(60);
            $t->boolean('is_active')->default(true);
            $t->timestamps();
        });

        Schema::create('world_progress', function (Blueprint $t) {
            $t->id();
            $t->foreignId('user_id')->constrained()->cascadeOnDelete();
            $t->foreignId('world_level_id')->constrained()->cascadeOnDelete();
            $t->unsignedTinyInteger('grade_level');
            $t->unsignedTinyInteger('best_score')->default(0);
            $t->unsignedTinyInteger('stars')->default(0);
            $t->boolean('passed')->default(false);
            $t->timestamps();
            $t->unique(['user_id', 'world_level_id', 'grade_level']);
        });

        Schema::create('game_configs', function (Blueprint $t) {
            $t->id();
            $t->string('game_code', 30)->unique();
            $t->string('title', 120);
            $t->boolean('enabled')->default(true);
            $t->json('config');
            $t->unsignedInteger('version')->default(1);
            $t->foreignId('updated_by')->nullable()->constrained('users')->nullOnDelete();
            $t->timestamps();
        });

        Schema::create('game_config_versions', function (Blueprint $t) {
            $t->id();
            $t->string('game_code', 30)->index();
            $t->unsignedInteger('version');
            $t->boolean('enabled');
            $t->json('config');
            $t->foreignId('created_by')->nullable()->constrained('users')->nullOnDelete();
            $t->timestamp('created_at')->useCurrent();
            $t->unique(['game_code', 'version']);
        });
    }

    public function down(): void
    {
        foreach (['game_config_versions', 'game_configs', 'world_progress', 'world_levels', 'worlds', 'farm_daily_losses',
                  'farm_raids', 'farm_storage', 'farm_plots', 'farms', 'farm_recipes', 'farm_crops', 'trade_offers',
                  'gacha_logs', 'gacha_pool_items', 'gacha_pools', 'inventory_items', 'shop_items', 'daily_counters',
                  'xu_ledger', 'wallets'] as $t) {
            Schema::dropIfExists($t);
        }
    }
};
