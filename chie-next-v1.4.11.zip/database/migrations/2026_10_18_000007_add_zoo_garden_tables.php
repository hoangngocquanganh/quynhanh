<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * v1.3.0 — Zoo Garden 3D trong Nông trại (/nong-trai).
 * - farms.zoo_save: bản lưu JSON của game (SaveState), zoo_revision, zoo_updated_at.
 * - farms.zoo_pending_energy: Năng lượng ϟ đã mua bằng Xu / được thưởng nhưng game chưa nhận (chống mất khi rớt mạng).
 * - zoo_catalog_overrides: Admin ghi đè tên/giá/thời gian/cấp mở/bật-tắt của mọi cây, thú, cá, vật phẩm, hành tinh.
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::table('farms', function (Blueprint $t) {
            if (!Schema::hasColumn('farms', 'zoo_save')) $t->longText('zoo_save')->nullable();
            if (!Schema::hasColumn('farms', 'zoo_revision')) $t->unsignedInteger('zoo_revision')->default(0);
            if (!Schema::hasColumn('farms', 'zoo_updated_at')) $t->timestamp('zoo_updated_at')->nullable();
            if (!Schema::hasColumn('farms', 'zoo_pending_energy')) $t->unsignedInteger('zoo_pending_energy')->default(0);
        });

        if (!Schema::hasTable('zoo_catalog_overrides')) {
            Schema::create('zoo_catalog_overrides', function (Blueprint $t) {
                $t->id();
                $t->string('category', 24);   // crop | animal | fish | item | planet | service
                $t->string('item_code', 60);
                $t->string('name_vi', 120)->nullable();
                $t->string('name_en', 120)->nullable();
                $t->string('desc_vi', 255)->nullable();
                $t->integer('price_energy')->nullable();
                $t->integer('sell_energy')->nullable();
                $t->integer('min_level')->nullable();
                $t->integer('grow_seconds')->nullable();
                $t->json('extra_json')->nullable();   // {"words":[["radish","củ cải"]]}
                $t->boolean('is_enabled')->default(true);
                $t->unsignedBigInteger('updated_by')->nullable();
                $t->timestamps();
                $t->unique(['category', 'item_code']);
            });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('zoo_catalog_overrides');
        Schema::table('farms', function (Blueprint $t) {
            foreach (['zoo_save', 'zoo_revision', 'zoo_updated_at', 'zoo_pending_energy'] as $c) {
                if (Schema::hasColumn('farms', $c)) $t->dropColumn($c);
            }
        });
    }
};
