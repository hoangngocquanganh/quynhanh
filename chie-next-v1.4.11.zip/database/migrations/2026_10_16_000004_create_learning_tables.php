<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * Lượt làm (attempt) + từng câu (snapshot nội dung tại thời điểm làm), tiến độ, SRS, thống kê kỹ năng,
 * bài giao + bài nộp + chấm. Tách rõ: nội dung học ≠ bài được giao ≠ lượt làm ≠ kết quả chấm ≠ tiến độ tổng hợp.
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::create('assignments', function (Blueprint $t) {
            $t->id();
            $t->foreignId('classroom_id')->constrained()->cascadeOnDelete();
            $t->foreignId('teacher_id')->constrained('users');
            $t->string('title', 190);
            $t->text('instructions')->nullable();
            $t->enum('type', ['lesson', 'practice', 'exam', 'writing', 'speaking']);
            $t->foreignId('lesson_id')->nullable()->constrained()->nullOnDelete();
            $t->foreignId('blueprint_id')->nullable()->constrained('exam_blueprints')->nullOnDelete();
            $t->json('question_ids')->nullable();     // bộ câu cố định giáo viên chọn (practice)
            $t->text('prompt_text')->nullable();      // đề viết/nói
            $t->unsignedTinyInteger('min_score')->default(0);
            $t->enum('target', ['class', 'students'])->default('class');
            $t->timestamp('available_from')->nullable();
            $t->timestamp('due_at')->nullable()->index();
            $t->enum('status', ['published', 'closed'])->default('published')->index();
            $t->timestamps();
        });

        Schema::create('assignment_targets', function (Blueprint $t) {
            $t->id();
            $t->foreignId('assignment_id')->constrained()->cascadeOnDelete();
            $t->foreignId('student_id')->constrained('users')->cascadeOnDelete();
            $t->unique(['assignment_id', 'student_id']);
        });

        Schema::create('attempts', function (Blueprint $t) {
            $t->id();
            $t->foreignId('user_id')->constrained()->cascadeOnDelete();
            $t->enum('kind', ['lesson', 'exam', 'review', 'game', 'raid', 'assignment', 'demo']);
            $t->string('ref_type', 30)->nullable();  // lesson, blueprint, game code, assignment
            $t->unsignedBigInteger('ref_id')->nullable();
            $t->foreignId('assignment_id')->nullable()->constrained()->nullOnDelete();
            $t->unsignedTinyInteger('grade_level');
            $t->enum('status', ['in_progress', 'submitted', 'expired', 'abandoned'])->default('in_progress')->index();
            $t->unsignedBigInteger('seed');
            $t->unsignedSmallInteger('total')->default(0);
            $t->unsignedSmallInteger('answered')->default(0);
            $t->unsignedSmallInteger('correct')->default(0);
            $t->unsignedTinyInteger('score_100')->nullable();
            $t->unsignedSmallInteger('best_streak')->default(0);
            $t->unsignedInteger('xp_awarded')->default(0);
            $t->unsignedInteger('xu_awarded')->default(0);
            $t->boolean('rewarded')->default(false);
            $t->string('title', 190)->nullable();
            $t->json('meta')->nullable();
            $t->string('share_token', 48)->nullable()->unique();
            $t->timestamp('share_revoked_at')->nullable();
            $t->timestamp('started_at')->useCurrent();
            $t->timestamp('expires_at')->nullable();
            $t->timestamp('last_activity_at')->nullable();
            $t->timestamp('submitted_at')->nullable();
            $t->timestamps();
            $t->index(['user_id', 'kind', 'status']);
            $t->index(['user_id', 'ref_type', 'ref_id']);
            $t->index(['grade_level', 'submitted_at']);
        });

        Schema::create('attempt_items', function (Blueprint $t) {
            $t->id();
            $t->foreignId('attempt_id')->constrained()->cascadeOnDelete();
            $t->unsignedSmallInteger('position');
            $t->foreignId('question_id')->nullable()->constrained()->nullOnDelete();
            $t->unsignedInteger('question_version')->default(1);
            $t->string('phase', 20)->default('independent');   // guided | independent
            $t->json('snapshot');        // đề + lựa chọn THEO THỨ TỰ HIỂN THỊ + đáp án + giải thích (không gửi đáp án cho client trước khi trả lời)
            $t->json('response')->nullable();
            $t->boolean('is_correct')->nullable();
            $t->boolean('hint_used')->default(false);
            $t->unsignedInteger('time_ms')->nullable();
            $t->timestamp('answered_at')->nullable();
            $t->unique(['attempt_id', 'position']);
        });

        Schema::create('lesson_progress', function (Blueprint $t) {
            $t->id();
            $t->foreignId('user_id')->constrained()->cascadeOnDelete();
            $t->foreignId('lesson_id')->constrained()->cascadeOnDelete();
            $t->unsignedTinyInteger('grade_level');            // tiến độ mỗi lớp lưu riêng
            $t->enum('status', ['in_progress', 'completed', 'mastered'])->default('in_progress');
            $t->unsignedTinyInteger('best_score')->default(0);
            $t->unsignedSmallInteger('attempts_count')->default(0);
            $t->timestamp('completed_at')->nullable();
            $t->timestamp('last_attempt_at')->nullable();
            $t->timestamps();
            $t->unique(['user_id', 'lesson_id', 'grade_level']);
            $t->index(['user_id', 'grade_level']);
        });

        Schema::create('srs_cards', function (Blueprint $t) {
            $t->id();
            $t->foreignId('user_id')->constrained()->cascadeOnDelete();
            $t->enum('item_type', ['question', 'word']);
            $t->unsignedBigInteger('item_id');
            $t->unsignedTinyInteger('grade_level');
            $t->unsignedTinyInteger('stage')->default(0);      // 0 → +1 ngày, 1 → +3, 2 → +7, 3 → thành thạo
            $t->unsignedSmallInteger('lapses')->default(0);
            $t->timestamp('due_at')->useCurrent()->index();
            $t->timestamp('last_reviewed_at')->nullable();
            $t->boolean('last_correct')->nullable();
            $t->timestamps();
            $t->unique(['user_id', 'item_type', 'item_id']);
            $t->index(['user_id', 'grade_level', 'due_at']);
        });

        Schema::create('skill_stats', function (Blueprint $t) {
            $t->id();
            $t->foreignId('user_id')->constrained()->cascadeOnDelete();
            $t->unsignedTinyInteger('grade_level');
            $t->string('skill', 20);
            $t->string('tag', 40)->default('');
            $t->unsignedInteger('correct')->default(0);
            $t->unsignedInteger('total')->default(0);
            $t->timestamps();
            $t->unique(['user_id', 'grade_level', 'skill', 'tag']);
        });

        Schema::create('assignment_submissions', function (Blueprint $t) {
            $t->id();
            $t->foreignId('assignment_id')->constrained()->cascadeOnDelete();
            $t->foreignId('student_id')->constrained('users')->cascadeOnDelete();
            $t->foreignId('attempt_id')->nullable()->constrained()->nullOnDelete();
            $t->enum('status', ['in_progress', 'submitted', 'graded', 'returned'])->default('in_progress');
            $t->text('text_answer')->nullable();
            $t->string('self_assessment', 30)->nullable();     // bài nói: tự đánh giá
            $t->unsignedTinyInteger('auto_score')->nullable();
            $t->unsignedTinyInteger('teacher_score')->nullable();
            $t->text('feedback')->nullable();
            $t->boolean('share_feedback_with_parent')->default(true);
            $t->foreignId('graded_by')->nullable()->constrained('users')->nullOnDelete();
            $t->timestamp('graded_at')->nullable();
            $t->timestamp('submitted_at')->nullable();
            $t->boolean('is_late')->default(false);
            $t->timestamps();
            $t->unique(['assignment_id', 'student_id']);
        });

        Schema::create('cheat_flags', function (Blueprint $t) {
            $t->id();
            $t->foreignId('user_id')->constrained()->cascadeOnDelete();
            $t->foreignId('attempt_id')->nullable()->constrained()->nullOnDelete();
            $t->string('reason', 120);
            $t->json('details')->nullable();
            $t->enum('status', ['open', 'dismissed', 'confirmed'])->default('open')->index();
            $t->timestamps();
        });
    }

    public function down(): void
    {
        foreach (['cheat_flags', 'assignment_submissions', 'skill_stats', 'srs_cards', 'lesson_progress', 'attempt_items',
                  'attempts', 'assignment_targets', 'assignments'] as $t) {
            Schema::dropIfExists($t);
        }
    }
};
