<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;

/** v1.3.1 — ghi chú khung đề theo lớp dễ hiểu hơn với học sinh (bỏ chữ "module"). */
return new class extends Migration
{
    public function up(): void
    {
        try {
            foreach (DB::table('exam_blueprints')->where('note', 'like', 'Khung đề theo lớp (module grade-%')->get(['id', 'code', 'grade_from']) as $b) {
                $g = (int) $b->grade_from;
                $note = str_ends_with((string) $b->code, '-term') ? "Ôn tập tổng hợp cả học kỳ Lớp {$g}." : "Câu hỏi lấy từ ngân hàng Lớp {$g}, đủ các kỹ năng của lớp.";
                DB::table('exam_blueprints')->where('id', $b->id)->update(['note' => $note, 'updated_at' => now()]);
            }
        } catch (\Throwable $e) {
            report($e);
        }
    }

    public function down(): void {}
};
