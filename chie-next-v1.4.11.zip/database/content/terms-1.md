## Thỏa thuận sử dụng & Tuyên bố miễn trừ trách nhiệm (terms-1)

Chào mừng bạn đến với CHIE NEXT — nền tảng hỗ trợ học tiếng Anh kết hợp trò chơi giáo dục dành cho học sinh Việt Nam. Khi tạo tài khoản và sử dụng CHIE NEXT, bạn (và phụ huynh/người giám hộ nếu bạn dưới 16 tuổi) đồng ý với các điều khoản dưới đây.

### 1. Cung cấp trên nguyên trạng
CHIE NEXT được cung cấp trên cơ sở hiện trạng ("as-is"). Chúng tôi cố gắng duy trì dịch vụ ổn định nhưng không cam kết dịch vụ không bao giờ gián đoạn. Trong phạm vi pháp luật cho phép, chúng tôi được miễn trừ trách nhiệm đối với sự cố khách quan từ nhà cung cấp hosting, đường truyền, bảo trì hoặc sự kiện bất khả kháng.

### 2. Xu, XP và vật phẩm không phải tài sản thật
Xu, XP, cấp độ, vật phẩm, kết quả quay Gacha và nông sản trong CHIE NEXT chỉ là dữ liệu khích lệ học tập nội bộ. Chúng **không phải tiền, không phải tài sản, không quy đổi ra tiền mặt, thẻ cào hay hiện vật** dưới bất kỳ hình thức nào và không thể mua bằng tiền thật. Chủ nền tảng có thể điều chỉnh thông số cân bằng, tỉ lệ, giá Xu, thu hồi vật phẩm phát sinh do lỗi hoặc gian lận, hoặc ngừng một tính năng mà không phát sinh nghĩa vụ bồi thường bằng tiền, trong phạm vi pháp luật cho phép.

### 3. Hành vi bị cấm
Không mua bán tài khoản; không mua bán vật phẩm bằng tiền thật ngoài hệ thống; không chia sẻ mật khẩu; không dùng công cụ gian lận. Mọi giao dịch tự phát ngoài website giữa người dùng với nhau là vi phạm điều khoản, chủ nền tảng không chịu trách nhiệm giải quyết tranh chấp hay bồi hoàn cho các giao dịch này.

### 4. Dữ liệu và sao lưu
Dữ liệu học tập được sao lưu định kỳ. Trong trường hợp hỏng phần cứng máy chủ hoặc tấn công mạng nghiêm trọng vượt ngoài tầm kiểm soát hợp lý, dữ liệu có thể được khôi phục về bản sao lưu gần nhất, không phát sinh trách nhiệm bồi thường thiệt hại gián tiếp, trong phạm vi pháp luật cho phép.

### 5. Trách nhiệm của phụ huynh / người giám hộ
Với người học dưới 16 tuổi, phụ huynh/người giám hộ đứng tên tạo tài khoản hoặc xác nhận liên kết, chịu trách nhiệm hướng dẫn, giám sát thời gian sử dụng thiết bị, sức khỏe thị lực và thể chất của trẻ trong quá trình học và chơi tại gia đình.

### 6. Bản quyền và gỡ bỏ
Học liệu trên CHIE NEXT là tài liệu biên soạn bổ trợ độc lập, **không phải sách giáo khoa chính thức** và không được Bộ GD&ĐT chứng nhận. Nếu phát hiện tài nguyên có dấu hiệu vi phạm bản quyền, vui lòng báo qua email liên hệ của quản trị viên; chúng tôi sẽ tạm gỡ trong vòng 24 giờ để xác minh.

### 7. Quyền riêng tư của trẻ em
CHIE NEXT chỉ thu thập dữ liệu tối thiểu cần cho việc học (tên hiển thị, lớp, kết quả học tập). Bảng xếp hạng chỉ hiển thị tên hiển thị, không hiển thị họ tên thật, email hay số điện thoại. Bản ghi âm luyện nói chỉ nằm trong trình duyệt của bạn và không được tải lên máy chủ. Phụ huynh có thể yêu cầu xem hoặc xóa dữ liệu của con bằng cách liên hệ quản trị viên.

### Giới hạn của miễn trừ
Tuyên bố miễn trừ này không loại bỏ các nghĩa vụ bắt buộc theo pháp luật (bảo vệ dữ liệu cá nhân, an toàn thông tin, trách nhiệm khi có lỗi cố ý). Văn bản cần được luật sư rà soát trước khi chính thức mở cho học sinh.
