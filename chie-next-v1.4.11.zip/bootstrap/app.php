<?php

use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;
use Illuminate\Http\Request;

$app = Application::configure(basePath: dirname(__DIR__))
    ->withRouting(
        web: __DIR__.'/../routes/web.php',
        commands: __DIR__.'/../routes/console.php',
    )
    ->withCommands([__DIR__.'/../app/Console/Commands'])
    ->withMiddleware(function (Middleware $middleware) {
        $middleware->web(prepend: [
            \App\Http\Middleware\EnsureInstalled::class,
        ], append: [
            \App\Http\Middleware\SecurityHeaders::class,
            \App\Http\Middleware\EnforceAccountState::class,
            \App\Http\Middleware\CheckFeature::class,   // v1.4: ma trận phân quyền theo tính năng
            \App\Http\Middleware\RecordActivity::class,
        ]);
        $middleware->alias([
            'role' => \App\Http\Middleware\RequireRole::class,
            'teacher.approved' => \App\Http\Middleware\RequireApprovedTeacher::class,
            'student.grade' => \App\Http\Middleware\RequireStudentGrade::class,
        ]);
        $middleware->redirectGuestsTo(fn (Request $r) => route('login', ['next' => $r->getRequestUri()]));
        $middleware->redirectUsersTo(fn () => route('home'));
        $middleware->trustProxies(at: '*');
    })
    ->withExceptions(function (Exceptions $exceptions) {
        $exceptions->dontReportDuplicates();
        $exceptions->dontReport([\App\Services\DomainError::class, \App\Services\InsufficientXu::class]);
        $exceptions->render(function (\Illuminate\Http\Exceptions\PostTooLargeException $e, Request $request) {
            $msg = 'Tệp gửi lên lớn hơn giới hạn của máy chủ (' . ini_get('post_max_size') . '). Hãy dùng tệp nhỏ hơn hoặc tải qua File Manager.';
            return $request->expectsJson() ? response()->json(['message' => $msg], 413) : back()->with('error', $msg);
        });
        $exceptions->shouldRenderJsonWhen(function (Request $request) {
            return $request->is('api/*') || $request->expectsJson();
        });
        // v1.3.3 — lỗi bất ngờ ở API: trả mã tra cứu; Admin thấy luôn nguyên nhân để chụp gửi hỗ trợ.
        $exceptions->render(function (\Throwable $e, Request $request) {
            if (app()->hasDebugModeEnabled()) return null;
            if ($e instanceof \Symfony\Component\HttpKernel\Exception\HttpExceptionInterface
                || $e instanceof \Illuminate\Validation\ValidationException
                || $e instanceof \Illuminate\Auth\AuthenticationException
                || $e instanceof \Illuminate\Auth\Access\AuthorizationException
                || $e instanceof \Illuminate\Database\Eloquent\ModelNotFoundException
                || $e instanceof \Illuminate\Session\TokenMismatchException
                || $e instanceof \App\Services\DomainError) return null;
            $ref = strtoupper(\Illuminate\Support\Str::random(6));
            \Illuminate\Support\Facades\Log::error('[CHIE-' . $ref . '] ' . $request->method() . ' ' . $request->path() . ' — ' . get_class($e) . ': ' . $e->getMessage(), ['exception' => $e]);
            $msg = 'Máy chủ gặp lỗi khi xử lý (mã ' . $ref . '). Vui lòng thử lại sau ít phút.';
            if (!($request->is('api/*') || $request->expectsJson())) {
                return response()->view('errors.server', ['ref' => $ref], 500);
            }
            try {
                if ($request->user()?->role === 'admin') {
                    $file = str_replace(base_path() . DIRECTORY_SEPARATOR, '', $e->getFile());
                    $msg .= ' Chi tiết cho Admin: ' . class_basename($e) . ': ' . \Illuminate\Support\Str::limit($e->getMessage(), 300) . ' @ ' . $file . ':' . $e->getLine();
                }
            } catch (\Throwable $ignored) {}
            return response()->json(['message' => $msg, 'ref' => $ref], 500);
        });
    })->create();

// Ứng dụng chạy ngay trong thư mục gốc được upload (public_html hoặc public_html/chie):
// thư mục public chính là thư mục gốc; file nội bộ được chặn bằng .htaccess.
if (defined('CHIE_SHARED_ROOT')) {
    $app->useStoragePath(CHIE_SHARED_ROOT . '/storage');
    $app->useEnvironmentPath(CHIE_SHARED_ROOT);
    $app->usePublicPath(CHIE_SHARED_ROOT);
} else {
    $app->usePublicPath($app->basePath());
}

return $app;
